package in.gov.gem.app.incident.domain.entity;
import in.gov.gem.app.service.core.entity.BaseEntity;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.GenericGenerator;
import java.util.UUID;
@Entity
@Table(name = "incident_attachment")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class IncidentAttachmentEntity extends BaseEntity {
    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(name = "attachment_pk", updatable = false, nullable = false)
    private UUID attachmentPk;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "doc_master_fk", nullable = false)
    private IncidentDocMasterEntity incidentDocMasterFk;
    @Column(name = "file_name")
    private String fileName;
    @Column(name = "file_type_lookup")
    private String fileTypeLookup;
    @Column(name = "file_path")
    private String filePath;
    @Column(name = "file_size")
    private Long fileSize;
    @Column(name = "uploaded_by_type_lookup")
    private String uploadedByTypeLookup;
    @Column(name = "uploaded_by_id")
    private String uploadedById;
    @Column(name = "status_lookup")
    private String statusLookup;
}