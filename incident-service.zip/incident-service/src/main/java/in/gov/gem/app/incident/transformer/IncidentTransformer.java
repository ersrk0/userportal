package in.gov.gem.app.incident.transformer;

import in.gov.gem.app.incident.domain.entity.*;
import in.gov.gem.app.incident.request.*;
import in.gov.gem.app.incident.response.*;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Component
public class IncidentTransformer {

    // Transform IncidentRequestDTO to IncidentMasterEntity
    public IncidentResponseDTO saveIncident(UUID incidentId, String acceptLanguage, IncidentRequestDTO dto) {
        if (dto == null || incidentId == null || incidentId == null) {
            throw new IllegalArgumentException("Invalid input: IncidentRequestDTO, incidentPk, or incidentId is null");
        }
        return IncidentResponseDTO.builder()

                .incidentTypeLookup(dto.getIncidentTypeLookup())
                .moduleCode(dto.getModuleCode())
                .raisedByTypeLookup(dto.getRaisedByTypeLookup())
                .raisedById(dto.getRaisedById())
                .raisedByRoleLookup(dto.getRaisedByRoleLookup())
                .raisedAgainstTypeLookup(dto.getRaisedAgainstTypeLookup())
                .raisedAgainstRoleLookup(dto.getRaisedAgainstRoleLookup())
                .incidentReasonLookup(dto.getIncidentReasonLookup())
                .issueTypeLookup(dto.getIssueTypeLookup())
                .incidentTitle(dto.getIncidentTitle())
                .incidentDescription(dto.getIncidentDescription())
                .statusLookup(dto.getStatusLookup())
                .severityLookup(dto.getSeverityLookup())
                .build();
    }

    // Transform IncidentDocMasterDTO to IncidentDocMasterEntity
    public static IncidentDocMasterEntity toDocMasterEntity(IncidentDocMasterDTO dto, UUID incidentPk) {
        if (dto == null || incidentPk == null) {
            throw new IllegalArgumentException("Invalid input: IncidentDocMasterDTO or incidentPk is null");
        }
        return IncidentDocMasterEntity.builder()

                .docId(dto.getDocId())
                .attachments(toAttachmentEntities(dto.getAttachments(), incidentPk)) // Transform child attachments
                .build();
    }

    // Transform AttachmentDTO to AttachmentEntity
    public  static List<IncidentAttachmentEntity> toAttachmentEntities(List<AttachmentDTO> dtos, UUID incidentPk) {
        if (dtos == null || incidentPk == null) {
            throw new IllegalArgumentException("Invalid input: AttachmentDTO list or incidentPk is null");
        }
        return dtos.stream()
                .map(dto -> IncidentAttachmentEntity.builder()
                         .fileName(dto.getFileName())
                        .filePath(dto.getFilePath() != null ? dto.getFilePath().getOriginalFilename() : null)
                        .fileSize(dto.getFileSize())
                        .fileTypeLookup(dto.getFileTypeLookup())
                        .uploadedByTypeLookup(dto.getUploadedByTypeLookup())
                        .uploadedById(dto.getUploadedById())
                        .statusLookup(dto.getStatusLookup())
                        .build())
                .collect(Collectors.toList());
    }

    // Transform PostContractDataDTO to PostContractIncidentEntity
    public static List<PostContractDataResponseDTO> toPostContractEntities(List<PostContractDataDTO> dtos, UUID incidentPk) {
        if (dtos == null || incidentPk == null) {
            throw new IllegalArgumentException("Invalid input: PostContractDataDTO list or incidentPk is null");
        }
        return dtos.stream()
                .map(dto -> PostContractDataResponseDTO.builder()

                        .auctionId(dto.getAuctionId())
                        .bidId(dto.getBidId())
                        .orderId(dto.getOrderId())
                        .productId(dto.getProductId())
                        .contractNo(dto.getContractNo())
                        .invoiceId(dto.getInvoiceId())
                        .panNo(dto.getPanNo())
                        .isDebarred(dto.getIsDebarred())
                        //.debarmentDetails(toDebarmentEntities(dto.getDebarmentDetail(), incidentPk)) // Transform child debarment details
                        .build())
                .collect(Collectors.toList());
    }

    // Transform DebarmentDetailDTO to DebarmentDetailEntity
    public static List<DebarmentDetailResponseDTO> toDebarmentEntities(List<DebarmentDetailDTO> dtos, UUID postContractPk) {
        if (dtos == null || postContractPk == null) {
            throw new IllegalArgumentException("Invalid input: DebarmentDetailDTO list or postContractPk is null");
        }
        return dtos.stream()
                .map(dto -> DebarmentDetailResponseDTO.builder()
                        .debarmentPk(UUID.randomUUID())
                        .debarmentClauseLookup(dto.getDebarmentClauseLookup())
                        .debarmentStartDate(dto.getDebarmentStartDate())
                        .debarmentEndDate(dto.getDebarmentEndDate())
                        .competentAuthorityName(dto.getCompetentAuthorityName())
                        .competentAuthorityDesignation(dto.getCompetentAuthorityDesignation())
                        .build())
                .collect(Collectors.toList());
    }

    // Transform PreContractDataDTO to PreContractIncidentEntity
    public static List<PreContractDataResponseDTO> toPreContractEntities(List<PreContractDataDTO> dtos, UUID incidentPk) {
        if (dtos == null || incidentPk == null) {
            throw new IllegalArgumentException("Invalid input: PreContractDataDTO list or incidentPk is null");
        }
        return dtos.stream()
                .map(dto -> PreContractDataResponseDTO.builder()

                        .traderId(dto.getTraderId())
                        .categoryCode(dto.getCategoryCode())
                        .productId(dto.getProductId())
                        .catalogId(dto.getCatalogId())
                        .compId(dto.getCompId())
                        .skuId(dto.getSkuId())
                        .brandId(dto.getBrandId())
                        .serviceId(dto.getServiceId())
                        .build())
                .collect(Collectors.toList());
    }

    // Transform IncidentStatusLogDTO to IncidentStatusLogEntity
    public static List<IncidentStatusLogResponseDTO> toStatusLogEntities(List<IncidentStatusLogDTO> dtos, UUID incidentPk) {
        if (dtos == null || incidentPk == null) {
            throw new IllegalArgumentException("Invalid input: IncidentStatusLogDTO list or incidentPk is null");
        }
        return dtos.stream()
                .map(dto -> IncidentStatusLogResponseDTO.builder()

                        .actionTypeLookup(dto.getActionTypeLookup())
                        .previousStatusLookup(dto.getPreviousStatusLookup())
                        .currentStatusLookup(dto.getCurrentStatusLookup())
                        .actionByTypeLookup(dto.getActionByTypeLookup())
                        .actionById(dto.getActionById())
                        .remarks(dto.getRemarks())
                        .build())
                .collect(Collectors.toList());
    }

    // Transform IncidentRequestDTO to IncidentResponseDTO
    public static IncidentResponseDTO toResponseDTO(String incidentId, String title, String description) {
        if (incidentId == null || title == null || description == null) {
            throw new IllegalArgumentException("Invalid input: incidentId, title, or description is null");
        }
        return IncidentResponseDTO.builder()
                .incidentId(incidentId)
               // .name(title)
                //.description("Incident for " + title + " has been created successfully.")
                .build();
    }


}