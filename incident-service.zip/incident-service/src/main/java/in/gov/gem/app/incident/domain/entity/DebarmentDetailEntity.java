package in.gov.gem.app.incident.domain.entity;
import in.gov.gem.app.service.core.entity.BaseEntity;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.GenericGenerator;

import java.util.Date;
import java.util.UUID;
@Entity
@Table(name = "debarment_detail")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DebarmentDetailEntity extends BaseEntity {
    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(name = "debarment_pk", updatable = false, nullable = false)
    private UUID debarmentPk;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "post_contract_pk", nullable = false)
    private PostContractIncidentEntity postContractPk;
    @Column(name = "debarment_clause_lookup")
    private String debarmentClauseLookup;
    @Column(name = "debarment_start_date")
    private Date debarmentStartDate;
    @Column(name = "debarment_end_date")
    private Date debarmentEndDate;
    @Column(name = "competent_authority_name")
    private String competentAuthorityName;
    @Column(name = "competent_authority_designation")
    private String competentAuthorityDesignation;
}