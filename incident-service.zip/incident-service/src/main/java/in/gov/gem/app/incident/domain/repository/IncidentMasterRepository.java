package in.gov.gem.app.incident.domain.repository;

import in.gov.gem.app.incident.domain.entity.IncidentMasterEntity;
import in.gov.gem.app.service.core.repository.BaseRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.util.UUID;
@Repository
public interface IncidentMasterRepository extends BaseRepository<IncidentMasterEntity, UUID> {
    boolean existsByIncidentId(String incidentId);
    @Query(value = "SELECT nextval('incident_master')", nativeQuery = true)
    Long getNextSequenceValue();
}