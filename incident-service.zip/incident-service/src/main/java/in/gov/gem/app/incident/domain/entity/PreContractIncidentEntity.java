package in.gov.gem.app.incident.domain.entity;
import in.gov.gem.app.service.core.entity.BaseEntity;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.GenericGenerator;
import java.util.UUID;
@Entity
@Table(name = "pre_contract_incident")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PreContractIncidentEntity extends BaseEntity {
    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(name = "pre_contract_pk", updatable = false, nullable = false)
    private UUID preContractPk;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "incident_pk", nullable = false)
    private IncidentMasterEntity incidentPk;
    @Column(name = "trader_id")
    private String traderId;
    @Column(name = "category_code")
    private UUID categoryCode;
    @Column(name = "product_id")
    private String productId;
    @Column(name = "catalog_id")
    private String catalogId;
    @Column(name = "comp_id")
    private String compId;
    @Column(name = "sku_id")
    private String skuId;
    @Column(name = "brand_id")
    private String brandId;
    @Column(name = "service_id")
    private String serviceId;
}