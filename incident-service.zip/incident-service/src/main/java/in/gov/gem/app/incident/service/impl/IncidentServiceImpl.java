package in.gov.gem.app.incident.service.impl;


import in.gov.gem.app.exception.generic.InvalidInputException;
import in.gov.gem.app.incident.domain.entity.IncidentMasterEntity;
import in.gov.gem.app.incident.domain.entity.PreContractIncidentEntity;
import in.gov.gem.app.incident.domain.repository.*;
import in.gov.gem.app.incident.request.IncidentRequestDTO;
import in.gov.gem.app.incident.response.IncidentResponseDTO;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

import static org.apache.kafka.common.requests.DeleteAclsResponse.log;

@Service
public class IncidentServiceImpl {

    private final IncidentMasterRepository incidentMasterRepository;
    private final PreContractIncidentRepository preContractIncidentRepository;
    private final PostContractIncidentRepository postContractIncidentRepository;
    private final IncidentDocMasterRepository incidentDocMasterRepository;
    private final IncidentStatusLogRepository incidentStatusLogRepository;
    private final DebarmentDetailRepository debarmentDetailRepository;
    private final IncidentAttachmentRepository incidentTransformer;



    @Transactional
    @Override
    public IncidentResponseDTO saveIncident(UUID incidentPk, String acceptLanguage, IncidentRequestDTO incidentRequestDTO) {
        if (incidentRequestDTO == null) {
            throw new IllegalArgumentException("IncidentRequestDTO cannot be null");
        }

        // Generate or validate incidentId


            log.info("Processing primary user registered event for given tenantId");
            SecondarySeller primarySeller = findPrimaryUserOfOrganisation(tenantId, sellerDivision);
            if(primarySeller!=null){
                throw new InvalidInputException(HttpStatus.BAD_REQUEST.getReasonPhrase(),
                        messageUtility.getMessage(MessageConstants.PRIMARY_USER_ALREADY_EXISTS));
            }
            SecondaryUserInfoResponse umsProfile = getUserInfo(profileFk);
            SecondarySeller secondarySeller = buildSecondarySeller(
                    tenantId,
                    umsProfile.getEmailId(),
                    umsProfile.getAadhaarMobileNumber(),
                    profileFk,
                    gemPvtOrgId,
                    profileFk,
                    getLookup(LookupConstants.INVITE_TYPE_SINGLE),
                    getLookup(LookupConstants.STATUS_ACTIVE)
            );
            secondarySellerRepository.save(secondarySeller);
            SecondarySellerRoleDivision roleDivision = buildSecondarySellerRoleDivision(
                    secondarySeller,
                    sellerDivision,
                    primaryUserRoleCode,
                    getLookup(LookupConstants.STATUS_ACTIVE)
            );
            secondarySellerRoleDivisionRepository.save(roleDivision);
            return secondarySeller;
        }
}