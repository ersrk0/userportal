package in.gov.gem.app.incident.service.impl;

import in.gov.gem.app.incident.service.IDocumentService;
import in.gov.gem.app.utility.CustomLoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.stereotype.Service;
import in.gov.gem.app.service.attachment.utility.S3AttachmentUtility;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

/**
 * The type Document service.
 */
@Service
public class DocumentService implements IDocumentService {

    @Value("${AWS_S3.BUCKET_NAME}")
    private String bucketName;

    private final S3AttachmentUtility s3AttachmentUtility;
    private final CustomLoggerFactory log = CustomLoggerFactory.getLogger(this.getClass());

    /**
     * Instantiates a new Document service.
     *
     * @param s3AttachmentUtility the s 3 attachment utility
     */
    public DocumentService(S3AttachmentUtility s3AttachmentUtility) {
        this.s3AttachmentUtility = s3AttachmentUtility;
    }

    /**
     * Upload bulk document string.
     *
     * @param file the file
     * @return the string
     * @throws IOException the io exception
     */
    @Override
    public String uploadBulkDocument(MultipartFile file) throws IOException {
        log.info("Uploading bulk document: {}", file.getOriginalFilename());
        String fileName = file.getOriginalFilename();
        String filePath = getFilePathForBulkInvite() + fileName;
        s3AttachmentUtility.uploadMultipart(bucketName, filePath, file);
        log.info("Uploaded bulk document to S3");
        return filePath;
    }

    private String getFilePathForBulkInvite() {
        return "bulk-documents/";
    }

    private String getFilePathForErroneousFile() {
        return "error-documents/";
    }

    /**
     * Upload errone document string.
     *
     * @param file the file
     * @return the string
     */
    @Override
    public String uploadErroneDocument(ByteArrayResource file) {
        log.info("Uploading erroneous document");
        String fileName = "erroneous-file-" + System.currentTimeMillis() + ".xlsx";
        String filePath = getFilePathForBulkInvite() + fileName;
        s3AttachmentUtility.uploadMultipart(bucketName, filePath, file);
        log.info("Uploaded erroneous document to S3");
        return filePath;
    }

    /**
     * Download erroneous document byte [ ].
     *
     * @param filePath the file path
     * @return the byte [ ]
     */
    public byte[]  DownloadErroneousDocument(String filePath) {
        log.info("Downloading erroneous document from S3");
        return s3AttachmentUtility.downloadAsBytes(bucketName, filePath);
    }
}