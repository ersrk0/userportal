package in.gov.gem.app.incident.service;

import in.gov.gem.app.incident.domain.entity.BulkUploadLog;
import in.gov.gem.app.incident.request.IncidentRequestDTO;
import in.gov.gem.app.incident.response.IncidentResponseDTO;

import org.springframework.web.multipart.MultipartFile;
import java.io.IOException;
import java.util.List;
import java.util.UUID;

public interface IncidentService {
    IncidentResponseDTO saveIncident(UUID incidentPk, String acceptLanguage, IncidentRequestDTO incidentRequestDTO) throws IOException;
}