package in.gov.gem.app.fa.pq.request;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@Data
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class QuestionCreateRequestDTO {

  @Schema(description = "Question for the buyer", example = "What is your domain name?", minLength = 1, maxLength = 1024)
  @NotBlank(message = "Question text can not be empty")
  private String questionText;

  @Schema(description = "Input type for choosing the type of answer", example = "LCGOV00002")
  @NotBlank(message = "Input type can not be empty") // Changed from @NotNull to @NotBlank for String
  private String inputType;

  @Schema(required = true, description = "Flag for compulsory question", example = "true")
  @NotNull(message = "Mandatory flag cannot be null")
  private Boolean isMandatory;

  @Schema(required = true, description = "Flag for document requirement", example = "true")
  @NotNull(message = "Document required flag cannot be null")
  private Boolean docRequired;

  @Schema(description = "Score set for the Question", example = "10")
  private BigDecimal score;

  @Schema(description = "List of options for multiple choice questions")
  private List<String> options;

  @Schema(description = "Flag for date range (true for Date to Date, false for fixed date). Required when inputType is DATE.", example = "true")
  private Boolean isDateRange;

}