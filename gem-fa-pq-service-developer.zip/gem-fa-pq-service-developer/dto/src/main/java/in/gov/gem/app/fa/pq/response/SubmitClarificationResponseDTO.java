package in.gov.gem.app.fa.pq.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Schema(name = "Questionnaire Response Clarification", description = "Questionnaire Response Clarification")
@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SubmitClarificationResponseDTO {

    @Schema(description = "additionalInfoId", example = "Submitted")
    String status;
    @Schema(description = "additionalInfoId", example = "77889")
    Long additionalInfoId;

    String responseBy;
}
