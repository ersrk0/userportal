package in.gov.gem.app.fa.pq.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ClarificationDTO {
    String clarificationId;
    String responseText;
    String responsBy;
    String createdDate;
    String lastUpdatedDate;
    List<ClarificationAttachmentDTO> attachments;

}

