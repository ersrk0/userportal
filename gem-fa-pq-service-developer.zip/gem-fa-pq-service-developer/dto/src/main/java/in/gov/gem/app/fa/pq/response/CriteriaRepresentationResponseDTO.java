package in.gov.gem.app.fa.pq.response;

import com.fasterxml.jackson.annotation.JsonFormat;
import in.gov.gem.app.fa.pq.constant.Constants;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
public class CriteriaRepresentationResponseDTO {
  private String raisedBy;
  private String responseBy;

  @JsonFormat(pattern = Constants.UTC_DATETIME_FORMAT, timezone = "UTC")
  private Instant raisedAt;

  @JsonFormat(pattern = Constants.UTC_DATETIME_FORMAT, timezone = "UTC")
  private Instant reponseAt;

  private String status;
  private String representationText;
  private String response;
  private UUID categoryCode;
  private UUID documentId;
  private List<DocAttachmentResponseDTO> raiseRepresentationDocuments;
  private List<DocAttachmentResponseDTO> responseRepresentationDocuments;
}
