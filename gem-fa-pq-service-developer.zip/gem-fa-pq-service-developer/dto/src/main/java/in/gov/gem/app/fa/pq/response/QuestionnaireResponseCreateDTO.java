package in.gov.gem.app.fa.pq.response;


import java.util.List;
import java.util.UUID;

public class QuestionnaireResponseCreateDTO {
    List<UUID> attachmentList;
}
