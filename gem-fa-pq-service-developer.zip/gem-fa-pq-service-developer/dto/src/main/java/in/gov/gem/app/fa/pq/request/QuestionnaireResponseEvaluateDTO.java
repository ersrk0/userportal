package in.gov.gem.app.fa.pq.request;

public class QuestionnaireResponseEvaluateDTO {

    String evaluationStatus;
    String remarks;
    Integer score;
}
