
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * Criteria Management ServiceImpl: Implements the Criteria Management service layer.
 */
package in.gov.gem.app.fa.pq.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.UUID;


@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PqQuestionResponseDTO {
    public UUID submissionId;
}
