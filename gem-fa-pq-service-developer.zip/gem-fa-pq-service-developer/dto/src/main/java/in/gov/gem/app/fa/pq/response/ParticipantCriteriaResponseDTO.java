
/*
 * This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * ParticipantCriteriaResponseDTO: Specifies the dto for the returned participant criteria responses.
 */

package in.gov.gem.app.fa.pq.response;


import com.fasterxml.jackson.annotation.JsonFormat;
import in.gov.gem.app.constant.RegexConstants;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

@Schema(name = "Participant Criteria Response DTO", description = "Participant Criteria Responses")
@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
public class ParticipantCriteriaResponseDTO {

  @Schema(description = "participant ID", example = "123e4567-e89b-12d3-a456-426614174000")
  private String participantId;

  @Schema(description = "Remarks", example = "Evaluated")
  private String evaluatorRemarks;

  @Schema(description = "submission ID", example = "123e4567-e89b-12d3-a456-426614174000")
  private UUID submissionId;

  @Schema(description = "submission date and time")
  @JsonFormat(pattern = RegexConstants.UTC_FORMAT, timezone = "UTC")
  private Instant submittedAt;

  private List<CriteriaResponsesDetailsDTO> questionDetails;

}
