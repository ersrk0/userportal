package in.gov.gem.app.fa.pq.response;


import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.UUID;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CreateQuestionResponseDTO {

  @Schema(description = "Criteria Id for Document", example = "d26c90c3-236c-4d4e-b73c-b1b6e4558665",
      minLength = 32,maxLength = 36)
  private UUID criteriaId;

  private List<QuestionResponseDTO> questions;
}
