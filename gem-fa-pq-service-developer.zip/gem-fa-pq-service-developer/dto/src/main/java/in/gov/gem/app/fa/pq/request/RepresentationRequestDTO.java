package in.gov.gem.app.fa.pq.request;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.UUID;

@Data
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class RepresentationRequestDTO {

  private String representationText;
  private UUID ginCode;
  private String participantId;
//  private Boolean isDocumentRequired;
//  private Boolean isTextRequired;

}