package in.gov.gem.app.fa.pq.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.UUID;

@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
public class RespondRepresentationResponseDTO {

  private String message;
  private UUID representationId;
}
