
/*
 * This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * AttachmentDetailsResponseDTO: Specifies the dto for the returned criteria responses details.
 */

package in.gov.gem.app.fa.pq.response;


import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.UUID;

@Schema(name = "Attachment Details Response DTO", description = "Attachment Details Response")
@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AttachmentDetailsResponseDTO {

  @Schema(description = "attachment ID", example = "a1b2c3d4-e5f6-7890-abcd-ef1234567890")
  private UUID attachmentId;

  @Schema(description = "attachment name", example = "financial_details.pdf")
  private String attachmentName;

  @Schema(description = "Url to the attachment", example = "https://example.com/files/financial_details.pdf")
  private String attachmentUrl;

  @Schema(description = "attachment Size", example = "100")
  private Long attachmentSize;

}
