
/*
 * This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * UpdateSubmissionEvaluationDTO: dto for the request of submission evaluation.
 */

package in.gov.gem.app.fa.pq.request;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class UpdateSubmissionEvaluationDTO {

  @Schema(description = "submission status", example = "Accepted")
  private String submissionStatus;

  @Schema(description = "submission remarks", example = "Done")
  private String remarks;

  @Schema(description = "submission remarks", example = "100", required = false)
  private Integer score;

}
