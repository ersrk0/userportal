package in.gov.gem.app.fa.pq.request;

public enum ResponseType {

    SINGLE_CHOICE,
    MULTI_CHOICE,
    TEXTBOX,
    DATE,
    NUMERIC
}
