package in.gov.gem.app.fa.pq.request;

import org.springframework.web.multipart.MultipartFile;

import java.util.List;

public class QuestionareRequestAttachmentsDTO {

    List<MultipartFile> Documents;
}
