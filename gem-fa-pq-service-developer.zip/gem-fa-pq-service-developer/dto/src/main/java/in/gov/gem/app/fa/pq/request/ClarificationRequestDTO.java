package in.gov.gem.app.fa.pq.request;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.springframework.web.multipart.MultipartFile;

@Data
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class ClarificationRequestDTO {

    boolean representationAllowed;

    @Schema(description = "Additional Query", example = "sample", required = false)
    String additionalQuery;
    @Schema(description = "documents", example = "sample", required = false)
    private MultipartFile file;
}
