package in.gov.gem.app.fa.pq.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.List;
import java.util.UUID;

@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
public class CriteriaResponsesDetailsDTO {

  @Schema(description = "response id for the response", example = "a1b2c3d4-e5f6-7890-abcd-ef1234567890")
  private UUID responseId;

  @Schema(description = "Question id for the question", example = "a1b2c3d4-e5f6-7890-abcd-ef1234567890")
  private UUID questionId;

  @Schema(description = "evaluatorScore", example = "85")
  private Integer evaluatorScore;

  @Schema(description = "Question type for the question", example = "Single choice")
  private String questionType;

  @Schema(description = "List of options for choice-type questions (only applicable for SINGLE_CHOICE and MULTIPLE_CHOICE)",
      example = "[\"Option 1\", \"Option 2\", \"Option 3\"]")
    private List<String> options;

  List<AttachmentDetailsResponseDTO> attachments;
}
