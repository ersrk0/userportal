package in.gov.gem.app.fa.pq.response;

import lombok.Builder;

@Builder
public record OtpResponseValidateDTO(
    Boolean otpValidated
) {}
