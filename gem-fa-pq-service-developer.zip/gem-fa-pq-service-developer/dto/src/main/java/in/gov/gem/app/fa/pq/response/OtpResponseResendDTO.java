package in.gov.gem.app.fa.pq.response;

import lombok.Builder;

@Builder
public record OtpResponseResendDTO(
    Boolean resendSuccessful,
    String message,
    Integer resendTimeSeconds,
    Integer totalResendAttempt,
    Integer totalIncorrectAttempt
) {}
