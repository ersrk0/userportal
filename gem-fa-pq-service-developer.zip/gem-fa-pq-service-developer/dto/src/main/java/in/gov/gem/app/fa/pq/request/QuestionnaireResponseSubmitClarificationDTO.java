package in.gov.gem.app.fa.pq.request;

import java.util.List;

public class QuestionnaireResponseSubmitClarificationDTO {

    List<String> documents;
    boolean representationAllowed;

    String additionalInfo;
}
