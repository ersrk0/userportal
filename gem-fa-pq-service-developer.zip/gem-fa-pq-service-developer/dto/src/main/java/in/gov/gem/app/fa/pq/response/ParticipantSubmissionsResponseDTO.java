
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * ParticipantSubmissionsResponse: DTO layer of participant submissions.
 */
package in.gov.gem.app.fa.pq.response;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import in.gov.gem.app.constant.RegexConstants;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.time.Instant;
import java.util.UUID;


@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ParticipantSubmissionsResponseDTO {

  @Schema(description = "submission Id", example = "123e4567-e89b-12d3-a456-426614174000")
  private UUID submissionId;

  @Schema(description = "ID of the bidder", example = "123e4567-e89b-12d3-a456-426614174000")
  private String bidder;

  @Schema(description = "pq submission date and time")
  @JsonFormat(pattern = RegexConstants.UTC_FORMAT, timezone = "UTC")
  private Instant pqSubmissionDateAndTime;

  @Schema(description = "pq assessment date")
  @JsonFormat(pattern = RegexConstants.UTC_FORMAT, timezone = "UTC")
  private Instant pqAssessmentDate;

  @Schema(description = "status of the submission", example = "pending")
  private String status;

}
