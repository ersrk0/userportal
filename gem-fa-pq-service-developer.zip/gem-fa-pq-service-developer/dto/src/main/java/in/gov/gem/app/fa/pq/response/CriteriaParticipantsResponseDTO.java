
/*
 * This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * CriteriaParticipantsResponseDTO: Specifies the dto for the returned participant id details.
 */

package in.gov.gem.app.fa.pq.response;


import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.UUID;

@Schema(name = "Criteria Participants Response DTO", description = "Criteria Participants Response")
@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CriteriaParticipantsResponseDTO {

  @Schema(description = "category ID", example = "123e4567-e89b-12d3-a456-426614174000")
  private UUID categoryId;

  @Schema(description = "participant ID", example = "123e4567-e89b-12d3-a456-426614174000")
  private UUID participantId;

  private boolean isAllowed;

}
