package in.gov.gem.app.fa.pq.request;

public class QuestionnaireResponseAttachmentDTO {

    String fileName;
    String fileUrl;
}
