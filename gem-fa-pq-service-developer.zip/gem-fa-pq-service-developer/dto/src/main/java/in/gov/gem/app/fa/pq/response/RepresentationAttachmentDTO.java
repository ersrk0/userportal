package in.gov.gem.app.fa.pq.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.UUID;

@Data
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class RepresentationAttachmentDTO {
    private UUID attachmentID;
    private long fileSize;
    private String fileName;
    private String fileUrl;
}
