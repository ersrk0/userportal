package in.gov.gem.app.fa.pq.request;

import java.util.List;

public class QuestionnaireResponseRequestClarificationDTO {

    List<String> documents;
    boolean representationAllowed;

    String additionalQuery;
}
