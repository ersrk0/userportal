package in.gov.gem.app.fa.pq.request;

public class QuestionnaireResponseSubmitChallengeDTO {

    String issueRaised;
    QuestionnaireResponseAttachmentDTO supportingDocuments;
}
