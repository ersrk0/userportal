package in.gov.gem.app.fa.pq.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class QuestionResponseDTO {

  @Schema(description = "Question id for the question", example = "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
      minLength = 32, maxLength = 36)
  private UUID questionId;

  @Schema(description = "The actual question text displayed to users", example = "What is your experience in years?",
      minLength = 1, maxLength = 1024)
  private String questionText;

  @Schema(description = "Type of input expected for the question", example = "SINGLE_CHOICE")
  private String inputType;

  @Schema(description = "Whether the question is mandatory to answer", example = "true")
  private Boolean isMandatory;

  @Schema(description = "List of options for choice-type questions (only applicable for SINGLE_CHOICE and MULTIPLE_CHOICE)",
      example = "[\"Option 1\", \"Option 2\", \"Option 3\"]")
  private List<Map<String, Object>> options;

  @Schema(description = "Whether supporting documents are required for this question", example = "false")
  private Boolean docRequired;

  @Schema(description = "Score weightage assigned to this question",
      example = "10")
  private BigDecimal score;

  private UUID documentId;

  List<DocAttachmentResponseDTO> attachments;
}
