package in.gov.gem.app.fa.pq.request;

import java.util.List;

public class QuestionnaireResponseSubmissionDTO {

    List<String> documents;

}
