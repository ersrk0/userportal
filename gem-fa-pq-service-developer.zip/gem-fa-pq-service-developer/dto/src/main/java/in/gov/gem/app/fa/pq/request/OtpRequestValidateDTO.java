package in.gov.gem.app.fa.pq.request;

public record OtpRequestValidateDTO(
    String otp,
    String deliveryChannel,
    String referenceId
){}
