package in.gov.gem.app.fa.pq.request;

import lombok.Data;
import java.util.List;
@Data
public class QuestionnaireResponseUpdateDTO {

    List<String> responseValue;
    String responseType;
}
