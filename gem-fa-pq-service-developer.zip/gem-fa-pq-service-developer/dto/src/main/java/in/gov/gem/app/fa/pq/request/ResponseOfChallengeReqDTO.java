package in.gov.gem.app.fa.pq.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.springframework.web.multipart.MultipartFile;
@Data
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class ResponseOfChallengeReqDTO {

    //private Long challengeId;
    private String responseText;
    private MultipartFile file;
}
