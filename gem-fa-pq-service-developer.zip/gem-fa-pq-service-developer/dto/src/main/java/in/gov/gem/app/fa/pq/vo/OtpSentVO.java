package in.gov.gem.app.fa.pq.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class OtpSentVO {
    private String referenceId;
    private boolean sent;
    private String message;
    private Integer resendTimeSeconds;
    private Integer totalResendAttempt;
    private Integer totalIncorrectAttempt;
}
