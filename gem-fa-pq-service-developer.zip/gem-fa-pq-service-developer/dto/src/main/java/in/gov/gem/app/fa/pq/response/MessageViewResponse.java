package in.gov.gem.app.fa.pq.response;

import lombok.Data;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
public class MessageViewResponse {
  private String message;
}
