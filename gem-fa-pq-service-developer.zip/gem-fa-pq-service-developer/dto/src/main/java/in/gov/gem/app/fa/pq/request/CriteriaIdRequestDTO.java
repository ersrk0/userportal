
/*
 * This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * CriteriaIdRequestDTO: Specifies the dto for the request of Criteria id details.
 */

package in.gov.gem.app.fa.pq.request;

import in.gov.gem.app.fa.pq.response.CategoryResponseDTO;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

@Data
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class CriteriaIdRequestDTO {

  @Schema(description = "Offering ID", example = "123e4567-e89b-12d3-a456-426614174000")
  private UUID offeringId;

  private Instant pqStartDate;

  private Instant pqEndDate;

  private List<CategoryResponseDTO> categories;

  private Boolean representationAllowed;

  private String status;

}
