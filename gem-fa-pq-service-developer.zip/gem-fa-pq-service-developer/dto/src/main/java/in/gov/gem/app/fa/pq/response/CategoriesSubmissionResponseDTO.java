package in.gov.gem.app.fa.pq.response;

import com.fasterxml.jackson.annotation.JsonFormat;
import in.gov.gem.app.fa.pq.constant.Constants;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

import java.time.Instant;
import java.util.UUID;

@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class CategoriesSubmissionResponseDTO {
  private UUID categoryCode;
  private String auctioneerRemarks;
  private String categoryName;
  private UUID submissionId;
  private String statusLookup;
  private Integer categoryScore;

  @JsonFormat(pattern = Constants.UTC_DATETIME_FORMAT, timezone = "UTC")
  private Instant submissionDateAndTime;

  @JsonFormat(pattern = Constants.UTC_DATETIME_FORMAT, timezone = "UTC")
  private Instant assessmentDateAndTime;
}
