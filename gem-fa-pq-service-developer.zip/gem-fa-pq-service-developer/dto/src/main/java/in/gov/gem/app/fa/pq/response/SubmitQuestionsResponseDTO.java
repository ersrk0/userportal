package in.gov.gem.app.fa.pq.response;


import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.UUID;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SubmitQuestionsResponseDTO {

  @Schema(description = "List of pending questions (inactive drafts)")
  private List<UUID> pendingQuestions;

  private UUID submissionId;

}
