package in.gov.gem.app.fa.pq.request;

import lombok.Builder;

@Builder
public record OtpGenerateRequestDTO(
   Boolean sentSuccessful,
   String referenceId,
   String message,
   Integer resendTimeSeconds,
   Integer totalResendAttempt,
   Integer totalIncorrectAttempt
) {}
