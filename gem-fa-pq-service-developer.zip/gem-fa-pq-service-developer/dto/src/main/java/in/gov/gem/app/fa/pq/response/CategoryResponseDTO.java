package in.gov.gem.app.fa.pq.response;

import lombok.*;
import lombok.experimental.SuperBuilder;

import java.util.UUID;

@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class CategoryResponseDTO {


  private UUID categoryCode;
  private String categoryName;
  private Boolean isPqEnabled;
  private Boolean isCategoryFilled = Boolean.FALSE;

  public CategoryResponseDTO(UUID categoryCode, String categoryName, Boolean isPqEnabled) {
    this.categoryCode = categoryCode;
    this.categoryName = categoryName;
    this.isPqEnabled = isPqEnabled;
  }
}
