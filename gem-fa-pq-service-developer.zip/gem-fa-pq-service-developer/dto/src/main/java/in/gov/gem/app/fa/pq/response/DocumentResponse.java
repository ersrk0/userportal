package in.gov.gem.app.fa.pq.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.experimental.SuperBuilder;

import java.util.UUID;

@Data
@SuperBuilder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DocumentResponse {

  @Schema(description = "response message about document upload", example = "File Upload Successfully!!")
  private String message;
  @Schema(description = "message code", example = "S-GM-20000004")
  private String code;
  @Schema(description = "File Name", example = "Aadhaar.pdf",minLength = 5,maxLength = 50)
  private String fileName;
  @Schema(description = "File Path", example = "https://gem.gov.in/")
  private String filePath;
  @Schema(description = "File Size", example = "182018")
  private Long fileSize;
  @Schema(description = "Unique Id for Document", example = "d26c90c3-236c-4d4e-b73c-b1b6e4558665",
      minLength = 32,maxLength = 36)
  private UUID uniqueId;
  @Schema(description = "Document Type", example = "Activity Log", minLength = 1,maxLength = 10)
  private String documentType;
  @Schema(description = "Document Validation", example = "True")
  private Boolean docValidated;
}
