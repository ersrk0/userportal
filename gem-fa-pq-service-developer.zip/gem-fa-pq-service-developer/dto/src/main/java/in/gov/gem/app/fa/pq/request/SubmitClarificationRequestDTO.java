//package in.gov.gem.app.fa.pq.request;
//
//import lombok.AllArgsConstructor;
//import lombok.Data;
//import lombok.NoArgsConstructor;
//import lombok.experimental.SuperBuilder;
//import org.springframework.web.multipart.MultipartFile;
//
//import java.util.List;
//@Data
//@NoArgsConstructor
//@AllArgsConstructor
//@SuperBuilder
//public class SubmitClarificationRequestDTO {
//
//    boolean representationAllowed;
//    String additionalInfo;
//}
