
/*
 * This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * CriteriaIdResponseDTO: Specifies the dto for the returned Criteria id details.
 */

package in.gov.gem.app.fa.pq.response;


import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

@Schema(name = "Criteria Id Response", description = "Criteria Id Response")
@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CriteriaIdResponseDTO {

  @Schema(description = "Criteria ID", example = "123e4567-e89b-12d3-a456-426614174000")
  private UUID criteriaId;

  @Schema(description = "Offering ID", example = "123e4567-e89b-12d3-a456-426614174000")
  private UUID offeringId;

  private Instant pqStartDate;

  private Instant pqEndDate;

  private List<CategoryResponseDTO> categories;

  private Boolean representationAllowed;

  private String status;

}
