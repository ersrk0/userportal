package in.gov.gem.app.fa.pq.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class TemporalCriteriaResponseDTO {

  private UUID offeringId;
  private LocalDate pqStartDate;
  private LocalDate pqEndDate;
  private List<CategoryResponseDTO> categories;
  private Boolean representationAllowed;
  private String status;

}
