package in.gov.gem.app.fa.pq.request;

import lombok.Builder;

@Builder
public record OtpRegenerateRequestDTO(
    String deliveryChannel,
    String referenceId
)
{}
