package in.gov.gem.app.fa.pq.client;

import in.gov.gem.app.fa.pq.request.OtpGenerateRequestDTO;
import in.gov.gem.app.fa.pq.request.OtpRegenerateRequestDTO;
import in.gov.gem.app.fa.pq.request.OtpRequestValidateDTO;
import in.gov.gem.app.fa.pq.response.OtpResponseResendDTO;
import in.gov.gem.app.fa.pq.response.OtpResponseSendDTO;
import in.gov.gem.app.fa.pq.response.OtpResponseValidateDTO;
import in.gov.gem.app.service.core.config.FeignClientConfig;
import in.gov.gem.app.service.core.utility.RetrieveMessageErrorDecoder;
import in.gov.gem.app.service.dto.APIResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;

/**
 * The interface Otp client.
 */
@FeignClient(name = "${endpoint.otp.name}", path = "${endpoint.otp.context-path}", configuration =
    {RetrieveMessageErrorDecoder.class, FeignClientConfig.class}, contextId = "otpClient")
public interface IOtpClient {

  @PostMapping(value = "${endpoint.otp.generate}", consumes = MediaType.APPLICATION_JSON_VALUE)
  ResponseEntity<APIResponse<OtpResponseSendDTO>> generateOtp(OtpGenerateRequestDTO otpGenerateRequestDTO);

  @PostMapping(value = "${endpoint.otp.regenerate}", consumes = MediaType.APPLICATION_JSON_VALUE)
  ResponseEntity<APIResponse<OtpResponseResendDTO>> regenerateOtp(OtpRegenerateRequestDTO otpRegenerateRequestDTO);

  @PostMapping(value = "${endpoint.otp.validate}", consumes = MediaType.APPLICATION_JSON_VALUE)
  ResponseEntity<APIResponse<OtpResponseValidateDTO>> otpValidate(OtpRequestValidateDTO otpRequestValidateDTO);


}
