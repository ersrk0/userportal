
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * Criteria Management ServiceImpl: Implements the Criteria Management service layer.
 */
package in.gov.gem.app.fa.pq.constant;

public class Regex {

    public static final String FREE_TEXT_PATTERN = "^[a-zA-Z0-9\\s]*$"; // Alphanumeric and spaces
    public static final String NUMERIC_PATTERN = "\\d+"; // Numeric only

}
