
/*
 * This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * This package consists of the Lookup code constants used in the app.
 */


package in.gov.gem.app.fa.pq.constant;

public class LookupConstants {

  public static final String SAVE_RESPONSE = "LCFAPQ0005";
  public static final String INPUT_TYPE_FREETEXT = "LCFA00001";
  public static final String INPUT_TYPE_SINGLE_CHOICE = "LCFA00002";
  public static final String INPUT_TYPE_MULTIPLE_CHOICE = "LCFA00003";
  public static final String INPUT_TYPE_NUMERIC = "LCFA00004";
  public static final String INPUT_TYPE_DATE = "LCFA00005";
  public static final String INPUT_TYPE_FIXED_DATE = "LCFA00006";
  public static final String INPUT_TYPE_DATE_TO_DATE = "LCFA00007";
  public static final Integer START_INDEX_OFFSET = 1;
  public static final String MODULE_PATH = "fapq/";

  public static final String DOCUMENT_PATH = "/fapq/v1/temporal/criteria/public/view/attachment/";
  public static final String QUESTION_CREATION = "/createquestion/";
  public static final String REPRESENTATION_ANSWERED = "LCFAPQ0010";
  private LookupConstants() {
    throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
  }
  public enum Status {
    PENDING("LCFAPQ0001"),
    VALID_DRAFT("LCFAPQ0002"),
    ACTIVE("LCFAPQ0003"),
    INACTIVE("LCFAPQ0004"),
    INVALID_DRAFT("LCFAPQ0009"),
    APPROVED("LCFAPQ0006"),
    REJECTED("LCFAPQ0011"),
    WITHDRAWN("LCFAPQ0008"),
    DRAFT("LCFAPQ0005"),

    SUBMITTED("LCFAPQ0012"),
    SEEK_CLARIFICATION("LCFAPQ0007");

    private final String lookupCode;

    Status(String lookupCode) {
      this.lookupCode = lookupCode;
    }

    public String getLookupCode() {
      return lookupCode;
    }
  }

  public static boolean containsStatus(String status) {
    try {
      Status.valueOf(status);
      return true;
    } catch (IllegalArgumentException e) {
      return false;
    }
  }

  public static String getEnumStatusKeyByValue(String lookupCode) {
    for (Status status : Status.values()) {
      if (status.getLookupCode().equals(lookupCode)) {
        return status.name();
      }
    }
    throw new IllegalArgumentException("No enum constant found for lookupCode: " + lookupCode);
  }

  public enum SenderType {
    AUCTIONER("LCFAPQ0007"),
    BIDDER("LCFAPQ0008");

    private final String lookupCode;

    SenderType(String lookupCode) {
      this.lookupCode = lookupCode;
    }

    public String getLookupCode() {
      return lookupCode;
    }


    @Override
    public String toString() {
      return lookupCode;
    }
  }

}
