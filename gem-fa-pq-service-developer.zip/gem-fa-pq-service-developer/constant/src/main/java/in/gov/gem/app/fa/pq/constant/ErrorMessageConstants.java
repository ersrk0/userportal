
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * This package consists of Error constants used in the app.
 */

package in.gov.gem.app.fa.pq.constant;

public class ErrorMessageConstants {

  private ErrorMessageConstants() {
    throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
  }

  public static final String CRITERIA_NOT_FOUND = "E-FAPQ-BV-I-40000001";
  public static final String DOCUMENT_UPLOAD_ERROR_MSG = "E-FAPQ-BV-I-40000002";
  public static final String DOCUMENT_OFFICIAL_LETTER_ERROR_MSG = "E-FAPQ-BV-I-40000003";
  public static final String INVALID_QUESTION_ID = "E-FAPQ-BV-I-40000004";
  public static final String SUBMISSION_NOT_EXIST = "E-FAPQ-BV-I-40000005";
  public static final String FILE_LIMIT_EXCEEDED = "File size exceeds limit";
  public static final String ACTIVE_CRITERIA_NOT_FOUND = "E-FAPQ-BV-I-40000008";
  public static final String ACTIVE_CATEGORY_NOT_FOUND = "E-FAPQ-BV-I-40000009";
  public static final String INVALID_REPRESENTATION = "E-FAPQ-BV-I-40000007";
  public static final String INVALID_OPTIONS = "E-FAPQ-BV-I-40000010";
  public static final String INVALID_QUESTION = "E-FAPQ-BV-I-40000011";
  public static final String INVALID_QUESTION_SCORE = "E-FAPQ-BV-I-40000012";
  public static final String INVALID_FILE_TYPE = "E-FAPQ-BV-I-40000013";
  public static final String REPRESENTATION_NOT_ALLOWED = "E-FAPQ-BV-I-40000014";
  public static final String INVALID_PARTICIPANT = "E-FAPQ-BV-I-40000015";
  public static final String REPRESENTATION_ALREADY_EXISTS = "E-FAPQ-BV-I-40000016";
  public static final String REPRESENTATION_NOT_FOUND = "E-FAPQ-BV-I-40000017";
  public static final String FORBIDDEN_PARTICIPANT = "E-FAPQ-BV-I-40000018";
  public static final String RESPONSE_ALREADY_EXISTS = "E-FAPQ-BV-I-40000019";
  public static final String INVALID_STATUS = "E-FAPQ-BV-I-40000021";

  public static final String INVALID_INPUT = "E-FAPQ-BV-I-40000022";





}
