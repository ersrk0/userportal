
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * This package consists of Success constants used in the app.
 */

package in.gov.gem.app.fa.pq.constant;

public class MessageConstants {


  private MessageConstants() {
    throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
  }

  public static final String SUCCESS_MESSAGE = "S-FAPQ-2000001";

  public static final String SUCCESS_WITHDRAWN = "S-FAPQ-2000004";
  public static final String DELETE_CATEGORY = "S-FAPQ-2000002";
  public static final String DELETE_CRITERIA = "S-FAPQ-2000003";
  public static final String DELETE_QUESTION = "S-FAPQ-2000005";
  public static final String DELETE_SUBMISSION = "S-FAPQ-2000010";
  public static final String CRITERIA_SYNCED = "E-FAPQ-BV-I-40000006";
  public static final String DOCUMENT_UPLOAD_MSG = "S-FAPQ-2000006";
  public static final String UPDATE_QUESTION = "S-FAPQ-2000007";
  public static final String UPLOAD_DOCUMENTS = "S-FAPQ-2000008";
  public static final String CREATED_BY = "TEMP";
  public static final String UPLOADED_BY = "SEED";
  public static final String DELETE_DOCUMENT = "S-FAPQ-2000009";
  public static final String INVALID_RESPONSE = "E-FAPQ-BV-I-40000005";
  public static final String INVALID_INPUT = "E-FAPQ-BV-I-40000006";
  public static final String RAISE_REPRESENTATION = "S-FAPQ-2000011";
  public static final String REPRESENTATION_RESPONSE = "S-FAPQ-2000012";
  public static final String CATEGORY_QUESTION_DELETED = "S-FAPQ-2000013";
  public static final String QUESTION_CREATED = "S-FAPQ-2000014";



}
