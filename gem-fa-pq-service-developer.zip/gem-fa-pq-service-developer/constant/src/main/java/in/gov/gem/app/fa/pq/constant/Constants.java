
/*
 * This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * This package consists of the constants used in the app.
 */

package in.gov.gem.app.fa.pq.constant;

import jakarta.persistence.criteria.CriteriaBuilder;

public class Constants {


  private Constants() {
    throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
  }

  public static final String MSID = "MS_FA_PQ";
  public static final Integer MAX_FILE_SIZE = 5 * 1024 * 1024;
  public static final Integer MIN_FILE_SIZE = 0;
  public static final String DOCUMENT_COMMON = "Common";
  public static final String LNG = "eng";
  public static final String UTC_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
  public static final String UTC_DATETIME_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX";
  public static final String ATTACHMENT_BASE_URL = "v1/temporal/criteria/public/view/attachment/";
  public static final String SLASH = "/";
  public static final String COMMA = ",";


  public static final String AUCTIONER = "auctioner";
}
