
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * ClassificationManagementFacadeTest: Tests the facade layer functioning.
 */

package in.gov.gem.app.fa.pq.facade;

import in.gov.gem.app.fa.pq.constant.TestConstants;
import in.gov.gem.app.fa.pq.domain.entity.DocMaster;
import in.gov.gem.app.fa.pq.domain.entity.PqClarificationMsg;
import in.gov.gem.app.fa.pq.domain.entity.PqClarificationThread;
import in.gov.gem.app.fa.pq.domain.entity.PqResponse;
import in.gov.gem.app.fa.pq.facade.impl.ClarificationManagementFacade;
import in.gov.gem.app.fa.pq.request.ClarificationRequestDTO;
import in.gov.gem.app.fa.pq.response.GetClarificationResponseDTO;
import in.gov.gem.app.fa.pq.response.ReqClarificationResponseDTO;
import in.gov.gem.app.fa.pq.response.SubmitClarificationResponseDTO;
import in.gov.gem.app.fa.pq.service.ClassificationManagementService;
import in.gov.gem.app.fa.pq.service.DocAttachmentService;
import in.gov.gem.app.fa.pq.service.DocumentMasterService;
import in.gov.gem.app.fa.pq.service.DocumentServiceUtil;
import in.gov.gem.app.fa.pq.service.PqClarificationMsgService;
import in.gov.gem.app.fa.pq.service.PqClarificationThreadService;
import in.gov.gem.app.fa.pq.service.PqResponseService;
import in.gov.gem.app.fa.pq.transformer.ClassificationManagementTransformer;
import in.gov.gem.app.fa.pq.utility.RequestUtil;
import in.gov.gem.app.service.attachment.utility.S3AttachmentUtility;
import in.gov.gem.app.service.dto.CoreLookupDto;
import in.gov.gem.app.service.pack.service.interfaces.CoreLookupService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.Collections;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

class ClarificationManagementFacadeTest {


    @Mock
    private ClassificationManagementService classificationManagementService;

    @Mock
    private PqClarificationThreadService pqClarificationThreadService;

    @Mock
    private PqClarificationMsgService pqClarificationMsgService;

    @Mock
    private PqResponseService pqResponseService;

    @Mock
    private ClassificationManagementTransformer classificationManagementTransformer;

    @Mock
    private RequestUtil requestUtil;

    @Mock
    private DocumentServiceUtil documentServiceUtil;

    @Mock
    private CoreLookupService coreLookupService;

    @Mock
    private DocumentMasterService documentMasterService;

    @Mock
    private DocAttachmentService docAttachmentService;

    @Mock
    private S3AttachmentUtility s3AttachmentUtility;

    @Mock
    private MultipartFile file;

    @InjectMocks
    private ClarificationManagementFacade clarificationManagementFacade;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testRequestClarification_WithNullFile() throws IOException {
        String acceptLanguage = TestConstants.LANGUAGE_CODE;
        UUID responseId = UUID.randomUUID();
        ClarificationRequestDTO requestDTO = new ClarificationRequestDTO();
        PqResponse pqResponse = mock(PqResponse.class);
        PqClarificationThread pqClarificationThread = new PqClarificationThread();
        PqClarificationMsg pqClarificationMsg = new PqClarificationMsg();
        ReqClarificationResponseDTO responseDTO = new ReqClarificationResponseDTO();

        when(pqResponseService.fetchPqResponseById(responseId)).thenReturn(pqResponse);
        when(pqClarificationThreadService.saveThread(acceptLanguage, pqResponse)).thenReturn(pqClarificationThread);
        when(pqClarificationMsgService.saveMsg(pqClarificationThread, requestDTO.getAdditionalQuery(), null))
                .thenReturn(pqClarificationMsg);
        when(classificationManagementTransformer.toReqClarificationResponseDTO(pqClarificationMsg))
                .thenReturn(responseDTO);

        ReqClarificationResponseDTO result = clarificationManagementFacade.requestClarification(
                acceptLanguage, responseId, null, requestDTO);

        assertNotNull(result, TestConstants.RESPONSE_NULL);
    }

    @Test
    void testGetClarification() {
        String acceptLanguage = "en";
        UUID responseId = UUID.randomUUID();
        PqResponse pqResponse = mock(PqResponse.class);
        PqClarificationThread thread = mock(PqClarificationThread.class);
        PqClarificationMsg[] messages = new PqClarificationMsg[1];
        messages[0] = mock(PqClarificationMsg.class);
        GetClarificationResponseDTO expectedResponse = mock(GetClarificationResponseDTO.class);

        when(pqResponseService.fetchPqResponseById(responseId)).thenReturn(pqResponse);
        when(pqClarificationThreadService.fetchThread(acceptLanguage, pqResponse)).thenReturn(thread);
        when(pqClarificationMsgService.fetchClarificationMsgByThread(thread)).thenReturn(messages);
        when(classificationManagementTransformer.toGetClarificationResponseDTO(messages, responseId))
                .thenReturn(expectedResponse);

        GetClarificationResponseDTO actualResponse = clarificationManagementFacade.getClarification(
                acceptLanguage,responseId);

        assertNotNull(actualResponse);
        assertEquals(expectedResponse, actualResponse);
    }

    @Test
    void testDocumentUpload() throws IOException {
        CoreLookupDto lookupDto = new CoreLookupDto();
        lookupDto.setLookupCode(TestConstants.LOOKUP_CODE_PDF);
        DocMaster expectedDocMaster = new DocMaster();
        expectedDocMaster.setDocumentId(UUID.randomUUID());

        when(file.getOriginalFilename()).thenReturn(TestConstants.FILE_NAME);
        when(file.getContentType()).thenReturn(TestConstants.CONTENT_TYPE);
        when(file.getSize()).thenReturn(TestConstants.FILE_SIZE);
        when(requestUtil.createRequestId()).thenReturn(UUID.randomUUID());
        when(coreLookupService.findAllByLookupValueIgnoreCase(anyString()))
            .thenReturn(Collections.singletonList(lookupDto));
        when(requestUtil.createPath(any(), any(), any()))
            .thenReturn(TestConstants.FILE_PATH);
        when(documentMasterService.saveDocumentMaster(any()))
            .thenReturn(expectedDocMaster);
        doNothing().when(docAttachmentService)
            .saveDocumentDetails(any(), any(), any(), any(), anyLong(), any());
        when(s3AttachmentUtility.uploadMultipart(anyString(), anyString(), any(MultipartFile.class)))
            .thenReturn(true);

        DocMaster result = clarificationManagementFacade.documentUpload(file);

        assertNotNull(result, TestConstants.RESPONSE_NULL);
    }

    @Test
    void testSubmitClarificationWithNullFile() throws IOException {
        String acceptLanguage = TestConstants.LANGUAGE_CODE;
        UUID responseId = UUID.randomUUID();
        ClarificationRequestDTO submitClarificationRequestDTO = new ClarificationRequestDTO();
        PqResponse pqResponse = mock(PqResponse.class);
        PqClarificationThread pqClarificationThread = mock(PqClarificationThread.class);
        PqClarificationMsg pqClarificationMsg = mock(PqClarificationMsg.class);
        SubmitClarificationResponseDTO expectedResponse = mock(SubmitClarificationResponseDTO.class);

        when(pqResponseService.fetchPqResponseById(responseId)).thenReturn(pqResponse);
        when(pqResponse.getPqResponseId()).thenReturn(UUID.randomUUID());
        when(pqClarificationThreadService.fetchThread(any(), any()))
            .thenReturn(pqClarificationThread);
        when(pqClarificationMsgService.saveSubmissionMsg(pqClarificationThread, submitClarificationRequestDTO.getAdditionalQuery(), null))
            .thenReturn(pqClarificationMsg);
        when(classificationManagementTransformer.toSubmitClarificationResponseDTO(pqClarificationMsg))
            .thenReturn(expectedResponse);

        SubmitClarificationResponseDTO actualResponse = clarificationManagementFacade.submitClarification(
            acceptLanguage, responseId, null, submitClarificationRequestDTO);

        assertNotNull(actualResponse, TestConstants.RESPONSE_NULL);
    }
}