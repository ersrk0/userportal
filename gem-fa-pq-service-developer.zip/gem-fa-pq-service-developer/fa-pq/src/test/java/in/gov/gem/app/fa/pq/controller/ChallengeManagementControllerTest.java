
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * Pq Clarification Msg Repository: Contains DB function to fetch Pq clarification msg data.
 */
package in.gov.gem.app.fa.pq.controller;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import in.gov.gem.app.fa.pq.constant.MessageConstants;
import in.gov.gem.app.fa.pq.constant.TestConstants;
import in.gov.gem.app.fa.pq.facade.IPqChallengeManagementFacade;
import in.gov.gem.app.fa.pq.request.ChallengeReqDTO;
import in.gov.gem.app.fa.pq.request.ResponseOfChallengeReqDTO;
import in.gov.gem.app.fa.pq.response.ChallnegeResDTO;
import in.gov.gem.app.fa.pq.response.ResponseOfChallenegeDTO;
import in.gov.gem.app.service.core.utility.MessageUtility;
import in.gov.gem.app.service.dto.APIResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.io.IOException;
import java.util.UUID;

class ChallengeManagementControllerTest {

    @Mock
    private MessageUtility messageUtility;

    @Mock
    private IPqChallengeManagementFacade challengeManagementFacade;

    @InjectMocks
    private ChallengeManagementController challengeManagementController;

    private ChallengeReqDTO challengeReqDTO;

    private ChallnegeResDTO challnegeResDTO;
    private UUID submissionId;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        submissionId = UUID.randomUUID(); // Initialize submissionId
        challengeReqDTO = new ChallengeReqDTO();
        challnegeResDTO = new ChallnegeResDTO();
    }

    @Test
    void testChallengeResponse() throws IOException {
        // Mock behavior
        when(challengeManagementFacade.challenegeResponse(submissionId, challengeReqDTO)).thenReturn(challnegeResDTO);
        when(messageUtility.getMessage(MessageConstants.SUCCESS_MESSAGE)).thenReturn("Success");

        // Call the method under test
        ResponseEntity<APIResponse<ChallnegeResDTO>> response = challengeManagementController.challengeResponse(
                "en", submissionId, challengeReqDTO);

        // Assertions
        assertNotNull(response);
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("Success", response.getBody().getMessage());
        assertEquals(challnegeResDTO, response.getBody().getData());

        // Verify interactions
        verify(challengeManagementFacade, times(1)).challenegeResponse(submissionId, challengeReqDTO);
        verify(messageUtility, times(1)).getMessage(MessageConstants.SUCCESS_MESSAGE);
    }

    @Test
    void testResponseOfChallenge() throws IOException {
        long challengeId = TestConstants.ID;
        ResponseOfChallengeReqDTO responseOfChallengeReqDTO = new ResponseOfChallengeReqDTO();
        ResponseOfChallenegeDTO responseOfChallenegeDTO = new ResponseOfChallenegeDTO();

        when(challengeManagementFacade.ResponseOfChallenge(challengeId, responseOfChallengeReqDTO))
            .thenReturn(responseOfChallenegeDTO);
        when(messageUtility.getMessage(any())).thenReturn(TestConstants.MESSAGE_UTILITY);

        ResponseEntity<APIResponse<ResponseOfChallenegeDTO>> response = challengeManagementController.ResponseOfChallenge(
            TestConstants.LANGUAGE_CODE, challengeId, responseOfChallengeReqDTO);

        assertNotNull(response, TestConstants.RESPONSE_NULL);
    }
}