
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * PqRepresentationServiceImplTest: Tests the service layer functioning.
 */

package in.gov.gem.app.fa.pq.service.impl;

import in.gov.gem.app.exception.generic.InvalidInputException;
import in.gov.gem.app.fa.pq.constant.ErrorMessageConstants;
import in.gov.gem.app.fa.pq.constant.LookupConstants;
import in.gov.gem.app.fa.pq.constant.TestConstants;
import in.gov.gem.app.fa.pq.domain.entity.DocMaster;
import in.gov.gem.app.fa.pq.domain.entity.PqCriteria;
import in.gov.gem.app.fa.pq.domain.entity.PqParticipant;
import in.gov.gem.app.fa.pq.domain.entity.PqRepresentation;
import in.gov.gem.app.fa.pq.domain.repository.PqRepresentationRepository;
import in.gov.gem.app.fa.pq.request.RepresentationRequestDTO;
import in.gov.gem.app.service.core.utility.MessageUtility;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.List;
import java.util.UUID;

import static org.junit.Assert.assertThrows;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

class PqRepresentationServiceImplTest {

  @Mock
  private PqRepresentationRepository pqRepresentationRepository;

  @InjectMocks
  private PqRepresentationServiceImpl pqRepresentationService;

  @Mock
  private MessageUtility messageUtility;

  @BeforeEach
  void setUp() {
    MockitoAnnotations.openMocks(this);
  }

  @Test
  void testRaiseRepresentationSuccess() {
    RepresentationRequestDTO request = mock(RepresentationRequestDTO.class);
    when(request.getRepresentationText()).thenReturn("Test Representation");
    PqCriteria pqCriteria = mock(PqCriteria.class);
    DocMaster docMaster = mock(DocMaster.class);
    PqParticipant pqParticipant = mock(PqParticipant.class);
    UUID representationId = UUID.randomUUID();

    pqRepresentationService.raiseRepresentation(request, pqCriteria, docMaster, pqParticipant, representationId);

    verify(pqRepresentationRepository, times(1)).save(any(PqRepresentation.class));
  }

  @Test
  void testFetchRepresentationThrowsExceptionIfExists() {
    PqCriteria pqCriteria = mock(PqCriteria.class);
    PqRepresentation pqRepresentation = mock(PqRepresentation.class);

    when(pqRepresentationRepository.findByPqCriteriaAndStatusLookup(
        any(PqCriteria.class), eq(LookupConstants.Status.PENDING.getLookupCode())))
        .thenReturn(pqRepresentation);
    when(messageUtility.getMessage(ErrorMessageConstants.REPRESENTATION_ALREADY_EXISTS))
        .thenReturn("Already exists");

    Assertions.assertThrows(InvalidInputException.class, () -> {
      pqRepresentationService.fetchRepresentation(pqCriteria);
    });

  }

  @Test
  void testFetchRepresentationNoExceptionIfNotExists() {
    PqCriteria pqCriteria = mock(PqCriteria.class);

    when(pqRepresentationRepository.findByPqCriteriaAndStatusLookup(
        any(PqCriteria.class), eq(LookupConstants.Status.PENDING.getLookupCode())))
        .thenReturn(null);

    assertDoesNotThrow(() -> pqRepresentationService.fetchRepresentation(pqCriteria));
  }


  @Test
  void testFetchRepresentationByPqCriteriaReturnsList() {
    PqCriteria pqCriteria = mock(PqCriteria.class);
    List<PqRepresentation> expectedList = List.of(mock(PqRepresentation.class));
    when(pqRepresentationRepository.findByPqCriteriaAndStatusLookupNot(any(), any()))
        .thenReturn(expectedList);

    List<PqRepresentation> result = pqRepresentationService.fetchRepresentationByPqCriteria(pqCriteria);

    Assertions.assertEquals(expectedList, result, TestConstants.VALUES_NOT_EQUAL);
  }


  @Test
  void testFetchRepresentationByRepresentationIdSuccess() {
    UUID representationId = UUID.randomUUID();
    PqRepresentation pqRepresentation = mock(PqRepresentation.class);

    when(pqRepresentationRepository.findByRepresentationIdAndStatusLookup(
        eq(representationId), eq(LookupConstants.Status.PENDING.getLookupCode())))
        .thenReturn(pqRepresentation);

    PqRepresentation result = pqRepresentationService.fetchRepresentationByRepresentationId(representationId);

    verify(pqRepresentationRepository, times(1))
        .findByRepresentationIdAndStatusLookup(representationId, LookupConstants.Status.PENDING.getLookupCode());
  }

  @Test
  void testFetchRepresentationByRepresentationIdThrowsExceptionWhenNotFound() {
    UUID representationId = UUID.randomUUID();

    when(pqRepresentationRepository.findByRepresentationIdAndStatusLookup(
        eq(representationId), eq(LookupConstants.Status.PENDING.getLookupCode())))
        .thenReturn(null);

    InvalidInputException exception = assertThrows(InvalidInputException.class, () -> {
      pqRepresentationService.fetchRepresentationByRepresentationId(representationId);
    });

    verify(pqRepresentationRepository, times(1))
        .findByRepresentationIdAndStatusLookup(representationId, LookupConstants.Status.PENDING.getLookupCode());
  }
}