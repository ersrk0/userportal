
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * Pq Clarification Msg Repository: Contains DB function to fetch Pq clarification msg data.
 */
package in.gov.gem.app.fa.pq.transformer;

import static org.junit.jupiter.api.Assertions.*;

import in.gov.gem.app.fa.pq.domain.entity.PqChallenge;
import in.gov.gem.app.fa.pq.response.ChallnegeResDTO;
import org.junit.jupiter.api.Test;

class PqChallengeTransformerTest {

    private final PqChallengeTransformer transformer = new PqChallengeTransformer();

    @Test
    void toChallengeResDTO_shouldMapFieldsCorrectly() {
        PqChallenge pqChallenge = new PqChallenge();
        pqChallenge.setId(100L);
        pqChallenge.setStatusLookUp("APPROVED");

        ChallnegeResDTO result = transformer.toChallengeResDTO(pqChallenge);

        assertNotNull(result);
        assertEquals(100L, result.getChallengeId());
        assertEquals("APPROVED", result.getStatus());
    }
}
