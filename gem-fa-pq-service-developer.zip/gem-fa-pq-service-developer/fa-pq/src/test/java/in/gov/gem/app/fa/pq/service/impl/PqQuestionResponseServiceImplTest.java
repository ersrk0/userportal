
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * PqOptionServiceImplTest: Tests the service layer functioning.
 */

package in.gov.gem.app.fa.pq.service.impl;

import in.gov.gem.app.exception.generic.ServiceException;
import in.gov.gem.app.fa.pq.constant.TestConstants;
import in.gov.gem.app.fa.pq.domain.entity.PqResponse;
import in.gov.gem.app.fa.pq.domain.repository.PqResponseRepository;
import in.gov.gem.app.fa.pq.response.PqQuestionResponseDTO;
import in.gov.gem.app.service.core.utility.MessageUtility;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class PqQuestionResponseServiceImplTest {

  @Mock
  private PqResponseRepository pqResponseRepository;

  @Mock
  private MessageUtility messageUtility;

  @InjectMocks
  private PqQuestionResponseServiceImpl pqQuestionResponseServiceImpl;

  @BeforeEach
  void setUp() {
    MockitoAnnotations.openMocks(this);
  }

  @Test
  void testSaveResponseEntityWithList() {
    List<PqResponse> pqResponseList = new ArrayList<>();
    PqResponse pqResponse1 = new PqResponse();
    pqResponse1.setPqResponseId(UUID.randomUUID());
    PqResponse pqResponse2 = new PqResponse();
    pqResponse2.setPqResponseId(UUID.randomUUID());
    pqResponseList.add(pqResponse1);
    pqResponseList.add(pqResponse2);

    when(pqResponseRepository.save(any(PqResponse.class))).thenAnswer(invocation -> invocation.getArgument(0));

    PqQuestionResponseDTO result = pqQuestionResponseServiceImpl.saveResponseEntity(pqResponseList);

    assertEquals(pqResponseList.get(0).getPqResponseId(), result.getSubmissionId(),
        TestConstants.VALUES_NOT_EQUAL);
  }

  @Test
  void testSaveResponseEntityWithSingleEntity() {
    PqResponse pqResponse = new PqResponse();
    pqResponse.setPqResponseId(UUID.randomUUID());

    when(pqResponseRepository.save(any(PqResponse.class))).thenReturn(pqResponse);

    PqResponse result = pqQuestionResponseServiceImpl.saveResponseEntity(pqResponse);

    assertEquals(pqResponse.getPqResponseId(), result.getPqResponseId(), TestConstants.VALUES_NOT_EQUAL);
  }

  @Test
  void testDeleteSubmittedResponseSuccess() {
    UUID criteriaId = UUID.randomUUID();
    UUID questionId = UUID.randomUUID();
    UUID submissionId = UUID.randomUUID();
    PqResponse pqResponse = new PqResponse();
    pqResponse.setPqResponseId(submissionId);

    when(pqResponseRepository.findByPqResponseId(any())).thenReturn(pqResponse);
    when(messageUtility.getMessage(any())).thenReturn(TestConstants.MESSAGE_UTILITY);


    String result = pqQuestionResponseServiceImpl.deleteSubmittedResponse(criteriaId, questionId, submissionId);

    assertEquals(TestConstants.MESSAGE_UTILITY, result);
  }

  @Test
  void testDeleteSubmittedResponseThrowsExceptionWhenNoResponsesFound() {
    UUID criteriaId = UUID.randomUUID();
    UUID questionId = UUID.randomUUID();
    UUID submissionId = UUID.randomUUID();

    when(pqResponseRepository.findByPqResponseId(any())).thenReturn(null);
    when(messageUtility.getMessage(any())).thenReturn(TestConstants.FAILURE_MESSAGE);

    Assertions.assertThrows(ServiceException.class, () ->
        pqQuestionResponseServiceImpl.deleteSubmittedResponse(criteriaId, questionId, submissionId)
    );

  }

  @Test
  void testFetchResponseFromSubmissionId() {
    UUID submissionId = UUID.randomUUID();
    List<PqResponse> responseList = new ArrayList<>();
    PqResponse pqResponse = new PqResponse();
    pqResponse.setPqResponseId(submissionId);
    responseList.add(pqResponse);

    when(pqResponseRepository.findByPqResponseId(any())).thenReturn(pqResponse);

    PqResponse result = pqQuestionResponseServiceImpl.fetchResponseFromSubmissionId(submissionId);

    assertEquals(pqResponse, result, TestConstants.VALUES_NOT_EQUAL);

  }
}