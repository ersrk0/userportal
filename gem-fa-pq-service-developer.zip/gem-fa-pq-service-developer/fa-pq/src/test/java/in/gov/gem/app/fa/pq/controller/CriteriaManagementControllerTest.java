
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * PrequalificationQuestionnaireControllerTest: Tests the controller functioning.
 */

package in.gov.gem.app.fa.pq.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import in.gov.gem.app.fa.pq.constant.TestConstants;
import in.gov.gem.app.fa.pq.facade.impl.CriteriaManagementFacade;
import in.gov.gem.app.fa.pq.request.CriteriaIdRequestDTO;
import in.gov.gem.app.fa.pq.response.CriteriaIdResponseDTO;
import in.gov.gem.app.fa.pq.response.MessageResponseDTO;
import in.gov.gem.app.fa.pq.response.SubmitRepresentationResDTO;
import in.gov.gem.app.service.core.utility.MessageUtility;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.time.Instant;
import java.util.ArrayList;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

class CriteriaManagementControllerTest {

  @InjectMocks
  private CriteriaManagementController criteriaManagementController;

  @Mock
  private CriteriaManagementFacade criteriaManagementFacade;

  @Mock
  private MessageUtility messageUtility;

  private MockMvc mockMvc;
  private String acceptLanguage;

  @BeforeEach
  void setUp() {
    MockitoAnnotations.openMocks(this);
    mockMvc = MockMvcBuilders.standaloneSetup(criteriaManagementController).build();

    acceptLanguage = TestConstants.LANGUAGE_CODE;
  }

  public static String asJsonString(final Object obj) {
    try {
      ObjectMapper objectMapper = new ObjectMapper();
      objectMapper.registerModule(new JavaTimeModule());
      return objectMapper.writeValueAsString(obj);
    } catch (Exception e) {
      throw new RuntimeException(e);
    }
  }

  @Test
  void testCreateCriteria() throws Exception {
    CriteriaIdRequestDTO criteriaIdRequestDTO = CriteriaIdRequestDTO.builder()
        .offeringId(UUID.randomUUID())
        .pqStartDate(Instant.now())
        .pqEndDate(Instant.now().plusSeconds(3600))
        .categories(new ArrayList<>())
        .representationAllowed(true)
        .status(TestConstants.STATUS_LOOKUP)
        .build();
    CriteriaIdResponseDTO criteriaIdResponseDTO = CriteriaIdResponseDTO.builder()
        .criteriaId(TestConstants.CRITERIA_ID)
        .offeringId(UUID.randomUUID())
        .pqStartDate(Instant.now())
        .pqEndDate(Instant.now().plusSeconds(3600))
        .categories(new ArrayList<>())
        .representationAllowed(true)
        .status(TestConstants.STATUS_LOOKUP)
        .build();

    when(criteriaManagementFacade.createCriteria(any(), any())).thenReturn(criteriaIdResponseDTO);
    when(messageUtility.getMessage(any())).thenReturn(TestConstants.MESSAGE_UTILITY);

    mockMvc.perform(post("/v1/public/criteria")
            .header("Accept-Language", acceptLanguage)
            .contentType(MediaType.APPLICATION_JSON)
            .content(asJsonString(criteriaIdRequestDTO)))
        .andExpect(status().isCreated())
        .andExpect(jsonPath("$.status").value(HttpStatus.CREATED.getReasonPhrase()));

    assertNotNull(criteriaIdResponseDTO, TestConstants.RESPONSE_NULL);
  }

  @Test
  void testFetchCriteria() throws Exception {
    UUID offeringId = UUID.randomUUID();
    CriteriaIdResponseDTO criteriaIdResponseDTO = CriteriaIdResponseDTO.builder()
        .criteriaId(TestConstants.CRITERIA_ID)
        .offeringId(offeringId)
        .pqStartDate(Instant.now())
        .pqEndDate(Instant.now().plusSeconds(3600))
        .categories(new ArrayList<>())
        .representationAllowed(true)
        .status(TestConstants.STATUS_LOOKUP)
        .build();

    when(criteriaManagementFacade.fetchCriteria(any(), any())).thenReturn(criteriaIdResponseDTO);
    when(messageUtility.getMessage(any())).thenReturn(TestConstants.MESSAGE_UTILITY);

    mockMvc.perform(get("/v1/public/criteria")
            .header(TestConstants.HEADER_NAME_LANGUAGE_CODE, acceptLanguage)
            .param(TestConstants.PARAM_NAME_OFFERING_ID, offeringId.toString())
            .contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.status").value(HttpStatus.OK.getReasonPhrase()))
        .andExpect(jsonPath("$.data.offeringId").value(offeringId.toString()));

    assertNotNull(criteriaIdResponseDTO, TestConstants.RESPONSE_NULL);
  }

  @Test
  void testDeleteCriteria() throws Exception {
    UUID criteriaId = UUID.randomUUID();
    MessageResponseDTO messageResponseDTO = MessageResponseDTO.builder()
        .message(TestConstants.MESSAGE_UTILITY)
        .build();

    when(criteriaManagementFacade.deleteCriteria(any(), any())).thenReturn(messageResponseDTO);
    when(messageUtility.getMessage(any())).thenReturn(TestConstants.MESSAGE_UTILITY);

    mockMvc.perform(
            org.springframework.test.web.servlet.request.MockMvcRequestBuilders
                .delete("/v1/public/criteria/{criteriaId}", criteriaId)
                .header(TestConstants.HEADER_NAME_LANGUAGE_CODE, acceptLanguage)
                .contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.status").value(HttpStatus.OK.getReasonPhrase()))
        .andExpect(jsonPath("$.data.message").value(TestConstants.MESSAGE_UTILITY));

    assertNotNull(messageResponseDTO, TestConstants.RESPONSE_NULL);
  }

  @Test
  void testDeleteCategory() throws Exception {
    UUID categoryId = TestConstants.CATEGORY_CODE;
    UUID criteriaId = UUID.randomUUID();
    MessageResponseDTO messageResponseDTO = MessageResponseDTO.builder()
        .message(TestConstants.MESSAGE_UTILITY)
        .build();

    when(criteriaManagementFacade.deleteCategory(any(), any(), any())).thenReturn(messageResponseDTO);
    when(messageUtility.getMessage(any())).thenReturn(TestConstants.MESSAGE_UTILITY);

    mockMvc.perform(
            org.springframework.test.web.servlet.request.MockMvcRequestBuilders
                .delete("/v1/public/criteria/{criteriaId}/category/{categoryId}", criteriaId, categoryId)
                .header(TestConstants.HEADER_NAME_LANGUAGE_CODE, acceptLanguage)
                .contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.status").value(HttpStatus.OK.getReasonPhrase()))
        .andExpect(jsonPath("$.data.message").value(TestConstants.MESSAGE_UTILITY));

    assertNotNull(messageResponseDTO, TestConstants.RESPONSE_NULL);
  }

  @Test
  void testSyncCriteria() throws Exception {
    MessageResponseDTO messageResponseDTO = MessageResponseDTO.builder()
        .message(TestConstants.MESSAGE_UTILITY)
        .build();

    when(criteriaManagementFacade.syncCriteria()).thenReturn(messageResponseDTO);
    when(messageUtility.getMessage(any())).thenReturn(TestConstants.MESSAGE_UTILITY);

    mockMvc.perform(
            org.springframework.test.web.servlet.request.MockMvcRequestBuilders
                .put("/v1/public/criteria")
                .header(TestConstants.HEADER_NAME_LANGUAGE_CODE, acceptLanguage)
                .contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.status").value(HttpStatus.OK.getReasonPhrase()))
        .andExpect(jsonPath("$.data.message").value(TestConstants.MESSAGE_UTILITY));

    assertNotNull(messageResponseDTO, TestConstants.RESPONSE_NULL);
  }

  @Test
  void testSubmitRepresentation() throws Exception {
    UUID criteriaId = UUID.randomUUID();
    SubmitRepresentationResDTO responseDTO = new SubmitRepresentationResDTO();
    responseDTO.setRepresentation(true);
    responseDTO.setRemarks("Updated successfully");

    when(criteriaManagementFacade.submitRepresentationStatus(any(), any(), any())).thenReturn(responseDTO);
    when(messageUtility.getMessage(any())).thenReturn("Success");

    mockMvc.perform(put("/v1/public/criteria/{criteriaId}/submitRepresentationStatus", criteriaId)
                    .header("Accept-Language", acceptLanguage)
                    .contentType(MediaType.APPLICATION_FORM_URLENCODED))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.status").value(HttpStatus.OK.getReasonPhrase()))
            .andExpect(jsonPath("$.data.representation").value(true))
            .andExpect(jsonPath("$.data.remarks").value("Updated successfully"));
  }

  @Test
  void testGetRepresentation() throws Exception {
    UUID criteriaId = UUID.randomUUID();
    SubmitRepresentationResDTO responseDTO = new SubmitRepresentationResDTO();
    responseDTO.setRepresentation(true);
    responseDTO.setRemarks("Representation status fetched");

    when(criteriaManagementFacade.getRepresentationStatus(any(), any())).thenReturn(responseDTO);
    when(messageUtility.getMessage(any())).thenReturn("Success");

    mockMvc.perform(get("/v1/public/criteria/{criteriaId}/getRepresentationStatus", criteriaId)
                    .header("Accept-Language", acceptLanguage)
                    .contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.status").value(HttpStatus.OK.getReasonPhrase()))
            .andExpect(jsonPath("$.data.representation").value(true))
            .andExpect(jsonPath("$.data.remarks").value("Representation status fetched"));
  }
}