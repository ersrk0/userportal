
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * NumericResponseValidationImplTest: Tests the response validations.
 */

package in.gov.gem.app.fa.pq.validation.response.impl;

import in.gov.gem.app.fa.pq.constant.TestConstants;
import in.gov.gem.app.fa.pq.domain.entity.PqParticipant;
import in.gov.gem.app.fa.pq.domain.entity.PqQuestion;
import in.gov.gem.app.fa.pq.domain.entity.PqResponse;
import in.gov.gem.app.fa.pq.service.PqQuestionResponseService;
import in.gov.gem.app.fa.pq.transformer.QuestionResponseTransformer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Collections;
import java.util.List;
import java.util.UUID;

import static org.junit.Assert.assertFalse;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class NumericResponseValidationImplTest {

    private QuestionResponseTransformer questionResponseTransformer;
    private PqQuestionResponseService pqQuestionResponseService;
    private NumericResponseValidationImpl validation;
    private PqParticipant pqParticipant;

  @BeforeEach
  void setUp() {
    questionResponseTransformer = mock(QuestionResponseTransformer.class);
    pqQuestionResponseService = mock(PqQuestionResponseService.class);
    pqParticipant = mock(PqParticipant.class);

    validation = new NumericResponseValidationImpl(
            null,
            questionResponseTransformer,
            pqQuestionResponseService,
            null
    );
  }

    @Test
  void testValidateWithValidNumericResponse() {
    PqQuestion pqQuestion = new PqQuestion();
    List<String> response = List.of("12345");
    assertTrue(validation.validate(pqQuestion, response));
  }

  @Test
  void testValidateWithEmptyResponse() {
    PqQuestion pqQuestion = new PqQuestion();
    List<String> response = Collections.emptyList();
    assertFalse(validation.validate(pqQuestion, response));
  }


  @Test
  void testValidateWithNonNumericResponse() {
    PqQuestion pqQuestion = new PqQuestion();
    List<String> response = List.of("abc123");
    assertFalse(validation.validate(pqQuestion, response));
  }

  @Test
  void testBuildPqResponse() {
    UUID submissionId = UUID.randomUUID();
    PqQuestion pqQuestion = new PqQuestion();
    List<String> responses = List.of("42");
    PqResponse pqResponse = new PqResponse();
    PqResponse savedResponse = new PqResponse();

    when(questionResponseTransformer.toPqResponseEntityForInput(submissionId, pqQuestion, "42", TestConstants.STATUS_LOOKUP, pqParticipant)).thenReturn(pqResponse);
    when(pqQuestionResponseService.saveResponseEntity(pqResponse)).thenReturn(savedResponse);

    PqResponse result = validation.buildPqResponse(submissionId, pqQuestion, responses,TestConstants.STATUS_LOOKUP, pqParticipant);

    assertEquals(savedResponse, result);
    verify(questionResponseTransformer).toPqResponseEntityForInput(submissionId, pqQuestion, "42", TestConstants.STATUS_LOOKUP, pqParticipant);
    verify(pqQuestionResponseService).saveResponseEntity(pqResponse);
  }

  @Test
  void testUpdatePqResponse() {
    UUID submissionId = UUID.randomUUID();
    PqQuestion pqQuestion = new PqQuestion();
    List<String> responseList = List.of("99");
    PqResponse pqResponse = mock(PqResponse.class);
    PqResponse savedResponse = new PqResponse();

    when(pqQuestionResponseService.fetchResponseFromSubmissionId(submissionId)).thenReturn(pqResponse);
    when(pqQuestionResponseService.saveResponseEntity(pqResponse)).thenReturn(savedResponse);

    PqResponse result = validation.updatePqResponse(submissionId, pqQuestion, responseList);

    assertEquals(savedResponse, result);
    verify(pqResponse).setResponseText("99");
    verify(pqQuestionResponseService).saveResponseEntity(pqResponse);
  }
}