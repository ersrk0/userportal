
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * LanguageServiceImplTest: Tests the facade layer functioning.
 */

package in.gov.gem.app.fa.pq.service.impl;

import in.gov.gem.app.fa.pq.domain.entity.MessageLog;
import in.gov.gem.app.fa.pq.domain.repository.MessageLogRepository;
import in.gov.gem.app.fa.pq.response.MessageViewResponse;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class LanguageServiceImplTest {

    @InjectMocks
    private LanguageServiceImpl languageService;
    @Mock
    private MessageLogRepository messageLogRepository;

    @Test
    void messageView() {

        String messageCode="message_code";
        MessageLog byMessageCode=new MessageLog();
        byMessageCode.setMessage("Success");

        when(messageLogRepository.findByMessageCode(any())).thenReturn(byMessageCode);
        MessageViewResponse response = languageService.messageView(messageCode);
        assertEquals(response.getMessage(), byMessageCode.getMessage());

    }
}