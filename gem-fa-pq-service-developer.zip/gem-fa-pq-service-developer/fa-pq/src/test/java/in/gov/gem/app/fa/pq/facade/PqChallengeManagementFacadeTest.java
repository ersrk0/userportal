
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * Pq Clarification Msg Repository: Contains DB function to fetch Pq clarification msg data.
 */
package in.gov.gem.app.fa.pq.facade;

import in.gov.gem.app.fa.pq.domain.entity.*;
import in.gov.gem.app.fa.pq.facade.impl.PqChallengeManagementFacade;
import in.gov.gem.app.fa.pq.request.ChallengeReqDTO;
import in.gov.gem.app.fa.pq.response.ChallnegeResDTO;
import in.gov.gem.app.fa.pq.service.*;
import in.gov.gem.app.fa.pq.service.impl.PqChallenegeServiceImp;
import in.gov.gem.app.fa.pq.transformer.PqChallengeTransformer;
import in.gov.gem.app.fa.pq.utility.RequestUtil;
import in.gov.gem.app.service.attachment.utility.S3AttachmentUtility;
import in.gov.gem.app.service.dto.CoreLookupDto;
import in.gov.gem.app.service.pack.service.interfaces.CoreLookupService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class PqChallengeManagementFacadeTest {

    @Mock
    private RequestUtil requestUtil;
    @Mock private DocumentServiceUtil documentServiceUtil;
    @Mock private CoreLookupService coreLookupService;
    @Mock private DocumentMasterService documentMasterService;
    @Mock private DocAttachmentService docAttachmentService;
    @Mock private S3AttachmentUtility s3AttachmentUtility;
    @Mock private PqSubmissionService pqSubmissionService;
    @Mock private PqAssessmentService pqAssessmentService;
    @Mock private PqChallenegeServiceImp pqChallenegeService;
    @Mock private PqChallengeTransformer pqChallengeTransformer;

    @InjectMocks
    private PqChallengeManagementFacade pqChallengeManagementFacade;


    @Test
    void challenegeResponse_withFile_shouldReturnChallengeResDTO1() throws IOException, IOException {
        UUID assessmentId = UUID.randomUUID();
        MultipartFile mockFile = mock(MultipartFile.class);
        when(mockFile.getOriginalFilename()).thenReturn("document.pdf");
        when(mockFile.getContentType()).thenReturn("application/pdf");
        when(mockFile.getSize()).thenReturn(1024L);

        ChallengeReqDTO reqDTO = new ChallengeReqDTO();
        reqDTO.setSupportingDocuments(mockFile);

        UUID docId = UUID.randomUUID();
        UUID attachId = UUID.randomUUID();

        DocMaster docMaster = new DocMaster();
        CoreLookupDto lookupDto = new CoreLookupDto();
        lookupDto.setLookupCode("PDF");

        PqParticipant participant = new PqParticipant();
        PqSubmission submission = new PqSubmission();
        submission.setPqParticipantFk(participant);

        PqAssessment pqAssessment = new PqAssessment();
        pqAssessment.setId(1L);
        pqAssessment.setPqSubmission(submission);
        pqAssessment.setAssessmentStatusLookup("status");

        PqChallenge challenge = new PqChallenge();
        ChallnegeResDTO challengeResDTO = new ChallnegeResDTO();

        // Mock behaviors
        when(requestUtil.createRequestId()).thenReturn(docId, attachId);
        when(coreLookupService.findAllByLookupValueIgnoreCase("application/pdf")).thenReturn(List.of(lookupDto));
        when(documentMasterService.saveDocumentMaster(docId)).thenReturn(docMaster);
        when(pqAssessmentService.fetchAssessmentByAssessmentId(any())).thenReturn(pqAssessment);
        when(pqChallenegeService.createChallenege(participant, pqAssessment, reqDTO, docMaster, pqAssessment.getAssessmentStatusLookup()))
                .thenReturn(challenge);
        when(pqChallengeTransformer.toChallengeResDTO(challenge)).thenReturn(challengeResDTO);

        // Act
        ChallnegeResDTO result = pqChallengeManagementFacade.challenegeResponse(assessmentId, reqDTO);

        // Assert
        assertNotNull(result);
        assertEquals(challengeResDTO, result);
        verify(documentServiceUtil).fileSizeCheck(mockFile);
        verify(s3AttachmentUtility).uploadMultipart(any(), any(), eq(mockFile));
    }
}