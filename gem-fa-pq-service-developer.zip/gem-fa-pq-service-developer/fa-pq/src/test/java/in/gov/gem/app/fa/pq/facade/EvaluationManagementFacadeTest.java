
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * Pq Clarification Msg Repository: Contains DB function to fetch Pq clarification msg data.
 */
package in.gov.gem.app.fa.pq.facade;


import in.gov.gem.app.fa.pq.constant.Constants;
import in.gov.gem.app.fa.pq.constant.MessageConstants;
import in.gov.gem.app.fa.pq.controller.EvaluatorManagementController;
import in.gov.gem.app.fa.pq.domain.entity.PqCriteria;
import in.gov.gem.app.fa.pq.domain.entity.PqCriteriaMaster;
import in.gov.gem.app.fa.pq.domain.entity.PqParticipant;
import in.gov.gem.app.fa.pq.domain.entity.PqQuestion;
import in.gov.gem.app.fa.pq.domain.entity.PqResponse;
import in.gov.gem.app.fa.pq.domain.entity.PqSubmission;
import in.gov.gem.app.fa.pq.facade.impl.EvaluationManagementFacade;
import in.gov.gem.app.fa.pq.request.ScoreRequestDto;
import in.gov.gem.app.fa.pq.response.CategoriesSubmissionResponseDTO;
import in.gov.gem.app.fa.pq.response.SubmissionListResponseDTO;
import in.gov.gem.app.fa.pq.service.PqCriteriaMasterService;
import in.gov.gem.app.fa.pq.service.PqCriteriaService;
import in.gov.gem.app.fa.pq.service.PqParticipateService;
import in.gov.gem.app.fa.pq.service.PqQuestionService;
import in.gov.gem.app.fa.pq.service.PqResponseService;
import in.gov.gem.app.fa.pq.service.PqSubmissionService;
import in.gov.gem.app.fa.pq.service.impl.EvaluationManagementServiceImpl;
import in.gov.gem.app.fa.pq.transformer.PqSubmissionTransformer;
import in.gov.gem.app.service.core.utility.MessageUtility;
import in.gov.gem.app.service.dto.APIResponse;
import in.gov.gem.app.service.dto.PaginationParams;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.parameters.P;

import java.util.List;
import java.util.UUID;

import static com.amazonaws.util.ValidationUtils.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

class EvaluationManagementFacadeTest {

    @Mock
    private MessageUtility messageUtility;
    @InjectMocks
    private EvaluationManagementFacade evaluationManagementFacade;
    @Mock
    private PqCriteriaMasterService pqCriteriaMasterService;
    @Mock
    private PqCriteriaService pqCriteriaService;
    @Mock
    private PqParticipateService pqParticipateService;
    @Mock
    private PqSubmissionService pqSubmissionService;
    @Mock
    private PqSubmissionTransformer pqSubmissionTransformer;
    @Mock
    private PqQuestionService pqQuestionService;
    @Mock
    private PqResponseService pqResponseService;
    @Mock
    private EvaluationManagementServiceImpl evaluationManagementService;



    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testSaveScore() {
        // Arrange
        UUID questionId = UUID.randomUUID();
        String participationId = "test-participation-id";
        String acceptLanguage = "en";
        ScoreRequestDto scoreRequestDto = new ScoreRequestDto();
        PqQuestion pqQuestion = new PqQuestion();
        PqCriteria pqCriteria = new PqCriteria();
        pqQuestion.setPqCriteria(pqCriteria);
        PqParticipant pqParticipant = new PqParticipant();
        PqResponse pqResponse = new PqResponse();
        String expectedMessage = "Operation successful";

        when(pqQuestionService.fetchQuestionByQuestionId(questionId)).thenReturn(pqQuestion);
        when(pqParticipateService.fetchParticipantById(participationId, pqCriteria)).thenReturn(pqParticipant);
        when(pqResponseService.fetchPqResponsesByQuestionAndParticipant(pqQuestion, pqParticipant)).thenReturn(pqResponse);
        doNothing().when(evaluationManagementService).saveScore(scoreRequestDto, acceptLanguage, pqResponse);
        when(messageUtility.getMessage(MessageConstants.SUCCESS_MESSAGE)).thenReturn(expectedMessage);

        // Act
        String result = evaluationManagementFacade.saveScore(questionId, participationId, scoreRequestDto, acceptLanguage);

        // Assert
        assertNotNull(result, "Result should not be null");
        assertEquals(expectedMessage, result, "Returned message should match the expected message");
        verify(pqQuestionService, times(1)).fetchQuestionByQuestionId(questionId);
        verify(pqParticipateService, times(1)).fetchParticipantById(participationId, pqCriteria);
        verify(pqResponseService, times(1)).fetchPqResponsesByQuestionAndParticipant(pqQuestion, pqParticipant);
        verify(evaluationManagementService, times(1)).saveScore(scoreRequestDto, acceptLanguage, pqResponse);
        verify(messageUtility, times(1)).getMessage(MessageConstants.SUCCESS_MESSAGE);
    }


    @Test
    void testFetchCategoriesSubmission() {
        // Arrange
        UUID criteriaId = UUID.randomUUID();
        String participationId = "test-participation-id";
        String acceptLanguage = "en";

        PqCriteriaMaster pqCriteriaMaster = new PqCriteriaMaster();
        List<PqCriteria> pqCriteriaList = List.of(new PqCriteria(), new PqCriteria());
        List<PqParticipant> pqParticipants = List.of(new PqParticipant(), new PqParticipant());
        List<PqSubmission> pqSubmissions = List.of(new PqSubmission(), new PqSubmission());
        CategoriesSubmissionResponseDTO responseDTO1 = new CategoriesSubmissionResponseDTO();
        CategoriesSubmissionResponseDTO responseDTO2 = new CategoriesSubmissionResponseDTO();
        List<CategoriesSubmissionResponseDTO> responseDTOList = List.of(responseDTO1, responseDTO2);

        PaginationParams paginationParams = new PaginationParams();
        paginationParams.setPageNumber(1);
        paginationParams.setPageSize(10);

        Page<PqSubmission> pqSubmissionPage = new PageImpl<>(pqSubmissions);

        when(pqCriteriaMasterService.fetchActiveCriteriaFromCriteriaId(criteriaId)).thenReturn(pqCriteriaMaster);
        when(pqCriteriaService.fetchCategories(pqCriteriaMaster)).thenReturn(pqCriteriaList);
        when(pqParticipateService.fetchParticipantById(anyString(), any(PqCriteria.class)))
            .thenReturn(pqParticipants.get(0), pqParticipants.get(1));
        when(pqSubmissionService.fetchSubmissionByParticipantId(any(), any()))
            .thenReturn(pqSubmissionPage);
        when(pqSubmissionTransformer.toCategoriesSubmissionResponseDTO(any(PqSubmission.class)))
            .thenReturn(responseDTO1, responseDTO2);

        // Act
        SubmissionListResponseDTO result = evaluationManagementFacade.fetchCategoriesSubmission(criteriaId, participationId, acceptLanguage, paginationParams);

        // Assert
        assertNotNull(result, "Result should not be null");
        assertEquals(criteriaId, result.getCriteriaId(), "Criteria ID should match");
    }
}