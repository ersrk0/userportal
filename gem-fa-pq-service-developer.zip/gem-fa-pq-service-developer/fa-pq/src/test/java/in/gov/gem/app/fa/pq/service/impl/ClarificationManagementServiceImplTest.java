//package in.gov.gem.app.fa.pq.service.impl;
//
//import in.gov.gem.app.fa.pq.constant.TestConstants;
//import in.gov.gem.app.fa.pq.entity.DocMaster;
//import in.gov.gem.app.fa.pq.entity.PqClarification;
//import in.gov.gem.app.fa.pq.entity.PqResponse;
//import in.gov.gem.app.fa.pq.repository.PqClarificationRepository;
//import in.gov.gem.app.fa.pq.request.ClarificationRequestDTO;
//import in.gov.gem.app.fa.pq.request.SubmitClarificationRequestDTO;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.MockitoAnnotations;
//
//import java.util.UUID;
//
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.mockito.Mockito.times;
//import static org.mockito.Mockito.verify;
//import static org.mockito.Mockito.when;
//
//
//class ClarificationManagementServiceImplTest {
//
//    @Mock
//    private PqQuestionResponseServiceImpl pqQuestionResponseService;
//
//    @Mock
//    private PqClarificationRepository pqClarificationRepository;
//
//    @InjectMocks
//    private ClarificationManagementServiceImpl clarificationManagementServiceImpl;
//
//    @BeforeEach
//    void setUp() {
//        MockitoAnnotations.openMocks(this);
//    }
//
//    @Test
//    void testSubmitClarification() {
//        String acceptLanguage = "en";
//        UUID criteriaId = UUID.randomUUID();
//        UUID responseId = UUID.randomUUID();
//        DocMaster documentMaster = new DocMaster();
//        SubmitClarificationRequestDTO requestDTO = new SubmitClarificationRequestDTO();
//        requestDTO.setAdditionalInfo("Test clarification response");
//
//        PqResponse pqResponse = new PqResponse();
//        PqClarification pqClarification = new PqClarification();
//        pqClarification.setClarificationResponse("Test clarification response");
//        pqClarification.setDocMaster(documentMaster);
//
//        when(pqQuestionResponseService.fetchResponseFromResponseId(responseId)).thenReturn(pqResponse);
//        when(pqClarificationRepository.findByPqResponse(pqResponse)).thenReturn(pqClarification);
//        when(pqClarificationRepository.save(pqClarification)).thenReturn(pqClarification);
//
//        PqClarification result = clarificationManagementServiceImpl.submitClarification(acceptLanguage, criteriaId, responseId, documentMaster, requestDTO);
//
//        assertEquals("Test clarification response", result.getClarificationResponse());
//        assertEquals(documentMaster, result.getDocMaster());
//        verify(pqClarificationRepository, times(1)).save(pqClarification);
//    }
//
//    @Test
//    void testRequestClarification() {
//        String acceptLanguage = "en";
//        UUID responseId = UUID.randomUUID();
//        ClarificationRequestDTO requestDTO = new ClarificationRequestDTO();
//        requestDTO.setAdditionalQuery("Test additional query");
//
//        PqResponse pqResponse = new PqResponse();
//        PqClarification pqClarification = new PqClarification();
//        pqClarification.setClarificationText("Test additional query");
//
//        when(pqQuestionResponseService.fetchResponseFromResponseId(responseId)).thenReturn(pqResponse);
//        when(pqClarificationRepository.findByPqResponse(pqResponse)).thenReturn(pqClarification);
//        when(pqClarificationRepository.save(pqClarification)).thenReturn(pqClarification);
//
//        PqClarification result = clarificationManagementServiceImpl.getClarification(acceptLanguage, UUID.randomUUID(), responseId);
//
//        assertEquals("Test additional query", result.getClarificationText());
//        verify(pqClarificationRepository, times(1)).findByPqResponse(pqResponse);
//    }
//
//    @Test
//    void testGetClarification() {
//        String acceptLanguage = TestConstants.LANGUAGE_CODE;
//        UUID criteriaId = UUID.randomUUID();
//        UUID responseId = UUID.randomUUID();
//
//        PqResponse pqResponse = new PqResponse();
//        PqClarification pqClarification = new PqClarification();
//
//        when(pqQuestionResponseService.fetchResponseFromResponseId(responseId)).thenReturn(pqResponse);
//        when(pqClarificationRepository.findByPqResponse(pqResponse)).thenReturn(pqClarification);
//
//        PqClarification result = clarificationManagementServiceImpl.getClarification(acceptLanguage, criteriaId, responseId);
//
//        assertEquals(pqClarification, result);
//        verify(pqClarificationRepository, times(1)).findByPqResponse(pqResponse);
//    }
//}