
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * CriteriaManagementTransformerTest: Tests the transformer layer functioning.
 */

package in.gov.gem.app.fa.pq.transformer;

import in.gov.gem.app.fa.pq.constant.LookupConstants;
import in.gov.gem.app.fa.pq.constant.MessageConstants;
import in.gov.gem.app.fa.pq.constant.TestConstants;
import in.gov.gem.app.fa.pq.domain.entity.DocAttachment;
import in.gov.gem.app.fa.pq.domain.entity.DocMaster;
import in.gov.gem.app.fa.pq.domain.entity.PqCriteria;
import in.gov.gem.app.fa.pq.domain.entity.PqCriteriaMaster;
import in.gov.gem.app.fa.pq.facade.impl.CriteriaManagementFacade;
import in.gov.gem.app.fa.pq.request.CriteriaIdRequestDTO;
import in.gov.gem.app.fa.pq.response.*;
import in.gov.gem.app.fa.pq.service.DocAttachmentService;
import in.gov.gem.app.service.core.utility.MessageUtility;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Instant;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.times;

@ExtendWith(MockitoExtension.class)
class CriteriaManagementTransformerTest {

  @Mock
  private CriteriaManagementTransformer criteriaManagementTransformer;

  @Mock
  private CriteriaManagementFacade criteriaManagementFacade;
  @InjectMocks
  private CriteriaManagementTransformer transformer;
  private MessageUtility messageUtility;
  @Mock
  private DocAttachmentService docAttachmentService;

  @BeforeEach
  void setUp() {
    messageUtility = mock(MessageUtility.class);
    docAttachmentService = mock(DocAttachmentService.class);
    transformer = new CriteriaManagementTransformer(messageUtility,docAttachmentService);

  }

  @Test
  void toCriteriaIdResponseDTO() {
    UUID criteriaId = UUID.randomUUID();
    CriteriaIdRequestDTO requestDTO = CriteriaIdRequestDTO.builder()
        .offeringId(TestConstants.CRITERIA_ID)
        .pqStartDate(Instant.now())
        .pqEndDate(Instant.now())
        .representationAllowed(true)
        .status(TestConstants.STATUS_LOOKUP)
        .build();

    CriteriaIdResponseDTO responseDTO = transformer.toCriteriaIdResponseDTO(criteriaId, requestDTO);

    assertNotNull(responseDTO, TestConstants.RESPONSE_NULL);
  }

  @Test
  void toCriteriaIdResponse() {
    PqCriteria criteria1 = PqCriteria.builder()
        .pqCategoryId(UUID.randomUUID())
        .categoryCode(TestConstants.CATEGORY_CODE)
        .criteriaName(TestConstants.CRITERIA_NAME)
        .statusLookup(TestConstants.STATUS_LOOKUP)
        .build();

    PqCriteria criteria2 = PqCriteria.builder()
        .pqCategoryId(UUID.randomUUID())
        .categoryCode(TestConstants.CATEGORY_CODE_2)
        .criteriaName(TestConstants.CRITERIA_NAME)
        .statusLookup(TestConstants.STATUS_LOOKUP)
        .build();
    List<CategoryResponseDTO> categoryResponseDTOList = Arrays.asList(
            new CategoryResponseDTO(UUID.randomUUID(), "Technology", Boolean.TRUE),
            new CategoryResponseDTO(UUID.randomUUID(), "Finance", Boolean.TRUE),
            new CategoryResponseDTO(UUID.randomUUID(), "Healthcare", Boolean.FALSE)
    );

    PqCriteriaMaster pqCriteriaMaster = PqCriteriaMaster.builder().statusLookup(LookupConstants.Status.ACTIVE.getLookupCode()).build();

    List<PqCriteria> pqCriteriaList = Arrays.asList(criteria1, criteria2);

    CriteriaIdResponseDTO responseDTO = transformer.toCriteriaIdResponse(pqCriteriaMaster, categoryResponseDTOList);

    assertNotNull(responseDTO, TestConstants.RESPONSE_NULL);

  }

  @Test
  void toDeleteCriteriaMessageResponseDTO() {
    when(messageUtility.getMessage(MessageConstants.DELETE_CRITERIA)).thenReturn(TestConstants.MESSAGE_UTILITY);

    MessageResponseDTO responseDTO = transformer.toDeleteCriteriaMessageResponseDTO();

    assertNotNull(responseDTO, TestConstants.RESPONSE_NULL);
  }

  @Test
  void toDeleteCategoryMessageResponseDTO() {
    when(messageUtility.getMessage(MessageConstants.DELETE_CATEGORY)).thenReturn(TestConstants.MESSAGE_UTILITY);

    MessageResponseDTO responseDTO = transformer.toDeleteCategoryMessageResponseDTO();

    assertNotNull(responseDTO);
  }


  @Test
  void toPqCriteria_shouldMapAllFieldsCorrectly() {
    UUID criteriaId = UUID.randomUUID();
    CriteriaIdRequestDTO requestDTO = CriteriaIdRequestDTO.builder()
        .offeringId(UUID.randomUUID())
        .pqStartDate(Instant.now())
        .pqEndDate(Instant.now().plusSeconds(3600))
        .representationAllowed(true)
        .status(TestConstants.STATUS_LOOKUP)
        .build();
    CategoryResponseDTO categoryResponseDTO = CategoryResponseDTO.builder()
        .categoryCode(TestConstants.CATEGORY_CODE)
        .categoryName(TestConstants.CATEGORY_NAME)
        .build();
    PqCriteriaMaster pqCriteriaMaster = PqCriteriaMaster.builder()
        .masterCriteriaId(UUID.randomUUID())
        .build();

    PqCriteria pqCriteria = transformer.toPqCriteria(criteriaId, requestDTO, categoryResponseDTO, pqCriteriaMaster);

    assertNotNull(pqCriteria, TestConstants.RESPONSE_NULL);
  }


  @Test
  void toSyncCriteriaMessageResponseDTO() {
    when(messageUtility.getMessage(MessageConstants.CRITERIA_SYNCED)).thenReturn(TestConstants.MESSAGE_UTILITY);

    MessageResponseDTO responseDTO = transformer.toSyncCriteriaMessageResponseDTO();

    assertNotNull(responseDTO, TestConstants.RESPONSE_NULL);
  }

  @Test
  void testToSubmitRepresentationDTOWithUUID() {
    // Arrange
    DocMaster docMaster = new DocMaster();
    PqCriteriaMaster pqCriteriaMaster = PqCriteriaMaster.builder()
            .docMaster(docMaster)
            .remarks("Test Remarks")
            .isRepresentationAllowed(true)
            .build();

    DocAttachment docAttachment1 = DocAttachment.builder()
            .attachmentName("File1")
            .attachmentId(UUID.randomUUID()) // Generate UUID for attachmentId
            .attachmentSize(1024L)
            .build();

    DocAttachment docAttachment2 = DocAttachment.builder()
            .attachmentName("File2")
            .attachmentId(UUID.randomUUID()) // Generate UUID for attachmentId
            .attachmentSize(2048L)
            .build();

    List<DocAttachment> docAttachments = Arrays.asList(docAttachment1, docAttachment2);
    when(docAttachmentService.fetchAllAttachmentsByQuestion(docMaster)).thenReturn(docAttachments);

    // Act
    SubmitRepresentationResDTO result = transformer.toSubmitRepresentationDTO(pqCriteriaMaster);

    // Assert
    assertNotNull(result);
    assertEquals("Test Remarks", result.getRemarks());
    assertTrue(result.getRepresentation());
    assertNotNull(result.getRepresentationAttachmentDTOList());
    assertEquals(2, result.getRepresentationAttachmentDTOList().size());

    RepresentationAttachmentDTO attachment1 = result.getRepresentationAttachmentDTOList().get(0);
    assertEquals("File1", attachment1.getFileName());
    assertEquals(LookupConstants.DOCUMENT_PATH + docAttachment1.getAttachmentId(), attachment1.getFileUrl());
    assertEquals(docAttachment1.getAttachmentId(), attachment1.getAttachmentID());
    assertEquals(1024L, attachment1.getFileSize());

    RepresentationAttachmentDTO attachment2 = result.getRepresentationAttachmentDTOList().get(1);
    assertEquals("File2", attachment2.getFileName());
    assertEquals(LookupConstants.DOCUMENT_PATH + docAttachment2.getAttachmentId(), attachment2.getFileUrl());
    assertEquals(docAttachment2.getAttachmentId(), attachment2.getAttachmentID());
    assertEquals(2048L, attachment2.getFileSize());

    verify(docAttachmentService, times(1)).fetchAllAttachmentsByQuestion(docMaster);
  }
}