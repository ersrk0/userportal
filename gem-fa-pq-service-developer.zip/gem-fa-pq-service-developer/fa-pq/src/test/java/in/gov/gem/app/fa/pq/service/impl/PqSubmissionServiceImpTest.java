
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * Pq Clarification Msg Repository: Contains DB function to fetch Pq clarification msg data.
 */
package in.gov.gem.app.fa.pq.service.impl;

import in.gov.gem.app.fa.pq.domain.entity.PqCriteria;
import in.gov.gem.app.fa.pq.domain.entity.PqParticipant;
import in.gov.gem.app.fa.pq.domain.entity.PqQuestion;
import in.gov.gem.app.fa.pq.domain.entity.PqSubmission;
import in.gov.gem.app.fa.pq.domain.repository.PqSubmissionRepository;
import in.gov.gem.app.service.dto.PaginationParams;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class PqSubmissionServiceImpTest {

    @Mock
    private PqSubmissionRepository pqSubmissionRepository;

    @InjectMocks
    private PqSubmissionServiceImpl pqSubmissionServiceImpl;

    private PqCriteria pqCriteria;
    private PqParticipant pqParticipant;
    private PqSubmission pqSubmission;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        pqCriteria = new PqCriteria();
        pqParticipant = new PqParticipant();
        pqSubmission = new PqSubmission();
    }

    @Test
    void fetchSubmissionByIdShouldReturnSubmission() {
        UUID submissionId = UUID.randomUUID();
        PqSubmission expectedSubmission = new PqSubmission();

        when(pqSubmissionRepository.findBySubmissionIdAndIsDeleted(any(UUID.class), anyBoolean()))
            .thenReturn(expectedSubmission);

        PqSubmission result = pqSubmissionServiceImpl.fetchSubmissionById(submissionId);

        assertEquals(expectedSubmission, result);
    }

    @Test
    void testFetchSubmissionByCriteriaAndParticipantFk() {
        when(pqSubmissionRepository.findByPqCriteriaAndPqParticipantFk(any(), any()))
            .thenReturn(pqSubmission);

        PqSubmission result = pqSubmissionServiceImpl.fetchSubmissionByCriteriaAndParticipantFk(pqCriteria, pqParticipant);

        assertNotNull(result);
    }

    @Test
    void testSaveSubmission() {
        when(pqSubmissionRepository.save(pqSubmission)).thenReturn(pqSubmission);

        PqSubmission result = pqSubmissionServiceImpl.saveSubmission(pqSubmission);

        assertNotNull(result);
    }



    @Test
    void testFetchSubmissionByParticipantId() {
        // Arrange
        PqParticipant pqParticipant = new PqParticipant();
        List<PqSubmission> expectedSubmissions = List.of(new PqSubmission(), new PqSubmission());
        Pageable pageable = PageRequest.of(1, 10); // Convert PaginationParams to Pageable
        Page<PqSubmission> pqSubmissionPage = new PageImpl<>(expectedSubmissions, pageable, expectedSubmissions.size());

        when(pqSubmissionRepository.findByPqParticipantFk(eq(pqParticipant), eq(pageable))).thenReturn(pqSubmissionPage);

        // Act
        Page<PqSubmission> actualSubmissions = pqSubmissionServiceImpl.fetchSubmissionByParticipantId(pqParticipant, pageable);

        // Assert
        assertNotNull(actualSubmissions, "Result should not be null");
        assertEquals(expectedSubmissions.size(), actualSubmissions.getContent().size(), "Returned list size should match the expected size");
        assertEquals(expectedSubmissions, actualSubmissions.getContent(), "Returned list should match the expected list");
        verify(pqSubmissionRepository, times(1)).findByPqParticipantFk(eq(pqParticipant), eq(pageable));
    }
}
