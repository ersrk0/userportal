
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * SingleResponseValidationImplTest: Tests response validations.
 */

package in.gov.gem.app.fa.pq.validation.response.impl;

import in.gov.gem.app.fa.pq.constant.TestConstants;
import in.gov.gem.app.fa.pq.domain.entity.*;
import in.gov.gem.app.fa.pq.service.PqOptionService;
import in.gov.gem.app.fa.pq.service.PqQuestionResponseService;
import in.gov.gem.app.fa.pq.service.PqResponseOptionMappingService;
import in.gov.gem.app.fa.pq.transformer.QuestionResponseTransformer;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Collections;
import java.util.List;
import java.util.UUID;

import static com.jayway.jsonpath.internal.path.PathCompiler.fail;
import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class SingleResponseValidationImplTest {

  @InjectMocks
  private SingleResponseValidationImpl singleResponseValidation;

  @Mock
  private QuestionResponseTransformer questionResponseTransformer;
  @Mock
  private PqOptionService pqOptionService;
  @Mock
  private PqQuestionResponseService pqQuestionResponseService;
  @Mock
  private PqParticipant pqParticipant;

  @Mock
  private PqResponseOptionMappingService pqResponseOptionMappingService;
    private final SingleResponseValidationImpl validation =
            new SingleResponseValidationImpl(
                    mock(PqResponseOptionMappingService.class),
                    mock(QuestionResponseTransformer.class),
                    mock(PqQuestionResponseService.class),
                    mock(PqOptionService.class)
            );

  @Test
  void testValidateInvalidResponse() {
    PqQuestion pqQuestion = new PqQuestion();
    PqOption pqOption = PqOption.builder()
        .optionValue((TestConstants.OPTION_1))
        .build();
    pqQuestion.setOptions(Collections.singletonList(pqOption));
    List<String> response = Collections.singletonList(TestConstants.OPTION_2);
    assertFalse(validation.validate(pqQuestion, response), TestConstants.NOT_FALSE);
  }

  @Test
  void testValidateEmptyResponse() {
    PqQuestion pqQuestion = new PqQuestion();
    List<String> response = Collections.emptyList();
    assertFalse(validation.validate(pqQuestion, response), TestConstants.NOT_FALSE);
  }


  @Test
  void testValidateOptionsInvalidOptions() {
    PqQuestion pqQuestion = new PqQuestion();
    PqOption pqOption = PqOption.builder()
        .optionValue(TestConstants.OPTION_1)
        .build();
    pqQuestion.setOptions(Collections.singletonList(pqOption));
    List<String> response = Collections.singletonList(TestConstants.OPTION_2);
    assertFalse(validation.validateOptions(pqQuestion, response), TestConstants.NOT_FALSE);
  }

  @Test
  void testValidateOptionsEmptyOptions() {
    PqQuestion pqQuestion = new PqQuestion();
    pqQuestion.setOptions(Collections.emptyList());
    List<String> response = Collections.singletonList(TestConstants.OPTION_1);
    assertFalse(validation.validateOptions(pqQuestion, response), TestConstants.NOT_FALSE);
  }

  @Test
  void testBuildPqResponse() {
    UUID submissionId = UUID.randomUUID();
    PqQuestion pqQuestion = new PqQuestion();
    List<String> responses = List.of("1");

    PqResponse pqResponse = new PqResponse();
    pqResponse.setResponseText("This is a test response");
    PqResponse savedPqResponse = new PqResponse();
    savedPqResponse.setResponseText("This is a test response");
    PqOption pqOption = mock(PqOption.class);

    when(questionResponseTransformer.toPqResponseEntityForSelectedOptions(submissionId, pqQuestion, TestConstants.STATUS_LOOKUP,pqParticipant)).thenReturn(pqResponse);
    when(pqQuestionResponseService.saveResponseEntity(pqResponse)).thenReturn(savedPqResponse);
    when(pqOptionService.fetchOptionById(anyLong())).thenReturn(pqOption);
    var result = singleResponseValidation.buildPqResponse(submissionId, pqQuestion, responses, TestConstants.STATUS_LOOKUP, pqParticipant);
    Assertions.assertNotNull(result);
  }

  @Test
  void testSavePqResponseOptionMapping() {
    PqResponse pqResponse = new PqResponse();
    PqOption pqOption = new PqOption();
    try {
      var method = SingleResponseValidationImpl.class.getDeclaredMethod("savePqResponseOptionMapping", PqResponse.class, PqOption.class);
      method.setAccessible(true);
      method.invoke(singleResponseValidation, pqResponse, pqOption);
    } catch (Exception e) {
      fail("Exception thrown: " + e.getMessage());
    }

    verify(pqResponseOptionMappingService).savePqResponseOptionMapping(any(PqResponseOptionMap.class));
  }


  @Test
  void testUpdatePqResponseReturnsNullWhenResponseListIsNull() {
    UUID submissionId = UUID.randomUUID();
    PqResponse pqResponse = mock(PqResponse.class);
    List<String> responseList = List.of("1");
    when(pqQuestionResponseService.fetchResponseFromSubmissionId(submissionId)).thenReturn(pqResponse);
    when(pqResponse.getSelectedOptions()).thenReturn(List.of());

    PqResponse result = singleResponseValidation.updatePqResponse(submissionId, new PqQuestion(), responseList);
    assertNull(result);
  }

}