
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * DocumentServiceUtilImplTest: Tests the facade layer functioning.
 */

package in.gov.gem.app.fa.pq.service.impl;

import in.gov.gem.app.fa.pq.constant.LookupConstants;
import in.gov.gem.app.fa.pq.domain.entity.DocAttachment;
import in.gov.gem.app.fa.pq.domain.entity.DocMaster;
import in.gov.gem.app.fa.pq.domain.entity.PqClarification;
import in.gov.gem.app.fa.pq.domain.repository.DocAttachmentRepository;
import in.gov.gem.app.fa.pq.request.AttachmentTemplate;
import in.gov.gem.app.service.attachment.utility.S3AttachmentUtility;
import in.gov.gem.app.service.dto.CoreLookupDto;
import in.gov.gem.app.service.pack.service.interfaces.CoreLookupService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.UUID;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class DocAttachmentServiceImplTest {

  @Mock
  private DocAttachmentRepository docAttachmentRepository;

  @InjectMocks
  private DocAttachmentServiceImpl docAttachmentService;

  private DocMaster docMaster;

  private DocAttachment docAttachment;
  @Mock
  private S3AttachmentUtility s3AttachmentUtility;
  @Mock
  private CoreLookupService coreLookupService;

  @BeforeEach
  void setUp() {
    MockitoAnnotations.openMocks(this);

    docMaster = DocMaster.builder()
        .documentId(UUID.randomUUID())
        .build();

    docAttachment = DocAttachment.builder()
        .attachmentId(UUID.randomUUID())
        .docMaster(docMaster)
        .attachmentName("Test File")
        .attachmentPath("path/to/file")
        .attachmentTypeLookup("PDF")
        .attachmentSize(1024L)
        .statusLookup(LookupConstants.Status.ACTIVE.getLookupCode())
        .uploadedBy("testUser")
        .build();
  }

  @Test
  void testSaveDocumentDetails() {
    docAttachmentService.saveDocumentDetails(
        docMaster, "path/to/file", "PDF", "Test File", 1024L, UUID.randomUUID());

    verify(docAttachmentRepository, times(1)).save(any(DocAttachment.class));
  }

  @Test
  void testDeleteDocumentMetadata() {
    List<DocAttachment> docAttachments = List.of(docAttachment);

    docAttachmentService.deleteDocumentMetadata(docAttachments);

    assertEquals(LookupConstants.Status.INACTIVE.getLookupCode(), docAttachment.getStatusLookup());
    verify(docAttachmentRepository, times(1)).save(docAttachment);
  }

  @Test
  void testDeleteDocumentByAttachmentId() {
    UUID attachmentId = docAttachment.getAttachmentId();

    when(docAttachmentRepository.findByAttachmentIdAndDocMaster(attachmentId, docMaster))
        .thenReturn(docAttachment);

    docAttachmentService.deleteDocumentByAttachmentId(attachmentId, docMaster);

    assertEquals(LookupConstants.Status.INACTIVE.getLookupCode(), docAttachment.getStatusLookup());
    verify(docAttachmentRepository, times(1)).save(docAttachment);
  }

  @Test
  void testFetchAllAttachmentsByQuestion() {
    when(docAttachmentRepository.findAllByDocMaster(docMaster))
        .thenReturn(List.of(docAttachment));

    List<DocAttachment> result = docAttachmentService.fetchAllAttachmentsByQuestion(docMaster);

    assertEquals(1, result.size());
    assertEquals(docAttachment, result.get(0));
  }


  @Test
  void testViewAttachment() {
    // Arrange
    UUID attachmentId = UUID.randomUUID();
    String attachmentTypeLookup = "PDF";
    String attachmentPath = "path/to/file";
    String fileName = "Test File";
    String contentType = "application/pdf";
    byte[] fileBytes = new byte[]{1, 2, 3};

    DocAttachment docAttachment = DocAttachment.builder()
        .attachmentId(attachmentId)
        .attachmentTypeLookup(attachmentTypeLookup)
        .attachmentPath(attachmentPath)
        .attachmentName(fileName)
        .statusLookup(LookupConstants.Status.ACTIVE.getLookupCode())
        .build();

    CoreLookupDto coreLookupDto = CoreLookupDto.builder()
        .lookupValue(contentType)
        .build();

    when(docAttachmentRepository.findByAttachmentIdAndStatusLookup(attachmentId, LookupConstants.Status.ACTIVE.getLookupCode()))
        .thenReturn(docAttachment);
    when(coreLookupService.findByLookupCode(attachmentTypeLookup)).thenReturn(coreLookupDto);
    when(s3AttachmentUtility.downloadAsBytes("gem-consent-service", attachmentPath)).thenReturn(fileBytes);

    // Act
    AttachmentTemplate result = docAttachmentService.viewAttachment(attachmentId);

    // Assert
    assertNotNull(result);
    assertEquals(contentType, result.getAttachmentType());

  }

  @Test
  void testFetchDocAttachmentByDocMaster_Found() {
    UUID attachmentId = UUID.randomUUID();
    DocMaster docMaster = DocMaster.builder().documentId(UUID.randomUUID()).build();
    DocAttachment docAttachment = DocAttachment.builder().attachmentId(attachmentId).docMaster(docMaster).build();

    when(docAttachmentRepository.findByAttachmentIdAndDocMaster(attachmentId, docMaster)).thenReturn(docAttachment);

    DocAttachment result = docAttachmentService.fetchDocAttachmentByDocMaster(attachmentId, docMaster);

    assertEquals(docAttachment, result);
    verify(docAttachmentRepository).findByAttachmentIdAndDocMaster(attachmentId, docMaster);
  }

  @Test
  void testFetchDocumentMaster_Found() {
    DocMaster docMaster = DocMaster.builder().documentId(UUID.randomUUID()).build();
    PqClarification pqClarification = mock(PqClarification.class);
    DocAttachment docAttachment = DocAttachment.builder().docMaster(docMaster).build();

    when(pqClarification.getDocMaster()).thenReturn(docMaster);
    when(docAttachmentRepository.findByDocMaster(docMaster)).thenReturn(docAttachment);

    DocAttachment result = docAttachmentService.fetchDocumentMaster(pqClarification);

    assertEquals(docAttachment, result);
    verify(docAttachmentRepository).findByDocMaster(docMaster);
  }

}

