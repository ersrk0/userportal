
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * Pq Clarification Msg Repository: Contains DB function to fetch Pq clarification msg data.
 */
package in.gov.gem.app.fa.pq.service.impl;

import in.gov.gem.app.fa.pq.domain.entity.PqResponse;
import in.gov.gem.app.fa.pq.domain.repository.PqResponseRepository;
import in.gov.gem.app.fa.pq.request.ScoreRequestDto;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.mockito.Mockito.*;

class EvaluationManagementServiceImplTest {

    @Mock
    private PqResponseRepository pqResponseRepository;

    @InjectMocks
    private EvaluationManagementServiceImpl evaluationManagementService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testSaveScore() {

        ScoreRequestDto scoreRequestDto = new ScoreRequestDto();
        scoreRequestDto.setScore(8); // Example score
        String acceptLanguage = "en";
        PqResponse pqResponse = new PqResponse();

        evaluationManagementService.saveScore(scoreRequestDto, acceptLanguage, pqResponse);

        verify(pqResponseRepository, times(1)).save(pqResponse);
        assert pqResponse.getEvaluatorScore() == 8;
    }
}