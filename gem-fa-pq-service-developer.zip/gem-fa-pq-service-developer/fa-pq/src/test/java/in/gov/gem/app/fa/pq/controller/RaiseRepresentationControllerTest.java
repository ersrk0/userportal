package in.gov.gem.app.fa.pq.controller;

import in.gov.gem.app.fa.pq.constant.MessageConstants;
import in.gov.gem.app.fa.pq.facade.IRaiseRepresentationFacade;
import in.gov.gem.app.fa.pq.request.RespondRepresentationRequestDTO;
import in.gov.gem.app.fa.pq.response.RaiseRepresentationResponseDTO;
import in.gov.gem.app.fa.pq.response.RepresentationResponseDTO;
import in.gov.gem.app.fa.pq.response.RespondRepresentationResponseDTO;
import in.gov.gem.app.service.core.utility.MessageUtility;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.Mockito.times;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)
class RaiseRepresentationControllerTest {
  @InjectMocks
  private RaiseRepresentationController raiseRepresentationController;

  @Mock
  private IRaiseRepresentationFacade raiseRepresentationFacade;

  @Mock
  private MessageUtility messageUtility;

  private MockMvc mockMvc;
  private String acceptLanguage;

  @BeforeEach
  void setUp() {
    mockMvc = MockMvcBuilders.standaloneSetup(raiseRepresentationController).build();
    acceptLanguage = "eng";
  }

  @Test
  void testRaiseRepresentation() throws Exception {
    UUID criteriaId = UUID.randomUUID();
    MockMultipartFile file = new MockMultipartFile(
        "file", "test-file.pdf", MediaType.APPLICATION_PDF_VALUE, "test content".getBytes()
    );

    MockMultipartFile requestPart = new MockMultipartFile(
        "request", "", MediaType.APPLICATION_JSON_VALUE,
        "{\"ginCode\":\"123e4567-e89b-12d3-a456-426614174000\", \"representationText\":\"Test Representation\"}".getBytes()
    );

    RaiseRepresentationResponseDTO response = RaiseRepresentationResponseDTO.builder()
        .representationText("Test Representation")
        .build();

    Mockito.when(messageUtility.getMessage(anyString())).thenReturn("Representation raised successfully");
    Mockito.when(raiseRepresentationFacade.raiseRepresentation(anyString(), any(), any(), any()))
        .thenReturn(response);

    mockMvc.perform(multipart("/v1/public/criteria/{criteriaId}/representation/raise", criteriaId)
            .file(file)
            .file(requestPart)
            .header("Accept-Language", acceptLanguage))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.status").value(HttpStatus.OK.getReasonPhrase()))
        .andExpect(jsonPath("$.message").value("Representation raised successfully"));

    assertNotNull(response);
  }

  @Test
  void testFetchRepresentation() throws Exception {
    UUID criteriaId = UUID.randomUUID();
    UUID categoryCode = UUID.randomUUID();

    RepresentationResponseDTO response = RepresentationResponseDTO.builder()
        .criteriaId(criteriaId)
        .build();

    Mockito.when(messageUtility.getMessage(anyString())).thenReturn("Representation fetched successfully");
    Mockito.when(raiseRepresentationFacade.fetchRepresentation(anyString(), any(), any()))
        .thenReturn(response);

    mockMvc.perform(get("/v1/public/criteria/{criteriaId}/representation/{categoryCode}", criteriaId, categoryCode)
            .header("Accept-Language", acceptLanguage))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.status").value(HttpStatus.OK.getReasonPhrase()))
        .andExpect(jsonPath("$.message").value("Representation fetched successfully"));

    assertNotNull(response);
  }


  @Test
  @Disabled
  void testResponseRepresentation() throws Exception {
    RespondRepresentationResponseDTO response = RespondRepresentationResponseDTO.builder()
        .message(MessageConstants.REPRESENTATION_RESPONSE)
        .build();

    Mockito.when(messageUtility.getMessage(anyString())).thenReturn("Representation response submitted successfully");
    Mockito.when(raiseRepresentationFacade.responseRepresentation(
            eq("eng"),
            any(RespondRepresentationRequestDTO.class),
            isNull()))
        .thenReturn(response);

    mockMvc.perform(post("/v1/public/criteria/representation/respond")
            .header("Accept-Language", "eng")
            .contentType(MediaType.APPLICATION_JSON)
            .content("{\"responseText\":\"Test Response\"}"))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.status").value(HttpStatus.OK.getReasonPhrase()))
        .andExpect(jsonPath("$.message").value("Representation response submitted successfully"));

    Mockito.verify(raiseRepresentationFacade, times(1)).responseRepresentation(
        eq("eng"),
        any(RespondRepresentationRequestDTO.class),
        isNull()
    );
    Mockito.verify(messageUtility, times(1)).getMessage(anyString());
  }
}
