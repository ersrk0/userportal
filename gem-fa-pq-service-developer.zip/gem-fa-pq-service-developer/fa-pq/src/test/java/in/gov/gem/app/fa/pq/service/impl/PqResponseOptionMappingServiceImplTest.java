
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * PqQuestionServiceImplTest: Tests the service layer functioning.
 */

package in.gov.gem.app.fa.pq.service.impl;

import in.gov.gem.app.fa.pq.constant.TestConstants;
import in.gov.gem.app.fa.pq.domain.entity.PqResponse;
import in.gov.gem.app.fa.pq.domain.entity.PqResponseOptionMap;
import in.gov.gem.app.fa.pq.domain.repository.PqResponseOptionMapRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class PqResponseOptionMappingServiceImplTest {

  @Mock
  private PqResponseOptionMapRepository pqResponseOptionMapRepository;

  @InjectMocks
  private PqResponseOptionMappingServiceImpl pqResponseOptionMappingService;

  @Test
  void savePqResponseOptionMapping_callsRepositorySave() {
    PqResponseOptionMap mockEntity = new PqResponseOptionMap();
    pqResponseOptionMappingService.savePqResponseOptionMapping(mockEntity);
    verify(pqResponseOptionMapRepository, times(1)).save(mockEntity);
  }

  @Test
  void deleteById_callsRepositoryDeleteById() {
    Long id = 1L;
    pqResponseOptionMappingService.deleteById(id);
    verify(pqResponseOptionMapRepository, times(1)).deleteById(id);
  }

  @Test
  void testFindAllByPqResponse() {
    PqResponse pqResponse = new PqResponse();
    List<PqResponseOptionMap> expectedResponseOptionMaps = List.of(new PqResponseOptionMap(), new PqResponseOptionMap());
    when(pqResponseOptionMapRepository.findAllByPqResponse(pqResponse)).thenReturn(expectedResponseOptionMaps);

    List<PqResponseOptionMap> actualResponseOptionMaps = pqResponseOptionMappingService.findAllByPqResponse(pqResponse);

    assertEquals(expectedResponseOptionMaps, actualResponseOptionMaps, TestConstants.VALUES_NOT_EQUAL);
  }
}