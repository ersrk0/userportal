package in.gov.gem.app.fa.pq.controller;

import in.gov.gem.app.fa.pq.constant.TestConstants;
import in.gov.gem.app.fa.pq.facade.impl.ClarificationManagementFacade;
import in.gov.gem.app.fa.pq.request.ClarificationRequestDTO;
import in.gov.gem.app.fa.pq.response.GetClarificationResponseDTO;
import in.gov.gem.app.fa.pq.response.ReqClarificationResponseDTO;
import in.gov.gem.app.fa.pq.response.SubmitClarificationResponseDTO;
import in.gov.gem.app.service.core.utility.MessageUtility;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class ClarificationManagementControllerTest {

    @Mock
    private ClarificationManagementFacade classificationManagementFacade;

    @Mock
    private MessageUtility messageUtility;

    @InjectMocks
    private ClarificationManagementController clarificationManagementController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    @Disabled
    void testSubmitClarification() throws IOException {
        String acceptLanguage = "en";
        UUID responseId = UUID.randomUUID();
        MultipartFile file = mock(MultipartFile.class);
        ClarificationRequestDTO submitClarificationDTO = new ClarificationRequestDTO();
        SubmitClarificationResponseDTO responseDTO = new SubmitClarificationResponseDTO();

        when(classificationManagementFacade.submitClarification(acceptLanguage, responseId, file, submitClarificationDTO))
                .thenReturn(responseDTO);
        when(messageUtility.getMessage(anyString())).thenReturn("Success");

        ResponseEntity<?> response = clarificationManagementController.submitClarification(acceptLanguage, responseId, submitClarificationDTO);

        assertEquals(201, response.getStatusCodeValue());
    }

    @Test
    @Disabled
    void testRequestClarification() throws IOException {
        String acceptLanguage = "en";
        UUID responseId = UUID.randomUUID();
        MultipartFile file = mock(MultipartFile.class);

        ClarificationRequestDTO clarificationRequestDTO = new ClarificationRequestDTO();
        ReqClarificationResponseDTO responseDTO = new ReqClarificationResponseDTO();

        when(classificationManagementFacade.requestClarification(any(), any(), any(), any()))
                .thenReturn(responseDTO);
        when(messageUtility.getMessage(anyString())).thenReturn(TestConstants.MESSAGE_UTILITY);

        ResponseEntity<?> response = clarificationManagementController.requestClarification(acceptLanguage, responseId, clarificationRequestDTO);

        assertEquals(201, response.getStatusCodeValue());
    }

    @Test
    void testGetClarification() {
        String acceptLanguage = "en";
        UUID criteriaId = UUID.randomUUID();
        UUID responseId = UUID.randomUUID();
        GetClarificationResponseDTO responseDTO = new GetClarificationResponseDTO();

        when(classificationManagementFacade.getClarification(acceptLanguage, responseId))
                .thenReturn(responseDTO);
        when(messageUtility.getMessage(anyString())).thenReturn("Success");

        ResponseEntity<?> response = clarificationManagementController.getClarification(acceptLanguage, responseId);

        assertEquals(200, response.getStatusCodeValue());
        verify(classificationManagementFacade, times(1)).getClarification(acceptLanguage, responseId);
    }
}