
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * PqCriteriaServiceImplTest: Tests the service layer functioning.
 */
package in.gov.gem.app.fa.pq.service.impl;

import in.gov.gem.app.fa.pq.domain.entity.DocMaster;
import in.gov.gem.app.fa.pq.domain.entity.PqChallenge;
import in.gov.gem.app.fa.pq.domain.entity.PqChallengeResponse;
import in.gov.gem.app.fa.pq.domain.repository.PqChallengeResponseRepository;
import in.gov.gem.app.fa.pq.request.ResponseOfChallengeReqDTO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;

        import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class PqChallengeResponseImplTest {

    @Mock
    private PqChallengeResponseRepository pqChallengeResponseRepository;

    @InjectMocks
    private PqChallengeResponseImpl pqChallengeResponseImpl;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testCreateChallengeResponse() {
        // Arrange
        ResponseOfChallengeReqDTO reqDTO = new ResponseOfChallengeReqDTO();
        reqDTO.setResponseText("Test Response");

        PqChallenge pqChallenge = PqChallenge.builder()
                .statusLookUp("ACTIVE")
                .build();

        DocMaster docMaster = new DocMaster();

        PqChallengeResponse expectedResponse = PqChallengeResponse.builder()
                .responseText("Test Response")
                .pqChallenge(pqChallenge)
                .docMaster(docMaster)
                .statusLookUp("ACTIVE")
                .respondedBy("Not Known Yet")
                .build();

        when(pqChallengeResponseRepository.save(any(PqChallengeResponse.class))).thenReturn(expectedResponse);

        // Act
        PqChallengeResponse actualResponse = pqChallengeResponseImpl.createChallengeResponse(reqDTO, pqChallenge, docMaster);

        // Assert
        assertNotNull(actualResponse);
        assertEquals("Test Response", actualResponse.getResponseText());
        assertEquals("ACTIVE", actualResponse.getStatusLookUp());
        assertEquals("Not Known Yet", actualResponse.getRespondedBy());
        assertEquals(pqChallenge, actualResponse.getPqChallenge());
        assertEquals(docMaster, actualResponse.getDocMaster());
        verify(pqChallengeResponseRepository, times(1)).save(any(PqChallengeResponse.class));
    }
}
