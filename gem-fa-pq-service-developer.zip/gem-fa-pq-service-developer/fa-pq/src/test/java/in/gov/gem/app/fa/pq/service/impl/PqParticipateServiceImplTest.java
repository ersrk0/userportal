package in.gov.gem.app.fa.pq.service.impl;

import in.gov.gem.app.exception.generic.InvalidInputException;
import in.gov.gem.app.fa.pq.constant.ErrorMessageConstants;
import in.gov.gem.app.fa.pq.domain.entity.PqCriteria;
import in.gov.gem.app.fa.pq.domain.entity.PqParticipant;
import in.gov.gem.app.fa.pq.domain.repository.PqParticipationRepository;
import in.gov.gem.app.service.core.utility.MessageUtility;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class PqParticipateServiceImplTest {


  @Mock
  private PqParticipationRepository pqParticipationRepository;

  @Mock
  private MessageUtility messageUtility;

  @InjectMocks
  private PqParticipateServiceImpl pqParticipateService;

  @BeforeEach
  void setUp() {
    MockitoAnnotations.openMocks(this);
  }

  @Test
  void testFetchParticipantByIdSuccess() {
    String participationId = "test-participant-id";
    PqCriteria pqCriteria = new PqCriteria();
    PqParticipant pqParticipant = new PqParticipant();

    when(pqParticipationRepository.findByParticipantIdAndPqCriteriaAndIsAllowed(participationId, pqCriteria, Boolean.TRUE))
        .thenReturn(Optional.of(pqParticipant));

    PqParticipant result = pqParticipateService.fetchParticipantById(participationId, pqCriteria);

    assertNotNull(result, "Result should not be null");
    assertEquals(pqParticipant, result, "Returned participant should match the expected participant");
    verify(pqParticipationRepository, times(1))
        .findByParticipantIdAndPqCriteriaAndIsAllowed(participationId, pqCriteria, Boolean.TRUE);
  }

  @Test
  void testFetchParticipantByIdInvalidInputException() {
    String participationId = "invalid-participant-id";
    PqCriteria pqCriteria = new PqCriteria();
    String errorMessage = "Invalid participant";

    when(pqParticipationRepository.findByParticipantIdAndPqCriteriaAndIsAllowed(participationId, pqCriteria, Boolean.TRUE))
        .thenReturn(Optional.empty());
    when(messageUtility.getMessage(ErrorMessageConstants.INVALID_PARTICIPANT)).thenReturn(errorMessage);

    InvalidInputException exception = assertThrows(InvalidInputException.class, () ->
        pqParticipateService.fetchParticipantById(participationId, pqCriteria));
    assertEquals(errorMessage, exception.getMessage(), "Exception message should match the expected message");
    verify(pqParticipationRepository, times(1))
        .findByParticipantIdAndPqCriteriaAndIsAllowed(participationId, pqCriteria, Boolean.TRUE);
    verify(messageUtility, times(1)).getMessage(ErrorMessageConstants.INVALID_PARTICIPANT);
  }

  @Test
  void testFetchParticipantByCrtieria() {
    PqCriteria pqCriteria = new PqCriteria();
    List<PqParticipant> participants = List.of(new PqParticipant(), new PqParticipant());

    when(pqParticipationRepository.findByPqCriteria(pqCriteria)).thenReturn(participants);

    List<PqParticipant> result = pqParticipateService.fetchParticipantByCrtieria(pqCriteria);

    assertNotNull(result, "Result should not be null");
    assertEquals(participants.size(), result.size(), "Returned list size should match the expected size");
    verify(pqParticipationRepository, times(1)).findByPqCriteria(pqCriteria);
  }

  @Test
  void testSaveParticipant() {
    PqParticipant pqParticipant = new PqParticipant();

    pqParticipateService.saveParticipant(pqParticipant);
    verify(pqParticipationRepository, times(1)).save(pqParticipant);
  }
}
