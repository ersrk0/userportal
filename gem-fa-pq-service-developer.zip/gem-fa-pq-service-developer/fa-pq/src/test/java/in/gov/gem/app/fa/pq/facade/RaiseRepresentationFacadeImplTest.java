package in.gov.gem.app.fa.pq.facade;

import in.gov.gem.app.exception.generic.InvalidInputException;
import in.gov.gem.app.exception.generic.ServiceException;
import in.gov.gem.app.fa.pq.constant.ErrorMessageConstants;
import in.gov.gem.app.fa.pq.constant.LookupConstants;
import in.gov.gem.app.fa.pq.constant.TestConstants;
import in.gov.gem.app.fa.pq.domain.entity.DocAttachment;
import in.gov.gem.app.fa.pq.domain.entity.DocMaster;
import in.gov.gem.app.fa.pq.domain.entity.PqCriteria;
import in.gov.gem.app.fa.pq.domain.entity.PqCriteriaMaster;
import in.gov.gem.app.fa.pq.domain.entity.PqParticipant;
import in.gov.gem.app.fa.pq.domain.entity.PqRepresentation;
import in.gov.gem.app.fa.pq.domain.entity.PqRepresentationResponse;
import in.gov.gem.app.fa.pq.facade.impl.RaiseRepresentationFacadeImpl;
import in.gov.gem.app.fa.pq.request.RepresentationRequestDTO;
import in.gov.gem.app.fa.pq.request.RespondRepresentationRequestDTO;
import in.gov.gem.app.fa.pq.response.CriteriaRepresentationResponseDTO;
import in.gov.gem.app.fa.pq.response.RaiseRepresentationResponseDTO;
import in.gov.gem.app.fa.pq.response.RepresentationResponseDTO;
import in.gov.gem.app.fa.pq.response.RespondRepresentationResponseDTO;
import in.gov.gem.app.fa.pq.service.DocAttachmentService;
import in.gov.gem.app.fa.pq.service.DocumentMasterService;
import in.gov.gem.app.fa.pq.service.DocumentServiceUtil;
import in.gov.gem.app.fa.pq.service.PqCriteriaMasterService;
import in.gov.gem.app.fa.pq.service.PqCriteriaService;
import in.gov.gem.app.fa.pq.service.PqParticipateService;
import in.gov.gem.app.fa.pq.service.PqRepresentationService;
import in.gov.gem.app.fa.pq.transformer.PqRepresentationTransformer;
import in.gov.gem.app.fa.pq.utility.RequestUtil;
import in.gov.gem.app.service.attachment.utility.S3AttachmentUtility;
import in.gov.gem.app.service.core.utility.MessageUtility;
import in.gov.gem.app.service.dto.CoreLookupDto;
import in.gov.gem.app.service.pack.service.interfaces.CoreLookupService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class RaiseRepresentationFacadeImplTest {

  @InjectMocks
  private RaiseRepresentationFacadeImpl raiseRepresentationFacade;

  @Mock
  private PqCriteriaService pqCriteriaService;

  @Mock
  private PqRepresentationService pqRepresentationService;

  @Mock
  private DocumentServiceUtil documentServiceUtil;

  @Mock
  private DocAttachmentService docAttachmentService;

  @Mock
  private DocumentMasterService documentMasterService;

  @Mock
  private MessageUtility messageUtility;

  @Mock
  private PqRepresentationTransformer pqRepresentationTransformer;

  @Mock
  private S3AttachmentUtility s3AttachmentUtility;

  @Mock
  private CoreLookupService coreLookupService;

  @Mock
  private RequestUtil requestUtil;

  @Mock
  private PqCriteriaMasterService pqCriteriaMasterService;

  @Mock
  private PqParticipateService pqParticipateService;

  private UUID criteriaId;
  private RepresentationRequestDTO request;
  private MultipartFile[] files;

  @BeforeEach
  void setUp() {
    criteriaId = UUID.randomUUID();
    request = new RepresentationRequestDTO();
    request.setGinCode(UUID.randomUUID());
    request.setParticipantId(TestConstants.PARAM_NAME_OFFERING_ID);
    files = new MultipartFile[]{
        new MockMultipartFile(TestConstants.FILE_NAME, TestConstants.FILE_PATH, TestConstants.CONTENT_TYPE,
            "Sample content".getBytes())
    };
  }

  @Test
  void testRaiseRepresentationNotAllowed() {
    PqCriteriaMaster pqCriteriaMaster = new PqCriteriaMaster();
    PqCriteria pqCriteria = new PqCriteria();

    when(pqCriteriaMasterService.fetchActiveCriteriaFromCriteriaId(criteriaId)).thenReturn(pqCriteriaMaster);
    when(pqCriteriaService.fetchActiveCategory(pqCriteriaMaster, request.getGinCode())).thenReturn(pqCriteria);

    Assertions.assertThrows(InvalidInputException.class, () ->
        raiseRepresentationFacade.raiseRepresentation(TestConstants.LANGUAGE_CODE, criteriaId, request, files)
    );

  }



  @Test
  void testRaiseRepresentation() throws IOException {
    // Arrange
    RaiseRepresentationFacadeImpl facadeSpy = spy(raiseRepresentationFacade);

    String acceptLanguage = "en";
    UUID criteriaId = UUID.randomUUID();
    RepresentationRequestDTO request = new RepresentationRequestDTO();
    request.setGinCode(UUID.randomUUID());
    request.setParticipantId(String.valueOf(UUID.randomUUID()));
    MultipartFile[] files = new MultipartFile[]{
        new MockMultipartFile("file1", "test.pdf", "application/pdf", "Sample content".getBytes())
    };

    PqCriteriaMaster pqCriteriaMaster = new PqCriteriaMaster();
    pqCriteriaMaster.setIsRepresentationAllowed(true);

    PqCriteria pqCriteria = new PqCriteria();
    PqParticipant pqParticipant = new PqParticipant();
    DocMaster docMaster = new DocMaster();
    UUID representationId = UUID.randomUUID();

    List<DocAttachment> docAttachments = List.of(new DocAttachment());

    // Mock behavior
    when(pqCriteriaMasterService.fetchActiveCriteriaFromCriteriaId(criteriaId)).thenReturn(pqCriteriaMaster);
    when(pqCriteriaService.fetchActiveCategory(pqCriteriaMaster, request.getGinCode())).thenReturn(pqCriteria);
    when(pqParticipateService.fetchParticipantById(request.getParticipantId(), pqCriteria)).thenReturn(pqParticipant);
    when(requestUtil.generateRandomUUID()).thenReturn(representationId);
    when(requestUtil.createRequestId()).thenReturn(UUID.randomUUID());
    when(documentMasterService.saveDocumentMaster(any(UUID.class))).thenReturn(docMaster);
    doNothing().when(facadeSpy).activityLogDocumentUpload(any(MultipartFile.class), any()); // Use spy here
    when(docAttachmentService.fetchAllAttachmentsByQuestion(docMaster)).thenReturn(docAttachments);
    when(pqRepresentationTransformer.toRaiseRepresentationResponseDTO(docAttachments, docMaster, request, representationId))
        .thenReturn(new RaiseRepresentationResponseDTO());

    // Act
    RaiseRepresentationResponseDTO response = facadeSpy.raiseRepresentation(
        acceptLanguage, criteriaId, request, files);

    // Assert
    assertNotNull(response, TestConstants.RESPONSE_NULL);
  }

  @Test
  void testFetchRepresentationNoRepresentations() {
    UUID categoryCode = UUID.randomUUID();
    PqCriteriaMaster pqCriteriaMaster = new PqCriteriaMaster();
    PqCriteria pqCriteria = new PqCriteria();

    when(pqCriteriaMasterService.fetchActiveCriteriaFromCriteriaId(criteriaId)).thenReturn(pqCriteriaMaster);
    when(pqCriteriaService.fetchActiveCategory(pqCriteriaMaster, categoryCode)).thenReturn(pqCriteria);
    when(pqRepresentationService.fetchRepresentationByPqCriteria(pqCriteria)).thenReturn(Collections.emptyList());

    RepresentationResponseDTO response = raiseRepresentationFacade.fetchRepresentation("en", criteriaId, categoryCode);

    assertNotNull(response, TestConstants.RESPONSE_NULL);

  }

  @Test
  void testFetchRepresentation() {
    // Test data
    UUID criteriaId = UUID.randomUUID();
    UUID categoryCode = UUID.randomUUID();
    UUID attachmentId = UUID.randomUUID();

    PqCriteriaMaster pqCriteriaMaster = new PqCriteriaMaster();
    PqCriteria pqCriteria = new PqCriteria();

    PqRepresentation pqRepresentation = new PqRepresentation();
    DocMaster docMaster = new DocMaster();
    pqRepresentation.setDocMaster(docMaster);

    PqRepresentationResponse pqRepresentationResponse = new PqRepresentationResponse();
    pqRepresentationResponse.setDocMaster(docMaster); // Ensure DocMaster is not null

    DocAttachment docAttachment = new DocAttachment();
    docAttachment.setAttachmentId(attachmentId);
    docAttachment.setAttachmentTypeLookup("PDF");
    docAttachment.setAttachmentName("test.pdf");
    docAttachment.setAttachmentSize(456L);
    docAttachment.setStatusLookup(LookupConstants.Status.ACTIVE.getLookupCode());

    List<DocAttachment> docAttachments = List.of(docAttachment);
    List<PqRepresentation> pqRepresentations = List.of(pqRepresentation);

    CriteriaRepresentationResponseDTO criteriaRepresentationResponseDTO = new CriteriaRepresentationResponseDTO();

    when(pqCriteriaMasterService.fetchActiveCriteriaFromCriteriaId(criteriaId)).thenReturn(pqCriteriaMaster);
    when(pqCriteriaService.fetchActiveCategory(pqCriteriaMaster, categoryCode)).thenReturn(pqCriteria);
    when(pqRepresentationService.fetchRepresentationByPqCriteria(pqCriteria)).thenReturn(pqRepresentations);
    when(docAttachmentService.fetchAllAttachmentsByQuestion(docMaster)).thenReturn(docAttachments);
    when(pqRepresentationService.fetchResponse(pqRepresentation)).thenReturn(pqRepresentationResponse); // Mock fetchResponse
    when(pqRepresentationTransformer.toCriteriaRepresentationResponseDTO(any(), any(), any(), any(), any()))
        .thenReturn(criteriaRepresentationResponseDTO);

    RepresentationResponseDTO response = raiseRepresentationFacade.fetchRepresentation("en", criteriaId, categoryCode);

    assertNotNull(response, "Response should not be null");
    assertEquals(criteriaId, response.getCriteriaId(), "Criteria ID should match");
    assertNotNull(response.getRepresentations(), "Representations list should not be null");
    assertEquals(1, response.getRepresentations().size(), "Representations list size should be 1");

    CriteriaRepresentationResponseDTO representationResponse = response.getRepresentations().get(0);
    assertNotNull(representationResponse, "Representation response should not be null");
  }

    @Test
    void testResponseRepresentationWithoutFiles() throws IOException {
      String acceptLanguage = "en";
      UUID representationId = UUID.randomUUID();
      RespondRepresentationRequestDTO request = new RespondRepresentationRequestDTO();
      request.setRepresentationId(representationId);

      PqRepresentation pqRepresentation = new PqRepresentation();
      RespondRepresentationResponseDTO expectedResponse = new RespondRepresentationResponseDTO();

      when(pqRepresentationService.fetchRepresentationByRepresentationId(representationId))
          .thenReturn(pqRepresentation);
      when(pqRepresentationTransformer.toRespondRepresentationResponseDTO(representationId))
          .thenReturn(expectedResponse);

      RespondRepresentationResponseDTO result = raiseRepresentationFacade
          .responseRepresentation(acceptLanguage, request, null);

      assertNotNull(result);
      assertEquals(LookupConstants.REPRESENTATION_ANSWERED, pqRepresentation.getStatusLookup());
    }


  @Test
  void testResponseRepresentationWithFiles() throws IOException {
    // Setup
    String acceptLanguage = "en";
    UUID representationId = UUID.randomUUID();
    UUID documentId = UUID.randomUUID();
    RespondRepresentationRequestDTO request = new RespondRepresentationRequestDTO();
    request.setRepresentationId(representationId);

    MultipartFile file1 = mock(MultipartFile.class);
    MultipartFile[] files = new MultipartFile[]{file1};

    PqRepresentation pqRepresentation = new PqRepresentation();
    DocMaster docMaster = new DocMaster();
    RespondRepresentationResponseDTO expectedResponse = new RespondRepresentationResponseDTO();

    // Create spy of facade
    RaiseRepresentationFacadeImpl facadeSpy = spy(raiseRepresentationFacade);

    // Mock behavior
    when(pqRepresentationService.fetchRepresentationByRepresentationId(representationId))
        .thenReturn(pqRepresentation);
    when(requestUtil.createRequestId()).thenReturn(documentId);
    when(documentMasterService.saveDocumentMaster(documentId)).thenReturn(docMaster);
    when(pqRepresentationTransformer.toRespondRepresentationResponseDTO(representationId))
        .thenReturn(expectedResponse);

    // Use doNothing() for void method
    doNothing().when(facadeSpy).activityLogDocumentUpload(file1, docMaster);

    // Execute - Update method call to match the actual method signature
    RespondRepresentationResponseDTO result = facadeSpy.responseRepresentation(acceptLanguage, request, files);

    // Verify
    assertNotNull(result);
    assertEquals(LookupConstants.REPRESENTATION_ANSWERED, pqRepresentation.getStatusLookup());
  }


  @Test
  void testDocumentUploadProcessing() throws IOException {
    // Setup
    MultipartFile file = mock(MultipartFile.class);
    DocMaster documentMaster = mock(DocMaster.class);
    CoreLookupDto lookupDto = new CoreLookupDto();
    UUID attachmentId = UUID.randomUUID();
    String fileName = "test.pdf";
    String docType = "PDF";
    String filePath = "path/to/file.pdf";
    long fileSize = 1024L;

    // Mock file properties
    when(file.getOriginalFilename()).thenReturn(fileName);
    when(file.getContentType()).thenReturn("application/pdf");
    when(file.getSize()).thenReturn(fileSize);

    // Mock UUID generation
    when(requestUtil.createRequestId()).thenReturn(attachmentId);

    // Mock lookup service
    lookupDto.setLookupCode(docType);
    when(coreLookupService.findAllByLookupValueIgnoreCase(any())).thenReturn(List.of(lookupDto));

    // Mock path creation
    when(requestUtil.createPath(
        eq(LookupConstants.QUESTION_CREATION),
        eq(attachmentId),
        eq(fileName)
    )).thenReturn(filePath);

    // Mock document service
    doNothing().when(docAttachmentService).saveDocumentDetails(
        eq(documentMaster),
        eq(filePath),
        eq(docType),
        eq(fileName),
        eq(fileSize),
        eq(attachmentId)
    );

    // Mock S3 upload
    when(s3AttachmentUtility.uploadMultipart(
        eq("gem-consent-service"),
        eq(filePath),
        eq(file)
    )).thenReturn(true);

    // Execute
    raiseRepresentationFacade.activityLogDocumentUpload(file, documentMaster);

//    // Verify
//    verify(docAttachmentService).saveDocumentDetails(
//        documentMaster,
//        filePath,
//        docType,
//        fileName,
//        fileSize,
//        attachmentId
//    );
//    verify(s3AttachmentUtility).uploadMultipart("gem-consent-service", filePath, file);
  }
  }



