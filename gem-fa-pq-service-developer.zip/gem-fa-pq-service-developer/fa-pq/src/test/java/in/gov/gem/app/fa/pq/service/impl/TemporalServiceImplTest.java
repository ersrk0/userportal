
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * TemporalServiceImplTest: Tests the facade layer functioning.
 */

package in.gov.gem.app.fa.pq.service.impl;

import in.gov.gem.app.exception.generic.NotFoundException;
import in.gov.gem.app.fa.pq.constant.TestConstants;
import in.gov.gem.app.fa.pq.domain.entity.PqCriteria;
import in.gov.gem.app.fa.pq.domain.entity.PqCriteriaMaster;
import in.gov.gem.app.fa.pq.request.AttachmentTemplate;
import in.gov.gem.app.fa.pq.response.MessageResponseDTO;
import in.gov.gem.app.fa.pq.response.TemporalCriteriaResponseDTO;
import in.gov.gem.app.fa.pq.service.DocAttachmentService;
import in.gov.gem.app.fa.pq.service.PqCriteriaMasterService;
import in.gov.gem.app.fa.pq.service.PqCriteriaService;
import in.gov.gem.app.fa.pq.service.PqParticipateService;
import in.gov.gem.app.fa.pq.utility.RequestUtil;
import in.gov.gem.app.service.core.utility.MessageUtility;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class TemporalServiceImplTest {

  @InjectMocks
  private TemporalServiceImpl temporalService;

  @Mock
  private MessageUtility messageUtility;

  @Mock
  private PqCriteriaMasterService pqCriteriaMasterService;

  @Mock
  private PqCriteriaService pqCriteriaService;

  @Mock
  private DocAttachmentService docAttachmentService;

  @Mock
  private RequestUtil requestUtil;

  @Mock
  private PqParticipateService pqParticipationService;

  @BeforeEach
  void setUp() {
    temporalService = new TemporalServiceImpl(messageUtility,docAttachmentService, pqCriteriaMasterService,
         pqCriteriaService, requestUtil,  pqParticipationService);
  }

  @Test
  void testInitializeInMemoryData() {
    Map<String, TemporalCriteriaResponseDTO> inMemoryData = temporalService.getInMemoryData();

    assertEquals(3, inMemoryData.size(), "Expected inMemoryData to contain 3 entries");

    TemporalCriteriaResponseDTO criteria2 = inMemoryData.get("c00fcf61-9a54-4a83-afd1-2e5ff29b724e");
    assertNotNull(criteria2, "Criteria2 should not be null");

    TemporalCriteriaResponseDTO criteria3 = inMemoryData.get("8bf2816d-d9f3-45c9-b09d-d256c65b8c3f");
    assertNotNull(criteria3, "Criteria3 should not be null");

  }

  @Test
  void testGetTemporalCriteriaValidCriteriaId() {
    String validCriteriaKey = "a6b46a3c-99ce-4d06-9775-7032b1fd24de";
    TemporalCriteriaResponseDTO criteria = temporalService.getTemporalCriteria(UUID.fromString(validCriteriaKey));

    assertNotNull(criteria, TestConstants.RESPONSE_NULL);
  }

  @Test
  void testGetTemporalCriteriaInvalidCriteriaId() {
    UUID invalidCriteriaId = UUID.randomUUID();

    when(messageUtility.getMessage(any())).thenReturn(TestConstants.MESSAGE_UTILITY);

    Assertions.assertThrows(NotFoundException.class, () -> {
      temporalService.getTemporalCriteria(invalidCriteriaId);
    }, TestConstants.EXCEPTION_NOT_THROWN);
  }


  @Test
  void testViewAttachmentReturnsAttachmentTemplate() {
    UUID attachmentId = UUID.randomUUID();
    AttachmentTemplate expectedTemplate = new AttachmentTemplate();

    when(docAttachmentService.viewAttachment(any())).thenReturn(expectedTemplate);

    AttachmentTemplate result = temporalService.viewAttachment(attachmentId);

    assertNotNull(result, TestConstants.RESPONSE_NULL);
  }


  @Test
  void testSaveParticipantsSuccess() {
    UUID criteriaId = UUID.randomUUID();
    String languageCode = TestConstants.LANGUAGE_CODE;

    PqCriteriaMaster pqCriteriaMaster = new PqCriteriaMaster();
    PqCriteria criteria1 = new PqCriteria();
    PqCriteria criteria2 = new PqCriteria();
    List<PqCriteria> pqCriteriaList = List.of(criteria1, criteria2);

    when(pqCriteriaMasterService.fetchCriteriaFromCriteriaId(any())).thenReturn(pqCriteriaMaster);
    when(pqCriteriaService.fetchCategories(any())).thenReturn(pqCriteriaList);
    when(requestUtil.createRequestId()).thenReturn(UUID.randomUUID());
    when(messageUtility.getMessage(any())).thenReturn(TestConstants.MESSAGE_UTILITY);

    MessageResponseDTO response = temporalService.saveParticipants(criteriaId, languageCode);

    assertNotNull(response, TestConstants.RESPONSE_NULL);

  }

  @Test
  void testSaveParticipantsEmptyCriteriaList() {
    UUID criteriaId = UUID.randomUUID();
    String languageCode = TestConstants.LANGUAGE_CODE;
    PqCriteriaMaster pqCriteriaMaster = new PqCriteriaMaster();

    when(pqCriteriaMasterService.fetchCriteriaFromCriteriaId(criteriaId)).thenReturn(pqCriteriaMaster);
    when(pqCriteriaService.fetchCategories(pqCriteriaMaster)).thenReturn(List.of());
    when(requestUtil.createRequestId()).thenReturn(UUID.randomUUID());
    when(messageUtility.getMessage(any())).thenReturn(TestConstants.MESSAGE_UTILITY);

    MessageResponseDTO response = temporalService.saveParticipants(criteriaId, languageCode);

    assertNotNull(response, TestConstants.RESPONSE_NULL);

  }
}