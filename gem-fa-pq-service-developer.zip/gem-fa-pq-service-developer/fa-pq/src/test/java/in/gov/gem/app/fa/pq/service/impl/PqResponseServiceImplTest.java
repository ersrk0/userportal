package in.gov.gem.app.fa.pq.service.impl;

import in.gov.gem.app.exception.generic.ServiceException;
import in.gov.gem.app.fa.pq.constant.TestConstants;
import in.gov.gem.app.fa.pq.domain.entity.PqQuestion;
import in.gov.gem.app.fa.pq.domain.entity.PqResponse;
import in.gov.gem.app.fa.pq.domain.repository.PqResponseRepository;
import in.gov.gem.app.service.core.utility.MessageUtility;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class PqResponseServiceImplTest {

  @Mock
  private PqResponseRepository pqResponseRepository;

  @Mock
  private MessageUtility messageUtility;

  @InjectMocks
  private PqResponseServiceImpl pqResponseServiceImpl;

  @BeforeEach
  void setUp() {
    MockitoAnnotations.openMocks(this);
  }

  @Test
  void testFetchPqResponseByIdWhenResponseExistsShouldReturnResponse() {
    UUID responseId = UUID.randomUUID();
    PqResponse expectedResponse = PqResponse.builder()
        .pqResponseId(responseId)
        .build();

    when(pqResponseRepository.findByPqResponseId(responseId)).thenReturn(expectedResponse);

    PqResponse result = pqResponseServiceImpl.fetchPqResponseById(responseId);

    assertNotNull(result, TestConstants.RESPONSE_NULL);
  }

  @Test
  void testFetchPqResponseByIdWhenResponseDoesNotExistShouldThrowServiceException() {
    UUID responseId = UUID.randomUUID();
    when(pqResponseRepository.findByPqResponseId(responseId)).thenReturn(null);
    when(messageUtility.getMessage(any())).thenReturn(TestConstants.MESSAGE_UTILITY);

    Assertions.assertThrows(ServiceException.class, () ->
        pqResponseServiceImpl.fetchPqResponseById(responseId)
    );

  }


  @Test
  void testFetchPqResponsesByQuestionShouldReturnResponses() {
    PqQuestion pqQuestion = PqQuestion.builder().pqQuestionId(UUID.randomUUID()).build();
    PqResponse response1 = PqResponse.builder().pqResponseId(UUID.randomUUID()).build();
    PqResponse response2 = PqResponse.builder().pqResponseId(UUID.randomUUID()).build();
    List<PqResponse> expectedResponses = List.of(response1, response2);

    when(pqResponseRepository.findByPqQuestionFk(any())).thenReturn(expectedResponses);

    List<PqResponse> result = pqResponseServiceImpl.fetchPqResponsesByQuestion(pqQuestion);

    assertNotNull(result, TestConstants.RESPONSE_NULL);
  }
}