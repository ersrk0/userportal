package in.gov.gem.app.fa.pq.transformer;

import in.gov.gem.app.fa.pq.constant.LookupConstants;
import in.gov.gem.app.fa.pq.domain.entity.*;
import in.gov.gem.app.fa.pq.response.*;
import in.gov.gem.app.fa.pq.service.DocAttachmentService;
import in.gov.gem.app.fa.pq.service.PqResponseOptionMappingService;
import in.gov.gem.app.fa.pq.service.impl.PqQuestionResponseServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class ClassificationManagementTransformerTest {

    @Mock
    private PqResponseOptionMappingService pqResponseOptionMappingService;
    @Mock
    private PqQuestionResponseServiceImpl pqQuestionResponseService;

    @Mock
    private DocAttachmentService docAttachmentService;


    private ClassificationManagementTransformer classificationManagementTransformer;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        classificationManagementTransformer = new ClassificationManagementTransformer(
                pqQuestionResponseService,
                pqResponseOptionMappingService,
                docAttachmentService
        );
    }

    @Test
    void toSubmitClarificationResponseDTO() {
        PqClarificationMsg pqClarificationMsg = new PqClarificationMsg();
        pqClarificationMsg.setId(1L);

        SubmitClarificationResponseDTO result =
            classificationManagementTransformer.toSubmitClarificationResponseDTO(pqClarificationMsg);

        assertEquals(pqClarificationMsg.getId(), result.getAdditionalInfoId());
    }

    @Test
    void testToGetClarificationResponseDTO() {
        // Mock input data
        UUID responseId = UUID.randomUUID();
        PqClarificationMsg[] pqClarificationMsgs = new PqClarificationMsg[1];
        PqClarificationMsg pqClarificationMsg = new PqClarificationMsg();
        pqClarificationMsg.setId(1L);
        pqClarificationMsg.setMsgText("Sample Message");
        pqClarificationMsg.setSenderTypeLookup(LookupConstants.SenderType.BIDDER.getLookupCode());
        pqClarificationMsg.setCreatedTimestamp(Instant.now());
        pqClarificationMsg.setUpdateTimestamp(Instant.now());
        pqClarificationMsgs[0] = pqClarificationMsg;

        PqResponse pqResponse = new PqResponse();
        PqQuestion pqQuestion = new PqQuestion();
        pqQuestion.setQuestionTypeLookup(LookupConstants.INPUT_TYPE_SINGLE_CHOICE);
        pqResponse.setPqQuestionFk(pqQuestion);

        List<PqResponseOptionMap> responseOptionMaps = new ArrayList<>();
        PqResponseOptionMap optionMap = new PqResponseOptionMap();
        PqOption pqOption = new PqOption();
        pqOption.setOptionValue("Option 1");
        optionMap.setPqOption(pqOption);
        responseOptionMaps.add(optionMap);

        List<DocAttachment> docAttachments = new ArrayList<>();
        DocAttachment docAttachment = new DocAttachment();
        docAttachment.setAttachmentId(UUID.randomUUID());
        docAttachment.setAttachmentName("file.pdf");
        docAttachment.setAttachmentPath("/path/to/file.pdf");
        docAttachments.add(docAttachment);

        DocMaster docMaster = new DocMaster();
        pqClarificationMsg.setDocMaster(docMaster);

        // Mock behavior
        when(pqQuestionResponseService.fetchResponseFromResponseId(responseId)).thenReturn(pqResponse);
        when(pqResponseOptionMappingService.findAllByPqResponse(pqResponse)).thenReturn(responseOptionMaps);
        when(docAttachmentService.fetchAllAttachmentsByQuestion(docMaster)).thenReturn(docAttachments);

        // Call the method under test
        GetClarificationResponseDTO result = classificationManagementTransformer.toGetClarificationResponseDTO(pqClarificationMsgs, responseId);

        // Assertions
        assertNotNull(result);
        assertEquals(responseId, result.getResponseID());
        assertEquals("Option 1", result.getResponse());
        assertEquals(1, result.getClarification().size());

        ClarificationDTO clarificationDTO = result.getClarification().get(0);
        assertEquals("1", clarificationDTO.getClarificationId());
        assertEquals("Bidder", clarificationDTO.getResponsBy());
        assertEquals("Sample Message", clarificationDTO.getResponseText());
        assertEquals(1, clarificationDTO.getAttachments().size());

        ClarificationAttachmentDTO attachmentDTO = clarificationDTO.getAttachments().get(0);
        assertEquals(docAttachment.getAttachmentId(), attachmentDTO.getAttachmentID());
        assertEquals(docAttachment.getAttachmentName(), attachmentDTO.getFileName());
        assertEquals(docAttachment.getAttachmentPath(), attachmentDTO.getFileUrl());

        // Verify interactions
        verify(pqQuestionResponseService, times(1)).fetchResponseFromResponseId(responseId);
        verify(pqResponseOptionMappingService, times(1)).findAllByPqResponse(pqResponse);
        verify(docAttachmentService, times(1)).fetchAllAttachmentsByQuestion(docMaster);
    }

    @Test
    void toReqClarificationResponseDTO() {
        PqClarificationMsg pqClarificationMsg = new PqClarificationMsg();
        pqClarificationMsg.setId(1L);

        ReqClarificationResponseDTO result =
            classificationManagementTransformer.toReqClarificationResponseDTO(pqClarificationMsg);

        assertEquals(pqClarificationMsg.getId(), result.getClarificationId());
    }
}