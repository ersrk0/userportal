
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * Pq Clarification Msg Repository: Contains DB function to fetch Pq clarification msg data.
 */
package in.gov.gem.app.fa.pq.service.impl;

import in.gov.gem.app.fa.pq.domain.entity.PqAssessment;
import in.gov.gem.app.fa.pq.domain.entity.PqSubmission;
import in.gov.gem.app.fa.pq.domain.repository.PqAssessmentRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class PqAssessmentServiceImpTest {

    @Mock
    private PqAssessmentRepository pqAssessmentRepository;

    @InjectMocks
    private PqAssessmentServiceImp pqAssessmentServiceImp;

    @Test
    void fetchAssessmentBySubmission_shouldReturnExpectedAssessment() {

        PqSubmission pqSubmission = new PqSubmission();
        PqAssessment expectedAssessment = new PqAssessment();

        when(pqAssessmentRepository.findByPqSubmission(pqSubmission)).thenReturn(expectedAssessment);

        PqAssessment result = pqAssessmentServiceImp.fetchAssessmentBySubmission(pqSubmission);

        assertEquals(expectedAssessment, result);
        verify(pqAssessmentRepository).findByPqSubmission(pqSubmission);
    }
}
