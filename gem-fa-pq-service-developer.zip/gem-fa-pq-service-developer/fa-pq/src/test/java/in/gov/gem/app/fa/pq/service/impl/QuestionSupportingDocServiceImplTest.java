
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * QuestionSupportingDocServiceImplTest: Tests the facade layer functioning.
 */

package in.gov.gem.app.fa.pq.service.impl;

import in.gov.gem.app.fa.pq.constant.LookupConstants;
import in.gov.gem.app.fa.pq.constant.TestConstants;
import in.gov.gem.app.fa.pq.domain.entity.PqQuestion;
import in.gov.gem.app.fa.pq.domain.entity.QuestionSupportingDoc;
import in.gov.gem.app.fa.pq.domain.repository.QuestionSupportingDocRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Instant;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class QuestionSupportingDocServiceImplTest {

    @InjectMocks
    private QuestionSupportingDocServiceImpl questionSupportingDocService;

    @Mock
    private QuestionSupportingDocRepository questionSupportingDocRepository;

    private PqQuestion mockPqQuestion;
    private QuestionSupportingDoc mockSupportingDoc;

    @BeforeEach
    void setUp() {

        mockPqQuestion = new PqQuestion();
        mockPqQuestion.setId(1L);
        mockPqQuestion.setQuestionText("Test Question");

        mockSupportingDoc = QuestionSupportingDoc.builder()
                .id(1L)
                .pqQuestion(mockPqQuestion)
                .documentPath("/test/path/document.pdf")
                .fileType("PDF")
                .documentName("test-document.pdf")
                .uploadedOn(Instant.now())
                .uploadedBy("SEED")
                .build();
    }

    @Test
    void testSaveDocument() {

        String filePath = "/test/path/document.pdf";
        String docType = "PDF";
        String fileName = "test-document.pdf";
        UUID attachmentId = UUID.fromString("35b127bd-73f9-4950-bff6-ca9767ea4e8e");

        when(questionSupportingDocRepository.save(any(QuestionSupportingDoc.class)))
                .thenReturn(mockSupportingDoc);

        questionSupportingDocService.saveDocument(mockPqQuestion, filePath, docType, fileName, attachmentId);

        ArgumentCaptor<QuestionSupportingDoc> captor = ArgumentCaptor.forClass(QuestionSupportingDoc.class);
        verify(questionSupportingDocRepository, times(1)).save(captor.capture());

        QuestionSupportingDoc savedDoc = captor.getValue();
        assertNotNull(savedDoc, TestConstants.RESPONSE_NULL);
    }

    @Test
    void testDeleteDocumentShouldSetStatusInactiveAndSave() {
        questionSupportingDocService.deleteDocument(mockSupportingDoc);

        assertEquals(LookupConstants.Status.INACTIVE.getLookupCode(), mockSupportingDoc.getStatusLookup());
    }


    @Test
    void testFetchDocumentByQuestionIdShouldReturnDocument() {
        UUID attachmentId = mockSupportingDoc.getDocumentId();

        when(questionSupportingDocRepository.findByPqQuestionAndDocumentId(any(), any()))
            .thenReturn(mockSupportingDoc);
        QuestionSupportingDoc result =
            questionSupportingDocService.fetchDocumentByQuestionId(mockPqQuestion, attachmentId);

        assertNotNull(result, TestConstants.RESPONSE_NULL);

    }
}
