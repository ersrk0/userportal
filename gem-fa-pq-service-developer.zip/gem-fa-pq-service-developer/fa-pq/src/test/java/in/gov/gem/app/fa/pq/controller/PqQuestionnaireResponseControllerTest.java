
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * Criteria Management ServiceImpl: Implements the Criteria Management service layer.
 */

package in.gov.gem.app.fa.pq.controller;

import in.gov.gem.app.exception.generic.ServiceException;
import in.gov.gem.app.exception.utility.ErrorConstant;
import in.gov.gem.app.fa.pq.constant.MessageConstants;
import in.gov.gem.app.fa.pq.constant.TestConstants;
import in.gov.gem.app.fa.pq.facade.impl.PqQuestionnaireResponseFacade;
import in.gov.gem.app.fa.pq.request.QuestionnaireResponseSubmitDTO;
import in.gov.gem.app.fa.pq.request.QuestionnaireResponseUpdateDTO;
import in.gov.gem.app.fa.pq.request.SubmissionStatusReqDTO;
import in.gov.gem.app.fa.pq.request.UpdateSubmissionEvaluationDTO;
import in.gov.gem.app.fa.pq.response.CriteriaResponsesDTO;
import in.gov.gem.app.fa.pq.response.MessageResponseDTO;
import in.gov.gem.app.fa.pq.response.ParticipantSubmissionsResponseDTO;
import in.gov.gem.app.fa.pq.response.PqDocumentsAnswerDTO;
import in.gov.gem.app.fa.pq.response.PqQuestionResponseDTO;
import in.gov.gem.app.fa.pq.response.SubmitQuestionsResponseDTO;
import in.gov.gem.app.fa.pq.response.UpdateSubmissionEvaluationResponseDTO;
import in.gov.gem.app.service.core.utility.MessageUtility;
import in.gov.gem.app.service.dto.APIResponse;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class PqQuestionnaireResponseControllerTest {

    @InjectMocks
    PqQuestionnaireResponseController pqQuestionnaireResponseController;

    @Mock
    private PqQuestionnaireResponseFacade pqQuestionnaireResponseFacade;

    @Mock
    private MessageUtility messageUtility;

    private MockMvc mockMvc;
    private String acceptLanguage;

    private UUID criteriaId;
    private UUID questionId;
    private UUID submissionId;
    private UUID attachmentId;
    private String participantId;
    private UpdateSubmissionEvaluationDTO updateSubmissionEvaluationRequest;


  @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(pqQuestionnaireResponseController).build();
        acceptLanguage = TestConstants.LANGUAGE_CODE;
        criteriaId = UUID.randomUUID();
        questionId = UUID.randomUUID();
        submissionId = UUID.randomUUID();
        attachmentId = UUID.randomUUID();
        participantId = UUID.randomUUID().toString();
    updateSubmissionEvaluationRequest = new UpdateSubmissionEvaluationDTO();

  }

    @Test
     void testSubmitQuestionResponse() throws Exception {
        QuestionnaireResponseSubmitDTO questionnaireResponseSubmit = QuestionnaireResponseSubmitDTO.builder().responseType("LCFA00002").responseValue(List.of("4")).build();
        MultipartFile[] files = new MultipartFile[0];

        PqQuestionResponseDTO responseDTO = PqQuestionResponseDTO.builder().submissionId(submissionId).build();
        when(pqQuestionnaireResponseFacade.submitQuestionResponse(any(UUID.class), any(UUID.class),
                any(QuestionnaireResponseSubmitDTO.class), any(MultipartFile[].class),anyString())).thenReturn(responseDTO);
        when(messageUtility.getMessage(MessageConstants.SUCCESS_MESSAGE)).thenReturn("Success");
        var response = pqQuestionnaireResponseController.submitQuestionResponse(criteriaId,questionId,participantId,files,questionnaireResponseSubmit);
        Assertions.assertNotNull(response.getBody());
        Assertions.assertEquals(submissionId, response.getBody().getData().getSubmissionId());
    }

    @Test
    void testSubmitDocumentsOnResponse() throws Exception {
        PqDocumentsAnswerDTO pqDocumentsAnswerDTO =
            PqDocumentsAnswerDTO.builder().documentAttachmentId(List.of(attachmentId)).build();
        MultipartFile[] files = new MultipartFile[0];

        when(pqQuestionnaireResponseFacade.addDocumentsToResponse(any(UUID.class), any(UUID.class), any(UUID.class),
            any(MultipartFile[].class),anyString())).thenReturn(pqDocumentsAnswerDTO);
        when(messageUtility.getMessage(MessageConstants.SUCCESS_MESSAGE)).thenReturn(TestConstants.MESSAGE_UTILITY);

        var response = pqQuestionnaireResponseController.submitDocumentsOnResponse(criteriaId, questionId, participantId,submissionId,
            files);

        Assertions.assertNotNull(response.getBody(), TestConstants.RESPONSE_NULL);
    }

    @Test
     void testDeleteSubmittedResponse() throws Exception{
        String message = "Submission Deleted Successfully";
        when(pqQuestionnaireResponseFacade.deleteSubmittedResponse(any(UUID.class),any(UUID.class),any(UUID.class),anyString())).thenReturn(message);
        when(messageUtility.getMessage(MessageConstants.DELETE_SUBMISSION)).thenReturn(message);
        var response = pqQuestionnaireResponseController.deleteSubmittedResponse(criteriaId,questionId,participantId,submissionId);
        Assertions.assertNotNull(response.getBody());
        Assertions.assertEquals(message, response.getBody().getData());
    }

    @Test
     void testUpdateQuestions() throws IOException {
        MultipartFile mockFile = Mockito.mock(MultipartFile.class);
        MultipartFile[] files = new MultipartFile[] { mockFile };
        QuestionnaireResponseUpdateDTO responseUpdateDTO = new QuestionnaireResponseUpdateDTO();
        responseUpdateDTO.setResponseType("LCFAPQ0004");
        responseUpdateDTO.setResponseValue(List.of("This is new Text"));
        MessageResponseDTO responseDTO = MessageResponseDTO.builder().message("Updated").build();

        when(pqQuestionnaireResponseFacade.updateSubmittedResponse(any(UUID.class), any(UUID.class),any(UUID.class),
                 any(MultipartFile[].class),any(QuestionnaireResponseUpdateDTO.class),anyString())).thenReturn(responseDTO);
        when(messageUtility.getMessage(MessageConstants.SUCCESS_MESSAGE)).thenReturn("Success");

        var response = pqQuestionnaireResponseController.updateSubmittedResponse(criteriaId, questionId, participantId, submissionId, files,responseUpdateDTO);
        Assertions.assertNotNull(response.getBody());
    }

  @Test
  void testDeleteResponseAttachment() throws Exception {
    MessageResponseDTO messageResponseDTO = MessageResponseDTO.builder().message(TestConstants.MESSAGE_UTILITY).build();

    when(pqQuestionnaireResponseFacade.deleteResponseAttachment(any(UUID.class), any(UUID.class), any(UUID.class), any(UUID.class)))
        .thenReturn(messageResponseDTO);
    when(messageUtility.getMessage(any())).thenReturn(TestConstants.MESSAGE_UTILITY);

    var response = pqQuestionnaireResponseController.deleteResponseAttachment(criteriaId, questionId, participantId,
        submissionId, attachmentId);

    Assertions.assertNotNull(response.getBody(), TestConstants.RESPONSE_NULL);
  }

  @Test
  void testSubmitResponseDraft() throws Exception {
    String participantId = TestConstants.CATEGORY_NAME;

    SubmitQuestionsResponseDTO mockResponse = SubmitQuestionsResponseDTO.builder()
        .submissionId(UUID.randomUUID())
        .pendingQuestions(null)
        .build();
    UUID categoryCode = UUID.randomUUID();

    when(pqQuestionnaireResponseFacade.submitResponseDraft(any(), any(), any(), any()))
        .thenReturn(mockResponse);
    when(messageUtility.getMessage(any())).thenReturn(TestConstants.MESSAGE_UTILITY);

    ResponseEntity<APIResponse<SubmitQuestionsResponseDTO>> response = pqQuestionnaireResponseController
        .submitResponseDraft(criteriaId, categoryCode, participantId, acceptLanguage);

    assertNotNull(response, TestConstants.RESPONSE_NULL);
  }

  @Test
  void testFetchCriteriaResponses() throws Exception {
      UUID categoryCode = UUID.randomUUID();
List<String> pqParticipants = new ArrayList<>();
    CriteriaResponsesDTO mockResponse = CriteriaResponsesDTO.builder()
        .criteriaId(criteriaId)
        .categoryId(categoryCode)
        .participantSubmissions(List.of())
        .build();

    when(pqQuestionnaireResponseFacade.fetchCriteriaResponses(any(), any(), any(), any()))
        .thenReturn(mockResponse);
    when(messageUtility.getMessage(any())).thenReturn(TestConstants.MESSAGE_UTILITY);

    var response = pqQuestionnaireResponseController.fetchCriteriaResponses(criteriaId, categoryCode, pqParticipants,
        acceptLanguage);

    assertNotNull(response.getBody(), TestConstants.RESPONSE_NULL);
  }

  @Test
  void testFetchParticipantSubmissionsSuccess() throws Exception {
    UUID categoryCode = UUID.randomUUID();

    ParticipantSubmissionsResponseDTO mockSubmission = ParticipantSubmissionsResponseDTO.builder()
        .bidder(TestConstants.CATEGORY_NAME)
        .submissionId(UUID.randomUUID())
        .pqSubmissionDateAndTime(Instant.now())
        .status(TestConstants.STATUS_LOOKUP)
        .build();

    when(pqQuestionnaireResponseFacade.fetchParticipantSubmissions(any(), any(), any()))
        .thenReturn(List.of(mockSubmission));
    when(messageUtility.getMessage(any())).thenReturn(TestConstants.MESSAGE_UTILITY);

    var response = pqQuestionnaireResponseController.fetchParticipantSubmissions(criteriaId, categoryCode, acceptLanguage);

    assertNotNull(response.getBody(), TestConstants.RESPONSE_NULL);
  }

  @Test
  void testFetchParticipantSubmissionsNoSubmissions() throws Exception {
    UUID categoryCode = UUID.randomUUID();
    String acceptLanguage = "en";

    when(pqQuestionnaireResponseFacade.fetchParticipantSubmissions(criteriaId, categoryCode, acceptLanguage))
        .thenReturn(List.of());
    when(messageUtility.getMessage(any())).thenReturn(TestConstants.MESSAGE_UTILITY);

    var response = pqQuestionnaireResponseController.fetchParticipantSubmissions(criteriaId, categoryCode, acceptLanguage);

    assertNotNull(response.getBody(), TestConstants.RESPONSE_NULL);
  }

  @Test
  void testUpdateSubmissionEvaluationThrowsExceptionWhenSubmissionNotFound() {
    when(pqQuestionnaireResponseFacade.updateSubmissionEvaluation(any(), any(UpdateSubmissionEvaluationDTO.class), any()))
        .thenThrow(new ServiceException(TestConstants.ERROR,
            TestConstants.NOT_FOUND,
            ErrorConstant.CATEGORY.TS,
            ErrorConstant.SEVERITY.I));
    lenient().when(messageUtility.getMessage(any())).thenReturn(TestConstants.MESSAGE_UTILITY);

    assertThrows(ServiceException.class, () ->
        pqQuestionnaireResponseController.updateSubmissionEvaluation(submissionId, updateSubmissionEvaluationRequest, acceptLanguage));

  }

  @Test
  void testUpdateSubmissionEvaluationThrowsExceptionWhenInvalidStatus() {
    updateSubmissionEvaluationRequest.setSubmissionStatus("INVALID_STATUS");
    when(pqQuestionnaireResponseFacade.updateSubmissionEvaluation(any(), any(UpdateSubmissionEvaluationDTO.class), any()))
        .thenThrow(new ServiceException(TestConstants.ERROR,
            TestConstants.NOT_FOUND,
            ErrorConstant.CATEGORY.TS,
            ErrorConstant.SEVERITY.I));
    lenient().when(messageUtility.getMessage(any())).thenReturn(TestConstants.MESSAGE_UTILITY);

    assertThrows(ServiceException.class, () ->
        pqQuestionnaireResponseController.updateSubmissionEvaluation(submissionId, updateSubmissionEvaluationRequest, "en"));

  }

  @Test
  void testUpdateSubmissionEvaluationSuccess() throws IOException {
    updateSubmissionEvaluationRequest.setSubmissionStatus("ACTIVE");
    updateSubmissionEvaluationRequest.setRemarks("Approved");

    UpdateSubmissionEvaluationResponseDTO responseDTO = new UpdateSubmissionEvaluationResponseDTO();
    responseDTO.setSubmissionId(submissionId);
    responseDTO.setMessage("Success");

    when(pqQuestionnaireResponseFacade.updateSubmissionEvaluation(eq(submissionId), any(UpdateSubmissionEvaluationDTO.class), anyString()))
        .thenReturn(responseDTO);
    when(messageUtility.getMessage(MessageConstants.SUCCESS_MESSAGE)).thenReturn(TestConstants.MESSAGE_UTILITY);

    var response = pqQuestionnaireResponseController.updateSubmissionEvaluation(submissionId, updateSubmissionEvaluationRequest, acceptLanguage);

    assertNotNull(response.getBody());

  }

    @Test
    void testUpdateSubmissionEvaluation() throws Exception {
        // Arrange
        UUID submissionId = UUID.randomUUID();
        UUID participantId = UUID.randomUUID();
        String acceptLanguage = "en";
        SubmissionStatusReqDTO requestDTO = SubmissionStatusReqDTO.builder()
                .status("ACTIVE")
                .build();

        SubmissionStatusReqDTO responseDTO = SubmissionStatusReqDTO.builder()
                .status("ACTIVE")
                .build();

        when(pqQuestionnaireResponseFacade.updateSubmissionStatus(any(UUID.class), any(UUID.class), any(SubmissionStatusReqDTO.class), anyString()))
                .thenReturn(responseDTO);
        when(messageUtility.getMessage(MessageConstants.SUCCESS_WITHDRAWN)).thenReturn("Success");

        // Act
        ResponseEntity<APIResponse<SubmissionStatusReqDTO>> response = pqQuestionnaireResponseController.updateSubmissionEvaluation(
                submissionId, participantId, requestDTO, acceptLanguage);

        // Assert
        assertNotNull(response);
        assertNotNull(response.getBody());
        assertEquals("Success", response.getBody().getMessage());
        assertEquals("ACTIVE", response.getBody().getData().getStatus());
    }


}
