
/*
 * This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * FreeTextResponseValidationImplTest: To test response validations.
 */

package in.gov.gem.app.fa.pq.validation.response.impl;

import in.gov.gem.app.fa.pq.constant.TestConstants;
import in.gov.gem.app.fa.pq.domain.entity.PqParticipant;
import in.gov.gem.app.fa.pq.domain.entity.PqQuestion;
import in.gov.gem.app.fa.pq.domain.entity.PqResponse;
import in.gov.gem.app.fa.pq.service.PqQuestionResponseService;
import in.gov.gem.app.fa.pq.transformer.QuestionResponseTransformer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Collections;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class FreeTextResponseValidationImplTest {

  private FreeTextResponseValidationImpl validation;
  private QuestionResponseTransformer questionResponseTransformer;
  private PqQuestionResponseService pqQuestionResponseService;
  private PqParticipant pqParticipant;

    @BeforeEach
  void setUp() {
    questionResponseTransformer = mock(QuestionResponseTransformer.class);
    pqQuestionResponseService = mock(PqQuestionResponseService.class);
    pqParticipant = mock(PqParticipant.class);
    validation = new FreeTextResponseValidationImpl(
            questionResponseTransformer,
            pqQuestionResponseService
    );
  }

  @Test
  void testValidateFreeTextEmptyInput() {
    assertFalse(FreeTextResponseValidationImpl.validateFreeText(TestConstants.EMPTY_TEXT));
  }

  @Test
  void testValidateFreeTextExceedsMaxLength() {
    String longText = "a".repeat(256);
    assertFalse(FreeTextResponseValidationImpl.validateFreeText(longText));
  }

  @Test
  void testValidateFreeTextInvalidCharacters() {
    assertFalse(FreeTextResponseValidationImpl.validateFreeText(TestConstants.INVALID_TEXT));
  }

  @Test
  void testValidateFreeTextMinLengthBoundary() {
    assertTrue(FreeTextResponseValidationImpl.validateFreeText("a"));
  }

  @Test
  void testValidateFreeTextMaxLengthBoundary() {
    String maxLengthText = "a".repeat(255);
    assertTrue(FreeTextResponseValidationImpl.validateFreeText(maxLengthText));
  }

  @Test
  void testValidateValidResponse() {
    PqQuestion pqQuestion = new PqQuestion();
    List<String> response = Collections.singletonList(TestConstants.VALID_TEXT);
    assertTrue(validation.validate(pqQuestion, response));
  }

  @Test
  void testValidateEmptyResponse() {
    PqQuestion pqQuestion = new PqQuestion();
    List<String> response = Collections.emptyList();
    assertFalse(validation.validate(pqQuestion, response));
  }

  @Test
  void testValidateInvalidFreeText() {
    PqQuestion pqQuestion = new PqQuestion();
    List<String> response = Collections.singletonList(TestConstants.INVALID_TEXT);
    assertFalse(validation.validate(pqQuestion, response));
  }

  @Test
  void testBuildPqResponse() {
    UUID submissionId = UUID.randomUUID();
    PqQuestion pqQuestion = new PqQuestion();
    List<String> responses = List.of("test response");
    PqResponse pqResponse = new PqResponse();
    PqResponse savedResponse = new PqResponse();

    when(questionResponseTransformer.toPqResponseEntityForInput(submissionId, pqQuestion, "test response",TestConstants.STATUS_LOOKUP,pqParticipant )).thenReturn(pqResponse);
    when(pqQuestionResponseService.saveResponseEntity(pqResponse)).thenReturn(savedResponse);

    PqResponse result = validation.buildPqResponse(submissionId, pqQuestion, responses,TestConstants.STATUS_LOOKUP,pqParticipant);

    assertEquals(savedResponse, result);
    verify(questionResponseTransformer).toPqResponseEntityForInput(submissionId, pqQuestion, "test response",TestConstants.STATUS_LOOKUP, pqParticipant);
    verify(pqQuestionResponseService).saveResponseEntity(pqResponse);
  }

  @Test
  void testUpdatePqResponse() {
    UUID submissionId = UUID.randomUUID();
    PqQuestion pqQuestion = new PqQuestion();
    List<String> responseList = List.of("updated response");
    PqResponse pqResponse = mock(PqResponse.class);
    PqResponse savedResponse = new PqResponse();

    when(pqQuestionResponseService.fetchResponseFromSubmissionId(submissionId)).thenReturn(pqResponse);
    when(pqQuestionResponseService.saveResponseEntity(pqResponse)).thenReturn(savedResponse);

    PqResponse result = validation.updatePqResponse(submissionId, pqQuestion, responseList);

    assertEquals(savedResponse, result);
    verify(pqResponse).setResponseText("updated response");
    verify(pqQuestionResponseService).saveResponseEntity(pqResponse);
  }
}