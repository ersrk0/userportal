
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * PqCriteriaServiceImplTest: Tests the service layer functioning.
 */

package in.gov.gem.app.fa.pq.service.impl;

import in.gov.gem.app.exception.generic.InvalidInputException;
import in.gov.gem.app.fa.pq.constant.ErrorMessageConstants;
import in.gov.gem.app.fa.pq.constant.LookupConstants;
import in.gov.gem.app.fa.pq.constant.TestConstants;
import in.gov.gem.app.fa.pq.domain.entity.PqCriteriaMaster;
import in.gov.gem.app.fa.pq.domain.repository.PqCriteriaMasterRepository;
import in.gov.gem.app.fa.pq.request.CriteriaIdRequestDTO;
import in.gov.gem.app.fa.pq.transformer.ParentCriteriaManagementTransformer;
import in.gov.gem.app.service.core.utility.MessageUtility;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.lenient;

@ExtendWith(MockitoExtension.class)
class PqCriteriaMasterServiceImplTest {

  @Mock
  private MessageUtility messageUtility;

  @Mock
  private PqCriteriaMasterRepository pqCriteriaMasterRepository;

  @Mock
  private ParentCriteriaManagementTransformer parentCriteriaManagementTransformer;

  @InjectMocks
  private PqCriteriaMasterServiceImpl pqCriteriaMasterService;

  private CriteriaIdRequestDTO criteriaIdRequestDTO;
  private UUID criteriaId;

  @BeforeEach
  void setUp() {
    MockitoAnnotations.openMocks(this);

    criteriaIdRequestDTO = CriteriaIdRequestDTO.builder()
        .status(TestConstants.STATUS_LOOKUP)
        .offeringId(TestConstants.CRITERIA_ID)
        .build();

    criteriaId = TestConstants.CRITERIA_ID;
  }


  @Test
  @Disabled
  void testCreateParentCriteriaTransformerReturnsNull() {
    lenient().when(parentCriteriaManagementTransformer.toPqParentCriteria(criteriaIdRequestDTO, criteriaId))
        .thenReturn(null);

    PqCriteriaMaster result = pqCriteriaMasterService.createParentCriteria(TestConstants.LANGUAGE_CODE, criteriaIdRequestDTO, criteriaId);

    assertNull(result, TestConstants.RESPONSE_NULL);
  }


  @Test
  void testDeleteParentCriteriaNotFound() {
    lenient().when(pqCriteriaMasterRepository.findByMasterCriteriaId(criteriaId))
        .thenReturn(Optional.empty());

    lenient().when(messageUtility.getMessage(any()))
        .thenReturn(TestConstants.MESSAGE_UTILITY);

    Assertions.assertThrows(InvalidInputException.class, () ->
        pqCriteriaMasterService.deleteParentCriteria(TestConstants.LANGUAGE_CODE, criteriaId)
    );
  }


  @Test
  void testFetchCriteriaNotFound() {
    UUID offeringId = UUID.randomUUID();

    lenient().when(pqCriteriaMasterRepository.findByStatusLookupAndOfferingId(LookupConstants.Status.ACTIVE.getLookupCode(), offeringId))
        .thenReturn(null);

    PqCriteriaMaster result = pqCriteriaMasterService.fetchCriteria(TestConstants.LANGUAGE_CODE, offeringId);

    Assertions.assertNull(result, TestConstants.RESPONSE_NULL);
  }

  @Test
  void testFetchCriteriaFromCriteriaIdNotFound() {
    UUID criteriaId = UUID.randomUUID();
    lenient().when(pqCriteriaMasterRepository.findByMasterCriteriaId(criteriaId))
        .thenReturn(Optional.empty());
    lenient().when(messageUtility.getMessage(ErrorMessageConstants.CRITERIA_NOT_FOUND))
        .thenReturn(TestConstants.MESSAGE_UTILITY);

    Assertions.assertThrows(InvalidInputException.class, () ->
        pqCriteriaMasterService.fetchCriteriaFromCriteriaId(criteriaId)
    );
  }


  @Test
  void testFetchActiveCriteriaFromCriteriaIdNotFound() {
    lenient().when(pqCriteriaMasterRepository.findByStatusLookupAndMasterCriteriaId(
            LookupConstants.Status.ACTIVE.getLookupCode(), criteriaId))
        .thenReturn(Optional.empty());

    lenient().when(messageUtility.getMessage(ErrorMessageConstants.ACTIVE_CRITERIA_NOT_FOUND))
        .thenReturn(TestConstants.MESSAGE_UTILITY);

    Assertions.assertThrows(InvalidInputException.class, () ->
        pqCriteriaMasterService.fetchActiveCriteriaFromCriteriaId(criteriaId)
    );
  }
}