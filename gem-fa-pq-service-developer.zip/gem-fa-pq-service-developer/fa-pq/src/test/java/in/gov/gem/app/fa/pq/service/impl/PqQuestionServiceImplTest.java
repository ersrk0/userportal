
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * PqQuestionServiceImplTest: Tests the service layer functioning.
 */

package in.gov.gem.app.fa.pq.service.impl;

import in.gov.gem.app.fa.pq.constant.LookupConstants;
import in.gov.gem.app.fa.pq.constant.TestConstants;
import in.gov.gem.app.fa.pq.domain.entity.DocMaster;
import in.gov.gem.app.fa.pq.domain.entity.PqCriteria;
import in.gov.gem.app.fa.pq.domain.entity.PqQuestion;
import in.gov.gem.app.fa.pq.domain.repository.PqQuestionRepository;
import in.gov.gem.app.fa.pq.request.QuestionCreateRequestDTO;
import in.gov.gem.app.fa.pq.request.QuestionUpdateRequestDTO;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class PqQuestionServiceImplTest {

  @Mock
  private PqQuestionRepository pqQuestionRepository;

  @InjectMocks
  private PqQuestionServiceImpl pqQuestionService;

  private PqCriteria pqCriteria;
  private QuestionCreateRequestDTO requestDTO;
  private PqQuestion pqQuestion;
  private String acceptLanguage;
  private DocMaster docMaster;


  @BeforeEach
  void setUp() {
    MockitoAnnotations.openMocks(this);

    pqCriteria = PqCriteria.builder()
        .categoryCode(TestConstants.CATEGORY_CODE)
        .build();

    requestDTO = QuestionCreateRequestDTO.builder()
        .questionText(TestConstants.QUESTION_TEXT)
        .isMandatory(TestConstants.IS_REQUIRED)
        .inputType(TestConstants.INPUT_TYPE)
        .docRequired(TestConstants.IS_REQUIRED)
        .score(TestConstants.SCORE)
        .build();

    pqQuestion = PqQuestion.builder()
        .pqQuestionId(TestConstants.QUESTION_ID)
        .pqCriteria(pqCriteria)
        .statusLookup(TestConstants.STATUS_LOOKUP)
        .questionText(TestConstants.QUESTION_TEXT)
        .isMandatory(TestConstants.IS_REQUIRED)
        .questionTypeLookup(TestConstants.INPUT_TYPE)
        .requiresDocument(TestConstants.IS_REQUIRED)
        .weightage(TestConstants.SCORE)
        .build();

    docMaster = DocMaster.builder().build();

    acceptLanguage = TestConstants.LANGUAGE_CODE;
  }

  @Test
  void testFetchQuestionByCriteria() {
    when(pqQuestionRepository.findAllByPqCriteriaAndStatusLookup(pqCriteria,LookupConstants.Status.ACTIVE.getLookupCode())).thenReturn(List.of(pqQuestion));

    List<PqQuestion> result = pqQuestionService.fetchQuestionByCriteria(pqCriteria);

    assertNotNull(result);
  }

  @Test
  void testCreateQuestion() {
    when(pqQuestionRepository.save(any(PqQuestion.class))).thenReturn(pqQuestion);

    PqQuestion result = pqQuestionService.createQuestion(acceptLanguage, requestDTO, pqCriteria,
        TestConstants.QUESTION_ID, docMaster);

    assertNotNull(result, TestConstants.RESPONSE_NULL);
  }

  @Test
  void testDeleteQuestion() {
    when(pqQuestionRepository.findByPqCriteriaAndPqQuestionIdAndStatusLookup(any(), any(), any())).thenReturn(pqQuestion);

    pqQuestionService.deleteQuestion(acceptLanguage, pqCriteria, TestConstants.QUESTION_ID);

    assertTrue(LookupConstants.Status.INACTIVE.getLookupCode().equals(pqQuestion.getStatusLookup()), TestConstants.NOT_TRUE);
  }

  @Test
  void testFetchQuestionByQuestionId() {
    when(pqQuestionRepository.findByPqCriteriaAndPqQuestionIdAndStatusLookup(any(), any(), any())).thenReturn(pqQuestion);

    PqQuestion result = pqQuestionService.fetchQuestionByQuestionId(pqCriteria, TestConstants.QUESTION_ID);

    assertNotNull(result, TestConstants.RESPONSE_NULL);
  }

  @Test
  void testUpdateQuestion() {
    QuestionUpdateRequestDTO updateRequest = QuestionUpdateRequestDTO.builder()
        .questionText(TestConstants.QUESTION_TEXT)
        .inputType(TestConstants.INPUT_TYPE)
        .isMandatory(true)
        .docRequired(false)
        .score(TestConstants.SCORE)
        .build();

    when(pqQuestionRepository.save(any(PqQuestion.class))).thenReturn(pqQuestion);

    pqQuestionService.updateQuestion(pqQuestion, updateRequest);

    Assertions.assertEquals(TestConstants.QUESTION_TEXT, pqQuestion.getQuestionText(), TestConstants.VALUES_NOT_EQUAL);
    verify(pqQuestionRepository).save(pqQuestion);
  }

  @Test
  void testSaveDocumentSuccess() {
    pqQuestionService.saveDocument(docMaster, pqQuestion);

    verify(pqQuestionRepository, times(1)).save(pqQuestion);

    Assertions.assertNotNull(pqQuestion.getDocMaster(), TestConstants.RESPONSE_NULL);
  }

  @Test
  void testFetchQuestionByQuestionIdWithoutCategory() {
    UUID questionId = TestConstants.QUESTION_ID;

    when(pqQuestionRepository.findByPqQuestionId(questionId)).thenReturn(Optional.ofNullable(pqQuestion));

    PqQuestion result = pqQuestionService.fetchQuestionByQuestionId(questionId);

    assertNotNull(result, TestConstants.RESPONSE_NULL);
  }
}