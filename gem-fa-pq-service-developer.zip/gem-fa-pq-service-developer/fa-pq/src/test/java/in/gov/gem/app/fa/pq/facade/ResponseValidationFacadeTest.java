
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * CriteriaManagementFacadeTest: Tests the facade layer functioning.
 */

package in.gov.gem.app.fa.pq.facade;

import in.gov.gem.app.fa.pq.constant.TestConstants;
import in.gov.gem.app.fa.pq.domain.entity.PqParticipant;
import in.gov.gem.app.fa.pq.domain.entity.PqQuestion;
import in.gov.gem.app.fa.pq.domain.entity.PqResponse;
import in.gov.gem.app.fa.pq.facade.impl.ResponseValidationFacade;
import in.gov.gem.app.fa.pq.request.QuestionnaireResponseSubmitDTO;
import in.gov.gem.app.fa.pq.service.PqQuestionResponseService;
import in.gov.gem.app.fa.pq.validation.response.ResponseValidation;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Collections;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ResponseValidationFacadeTest {

  private ResponseValidationFacade responseValidationFacade;
  private List<ResponseValidation> responseValidationList;
  private PqQuestionResponseService pqQuestionResponseService;
  private PqParticipant pqParticipant;

  @BeforeEach
  void setUp() {
    responseValidationList = mock(List.class);
    pqQuestionResponseService = mock(PqQuestionResponseService.class);
    pqParticipant = mock(PqParticipant.class);
    responseValidationFacade = new ResponseValidationFacade(responseValidationList, pqQuestionResponseService);
  }

  @Test
  void testValidateWhenResponseValidationCanHandleReturnsTrue() {
    PqQuestion pqQuestion = mock(PqQuestion.class);
    QuestionnaireResponseSubmitDTO answerDto = mock(QuestionnaireResponseSubmitDTO.class);
    ResponseValidation responseValidation = mock(ResponseValidation.class);
    when(answerDto.getResponseType()).thenReturn("type");
    when(responseValidation.canHandle(any())).thenReturn(true);
    when(responseValidation.validate(any(), any())).thenReturn(true);
    when(responseValidationList.iterator()).thenReturn(Collections.singletonList(responseValidation).iterator());

    boolean result = responseValidationFacade.validate(pqQuestion, answerDto);

    assertTrue(result, TestConstants.NOT_TRUE);
  }

  @Test
  void testBuildPqResponseSuccess() {
    UUID submissionId = UUID.randomUUID();
    PqQuestion pqQuestion = mock(PqQuestion.class);
    QuestionnaireResponseSubmitDTO answerDto = mock(QuestionnaireResponseSubmitDTO.class);
    ResponseValidation responseValidation = mock(ResponseValidation.class);
    PqResponse pqResponse = new PqResponse();

    when(answerDto.getResponseType()).thenReturn("type");
    when(answerDto.getResponseValue()).thenReturn(List.of("value"));
    when(responseValidation.canHandle("type")).thenReturn(true);
    when(responseValidation.buildPqResponse(submissionId, pqQuestion, List.of("value"),TestConstants.STATUS_LOOKUP,pqParticipant)).thenReturn(pqResponse);
    when(responseValidationList.iterator()).thenReturn(Collections.singletonList(responseValidation).iterator());

    PqResponse result = responseValidationFacade.buildPqResponse(submissionId, pqQuestion, answerDto,TestConstants.STATUS_LOOKUP,pqParticipant);

    assertEquals(pqResponse, result);
  }

  @Test
  void testBuildPqResponseThrowsExceptionWhenNoSuitableValidationFound() {
    UUID submissionId = UUID.randomUUID();
    PqQuestion pqQuestion = mock(PqQuestion.class);
    QuestionnaireResponseSubmitDTO answerDto = mock(QuestionnaireResponseSubmitDTO.class);

    when(responseValidationList.iterator()).thenReturn(Collections.emptyIterator());

    Assertions.assertThrows(IllegalArgumentException.class, () -> {
      responseValidationFacade.buildPqResponse(submissionId, pqQuestion, answerDto, TestConstants.STATUS_LOOKUP, pqParticipant);
    });

  }

  @Test
  void testUpdatePqResponseSuccess() {
    UUID submissionId = UUID.randomUUID();
    PqQuestion pqQuestion = mock(PqQuestion.class);
    QuestionnaireResponseSubmitDTO answerDto = mock(QuestionnaireResponseSubmitDTO.class);
    ResponseValidation responseValidation = mock(ResponseValidation.class);
    PqResponse pqResponse = new PqResponse();

    when(answerDto.getResponseType()).thenReturn("type");
    when(answerDto.getResponseValue()).thenReturn(List.of("value"));
    when(responseValidation.canHandle("type")).thenReturn(true);
    when(responseValidation.updatePqResponse(submissionId, pqQuestion, List.of("value"))).thenReturn(pqResponse);
    when(responseValidationList.iterator()).thenReturn(Collections.singletonList(responseValidation).iterator());

    PqResponse result = responseValidationFacade.updatePqResponse(submissionId, pqQuestion, answerDto);

    assertEquals(pqResponse, result);
  }

  @Test
  void testUpdatePqResponseThrowsExceptionWhenNoSuitableValidationFound() {
    UUID submissionId = UUID.randomUUID();
    PqQuestion pqQuestion = mock(PqQuestion.class);
    QuestionnaireResponseSubmitDTO answerDto = mock(QuestionnaireResponseSubmitDTO.class);

    when(responseValidationList.iterator()).thenReturn(Collections.emptyIterator());

    Assertions.assertThrows(IllegalArgumentException.class, () -> {
      responseValidationFacade.updatePqResponse(submissionId, pqQuestion, answerDto);
    });

  }

  @Test
  void testValidateWhenResponseValidationCannotHandleReturnsFalse() {
    PqQuestion pqQuestion = mock(PqQuestion.class);
    QuestionnaireResponseSubmitDTO answerDto = mock(QuestionnaireResponseSubmitDTO.class);
    ResponseValidation responseValidation = mock(ResponseValidation.class);

    when(answerDto.getResponseType()).thenReturn("type");
    when(responseValidation.canHandle(any())).thenReturn(false);
    when(responseValidationList.iterator()).thenReturn(Collections.singletonList(responseValidation).iterator());

    boolean result = responseValidationFacade.validate(pqQuestion, answerDto);

    assertFalse(result, TestConstants.NOT_FALSE);
  }

  @Test
  void testValidateWhenResponseValidationListIsEmptyReturnsFalse() {
    PqQuestion pqQuestion = mock(PqQuestion.class);
    QuestionnaireResponseSubmitDTO answerDto = mock(QuestionnaireResponseSubmitDTO.class);

    when(responseValidationList.iterator()).thenReturn(Collections.emptyIterator());

    boolean result = responseValidationFacade.validate(pqQuestion, answerDto);

    assertFalse(result, TestConstants.NOT_FALSE);
  }
}