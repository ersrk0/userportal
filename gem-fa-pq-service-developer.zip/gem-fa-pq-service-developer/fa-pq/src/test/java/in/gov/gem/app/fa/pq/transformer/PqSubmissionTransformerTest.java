package in.gov.gem.app.fa.pq.transformer;

import in.gov.gem.app.fa.pq.domain.entity.PqCriteria;
import in.gov.gem.app.fa.pq.domain.entity.PqSubmission;
import in.gov.gem.app.fa.pq.response.CategoriesSubmissionResponseDTO;
import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class PqSubmissionTransformerTest {


  private final PqSubmissionTransformer transformer = new PqSubmissionTransformer();

  @Test
  void testToCategoriesSubmissionResponseDTO() {
    // Arrange
    UUID categoryCode = UUID.randomUUID();
    UUID submissionId = UUID.randomUUID();
    Integer categoryScore = 85;

    PqCriteria pqCriteria = PqCriteria.builder()
        .categoryCode(categoryCode)
        .build();

    PqSubmission pqSubmission = PqSubmission.builder()
        .pqCriteria(pqCriteria)
        .submissionId(submissionId)
        .categoryScore(categoryScore)
        .submittedAt(Instant.now())
        .evaluatedAt(Instant.now())
        .build();

    // Act
    CategoriesSubmissionResponseDTO responseDTO = transformer.toCategoriesSubmissionResponseDTO(pqSubmission);

    // Assert
    assertNotNull(responseDTO, "Response DTO should not be null");
    assertEquals(categoryCode, responseDTO.getCategoryCode(), "Category code should match");
  }
}
