
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * CriteriaManagementFacadeTest: Tests the facade layer functioning.
 */

package in.gov.gem.app.fa.pq.facade;

import in.gov.gem.app.fa.pq.constant.LookupConstants;
import in.gov.gem.app.fa.pq.constant.TestConstants;
import in.gov.gem.app.fa.pq.domain.entity.DocMaster;
import in.gov.gem.app.fa.pq.domain.entity.PqCriteria;
import in.gov.gem.app.fa.pq.domain.entity.PqCriteriaMaster;
import in.gov.gem.app.fa.pq.domain.entity.PqSubmission;
import in.gov.gem.app.fa.pq.facade.impl.CriteriaManagementFacade;
import in.gov.gem.app.fa.pq.request.CriteriaIdRequestDTO;
import in.gov.gem.app.fa.pq.request.SubmitRepresentationReqDTO;
import in.gov.gem.app.fa.pq.response.CategoryResponseDTO;
import in.gov.gem.app.fa.pq.response.CriteriaIdResponseDTO;
import in.gov.gem.app.fa.pq.response.MessageResponseDTO;
import in.gov.gem.app.fa.pq.response.SubmitRepresentationResDTO;
import in.gov.gem.app.fa.pq.service.*;
import in.gov.gem.app.fa.pq.transformer.CriteriaManagementTransformer;
import in.gov.gem.app.fa.pq.utility.RequestUtil;
import in.gov.gem.app.service.attachment.utility.S3AttachmentUtility;
import in.gov.gem.app.service.dto.CoreLookupDto;
import in.gov.gem.app.service.pack.service.interfaces.CoreLookupService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.*;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.times;

class CriteriaManagementFacadeTest {

  @Mock
  private CriteriaManagementTransformer criteriaManagementTransformer;

  @Mock
  private PqCriteriaService pqCriteriaService;

  @Mock
  private PqCriteriaMasterService pqCriteriaMasterService;

  @InjectMocks
  private CriteriaManagementFacade criteriaManagementFacade;


  @Mock
  private RequestUtil requestUtil;

  @Mock
  private DocumentServiceUtil documentServiceUtil;

  @Mock
  private CoreLookupService coreLookupService;

  @Mock
  private MultipartFile file;

  @Mock
  private DocAttachmentService docAttachmentService;

  @Mock
  private S3AttachmentUtility s3AttachmentUtility;

  @Mock
  private DocumentMasterService documentMasterService;

  @Mock
  private TemporalService temporalService;

  @Mock
  private PqSubmissionService pqSubmissionService;


  private String acceptLanguage;

  @BeforeEach
  void setUp() {
    MockitoAnnotations.openMocks(this);

    acceptLanguage = TestConstants.LANGUAGE_CODE;
    criteriaManagementFacade = spy(new CriteriaManagementFacade(
        criteriaManagementTransformer,
        pqCriteriaService,
        pqCriteriaMasterService,
        requestUtil,
        documentServiceUtil,
        coreLookupService,
        docAttachmentService,
        s3AttachmentUtility,
        documentMasterService,
        pqSubmissionService,
        temporalService


    ));

  }

  @Test
  void testCreateCriteriaSuccess() {
    CriteriaIdRequestDTO criteriaIdRequestDTO = new CriteriaIdRequestDTO();
    CriteriaIdResponseDTO expectedResponse = new CriteriaIdResponseDTO();

    when(pqCriteriaMasterService.createParentCriteria(any(), any(), any()))
        .thenReturn(mock(PqCriteriaMaster.class));
    when(criteriaManagementTransformer.toCriteriaIdResponseDTO(any(), any()))
        .thenReturn(expectedResponse);

    CriteriaIdResponseDTO actualResponse = criteriaManagementFacade.createCriteria(acceptLanguage, criteriaIdRequestDTO);

    assertNotNull(actualResponse);
  }

  @Test
  void testFetchCriteriaSuccess() {
    UUID offeringId = UUID.randomUUID();
    PqCriteriaMaster pqCriteriaMaster = PqCriteriaMaster.builder()
            .offeringId(offeringId)
            .statusLookup(LookupConstants.Status.ACTIVE.getLookupCode())
            .build();
    PqCriteria pqCriteria = PqCriteria.builder()
            .pqCriteriaMaster(pqCriteriaMaster)
            .categoryCode(UUID.randomUUID())
            .criteriaName("Technology")
            .build();
    List<PqCriteria> pqCriteriaList = List.of(pqCriteria);
    CategoryResponseDTO temporalCategoryResponse = CategoryResponseDTO.builder()
            .categoryCode(pqCriteria.getCategoryCode())
            .categoryName("Technology")
            .isPqEnabled(Boolean.TRUE)
            .build();
    List<PqSubmission> pqSubmissionList = List.of(new PqSubmission(), new PqSubmission());
    Optional<List<PqSubmission>> optionalPqSubmissionList = Optional.of(pqSubmissionList);
    CriteriaIdResponseDTO expectedResponse = new CriteriaIdResponseDTO();
    when(pqCriteriaMasterService.fetchCriteria(acceptLanguage, offeringId)).thenReturn(pqCriteriaMaster);
    when(pqCriteriaService.fetchCriteria(acceptLanguage, pqCriteriaMaster)).thenReturn(pqCriteriaList);
    when(temporalService.getTemporalCategory(any(), any())).thenReturn(temporalCategoryResponse);
    when(pqSubmissionService.fetchSubmissionList(any())).thenReturn(optionalPqSubmissionList);
    when(criteriaManagementTransformer.toCriteriaIdResponse(any(), any())).thenReturn(expectedResponse);
    CriteriaIdResponseDTO actualResponse = criteriaManagementFacade.fetchCriteria(acceptLanguage, offeringId);
    assertNotNull(actualResponse, TestConstants.RESPONSE_NULL);
  }


  @Test
  void testFetchCriteriaEmptyList() {
    UUID offeringId = UUID.randomUUID();
    List<PqCriteria> pqCriteriaList = List.of();
    CriteriaIdResponseDTO expectedResponse = new CriteriaIdResponseDTO();
    PqCriteriaMaster pqCriteriaMaster = PqCriteriaMaster.builder().statusLookup(LookupConstants.Status.ACTIVE.getLookupCode()).build();

    when(pqCriteriaMasterService.fetchCriteria(acceptLanguage, offeringId)).thenReturn(pqCriteriaMaster);
    when(pqCriteriaService.fetchCriteria(any(), any())).thenReturn(pqCriteriaList);
    when(criteriaManagementTransformer.toCriteriaIdResponse(any(),any()))
        .thenReturn(expectedResponse);

    CriteriaIdResponseDTO actualResponse = criteriaManagementFacade.fetchCriteria(acceptLanguage, offeringId);

    assertNotNull(actualResponse, TestConstants.RESPONSE_NULL);
  }

  @Test
  void testDeleteCriteriaSuccess() {
    UUID criteriaId = TestConstants.CRITERIA_ID;
    MessageResponseDTO expectedResponse = MessageResponseDTO.builder()
        .message(TestConstants.MESSAGE_UTILITY)
        .build();

    when(criteriaManagementTransformer.toDeleteCriteriaMessageResponseDTO()).thenReturn(expectedResponse);

    MessageResponseDTO actualResponse = criteriaManagementFacade.deleteCriteria(acceptLanguage, criteriaId);

    assertNotNull(actualResponse, TestConstants.RESPONSE_NULL);
  }


  @Test
  void testDeleteCategorySuccess() {
    UUID criteriaId = TestConstants.CRITERIA_ID;
    UUID categoryId = TestConstants.CATEGORY_CODE;
    MessageResponseDTO expectedResponse = MessageResponseDTO.builder()
        .message(TestConstants.MESSAGE_UTILITY)
        .build();

    when(criteriaManagementTransformer.toDeleteCategoryMessageResponseDTO()).thenReturn(expectedResponse);

    MessageResponseDTO actualResponse = criteriaManagementFacade.deleteCategory(acceptLanguage, criteriaId, categoryId);

    assertNotNull(actualResponse, TestConstants.RESPONSE_NULL);
  }


  @Test
  void testSyncCriteria() {
    MessageResponseDTO expectedResponse = MessageResponseDTO.builder()
        .message(TestConstants.MESSAGE_UTILITY)
        .build();

    when(criteriaManagementTransformer.toSyncCriteriaMessageResponseDTO()).thenReturn(expectedResponse);

    MessageResponseDTO actualResponse = criteriaManagementFacade.syncCriteria();

    assertNotNull(actualResponse);
  }

  @Test
  void testDocumentUpload() throws IOException {
    CoreLookupDto lookupDto = new CoreLookupDto();
    lookupDto.setLookupCode(TestConstants.LOOKUP_CODE_PDF);
    DocMaster expectedDocMaster = new DocMaster();
    expectedDocMaster.setDocumentId(UUID.randomUUID());


    when(file.getOriginalFilename()).thenReturn(TestConstants.FILE_NAME);
    when(file.getContentType()).thenReturn(TestConstants.CONTENT_TYPE);
    when(file.getSize()).thenReturn(TestConstants.FILE_SIZE);
    when(requestUtil.createRequestId()).thenReturn(UUID.randomUUID());
    when(coreLookupService.findAllByLookupValueIgnoreCase(anyString()))
            .thenReturn(Collections.singletonList(lookupDto));
    when(requestUtil.createPath(any(), any(), any()))
            .thenReturn(TestConstants.FILE_PATH);
    when(documentMasterService.saveDocumentMaster(any()))
            .thenReturn(expectedDocMaster);
    doNothing().when(docAttachmentService)
            .saveDocumentDetails(any(), any(), any(), any(), anyLong(), any());
    when(s3AttachmentUtility.uploadMultipart(anyString(), anyString(), any(MultipartFile.class)))
            .thenReturn(true);

    DocMaster result = criteriaManagementFacade.documentUpload(file);

    assertNotNull(result, TestConstants.RESPONSE_NULL);
  }

  @Test
  void testGetRepresentationStatus() {
    UUID criteriaId = UUID.randomUUID();
    PqCriteriaMaster pqCriteriaMaster = new PqCriteriaMaster();
    SubmitRepresentationResDTO expectedResponse = new SubmitRepresentationResDTO();

    when(pqCriteriaMasterService.fetchActiveCriteriaFromCriteriaId(criteriaId)).thenReturn(pqCriteriaMaster);
    when(criteriaManagementTransformer.toSubmitRepresentationDTO(pqCriteriaMaster)).thenReturn(expectedResponse);

    SubmitRepresentationResDTO actualResponse = criteriaManagementFacade.getRepresentationStatus(criteriaId, "en");

    assertNotNull(actualResponse);
    assertEquals(expectedResponse, actualResponse);
    verify(pqCriteriaMasterService, times(1)).fetchActiveCriteriaFromCriteriaId(criteriaId);
  }

  @Test
  void testSubmitRepresentationStatusWithNullFile() throws IOException {
    // Arrange
    UUID criteriaId = UUID.randomUUID();
    SubmitRepresentationReqDTO requestDTO = new SubmitRepresentationReqDTO();
    requestDTO.setRepresentation(true);
    requestDTO.setRemarks("Test Remarks");
    requestDTO.setFile(null); // File is null

    PqCriteriaMaster pqCriteriaMaster = new PqCriteriaMaster();
    PqCriteriaMaster updatedCriteriaMaster = new PqCriteriaMaster();
    SubmitRepresentationResDTO expectedResponse = new SubmitRepresentationResDTO();

    when(pqCriteriaMasterService.fetchActiveCriteriaFromCriteriaId(criteriaId)).thenReturn(pqCriteriaMaster);
    when(pqCriteriaMasterService.submitRepresentation(pqCriteriaMaster)).thenReturn(updatedCriteriaMaster);
    when(criteriaManagementTransformer.toSubmitRepresentationDTO(updatedCriteriaMaster)).thenReturn(expectedResponse);

    // Act
    SubmitRepresentationResDTO actualResponse = criteriaManagementFacade.submitRepresentationStatus(criteriaId, requestDTO, "en");

    // Assert
    assertNotNull(actualResponse);
    assertEquals(expectedResponse, actualResponse);
    verify(pqCriteriaMasterService, times(1)).fetchActiveCriteriaFromCriteriaId(criteriaId);
    verify(pqCriteriaMasterService, times(1)).submitRepresentation(pqCriteriaMaster);
    verify(criteriaManagementTransformer, times(1)).toSubmitRepresentationDTO(updatedCriteriaMaster);
    verify(criteriaManagementFacade, never()).documentUpload(any()); // Ensure documentUpload is never called
  }

}