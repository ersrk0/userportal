
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * PqClarificationMsgServiceImplTest: Tests the facade layer functioning.
 */

package in.gov.gem.app.fa.pq.service.impl;

import in.gov.gem.app.fa.pq.constant.LookupConstants;
import in.gov.gem.app.fa.pq.constant.TestConstants;
import in.gov.gem.app.fa.pq.domain.entity.DocMaster;
import in.gov.gem.app.fa.pq.domain.entity.PqClarificationMsg;
import in.gov.gem.app.fa.pq.domain.entity.PqClarificationThread;
import in.gov.gem.app.fa.pq.domain.repository.PqClarificationMsgRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.lenient;

@ExtendWith(MockitoExtension.class)
class PqClarificationMsgServiceImplTest {

  @Mock
  private PqClarificationMsgRepository pqClarificationMsgRepository;

  @Mock
  private PqClarificationMsgRepository msgRepository;

  @InjectMocks
  private PqClarificationMsgServiceImpl pqClarificationMsgService;

  private PqClarificationThread pqClarificationThread;
  private DocMaster docMaster;

  @BeforeEach
  void setUp() {
    MockitoAnnotations.openMocks(this);

    pqClarificationThread = PqClarificationThread.builder()
        .threadId(UUID.randomUUID())
        .build();

    docMaster = DocMaster.builder()
        .documentId(UUID.randomUUID())
        .build();
  }

  @Test
  void testSaveMsg() {
    String msgText = TestConstants.QUESTION_TEXT;

    PqClarificationMsg expectedMsg = PqClarificationMsg.builder()
        .pqClarificationThread(pqClarificationThread)
        .senderTypeLookup(LookupConstants.SenderType.AUCTIONER.getLookupCode())
        .msgText(msgText)
        .docMaster(docMaster)
        .build();

    lenient().when(pqClarificationMsgRepository.save(any(PqClarificationMsg.class))).thenReturn(expectedMsg);

    PqClarificationMsg actualMsg = pqClarificationMsgService.saveMsg(pqClarificationThread, msgText, docMaster);

    assertNull(actualMsg, TestConstants.RESPONSE_NULL);
  }

  @Test
  void testSaveSubmissionMsg() {
    String additionalInfo = TestConstants.QUESTION_TEXT;

    PqClarificationMsg expectedMsg = PqClarificationMsg.builder()
        .pqClarificationThread(pqClarificationThread)
        .senderTypeLookup(LookupConstants.SenderType.BIDDER.getLookupCode())
        .msgText(additionalInfo)
        .docMaster(docMaster)
        .build();

    lenient().when(pqClarificationMsgRepository.save(any(PqClarificationMsg.class))).thenReturn(expectedMsg);

    PqClarificationMsg actualMsg = pqClarificationMsgService.saveSubmissionMsg(pqClarificationThread, additionalInfo, docMaster);

    assertNull(actualMsg, TestConstants.RESPONSE_NULL);
  }

  @Test
  void testFetchClarificationMsgByThread_shouldReturnMessageArray() {

    PqClarificationMsg[]  messages = new PqClarificationMsg[2];
    messages[0]= PqClarificationMsg.builder()
        .pqClarificationThread(pqClarificationThread)
        .senderTypeLookup(LookupConstants.SenderType.AUCTIONER.getLookupCode())
        .msgText("Message 1")
        .build();

    messages[1]= PqClarificationMsg.builder()
            .pqClarificationThread(pqClarificationThread)
            .senderTypeLookup(LookupConstants.SenderType.AUCTIONER.getLookupCode())
            .msgText("Message 2")
            .build();

    lenient().when(pqClarificationMsgRepository.findAllByPqClarificationThread(any(PqClarificationThread.class))).thenReturn(messages);

    PqClarificationMsg[] result = pqClarificationMsgService.fetchClarificationMsgByThread(pqClarificationThread);

    assertNull(result, TestConstants.RESPONSE_NULL);
  }
}