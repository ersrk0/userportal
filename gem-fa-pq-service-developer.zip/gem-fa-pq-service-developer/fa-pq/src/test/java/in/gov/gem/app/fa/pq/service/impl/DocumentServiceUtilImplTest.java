
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * DocumentServiceUtilImplTest: Tests the facade layer functioning.
 */

package in.gov.gem.app.fa.pq.service.impl;

import in.gov.gem.app.exception.generic.ServiceException;
import in.gov.gem.app.fa.pq.constant.ErrorMessageConstants;
import in.gov.gem.app.fa.pq.constant.TestConstants;
import in.gov.gem.app.service.core.utility.MessageUtility;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.multipart.MultipartFile;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class DocumentServiceUtilImplTest {

    @InjectMocks
    private DocumentServiceUtilImpl documentServiceUtil;
    @Mock
    private MessageUtility messageUtility;


    @Test
    void fileSizeCheck() {
        MultipartFile file = new MockMultipartFile(
                TestConstants.FILE_NAME,
                TestConstants.FILE_NAME,
                MediaType.APPLICATION_PDF_VALUE,
                "test content".getBytes()
        );

        Boolean flag=documentServiceUtil.fileSizeCheck(file);
        assertFalse(flag);
    }

    @Test
    void fileSizeCheckException() {
        byte[] content=new byte[TestConstants.MAX_FILE_SIZE+1];
        when(messageUtility.getMessage(any())).thenReturn(ErrorMessageConstants.DOCUMENT_UPLOAD_ERROR_MSG);
        MultipartFile file = new MockMultipartFile(
                TestConstants.FILE_NAME,
                TestConstants.FILE_NAME,
                MediaType.APPLICATION_PDF_VALUE,
                content
        );
        ServiceException exception = assertThrows(ServiceException.class, ()-> {
            documentServiceUtil.fileSizeCheck(file);
        });
        assertEquals(ErrorMessageConstants.DOCUMENT_UPLOAD_ERROR_MSG, exception.getMessage());
    }

    @Test
    void testFileSizeCheckExceedsLimit() {
        MultipartFile file = new MockMultipartFile(
            TestConstants.FILE_NAME,
            TestConstants.FILE_NAME,
            MediaType.APPLICATION_PDF_VALUE,
            new byte[TestConstants.MAX_FILE_SIZE + 1]
        );
        when(messageUtility.getMessage(any())).thenReturn(ErrorMessageConstants.DOCUMENT_UPLOAD_ERROR_MSG);

        Assertions.assertThrows(ServiceException.class, () -> {
            documentServiceUtil.fileSizeCheck(file);
        });
    }


}