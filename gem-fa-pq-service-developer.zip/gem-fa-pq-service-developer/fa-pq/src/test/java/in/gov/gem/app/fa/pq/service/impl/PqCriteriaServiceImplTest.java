
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * PqCriteriaServiceImplTest: Tests the service layer functioning.
 */

package in.gov.gem.app.fa.pq.service.impl;

import in.gov.gem.app.exception.generic.InvalidInputException;
import in.gov.gem.app.exception.generic.NotFoundException;
import in.gov.gem.app.fa.pq.constant.ErrorMessageConstants;
import in.gov.gem.app.fa.pq.constant.LookupConstants;
import in.gov.gem.app.fa.pq.constant.TestConstants;
import in.gov.gem.app.fa.pq.domain.entity.PqCriteria;
import in.gov.gem.app.fa.pq.domain.entity.PqCriteriaMaster;
import in.gov.gem.app.fa.pq.domain.repository.PqCriteriaRepository;
import in.gov.gem.app.fa.pq.request.CriteriaIdRequestDTO;
import in.gov.gem.app.fa.pq.response.CategoryResponseDTO;
import in.gov.gem.app.fa.pq.transformer.CriteriaManagementTransformer;
import in.gov.gem.app.service.core.utility.MessageUtility;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.junit.Assert.assertThrows;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class PqCriteriaServiceImplTest {

  @InjectMocks
  private PqCriteriaServiceImpl pqCriteriaService;

  @Mock
  private PqCriteriaRepository pqCriteriaRepository;

  @Mock
  private MessageUtility messageUtility;

  @Mock
  private CriteriaManagementTransformer criteriaManagementTransformer; // Add this mock

  private String acceptLanguage;
  private PqCriteriaMaster pqCriteriaMaster;
  private UUID categoryCode;


  @BeforeEach
  void setUp() {
    MockitoAnnotations.openMocks(this);
    acceptLanguage = TestConstants.LANGUAGE_CODE;
    pqCriteriaMaster = PqCriteriaMaster.builder()
        .masterCriteriaId(TestConstants.CRITERIA_ID)
        .build();
    categoryCode = TestConstants.CATEGORY_CODE;
  }


  @Test
  @Disabled
  void testCreateCriteriaNoExistingCriteria() {
    // Test data
    CriteriaIdRequestDTO criteriaIdRequestDTO = new CriteriaIdRequestDTO();
    CategoryResponseDTO category = new CategoryResponseDTO();
    category.setCategoryCode(UUID.randomUUID());
    category.setCategoryName("Category 1");
    criteriaIdRequestDTO.setCategories(List.of(category));

    PqCriteria pqCriteria = PqCriteria.builder()
        .categoryCode(category.getCategoryCode())
        .build();

    // Mocking
    when(criteriaManagementTransformer.toPqCriteria(categoryCode, criteriaIdRequestDTO, category, pqCriteriaMaster))
        .thenReturn(pqCriteria);
    when(pqCriteriaRepository.findByCategoryCodeAndStatusLookup(category.getCategoryCode(), LookupConstants.Status.ACTIVE.getLookupCode()))
        .thenReturn(null);
    when(pqCriteriaRepository.save(any(PqCriteria.class))).thenReturn(pqCriteria);

    // Method call
    pqCriteriaService.createCriteria(acceptLanguage, criteriaIdRequestDTO, categoryCode, pqCriteriaMaster);

    // Verify interactions
    verify(criteriaManagementTransformer, times(1)).toPqCriteria(categoryCode, criteriaIdRequestDTO, category, pqCriteriaMaster);
    verify(pqCriteriaRepository, times(1)).save(pqCriteria);
  }

  @Test
  @Disabled
  void testCreateCriteriaExistingCriteria() {
    // Test data
    CriteriaIdRequestDTO criteriaIdRequestDTO = new CriteriaIdRequestDTO();
    CategoryResponseDTO category = new CategoryResponseDTO();
    category.setCategoryCode(UUID.randomUUID());
    category.setCategoryName("Category 1");
    criteriaIdRequestDTO.setCategories(List.of(category));

    PqCriteria pqCriteria = PqCriteria.builder()
        .categoryCode(category.getCategoryCode())
        .build();

    // Mocking
    when(criteriaManagementTransformer.toPqCriteria(categoryCode, criteriaIdRequestDTO, category, pqCriteriaMaster))
        .thenReturn(pqCriteria);
    when(pqCriteriaRepository.findByCategoryCodeAndStatusLookup(category.getCategoryCode(), LookupConstants.Status.ACTIVE.getLookupCode()))
        .thenReturn(pqCriteria);

    // Method call
    pqCriteriaService.createCriteria(acceptLanguage, criteriaIdRequestDTO, categoryCode, pqCriteriaMaster);

    // Verify interactions
    verify(criteriaManagementTransformer, times(1)).toPqCriteria(categoryCode, criteriaIdRequestDTO, category, pqCriteriaMaster);
    verify(pqCriteriaRepository, times(0)).save(any());
  }

  @Test
  void testCreateCriteriaEmptyCategories() {
    // Test data
    CriteriaIdRequestDTO criteriaIdRequestDTO = new CriteriaIdRequestDTO();
    CategoryResponseDTO category = new CategoryResponseDTO();
    category.setCategoryCode(UUID.randomUUID());
    category.setCategoryName("Category 1");
    criteriaIdRequestDTO.setCategories(Collections.emptyList());

    // Method call
    pqCriteriaService.createCriteria(acceptLanguage, criteriaIdRequestDTO, categoryCode, pqCriteriaMaster);

  }

  @Test
  void testCreateCriteriaNullCategories() {
    // Test data
    CriteriaIdRequestDTO criteriaIdRequestDTO = new CriteriaIdRequestDTO();
    criteriaIdRequestDTO.setCategories(null);

    // Method call
    pqCriteriaService.createCriteria(acceptLanguage, criteriaIdRequestDTO, categoryCode, pqCriteriaMaster);

    // Verify no interactions
    verifyNoInteractions(criteriaManagementTransformer, pqCriteriaRepository);
  }


  @Test
  void testFetchCriteria() {
    MockitoAnnotations.openMocks(this);
    String acceptLanguage = TestConstants.LANGUAGE_CODE;
    UUID offeringId = UUID.randomUUID();
    PqCriteriaMaster pqCriteriaMaster = PqCriteriaMaster.builder().id(1L).build();
    List<PqCriteria> criteriaList = new ArrayList<>();
    criteriaList.add(new PqCriteria());
    when(pqCriteriaRepository.findByStatusLookupAndPqCriteriaMaster(
        LookupConstants.Status.ACTIVE.getLookupCode(), pqCriteriaMaster))
        .thenReturn(criteriaList);
    List<PqCriteria> result = pqCriteriaService.fetchCriteria(acceptLanguage, pqCriteriaMaster);
    assertNotNull(result, TestConstants.RESPONSE_NULL);
  }

  @Test
  void testDeleteCriteria() {
    PqCriteriaMaster pqCriteriaMaster = PqCriteriaMaster.builder().id(1L).build();
    List<PqCriteria> criteriaList = new ArrayList<>();
    PqCriteria criteria = new PqCriteria();
    criteria.setStatusLookup(LookupConstants.Status.ACTIVE.getLookupCode());
    criteriaList.add(criteria);

    when(pqCriteriaRepository.findByStatusLookupAndPqCriteriaMaster(
        LookupConstants.Status.ACTIVE.getLookupCode(), pqCriteriaMaster))
        .thenReturn(criteriaList);
    when(pqCriteriaRepository.save(any(PqCriteria.class))).thenReturn(criteria);
    pqCriteriaService.deleteCriteria(acceptLanguage, pqCriteriaMaster);
    assertEquals(LookupConstants.Status.INACTIVE.getLookupCode(), criteria.getStatusLookup());
    verify(pqCriteriaRepository, times(1)).save(criteria);
  }

  @Test
  void testDeleteCategory() {
    UUID criteriaId = TestConstants.CRITERIA_ID;
    UUID categoryId = TestConstants.CATEGORY_CODE;
    PqCriteriaMaster pqCriteriaMaster = PqCriteriaMaster.builder().masterCriteriaId(criteriaId).build();
    PqCriteria criteria = PqCriteria.builder()
        .statusLookup(LookupConstants.Status.ACTIVE.getLookupCode())
        .build();

    when(pqCriteriaRepository.findByPqCategoryIdAndCategoryCodeAndStatusLookup(
        criteriaId, categoryId, LookupConstants.Status.ACTIVE.getLookupCode()))
        .thenReturn(criteria);
    when(pqCriteriaRepository.save(any(PqCriteria.class))).thenReturn(criteria);

    pqCriteriaService.deleteCategory(TestConstants.LANGUAGE_CODE, pqCriteriaMaster, categoryId);

    assertEquals(LookupConstants.Status.INACTIVE.getLookupCode(), criteria.getStatusLookup());
    verify(pqCriteriaRepository, times(1)).save(criteria);
  }

  @Test
  void testFetchByCriteriaIdAndCategoryId() {
    UUID criteriaId = UUID.randomUUID();
    UUID categoryCode = TestConstants.CATEGORY_CODE;
    PqCriteria criteria = new PqCriteria();
    when(pqCriteriaRepository.findByPqCategoryIdAndCategoryCode(criteriaId, categoryCode))
        .thenReturn(criteria);

    PqCriteria result = pqCriteriaService.fetchByCriteriaIdAndCategoryId(acceptLanguage, criteriaId, categoryCode);

    assertNotNull(result, TestConstants.RESPONSE_NULL);
  }

  @Test
  void testFetchByCriteriaIdAndCategoryId_NotFound() {
    UUID criteriaId = TestConstants.CRITERIA_ID;
    UUID categoryCode = TestConstants.CATEGORY_CODE;
    when(pqCriteriaRepository.findByPqCategoryIdAndCategoryCode(criteriaId, categoryCode))
        .thenReturn(null);
    when(messageUtility.getMessage(any())).thenReturn(TestConstants.MESSAGE_UTILITY);

    Assertions.assertThrows(NotFoundException.class, () ->
        pqCriteriaService.fetchByCriteriaIdAndCategoryId(acceptLanguage, criteriaId, categoryCode));
  }

  @Test
  void testFetchCategory() {
    UUID categoryCode = TestConstants.CATEGORY_CODE;
    PqCriteria criteria = new PqCriteria();
    when(pqCriteriaRepository.findByCategoryCodeAndStatusLookup(any(), any())).thenReturn(criteria);

    PqCriteria result = pqCriteriaService.fetchCategory(acceptLanguage, categoryCode);

    assertNotNull(result, TestConstants.RESPONSE_NULL);
  }

  @Test
  void testFetchByCriteriaIdSuccess() {
    UUID criteriaId = UUID.randomUUID();
    PqCriteria criteria = new PqCriteria();
    when(pqCriteriaRepository.findByPqCategoryId(criteriaId)).thenReturn(criteria);

    PqCriteria result = pqCriteriaService.fetchByCriteriaId(TestConstants.LANGUAGE_CODE, criteriaId);

    assertNotNull(result, TestConstants.RESPONSE_NULL);
  }

  @Test
  void testFetchActiveCategoryValid() {
    PqCriteria pqCriteria = PqCriteria.builder()
        .statusLookup(LookupConstants.Status.ACTIVE.getLookupCode())
        .categoryCode(TestConstants.CATEGORY_CODE)
        .build();

    lenient().when(pqCriteriaRepository.findByStatusLookupAndPqCriteriaMasterAndCategoryCode(
            any(), any(), any()))
        .thenReturn(Optional.of(pqCriteria));


    PqCriteria result = pqCriteriaService.fetchActiveCategory(pqCriteriaMaster, categoryCode);

    Assertions.assertNotNull(result, TestConstants.RESPONSE_NULL);
  }

  @Test
  void testFetchActiveCategoryNotFound() {
    lenient().when(pqCriteriaRepository.findByStatusLookupAndPqCriteriaMasterAndCategoryCode(
            any(), any(), any()))
        .thenReturn(Optional.empty());

    lenient().when(messageUtility.getMessage(any()))
        .thenReturn(TestConstants.MESSAGE_UTILITY);

    Assertions.assertThrows(InvalidInputException.class, () ->
        pqCriteriaService.fetchActiveCategory(pqCriteriaMaster, categoryCode)
    );
  }

  @Test
  void testFetchCategoriesSuccess() {
    List<PqCriteria> pqCriteriaList = List.of(mock(PqCriteria.class), mock(PqCriteria.class));

    when(pqCriteriaRepository.findByStatusLookupAndPqCriteriaMaster(
        LookupConstants.Status.ACTIVE.getLookupCode(), pqCriteriaMaster))
        .thenReturn(pqCriteriaList);

    List<PqCriteria> result = pqCriteriaService.fetchCategories(pqCriteriaMaster);

    assertNotNull(result, TestConstants.RESPONSE_NULL);
  }

  @Test
  void testFetchCategoriesThrowsNotFoundException() {
    when(pqCriteriaRepository.findByStatusLookupAndPqCriteriaMaster(
        LookupConstants.Status.ACTIVE.getLookupCode(), pqCriteriaMaster))
        .thenReturn(List.of());

    assertThrows(NotFoundException.class, () ->
        pqCriteriaService.fetchCategories(pqCriteriaMaster)
    );
  }


  @Test
  void testCreateCriteriaWithNullCategories() {
    CriteriaIdRequestDTO criteriaIdRequestDTO = new CriteriaIdRequestDTO();
    criteriaIdRequestDTO.setCategories(null);

    pqCriteriaService.createCriteria(acceptLanguage, criteriaIdRequestDTO, UUID.randomUUID(), pqCriteriaMaster);

    verifyNoInteractions(criteriaManagementTransformer, pqCriteriaRepository);
  }

  @Test
  void testCreateCriteriaWithEmptyCategories() {
    CriteriaIdRequestDTO criteriaIdRequestDTO = new CriteriaIdRequestDTO();
    criteriaIdRequestDTO.setCategories(Collections.emptyList());

    pqCriteriaService.createCriteria(acceptLanguage, criteriaIdRequestDTO, UUID.randomUUID(), pqCriteriaMaster);

    verifyNoInteractions(criteriaManagementTransformer, pqCriteriaRepository);
  }

  @Test
  void testCreateCriteriaThrowsNotFoundExceptionForNullCategoryCode() {
    CriteriaIdRequestDTO criteriaIdRequestDTO = new CriteriaIdRequestDTO();
    CategoryResponseDTO category = new CategoryResponseDTO();
    category.setCategoryCode(null);
    category.setCategoryName("Category 1");

    criteriaIdRequestDTO.setCategories(List.of(category));

    lenient().when(criteriaManagementTransformer.toPqCriteria(any(), any(), any(), any()))
        .thenReturn(PqCriteria.builder().categoryCode(null).build());

    lenient().when(messageUtility.getMessage(ErrorMessageConstants.ACTIVE_CATEGORY_NOT_FOUND))
        .thenReturn(TestConstants.MESSAGE_UTILITY);

    assertThrows(NullPointerException.class, () ->
        pqCriteriaService.createCriteria(acceptLanguage, criteriaIdRequestDTO, UUID.randomUUID(), pqCriteriaMaster)
    );

  }

}