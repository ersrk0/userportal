
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * Pq Clarification Msg Repository: Contains DB function to fetch Pq clarification msg data.
 */
package in.gov.gem.app.fa.pq.controller;

import in.gov.gem.app.fa.pq.constant.Constants;
import in.gov.gem.app.fa.pq.constant.MessageConstants;
import in.gov.gem.app.fa.pq.domain.entity.PqSubmission;
import in.gov.gem.app.fa.pq.facade.IEvaluationManagementFacade;
import in.gov.gem.app.fa.pq.request.ScoreRequestDto;
import in.gov.gem.app.fa.pq.response.SubmissionListResponseDTO;
import in.gov.gem.app.service.core.utility.MessageUtility;
import in.gov.gem.app.service.dto.APIResponse;
import in.gov.gem.app.service.dto.PaginationParams;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

class EvaluatorManagementControllerTest {

    @Mock
    private MessageUtility messageUtility;

    @Mock
    private IEvaluationManagementFacade iEvaluationManagementFacade;

    @InjectMocks
    private EvaluatorManagementController evaluatorManagementController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testCreateCriteria_Success() {
        // Arrange
        UUID questionId = UUID.randomUUID();
        String participationId = "test-participation-id";
        String acceptLanguage = "en";
        ScoreRequestDto scoreRequestDto = new ScoreRequestDto();
        String expectedResponse = "Score saved successfully";

        when(iEvaluationManagementFacade.saveScore(questionId, participationId, scoreRequestDto, acceptLanguage))
                .thenReturn(expectedResponse);
        when(messageUtility.getMessage(MessageConstants.SUCCESS_MESSAGE))
                .thenReturn("Operation successful");

        ResponseEntity<APIResponse<String>> response = evaluatorManagementController.evaluateQuestion(
                questionId, participationId, acceptLanguage, scoreRequestDto);

        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals("Operation successful", response.getBody().getMessage());
        assertEquals(expectedResponse, response.getBody().getData());
        assertEquals(Constants.MSID, response.getBody().getMsId());

        verify(iEvaluationManagementFacade, times(1))
                .saveScore(questionId, participationId, scoreRequestDto, acceptLanguage);
        verify(messageUtility, times(1)).getMessage(MessageConstants.SUCCESS_MESSAGE);
    }



    @Test
    void testFetchCategoriesSubmission_Success() {

        PaginationParams paginationParams = new PaginationParams();
        paginationParams.setPageNumber(1);
        paginationParams.setPageSize(10);

        UUID criteriaId = UUID.randomUUID();
        String participationId = "test-participation-id";
        String acceptLanguage = "en";
        SubmissionListResponseDTO mockResponse = new SubmissionListResponseDTO();
        String successMessage = "Operation successful";

        when(iEvaluationManagementFacade.fetchCategoriesSubmission(criteriaId, participationId, acceptLanguage, paginationParams))
            .thenReturn(mockResponse);
        when(messageUtility.getMessage(MessageConstants.SUCCESS_MESSAGE))
            .thenReturn(successMessage);

        // Act
        ResponseEntity<APIResponse<SubmissionListResponseDTO>> response = evaluatorManagementController.fetchCategoriesSubmission(
            criteriaId, participationId, acceptLanguage, paginationParams);

        // Assert
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals(successMessage, response.getBody().getMessage());
        assertEquals(mockResponse, response.getBody().getData());
        assertEquals(Constants.MSID, response.getBody().getMsId());

        verify(iEvaluationManagementFacade, times(1))
            .fetchCategoriesSubmission(criteriaId, participationId, acceptLanguage, paginationParams);
        verify(messageUtility, times(1)).getMessage(MessageConstants.SUCCESS_MESSAGE);
    }
}