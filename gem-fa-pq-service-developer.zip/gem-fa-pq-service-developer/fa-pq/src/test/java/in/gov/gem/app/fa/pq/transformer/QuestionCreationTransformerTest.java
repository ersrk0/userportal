
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * QuestionCreationTransformerTest: Implements the transformer layer.
 */

package in.gov.gem.app.fa.pq.transformer;

import in.gov.gem.app.fa.pq.constant.MessageConstants;
import in.gov.gem.app.fa.pq.constant.TestConstants;
import in.gov.gem.app.fa.pq.domain.entity.DocAttachment;
import in.gov.gem.app.fa.pq.domain.entity.DocMaster;
import in.gov.gem.app.fa.pq.domain.entity.PqOption;
import in.gov.gem.app.fa.pq.domain.entity.PqQuestion;
import in.gov.gem.app.fa.pq.request.QuestionCreateRequestDTO;
import in.gov.gem.app.fa.pq.response.CreateQuestionResponseDTO;
import in.gov.gem.app.fa.pq.response.DeleteUploadedDocumentsResponseDTO;
import in.gov.gem.app.fa.pq.response.DocAttachmentResponseDTO;
import in.gov.gem.app.fa.pq.response.MessageResponseDTO;
import in.gov.gem.app.fa.pq.response.QuestionResponseDTO;
import in.gov.gem.app.fa.pq.response.UploadDocumentsResponseDTO;
import in.gov.gem.app.service.core.utility.MessageUtility;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class QuestionCreationTransformerTest {

  private QuestionCreationTransformer transformer;
  private MessageUtility messageUtility;

  @BeforeEach
  void setUp() {
    messageUtility = mock(MessageUtility.class);
    transformer = new QuestionCreationTransformer(messageUtility);
  }

  @Test
  void testToCreateQuestionResponseDTO() {
    UUID criteriaId = UUID.randomUUID();

    DocMaster docMaster = DocMaster.builder()
        .documentId(UUID.randomUUID())
        .build();


    List<PqOption> pqOptions = new ArrayList<>();
    pqOptions.add(PqOption.builder()
        .id(1L)
        .optionValue("Option 1")
        .build());
    pqOptions.add(PqOption.builder()
        .id(2L)
        .optionValue("Option 2")
        .build());
    QuestionCreateRequestDTO requestDTO = QuestionCreateRequestDTO.builder()
        .questionText(TestConstants.QUESTION_TEXT)
        .inputType(TestConstants.INPUT_TYPE)
        .isMandatory(true)
        .build();



    PqQuestion pqQuestion = PqQuestion.builder()
        .pqQuestionId(UUID.randomUUID())
        .build();

    List<DocAttachment> docAttachments = new ArrayList<>();
    DocAttachment docAttachment = DocAttachment.builder()
        .attachmentSize(TestConstants.FILE_SIZE)
        .attachmentName(TestConstants
            .FILE_NAME)
        .build();
    docAttachments.add(docAttachment);

    CreateQuestionResponseDTO responseDTO = transformer.toCreateQuestionResponseDTO(criteriaId, requestDTO, pqQuestion, docMaster, docAttachments, pqOptions);

    assertNotNull(responseDTO, TestConstants.RESPONSE_NULL);
  }

  @Test
  void testToDeleteQuestionMessageResponseDTO() {
    when(messageUtility.getMessage(MessageConstants.DELETE_QUESTION)).thenReturn(TestConstants.MESSAGE_UTILITY);

    MessageResponseDTO responseDTO = transformer.toDeleteQuestionMessageResponseDTO();

    assertNotNull(responseDTO, TestConstants.RESPONSE_NULL);
  }

  @Test
  void testToUpdateQuestionMessageResponseDTO() {
    when(messageUtility.getMessage(MessageConstants.UPDATE_QUESTION)).thenReturn(TestConstants.MESSAGE_UTILITY);

    MessageResponseDTO responseDTO = transformer.toUpdateQuestionMessageResponseDTO();

    assertNotNull(responseDTO, TestConstants.RESPONSE_NULL);
  }

  @Test
  void testToUploadDocumentResponseDTOShouldReturnResponseWithAttachments() {
    List<UUID> attachmentIds = Arrays.asList(UUID.randomUUID(), UUID.randomUUID());
    UUID documentId = UUID.randomUUID();
    DocMaster docMaster = DocMaster.builder().documentId(documentId).build();
    PqQuestion pqQuestion = PqQuestion.builder()
        .docMaster(docMaster)
        .build();

    UploadDocumentsResponseDTO response = transformer.toUploadDocumentResponseDTO(attachmentIds, pqQuestion);

    assertNotNull(response, TestConstants.RESPONSE_NULL);
  }

  @Test
  void testToDeleteDocumentMessageResponseDTO_shouldReturnResponseWithCorrectFields() {
    UUID attachmentId = UUID.randomUUID();
    DeleteUploadedDocumentsResponseDTO response = transformer.toDeleteDocumentMessageResponseDTO(attachmentId);

    assertNotNull(response, TestConstants.RESPONSE_NULL);
  }


  @Test
  void testToQuestionResponseDTOShouldMapFieldsCorrectly() {
    // Arrange
    UUID criteriaId = UUID.randomUUID();

    // Create mock PqOption list
    List<PqOption> pqOptions = new ArrayList<>();
    pqOptions.add(PqOption.builder()
        .id(1L)
        .optionValue("Option 1")
        .build());
    pqOptions.add(PqOption.builder()
        .id(2L)
        .optionValue("Option 2")
        .build());

    // Create mock QuestionCreateRequestDTO
    QuestionCreateRequestDTO requestDTO = QuestionCreateRequestDTO.builder()
        .questionText("Sample Question")
        .inputType("SINGLE_CHOICE")
        .isMandatory(true)
        .build();

    // Create mock PqQuestion
    PqQuestion pqQuestion = PqQuestion.builder()
        .pqQuestionId(UUID.randomUUID())
        .build();

    // Act
    CreateQuestionResponseDTO responseDTO = transformer.toQuestionResponseDTO(criteriaId, requestDTO, pqQuestion, pqOptions);

    // Assert
    assertNotNull(responseDTO, "Response DTO should not be null");
    assertEquals(criteriaId, responseDTO.getCriteriaId(), "Criteria ID should match");
    assertNotNull(responseDTO.getQuestions(), "Questions list should not be null");
    assertEquals(1, responseDTO.getQuestions().size(), "Questions list size should be 1");

    QuestionResponseDTO questionResponseDTO = responseDTO.getQuestions().get(0);
    assertEquals(pqQuestion.getPqQuestionId(), questionResponseDTO.getQuestionId(), "Question ID should match");
    assertEquals(requestDTO.getQuestionText(), questionResponseDTO.getQuestionText(), "Question text should match");
    assertEquals(requestDTO.getInputType(), questionResponseDTO.getInputType(), "Input type should match");
    assertEquals(requestDTO.getIsMandatory(), questionResponseDTO.getIsMandatory(), "Mandatory flag should match");
    assertNotNull(questionResponseDTO.getOptions(), "Options list should not be null");
    assertEquals(2, questionResponseDTO.getOptions().size(), "Options list size should match");
    assertEquals("Option 1", questionResponseDTO.getOptions().get(0).get("value"), "First option value should match");
    assertEquals("Option 2", questionResponseDTO.getOptions().get(1).get("value"), "Second option value should match");
  }

  @Test
  void testConvertToQuestionResponseDTOShouldMapAllFieldsCorrectly() {
    PqQuestion pqQuestion = PqQuestion.builder()
        .pqQuestionId(UUID.randomUUID())
        .questionText(TestConstants.QUESTION_TEXT)
        .questionTypeLookup(TestConstants.QUESTION_TYPE)
        .isMandatory(true)
        .weightage(TestConstants.SCORE)
        .requiresDocument(true)
        .build();

    List<Map<String, Object>> options = new ArrayList<>();
    Map<String, Object> option = new HashMap<>();
    option.put(TestConstants.OPTION_1, TestConstants.OPTION_2);
    options.add(option);

    List<DocAttachmentResponseDTO> attachments = new ArrayList<>();
    attachments.add(DocAttachmentResponseDTO.builder()
        .attachmentId(UUID.randomUUID())
        .docType(TestConstants.DOC_TYPE)
        .fileName(TestConstants.FILE_NAME)
        .fileSize(TestConstants.FILE_SIZE)
        .filePath(TestConstants.FILE_PATH)
        .build());

    QuestionResponseDTO dto = transformer.convertToQuestionResponseDTO(pqQuestion, options, attachments);

    assertNotNull(dto, TestConstants.RESPONSE_NULL);
  }

  @Test
  void testToDeleteCategoryQuestionMessageResponseDTO() {
    when(messageUtility.getMessage(MessageConstants.CATEGORY_QUESTION_DELETED))
        .thenReturn(TestConstants.MESSAGE_UTILITY);

    MessageResponseDTO responseDTO = transformer.toDeleteCategoryQuestionMessageResponseDTO();

    assertNotNull(responseDTO, TestConstants.RESPONSE_NULL);
  }
}