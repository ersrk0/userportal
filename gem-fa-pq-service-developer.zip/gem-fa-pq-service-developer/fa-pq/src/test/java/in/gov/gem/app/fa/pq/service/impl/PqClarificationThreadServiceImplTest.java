
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * PqClarificationThreadServiceImplTest: Tests the facade layer functioning.
 */

package in.gov.gem.app.fa.pq.service.impl;

import in.gov.gem.app.exception.generic.ServiceException;
import in.gov.gem.app.fa.pq.constant.TestConstants;
import in.gov.gem.app.fa.pq.domain.entity.PqClarificationThread;
import in.gov.gem.app.fa.pq.domain.entity.PqResponse;
import in.gov.gem.app.fa.pq.domain.repository.PqClarificationThreadRepository;
import in.gov.gem.app.fa.pq.utility.RequestUtil;
import in.gov.gem.app.service.core.utility.MessageUtility;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.lenient;

@ExtendWith(MockitoExtension.class)
class PqClarificationThreadServiceImplTest {

  @Mock
  private PqClarificationThreadRepository pqClarificationThreadRepository;

  @Mock
  private RequestUtil requestUtil;

  @Mock
  private MessageUtility messageUtility;

  @InjectMocks
  private PqClarificationThreadServiceImpl pqClarificationThreadServiceImpl;

  private String acceptLanguage;

  @BeforeEach
  void setUp() {
    MockitoAnnotations.openMocks(this);

    acceptLanguage = TestConstants.LANGUAGE_CODE;
  }

  @Test
  void testSaveThreadWhenThreadExistsShouldReturnExistingThread() {
    PqResponse pqResponse = new PqResponse();
    PqClarificationThread existingThread = PqClarificationThread.builder()
        .threadId(UUID.randomUUID())
        .pqResponse(pqResponse)
        .statusLookup(TestConstants.STATUS_LOOKUP)
        .build();

    lenient().when(pqClarificationThreadRepository.findByPqResponse(pqResponse)).thenReturn(existingThread);

    PqClarificationThread result = pqClarificationThreadServiceImpl.saveThread(acceptLanguage, pqResponse);

    assertNotNull(result, TestConstants.RESPONSE_NULL);
  }

  @Test
  void testSaveThreadWhenThreadDoesNotExistShouldCreateAndSaveNewThread() {
    PqResponse pqResponse = new PqResponse();
    UUID newThreadId = UUID.randomUUID();

    lenient().when(pqClarificationThreadRepository.findByPqResponse(pqResponse)).thenReturn(null);
    lenient().when(requestUtil.createRequestId()).thenReturn(newThreadId);

    PqClarificationThread result = pqClarificationThreadServiceImpl.saveThread(acceptLanguage, pqResponse);

    assertNotNull(result, TestConstants.RESPONSE_NULL);
  }

  @Test
  void testFetchThreadWhenThreadDoesNotExistShouldThrowServiceException() {
    PqResponse pqResponse = new PqResponse();
    lenient().when(pqClarificationThreadRepository.findByPqResponse(any())).thenReturn(null);
    lenient().when(messageUtility.getMessage(anyString())).thenReturn(TestConstants.MESSAGE_UTILITY);

    Assertions.assertThrows(ServiceException.class, () ->
        pqClarificationThreadServiceImpl.fetchThread(acceptLanguage, pqResponse)
    );
  }
}