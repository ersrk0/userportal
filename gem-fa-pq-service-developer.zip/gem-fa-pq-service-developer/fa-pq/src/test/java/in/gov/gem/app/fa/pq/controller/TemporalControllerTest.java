
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * TemporalControllerTest: Tests the controller functioning.
 */

package in.gov.gem.app.fa.pq.controller;

import in.gov.gem.app.fa.pq.constant.MessageConstants;
import in.gov.gem.app.fa.pq.constant.TestConstants;
import in.gov.gem.app.fa.pq.request.AttachmentTemplate;
import in.gov.gem.app.fa.pq.response.TemporalCriteriaResponseDTO;
import in.gov.gem.app.fa.pq.service.TemporalService;
import in.gov.gem.app.service.core.utility.MessageUtility;
import org.checkerframework.checker.units.qual.A;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)
class TemporalControllerTest {

  @InjectMocks
  private TemporalController temporalController;

  @Mock
  private TemporalService temporalService;

  @Mock
  private MessageUtility messageUtility;

  private MockMvc mockMvc;
  private String acceptLanguage;

  @BeforeEach
  void setUp() {
    mockMvc = MockMvcBuilders.standaloneSetup(temporalController).build();

    acceptLanguage = TestConstants.LANGUAGE_CODE;
  }

  @Test
  void testGetCrieteria() {
    UUID offeringId = TestConstants.CRITERIA_ID;

    TemporalCriteriaResponseDTO temporalCriteriaResponseDTO = TemporalCriteriaResponseDTO.builder()
        .offeringId(UUID.randomUUID())
        .representationAllowed(true)
        .status(TestConstants.STATUS_LOOKUP)
        .build();

    when(temporalService.getTemporalCriteria(any())).thenReturn(temporalCriteriaResponseDTO);
    try {
      mockMvc.perform(get("/v1/temporal/criteria/public/{offeringId}", offeringId)
              .header(TestConstants.HEADER_NAME_LANGUAGE_CODE, acceptLanguage))
          .andExpect(status().isOk())
          .andExpect(jsonPath("$.status").value(HttpStatus.OK.getReasonPhrase()))
          .andExpect(jsonPath("$.message")
              .value(messageUtility.getMessage(MessageConstants.SUCCESS_MESSAGE)));
    } catch (Exception e) {
      throw new RuntimeException(e);
    }
    assertNotNull(temporalCriteriaResponseDTO, TestConstants.RESPONSE_NULL);
  }

    @Test
    void testViewAttachment() {
        UUID attachmentId = UUID.randomUUID();
        byte[] mockResponse = new byte[]{1, 2, 3};
      AttachmentTemplate attachmentTemplate = AttachmentTemplate.builder()
          .byteArray(mockResponse)
          .build();
        when(temporalService.viewAttachment(attachmentId)).thenReturn(attachmentTemplate);
        ResponseEntity<Object> responseEntity = temporalController.viewAttachment(attachmentId);
        assertEquals(mockResponse, responseEntity.getBody());
    }
}