
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * DocumentServiceUtilImplTest: Tests the facade layer functioning.
 */

package in.gov.gem.app.fa.pq.service.impl;

import in.gov.gem.app.fa.pq.constant.TestConstants;
import in.gov.gem.app.fa.pq.domain.entity.DocMaster;
import in.gov.gem.app.fa.pq.domain.repository.DocMasterRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class DocMasterServiceImplTest {

  @Mock
  private DocMasterRepository docMasterRepository;

  @InjectMocks
  private DocMasterServiceImpl docMasterServiceImpl;

  @BeforeEach
  void setUp() {
    MockitoAnnotations.openMocks(this);
  }

  @Test
  void testSaveDocumentMaster() {
    UUID attachmentId = UUID.randomUUID();
    DocMaster mockDocMaster = DocMaster.builder()
        .documentId(attachmentId)
        .build();

    when(docMasterRepository.save(any(DocMaster.class))).thenReturn(mockDocMaster);

    DocMaster result = docMasterServiceImpl.saveDocumentMaster(attachmentId);

    assertNotNull(result, TestConstants.RESPONSE_NULL);
  }
}