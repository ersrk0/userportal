package in.gov.gem.app.fa.pq.validation.response.impl;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import in.gov.gem.app.fa.pq.constant.TestConstants;
import in.gov.gem.app.fa.pq.domain.entity.PqParticipant;
import in.gov.gem.app.fa.pq.domain.entity.PqQuestion;
import in.gov.gem.app.fa.pq.domain.entity.PqResponse;
import in.gov.gem.app.fa.pq.service.PqQuestionResponseService;
import in.gov.gem.app.fa.pq.transformer.QuestionResponseTransformer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.UUID;

@ExtendWith(MockitoExtension.class)
class DateResponseValidationImplTest {

    private DateResponseValidationImpl validation;
    private QuestionResponseTransformer questionResponseTransformer;
    private PqQuestionResponseService pqQuestionResponseService;
    private PqParticipant pqParticipant;

    @BeforeEach
    void setUp() {
        questionResponseTransformer = mock(QuestionResponseTransformer.class);
        pqQuestionResponseService = mock(PqQuestionResponseService.class);
        pqParticipant = mock(PqParticipant.class);
        validation = new DateResponseValidationImpl(
                questionResponseTransformer,
                pqQuestionResponseService
        );
    }

    @Test
    void testValidateWithValidDate() {
        PqQuestion pqQuestion = new PqQuestion();
        List<String> response = List.of("2025-07-11T18:30:00.000Z");
        assertTrue(validation.validate(pqQuestion, response));
    }

    @Test
    void testValidateWithInvalidDate() {
        PqQuestion pqQuestion = new PqQuestion();
        List<String> response = List.of("invalid-date");
        assertFalse(validation.validate(pqQuestion, response));
    }


    @Test
    void testValidateWithEmptyResponse() {
        PqQuestion pqQuestion = new PqQuestion();
        assertFalse(validation.validate(pqQuestion, List.of()));
    }

    @Test
    void testIsValidDateWithValidDate() {
        assertTrue(validation.isValidDate("15-06-2024", "dd-MM-yyyy"));
    }

    @Test
    void testIsValidDateWithInvalidDate() {
        assertFalse(validation.isValidDate("notadate", "dd-MM-yyyy"));
    }

    @Test
    void testBuildPqResponse() {
        UUID submissionId = UUID.randomUUID();
        PqQuestion pqQuestion = new PqQuestion();
        List<String> responses = List.of("01-01-2024");
        PqResponse pqResponse = new PqResponse();
        PqResponse savedResponse = new PqResponse();

        when(questionResponseTransformer.toPqResponseEntityForInput(submissionId, pqQuestion, "01-01-2024",TestConstants.STATUS_LOOKUP,pqParticipant)).thenReturn(pqResponse);
        when(pqQuestionResponseService.saveResponseEntity(pqResponse)).thenReturn(savedResponse);

        PqResponse result = validation.buildPqResponse(submissionId, pqQuestion, responses, TestConstants.STATUS_LOOKUP,pqParticipant);

        assertEquals(savedResponse, result);
        verify(questionResponseTransformer).toPqResponseEntityForInput(submissionId, pqQuestion, "01-01-2024",TestConstants.STATUS_LOOKUP, pqParticipant);
        verify(pqQuestionResponseService).saveResponseEntity(pqResponse);
    }

    @Test
    void testUpdatePqResponse() {
        UUID submissionId = UUID.randomUUID();
        PqQuestion pqQuestion = new PqQuestion();
        List<String> responseList = List.of("31-12-2024");
        PqResponse pqResponse = mock(PqResponse.class);
        PqResponse savedResponse = new PqResponse();

        when(pqQuestionResponseService.fetchResponseFromSubmissionId(submissionId)).thenReturn(pqResponse);
        when(pqQuestionResponseService.saveResponseEntity(pqResponse)).thenReturn(savedResponse);

        PqResponse result = validation.updatePqResponse(submissionId, pqQuestion, responseList);

        assertEquals(savedResponse, result);
        verify(pqResponse).setResponseText("31-12-2024");
        verify(pqQuestionResponseService).saveResponseEntity(pqResponse);
    }
}