
/*
 * This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * This package consists of the Test constants used in the app.
 */

package in.gov.gem.app.fa.pq.constant;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;

public class TestConstants {

  private TestConstants() {
    throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
  }

  public static final UUID CRITERIA_ID = UUID.fromString("550e8400-e29b-41d4-a716-446655440000");
  public static final UUID QUESTION_ID = UUID.fromString("123e4567-e89b-12d3-a456-426614174070");
  public static final Long FILE_SIZE = 1024L;
  public static final String FILE_NAME = "testFile.pdf";
  public static final String FILE_PATH = "test/path/document.pdf";
  public static final String FILE_TOO_LARGE = "File is too large.";

  public static final String NOT_FOUND = "Not Found";

  public static final String DUMMY_CONTENT = "dummy content";

  public static final String CONTENT_TYPE = "application/pdf";


  public static final UUID CATEGORY_CODE = UUID.fromString("123e4567-e89b-12d3-a456-426614174000");
  public static final String CATEGORY_NAME = "Retail";
  public static final UUID CATEGORY_CODE_2 = UUID.fromString("123e4567-e89b-12d3-a456-426614174060");
  public static final String LOOKUP_CODE_PDF = "PDF";

  public static final String LANGUAGE_CODE = "en";
  public static final String QUESTION_TEXT = "What is your experience with Java development?";
  public static final String QUESTION_TYPE = "TEXT";
  public static final String MESSAGE_UTILITY = "Operation successful";
  public static final String FAILURE_MESSAGE = "Operation could not be done.";
  public static final String EMPTY_TEXT = "";
  public static final String VALID_TEXT = "validText123";
  public static final String INVALID_TEXT = "invalidText@#";
  public static final String REPRESENTATION_TEXT = "representationText";
  public static final String USER = "user";



  public static final String RESPONSE_NULL = "Response should not be null.";
  public static final String EXCEPTION_NOT_THROWN = "Expected exception not thrown.";
  public static final String VALUES_NOT_EQUAL = "The two compared values are not equal";
  public static final String NOT_TRUE = "The asserted value is not true";
  public static final String NOT_FALSE = "The asserted value is not false";
  public static final String IO_ERROR = "IO error occured.";
  public static final String ERROR = "Error occured.";



  public static final String INPUT_TYPE = "LCGOV00002";
  public static final String DOC_TYPE = "3002";
  public static final String STATUS_LOOKUP = "ACTIVE";
  public static final String CRITERIA_NAME = "criteriaName";
  public static final String OPTION_1 = "optionValue1";
  public static final String OPTION_2 = "optionValue2";

  public static final String HEADER_NAME_LANGUAGE_CODE = "Accept-Language";
  public static final String PARAM_NAME_CATEGORY_CODE = "categoryCode";
  public static final String PARAM_NAME_CRITERIA_ID = "criteriaId";
  public static final String PARAM_NAME_OFFERING_ID = "offeringId";



  public static final Boolean IS_REQUIRED = Boolean.TRUE;

  public static final Long ID = 1L;

  public static final BigDecimal SCORE = new BigDecimal("100.00");
  public static final BigDecimal WEIGHTAGE = new BigDecimal("10.50");

  public static final LocalDateTime CREATED_AT =
      LocalDateTime.of(2024, 1, 15, 10, 30, 0);
  public static final Integer MAX_FILE_SIZE = 5 * 1024 * 1024;
}
