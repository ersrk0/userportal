
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * PrequalificationQuestionnaireControllerTest: Tests the controller functioning.
 */

package in.gov.gem.app.fa.pq.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import in.gov.gem.app.fa.pq.constant.MessageConstants;
import in.gov.gem.app.fa.pq.constant.TestConstants;
import in.gov.gem.app.fa.pq.domain.entity.PqOption;
import in.gov.gem.app.fa.pq.facade.impl.PrequalificationQuestionnaireFacade;
import in.gov.gem.app.fa.pq.request.QuestionCreateRequestDTO;
import in.gov.gem.app.fa.pq.request.QuestionUpdateRequestDTO;
import in.gov.gem.app.fa.pq.response.CreateQuestionResponseDTO;
import in.gov.gem.app.fa.pq.response.DeleteUploadedDocumentsResponseDTO;
import in.gov.gem.app.fa.pq.response.MessageResponseDTO;
import in.gov.gem.app.fa.pq.response.QuestionResponseDTO;
import in.gov.gem.app.fa.pq.response.UploadDocumentsResponseDTO;
import in.gov.gem.app.service.core.utility.MessageUtility;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.multipart.MultipartFile;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)
public class PrequalificationQuestionnaireControllerTest {

  @InjectMocks
  private PrequalificationQuestionnaireController prequalificationQuestionnaireController;

  @Mock
  private PrequalificationQuestionnaireFacade prequalificationQuestionnaireFacade;

  @Mock
  private MessageUtility messageUtility;

  private MockMvc mockMvc;
  private String acceptLanguage;

  @BeforeEach
  void setUp() {
    mockMvc = MockMvcBuilders.standaloneSetup(prequalificationQuestionnaireController).build();

    acceptLanguage = TestConstants.LANGUAGE_CODE;
  }

  public static String asJsonString(final Object obj) {
    try {
      ObjectMapper objectMapper = new ObjectMapper();
      objectMapper.registerModule(new JavaTimeModule());
      return objectMapper.writeValueAsString(obj);
    } catch (Exception e) {
      throw new RuntimeException(e);
    }
  }

  @Test
  void testCreateQuestion() throws Exception {
    UUID criteriaId = TestConstants.CRITERIA_ID;
    UUID categoryCode = TestConstants.CATEGORY_CODE;
    String acceptLanguage = TestConstants.LANGUAGE_CODE;

    List<PqOption> pqOptions = new ArrayList<>();
    pqOptions.add(PqOption.builder()
        .id(1L)
        .optionValue("Option 1")
        .build());
    pqOptions.add(PqOption.builder()
        .id(2L)
        .optionValue("Option 2")
        .build());
    QuestionCreateRequestDTO request = QuestionCreateRequestDTO.builder()
        .questionText(TestConstants.QUESTION_TEXT)
        .inputType(TestConstants.INPUT_TYPE)
        .isMandatory(TestConstants.IS_REQUIRED)
        .docRequired(TestConstants.IS_REQUIRED)
        .score(TestConstants.SCORE)
        .build();

    List<QuestionResponseDTO> questionsList = new ArrayList<>();

    CreateQuestionResponseDTO response = CreateQuestionResponseDTO.builder()
        .criteriaId(TestConstants.CRITERIA_ID)
        .questions(questionsList)
        .build();

    MockMultipartFile file = new MockMultipartFile(
        "file",
        "test-file.pdf",
        MediaType.APPLICATION_PDF_VALUE,
        "test content".getBytes()
    );

    MockMultipartFile requestPart = new MockMultipartFile(
        "request",
        "",
        MediaType.APPLICATION_JSON_VALUE,
        asJsonString(request).getBytes()
    );

    when(messageUtility.getMessage(any())).thenReturn(TestConstants.MESSAGE_UTILITY);
    when(prequalificationQuestionnaireFacade.createQuestion(any(), any(), any(), any(MultipartFile[].class),
        any(QuestionCreateRequestDTO.class)
    )).thenReturn(response);

    mockMvc.perform(multipart("/v1/public/criteria/{criteriaId}/categories/{categoryCode}/questions",
            criteriaId, categoryCode)
            .file(file)
            .file(requestPart)
            .header("Accept-Language", acceptLanguage))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.status").value(HttpStatus.OK.getReasonPhrase()));

    assertNotNull(response, TestConstants.RESPONSE_NULL);
  }

  @Test
  void testGetQuestions() {
    UUID categoryCode = TestConstants.CATEGORY_CODE;
    UUID criteriaId = TestConstants.CRITERIA_ID;

    List<QuestionResponseDTO> questionsList = new ArrayList<>();

    CreateQuestionResponseDTO createQuestionResponseDTO = CreateQuestionResponseDTO.builder()
        .criteriaId(TestConstants.CRITERIA_ID)
        .questions(questionsList)
        .build();

    Mockito.when(prequalificationQuestionnaireFacade.getQuestions(any(), any(), any(), any(), any()))
        .thenReturn(createQuestionResponseDTO);
    try {
      mockMvc.perform(get("/v1/public/criteria/{criteriaId}/categories/{categoryCode}/questions", criteriaId, categoryCode)
              .header(TestConstants.HEADER_NAME_LANGUAGE_CODE, acceptLanguage))
          .andExpect(status().isOk())
          .andExpect(jsonPath("$.status").value(HttpStatus.OK.getReasonPhrase()))
          .andExpect(jsonPath("$.message")
              .value(messageUtility.getMessage(MessageConstants.SUCCESS_MESSAGE)));
    } catch (Exception e) {
      throw new RuntimeException(e);
    }
    assertNotNull(createQuestionResponseDTO, TestConstants.RESPONSE_NULL);
  }

  @Test
  void testDeleteQuestion() throws Exception {
    UUID criteriaId = TestConstants.CRITERIA_ID; // Add criteriaId
    UUID categoryCode = TestConstants.CATEGORY_CODE;
    UUID questionId = UUID.randomUUID();

    MessageResponseDTO response = MessageResponseDTO.builder()
        .message("Deleted successfully")
        .build();

    when(messageUtility.getMessage(any())).thenReturn(TestConstants.MESSAGE_UTILITY);
    when(prequalificationQuestionnaireFacade.deleteQuestion(any(), any(), any(), any()))
        .thenReturn(response);

    mockMvc.perform(delete("/v1/public/criteria/{criteriaId}/categories/{categoryCode}/questions/{questionId}", criteriaId, categoryCode, questionId) // Include criteriaId
            .header("Accept-Language", acceptLanguage))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.status").value(HttpStatus.OK.getReasonPhrase()))
        .andExpect(jsonPath("$.message").value(TestConstants.MESSAGE_UTILITY));

    assertNotNull(response, TestConstants.RESPONSE_NULL);
  }


  @Test
  void testUpdateQuestions() throws Exception {
    UUID criteriaId = TestConstants.CRITERIA_ID; // Add criteriaId
    UUID categoryCode = TestConstants.CATEGORY_CODE;
    UUID questionsId = UUID.randomUUID();

    QuestionUpdateRequestDTO request = QuestionUpdateRequestDTO.builder()
        .questionText("Updated Question?")
        .inputType("text")
        .isMandatory(true)
        .docRequired(false)
        .score(TestConstants.SCORE)
        .build();

    MessageResponseDTO response = MessageResponseDTO.builder()
        .message(TestConstants.MESSAGE_UTILITY)
        .build();

    when(messageUtility.getMessage(any())).thenReturn(TestConstants.MESSAGE_UTILITY);
    when(prequalificationQuestionnaireFacade.updateQuestions(any(), any(), any(), any(), any()))
        .thenReturn(response);

    mockMvc.perform(put("/v1/public/criteria/{criteriaId}/categories/{categoryCode}/questions/{questionsId}", criteriaId, categoryCode, questionsId) // Include criteriaId
            .header("Accept-Language", acceptLanguage)
            .contentType(MediaType.APPLICATION_JSON)
            .content(asJsonString(request)))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.status").value(HttpStatus.OK.getReasonPhrase()))
        .andExpect(jsonPath("$.message").value(TestConstants.MESSAGE_UTILITY));

    assertNotNull(response, TestConstants.RESPONSE_NULL);
  }


  @Test
  void testUploadDocument() throws Exception {
    UUID criteriaId = UUID.randomUUID();
    UUID categoryCode = UUID.randomUUID();
    UUID questionId = UUID.randomUUID();

    MockMultipartFile file = new MockMultipartFile(
        "file", TestConstants.FILE_NAME, MediaType.APPLICATION_PDF_VALUE, TestConstants.DUMMY_CONTENT.getBytes()
    );

    UploadDocumentsResponseDTO responseDTO = UploadDocumentsResponseDTO.builder().build();

    when(messageUtility.getMessage(MessageConstants.UPLOAD_DOCUMENTS)).thenReturn("Document uploaded");
    when(prequalificationQuestionnaireFacade.uploadDocument(
        anyString(), any(UUID.class), any(UUID.class), any(), any(MultipartFile[].class)))
        .thenReturn(responseDTO);

    mockMvc.perform(multipart("/v1/public/criteria/{criteriaId}/categories/{categoryCode}/questions/{questionId}/attachment", criteriaId, categoryCode, questionId) // Include criteriaId
            .file(file)
            .header("Accept-Language", acceptLanguage))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.status").value(HttpStatus.OK.getReasonPhrase()))
        .andExpect(jsonPath("$.message").value("Document uploaded"));

    assertNotNull(responseDTO);
  }


  @Test
  void testDeleteUploadedDocuments() throws Exception {
    UUID criteriaId = UUID.randomUUID(); // Add criteriaId
    UUID categoryCode = UUID.randomUUID();
    UUID questionId = UUID.randomUUID();
    UUID attachmentId = UUID.randomUUID();

    DeleteUploadedDocumentsResponseDTO responseDTO = DeleteUploadedDocumentsResponseDTO.builder()
        .attachmentId(TestConstants.CATEGORY_CODE_2)
        .build();

    when(messageUtility.getMessage(MessageConstants.DELETE_DOCUMENT)).thenReturn("Document deleted");
    when(prequalificationQuestionnaireFacade.deleteUploadedDocuments(
        anyString(), any(UUID.class), any(UUID.class), any(UUID.class), any()))
        .thenReturn(responseDTO);

    mockMvc.perform(delete("/v1/public/criteria/{criteriaId}/categories/{categoryCode}/questions/{questionId}/attachment/{attachmentId}",
            criteriaId, categoryCode, questionId, attachmentId) // Include criteriaId
            .header("Accept-Language", acceptLanguage))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.status").value(HttpStatus.OK.getReasonPhrase()))
        .andExpect(jsonPath("$.message").value("Document deleted"));

    assertNotNull(responseDTO, TestConstants.RESPONSE_NULL);
  }

  @Test
  void testDeleteCategoryQuestions() throws Exception {
    UUID criteriaId = TestConstants.CRITERIA_ID;
    UUID categoryCode = TestConstants.CATEGORY_CODE;

    MessageResponseDTO response = MessageResponseDTO.builder()
        .message(TestConstants.MESSAGE_UTILITY)
        .build();

    when(messageUtility.getMessage(any())).thenReturn(TestConstants.MESSAGE_UTILITY);
    when(prequalificationQuestionnaireFacade.deleteCategoryQuestion(any(), any(), any()))
        .thenReturn(response);

    mockMvc.perform(delete("/v1/public/criteria/{criteriaId}/categories/{categoryCode}/questions",
            criteriaId, categoryCode)
            .header("Accept-Language", acceptLanguage))
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.status").value(HttpStatus.OK.getReasonPhrase()))
        .andExpect(jsonPath("$.message").value(TestConstants.MESSAGE_UTILITY));

    assertNotNull(response, TestConstants.RESPONSE_NULL);
  }

}
