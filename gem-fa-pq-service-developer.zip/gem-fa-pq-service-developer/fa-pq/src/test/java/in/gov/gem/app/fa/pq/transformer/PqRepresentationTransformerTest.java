
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * PqRepresentationTransformerTest: Implements the transformer layer.
 */

package in.gov.gem.app.fa.pq.transformer;

import in.gov.gem.app.fa.pq.constant.LookupConstants;
import in.gov.gem.app.fa.pq.constant.TestConstants;
import in.gov.gem.app.fa.pq.domain.entity.DocAttachment;
import in.gov.gem.app.fa.pq.domain.entity.DocMaster;
import in.gov.gem.app.fa.pq.domain.entity.PqCriteria;
import in.gov.gem.app.fa.pq.domain.entity.PqParticipant;
import in.gov.gem.app.fa.pq.domain.entity.PqRepresentation;
import in.gov.gem.app.fa.pq.domain.entity.PqRepresentationResponse;
import in.gov.gem.app.fa.pq.request.RepresentationRequestDTO;
import in.gov.gem.app.fa.pq.response.CriteriaRepresentationResponseDTO;
import in.gov.gem.app.fa.pq.response.DocAttachmentResponseDTO;
import in.gov.gem.app.fa.pq.response.RaiseRepresentationResponseDTO;
import in.gov.gem.app.fa.pq.response.RespondRepresentationResponseDTO;
import in.gov.gem.app.fa.pq.service.DocAttachmentService;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.ArgumentMatchers.any;

class PqRepresentationTransformerTest {

  private final PqRepresentationTransformer transformer = new PqRepresentationTransformer();

  @Test
  void testToRaiseRepresentationResponseDTO() {
    DocAttachment docAttachment = DocAttachment.builder()
        .attachmentId(UUID.randomUUID())
        .attachmentTypeLookup(TestConstants.LOOKUP_CODE_PDF)
        .attachmentName(TestConstants.FILE_NAME)
        .attachmentSize(TestConstants.FILE_SIZE)
        .attachmentPath(TestConstants.FILE_PATH)
        .build();
    DocMaster docMaster = DocMaster.builder()
        .documentId(UUID.randomUUID())
        .build();
    RepresentationRequestDTO request = RepresentationRequestDTO.builder()
        .representationText(TestConstants.REPRESENTATION_TEXT)
        .build();

    UUID representationId = UUID.randomUUID();

    List<DocAttachment> docAttachments = Arrays.asList(docAttachment);

    RaiseRepresentationResponseDTO response = transformer.toRaiseRepresentationResponseDTO(docAttachments, docMaster, request, representationId);

    assertNotNull(response, TestConstants.RESPONSE_NULL);
  }


  @Test
  void testToRespondRepresentationResponseDTO() {
    UUID criteriaId = TestConstants.CRITERIA_ID;
    UUID categoryCode = TestConstants.CATEGORY_CODE;

    RespondRepresentationResponseDTO response = transformer.toRespondRepresentationResponseDTO(criteriaId);

    assertNotNull(response, TestConstants.RESPONSE_NULL);
  }

  @Test
  void testToCriteriaRepresentationResponseDTO() {
    // Test data
    UUID documentId = UUID.randomUUID();
    String status = TestConstants.STATUS_LOOKUP;
    String representationText = TestConstants.REPRESENTATION_TEXT;
    UUID categoryCode = UUID.randomUUID();
    UUID raisedBy = UUID.randomUUID();
    UUID respondedBy = UUID.randomUUID();

    PqCriteria pqCriteria = PqCriteria.builder()
        .categoryCode(categoryCode)
        .build();

    DocMaster docMaster = DocMaster.builder()
        .documentId(documentId)
        .build();

    PqRepresentation representation = PqRepresentation.builder()
        .statusLookup(status)
        .representationText(representationText)
        .docMaster(docMaster)
        .pqParticipant(PqParticipant.builder().participantId(String.valueOf(raisedBy)).build())
        .build();

    PqRepresentationResponse pqRepresentationResponse = PqRepresentationResponse.builder()
        .docMaster(docMaster)
        .responseText("Response Text")
        .build();

    List<DocAttachmentResponseDTO> attachments = List.of(
        DocAttachmentResponseDTO.builder()
            .attachmentId(UUID.randomUUID())
            .docType("PDF")
            .fileName("test.pdf")
            .fileSize(123L)
            .filePath("/path/to/file")
            .build()
    );

    CriteriaRepresentationResponseDTO dto = transformer.toCriteriaRepresentationResponseDTO(
        pqCriteria, representation, pqRepresentationResponse, attachments, attachments);

    assertNotNull(dto, TestConstants.RESPONSE_NULL);
  }


  @Test
  void testToDocAttachmentResponseDTOsReturnsActiveAttachments() {
    DocAttachment activeAttachment = DocAttachment.builder()
        .attachmentId(UUID.randomUUID())
        .attachmentTypeLookup(TestConstants.FILE_NAME)
        .attachmentName(TestConstants.FILE_NAME)
        .attachmentSize(TestConstants.FILE_SIZE)
        .attachmentPath(TestConstants.FILE_PATH)
        .statusLookup(LookupConstants.Status.ACTIVE.getLookupCode())
        .build();
    DocAttachment inactiveAttachment = DocAttachment.builder()
        .attachmentId(UUID.randomUUID())
        .attachmentTypeLookup("PDF")
        .attachmentName("file2.pdf")
        .attachmentSize(456L)
        .attachmentPath("some/path2")
        .statusLookup("INACTIVE")
        .build();

    DocAttachmentService docAttachmentService = Mockito.mock(DocAttachmentService.class);
    Mockito.when(docAttachmentService.fetchAllAttachmentsByQuestion(any()))
        .thenReturn(List.of(activeAttachment, inactiveAttachment));

    List<DocAttachmentResponseDTO> result = List.of(
        DocAttachmentResponseDTO.builder()
            .attachmentId(activeAttachment.getAttachmentId())
            .docType(activeAttachment.getAttachmentTypeLookup())
            .fileName(activeAttachment.getAttachmentName())
            .fileSize(activeAttachment.getAttachmentSize())
            .filePath(activeAttachment.getAttachmentPath())
            .build()
    );

    assertNotNull(result, TestConstants.RESPONSE_NULL);
  }

}