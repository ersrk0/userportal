
/*
 * This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * Criteria Management Transformer: Transformer layer to transform an entity to dto & vice versa.
 */

package in.gov.gem.app.fa.pq.transformer;

import in.gov.gem.app.fa.pq.constant.TestConstants;
import in.gov.gem.app.fa.pq.domain.entity.*;
import in.gov.gem.app.fa.pq.request.SubmissionStatusReqDTO;
import in.gov.gem.app.fa.pq.response.PqQuestionResponseDTO;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
class QuestionResponseTransformerTest {

  private final QuestionResponseTransformer transformer = new QuestionResponseTransformer();
  @Mock
  private PqResponse pqResponse;
  @Mock
  private PqOption pqOption;
  @Mock
  private PqParticipant pqParticipant;

  @Test
  void testToPqResponseEntityForSelection() {
    UUID submissionId = UUID.randomUUID();
    PqQuestion pqQuestion = PqQuestion.builder().pqQuestionId(UUID.randomUUID()).build();
    PqOption pqOption = PqOption.builder()
        .pqQuestion(pqQuestion)
        .build();

    PqResponse response = transformer.toPqResponseEntityForSelection(submissionId, pqQuestion, pqOption);

    assertNotNull(response, TestConstants.RESPONSE_NULL);
  }

  @Test
  void testToPqResponseEntityForInput() {
    UUID submissionId = UUID.randomUUID();
    PqQuestion pqQuestion = PqQuestion.builder().pqQuestionId(UUID.randomUUID()).build();
    String data = TestConstants.MESSAGE_UTILITY;

    PqResponse response = transformer.toPqResponseEntityForInput(submissionId, pqQuestion, data, TestConstants.STATUS_LOOKUP, pqParticipant );

    assertNotNull(response, TestConstants.RESPONSE_NULL);
  }

  @Test
  void testToPqQuestionResponseDTO() {
      UUID submissionId = UUID.randomUUID();
      PqResponse pqResponse = PqResponse.builder().pqResponseId(submissionId).build();

      PqQuestionResponseDTO responseDTO = transformer.toPqQuestionResponseDTO(pqResponse);

      assertNotNull(responseDTO, TestConstants.RESPONSE_NULL);
  }

  @Test
  void testToPqResponseEntityForSelectedOptions() {
    UUID submissionId = UUID.randomUUID();
    PqQuestion pqQuestion = PqQuestion.builder().pqQuestionId(UUID.randomUUID()).build();

    PqResponse response = transformer.toPqResponseEntityForSelectedOptions(submissionId, pqQuestion, TestConstants.STATUS_LOOKUP, pqParticipant);

    assertNotNull(response, TestConstants.RESPONSE_NULL);
  }

  @Test
  void testToSubmissionStatusReqDTO() {
    // Arrange
    PqSubmission pqSubmission = PqSubmission.builder()
            .statusLookup("ACTIVE")
            .build();

    // Act
    SubmissionStatusReqDTO result = transformer.toSubmissionStatusReqDTO(pqSubmission);

    // Assert
    assertNotNull(result, "Result should not be null");
    assertEquals("ACTIVE", result.getStatus(), "Status should match the expected value");
  }
}