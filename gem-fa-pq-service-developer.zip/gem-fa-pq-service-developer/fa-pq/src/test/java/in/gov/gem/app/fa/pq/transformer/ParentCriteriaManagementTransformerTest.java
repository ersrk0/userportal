
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * QuestionCreationTransformerTest: Implements the transformer layer.
 */

package in.gov.gem.app.fa.pq.transformer;

import in.gov.gem.app.fa.pq.constant.TestConstants;
import in.gov.gem.app.fa.pq.domain.entity.PqCriteriaMaster;
import in.gov.gem.app.fa.pq.request.CriteriaIdRequestDTO;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Instant;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(MockitoExtension.class)
class ParentCriteriaManagementTransformerTest {

  @Test
  void toPqParentCriteria() {
    ParentCriteriaManagementTransformer transformer = new ParentCriteriaManagementTransformer();
    UUID criteriaId = TestConstants.CRITERIA_ID;
    CriteriaIdRequestDTO criteriaIdRequestDTO = CriteriaIdRequestDTO.builder()
        .offeringId(TestConstants.CRITERIA_ID)
        .status(TestConstants.STATUS_LOOKUP)
        .pqStartDate(Instant.now())
        .pqEndDate(Instant.now())
        .build();

    PqCriteriaMaster result = transformer.toPqParentCriteria(criteriaIdRequestDTO, criteriaId);

    assertNotNull(result);

  }
}