
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * PrequalificationQuestionnaireFacadeTest: Tests the facade layer functioning.
 */

package in.gov.gem.app.fa.pq.facade;

import in.gov.gem.app.exception.generic.ServiceException;
import in.gov.gem.app.exception.utility.ErrorConstant;
import in.gov.gem.app.fa.pq.constant.ErrorMessageConstants;
import in.gov.gem.app.fa.pq.constant.LookupConstants;
import in.gov.gem.app.fa.pq.constant.TestConstants;
import in.gov.gem.app.fa.pq.domain.entity.*;
import in.gov.gem.app.fa.pq.facade.impl.PrequalificationQuestionnaireFacade;
import in.gov.gem.app.fa.pq.request.QuestionCreateRequestDTO;
import in.gov.gem.app.fa.pq.request.QuestionFilter;
import in.gov.gem.app.fa.pq.request.QuestionUpdateRequestDTO;
import in.gov.gem.app.fa.pq.response.*;
import in.gov.gem.app.fa.pq.service.*;
import in.gov.gem.app.fa.pq.transformer.QuestionCreationTransformer;
import in.gov.gem.app.fa.pq.utility.RequestUtil;
import in.gov.gem.app.service.attachment.utility.S3AttachmentUtility;
import in.gov.gem.app.service.dto.CoreLookupDto;
import in.gov.gem.app.service.dto.PaginationParams;
import in.gov.gem.app.service.pack.service.interfaces.CoreLookupService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class PrequalificationQuestionnaireFacadeTest {

  @Spy
  @InjectMocks
  private PrequalificationQuestionnaireFacade prequalificationQuestionnaireFacade;

  @Mock
  private PqCriteriaService pqCriteriaService;

  @Mock
  private PqCriteriaMasterService pqCriteriaMasterService;

  @Mock
  private PqQuestionService pqQuestionService;

  @Mock
  private PqOptionService pqOptionService;

  @Mock
  private QuestionCreationTransformer questionCreationTransformer;

  @Mock
  private DocumentServiceUtil documentServiceUtil;

  @Mock
  private RequestUtil requestUtil;

  @Mock
  private S3AttachmentUtility s3AttachmentUtility;

  @Mock
  private CoreLookupService coreLookupService;

  @Mock
  private DocumentMasterService documentMasterService;

  @Mock
  private DocAttachmentService docAttachmentService;

  private MockMultipartFile file;

  @BeforeEach
  void setUp() {
    file = new MockMultipartFile(
        TestConstants.FILE_NAME,
        TestConstants.FILE_NAME,
        TestConstants.CONTENT_TYPE,
        "test content".getBytes()
    );
  }

  @Test
  void testCreateQuestion_SuccessWithFileUpload1() throws IOException {
    // Arrange
    String acceptLanguage = "en";
    UUID criteriaId = UUID.randomUUID();
    UUID categoryCode = UUID.randomUUID();
    UUID questionId = UUID.randomUUID();
    UUID documentId = UUID.randomUUID();

    MockMultipartFile file = new MockMultipartFile("file", "test.txt", "text/plain", "test".getBytes());
    MultipartFile[] files = new MultipartFile[]{file};

    QuestionCreateRequestDTO request = QuestionCreateRequestDTO.builder()
            .inputType(LookupConstants.INPUT_TYPE_SINGLE_CHOICE)
            .isDateRange(false)
            .score(BigDecimal.valueOf(10))
            .build();

    PqCriteriaMaster pqCriteriaMaster = PqCriteriaMaster.builder().build();
    PqCriteria pqCriteria = PqCriteria.builder().build();
    PqQuestion pqQuestion = PqQuestion.builder().weightage(BigDecimal.valueOf(10)).build();
    DocMaster docMaster = DocMaster.builder().build();
    PqQuestion savedQuestion = PqQuestion.builder().build();
    PqOption pqOption = PqOption.builder().build();
    CreateQuestionResponseDTO responseDTO = CreateQuestionResponseDTO.builder().build();

    when(pqCriteriaMasterService.fetchActiveCriteriaFromCriteriaId(criteriaId)).thenReturn(pqCriteriaMaster);
    when(pqCriteriaService.fetchActiveCategory(pqCriteriaMaster, categoryCode)).thenReturn(pqCriteria);
    when(pqQuestionService.fetchQuestionByCriteria(pqCriteria)).thenReturn(List.of(pqQuestion));
    when(requestUtil.createRequestId()).thenReturn(questionId, documentId);
    when(documentMasterService.saveDocumentMaster(documentId)).thenReturn(docMaster);
    doNothing().when(prequalificationQuestionnaireFacade).activityLogDocumentUpload(any(), any());
    when(pqQuestionService.createQuestion(any(), any(), any(), any(), any())).thenReturn(savedQuestion);
    when(pqOptionService.createOptions(any(), any())).thenReturn(List.of(pqOption));
    when(docAttachmentService.fetchAllAttachmentsByQuestion(docMaster)).thenReturn(List.of());
    when(questionCreationTransformer.toCreateQuestionResponseDTO(any(), any(), any(), any(), any(), any()))
            .thenReturn(responseDTO);

    // Act
    CreateQuestionResponseDTO result = prequalificationQuestionnaireFacade.createQuestion(
            acceptLanguage, criteriaId, categoryCode, files, request);

    // Assert
    assertNotNull(result);
    verify(prequalificationQuestionnaireFacade).activityLogDocumentUpload(any(), eq(docMaster));
  }

  @Test
  void testCreateQuestion_SuccessWithFileUpload() throws IOException {
    String acceptLanguage = "en";
    UUID criteriaId = UUID.randomUUID();
    UUID categoryCode = UUID.randomUUID();
    UUID questionId = UUID.randomUUID();
    UUID documentId = UUID.randomUUID();

    MockMultipartFile file = new MockMultipartFile("file", "test.txt", "text/plain", "test".getBytes());
    MultipartFile[] files = new MultipartFile[]{file};

    QuestionCreateRequestDTO request = QuestionCreateRequestDTO.builder()
            .inputType(LookupConstants.INPUT_TYPE_SINGLE_CHOICE)
            .isDateRange(false)
            .score(BigDecimal.valueOf(10))
            .build();

    PqCriteriaMaster pqCriteriaMaster = PqCriteriaMaster.builder().build();
    PqCriteria pqCriteria = PqCriteria.builder().build();
    PqQuestion pqQuestion = PqQuestion.builder().weightage(BigDecimal.valueOf(10)).build();
    DocMaster docMaster = DocMaster.builder().build();
    PqQuestion savedQuestion = PqQuestion.builder().build();
    PqOption pqOption = PqOption.builder().build();
    CreateQuestionResponseDTO responseDTO = CreateQuestionResponseDTO.builder().build();

    when(pqCriteriaMasterService.fetchActiveCriteriaFromCriteriaId(criteriaId)).thenReturn(pqCriteriaMaster);
    when(pqCriteriaService.fetchActiveCategory(pqCriteriaMaster, categoryCode)).thenReturn(pqCriteria);
    when(pqQuestionService.fetchQuestionByCriteria(pqCriteria)).thenReturn(List.of(pqQuestion));
    when(requestUtil.createRequestId()).thenReturn(questionId, documentId);
    when(documentMasterService.saveDocumentMaster(documentId)).thenReturn(docMaster);
    doNothing().when(prequalificationQuestionnaireFacade).activityLogDocumentUpload(any(), any());
    when(pqQuestionService.createQuestion(any(), any(), any(), any(), any())).thenReturn(savedQuestion);
    when(pqOptionService.createOptions(any(), any())).thenReturn(List.of(pqOption));
    when(docAttachmentService.fetchAllAttachmentsByQuestion(docMaster)).thenReturn(List.of());
    when(questionCreationTransformer.toCreateQuestionResponseDTO(any(), any(), any(), any(), any(), any()))
            .thenReturn(responseDTO);

    CreateQuestionResponseDTO result = prequalificationQuestionnaireFacade.createQuestion(acceptLanguage, criteriaId, categoryCode, files, request);

    assertNotNull(result);
    verify(prequalificationQuestionnaireFacade).activityLogDocumentUpload(any(), eq(docMaster));
  }


  @Test
  void testCreateQuestionThrowsExceptionWhenCriteriaNotFound() {
    String acceptLanguage = TestConstants.LANGUAGE_CODE;
    UUID criteriaId = UUID.randomUUID();
    UUID categoryCode = TestConstants.CATEGORY_CODE;

    QuestionCreateRequestDTO request = QuestionCreateRequestDTO.builder()
        .questionText(TestConstants.QUESTION_TEXT)
        .inputType(LookupConstants.INPUT_TYPE_SINGLE_CHOICE)
        .isMandatory(true)
        .docRequired(false)
        .build();

    when(pqCriteriaMasterService.fetchActiveCriteriaFromCriteriaId(criteriaId))
        .thenThrow(new ServiceException(
            ErrorMessageConstants.INVALID_QUESTION_ID,
            TestConstants.ERROR,
            ErrorConstant.CATEGORY.TS,
            ErrorConstant.SEVERITY.I
        ));

    Assertions.assertThrows(ServiceException.class, () -> {
      prequalificationQuestionnaireFacade.createQuestion(
          acceptLanguage, criteriaId, categoryCode, null, request);
    }, TestConstants.EXCEPTION_NOT_THROWN);
  }


  @Test
  void testActivityLogDocumentUploadSuccess() throws IOException {
    CoreLookupDto lookupDto = new CoreLookupDto();
    lookupDto.setLookupCode("PDF");
    DocMaster docMaster = DocMaster.builder()
        .documentId(UUID.randomUUID())
        .build();

    when(requestUtil.createRequestId()).thenReturn(UUID.randomUUID());
    when(documentServiceUtil.fileSizeCheck(file)).thenReturn(true);
    when(coreLookupService.findAllByLookupValueIgnoreCase(file.getContentType()))
        .thenReturn(List.of(lookupDto));
    when(requestUtil.createPath(any(), any(), any())).thenReturn("path/to/file");
    doNothing().when(docAttachmentService).saveDocumentDetails(any(), any(), any(), any(), any(), any());
    when(s3AttachmentUtility.uploadMultipart(any(), any(), any(MultipartFile.class))).thenReturn(true);

    Assertions.assertDoesNotThrow(() -> prequalificationQuestionnaireFacade.activityLogDocumentUpload(file, docMaster));
  }


  @Test
  void testActivityLogDocumentUploadThrowsExceptionForFileSizeCheckFailure() {
    DocMaster docMaster = DocMaster.builder()
        .documentId(UUID.randomUUID())
        .build();

    when(documentServiceUtil.fileSizeCheck(any())).thenThrow(new ServiceException(
        ErrorMessageConstants.DOCUMENT_UPLOAD_ERROR_MSG, ErrorMessageConstants.FILE_LIMIT_EXCEEDED,
        ErrorConstant.CATEGORY.TS, ErrorConstant.SEVERITY.I));

    Assertions.assertThrows(ServiceException.class, () -> {
      prequalificationQuestionnaireFacade.activityLogDocumentUpload(file, docMaster);
    }, TestConstants.EXCEPTION_NOT_THROWN);
  }


  @Test
  void testUploadDocumentThrowsExceptionForInvalidQuestionId() {
    String acceptLanguage = TestConstants.LANGUAGE_CODE;
    UUID categoryCode = TestConstants.CATEGORY_CODE;
    UUID questionId = TestConstants.QUESTION_ID;
    UUID criteriaId = TestConstants.CRITERIA_ID;

    PqCriteriaMaster pqCriteriaMaster = PqCriteriaMaster.builder().build();
    PqCriteria pqCriteria = PqCriteria.builder().build();

    when(pqCriteriaMasterService.fetchActiveCriteriaFromCriteriaId(criteriaId)).thenReturn(pqCriteriaMaster);
    when(pqCriteriaService.fetchActiveCategory(pqCriteriaMaster, categoryCode)).thenReturn(pqCriteria);

    when(pqQuestionService.fetchQuestionByQuestionId(pqCriteria, questionId))
        .thenThrow(new ServiceException(
            ErrorMessageConstants.INVALID_QUESTION_ID,
            "Invalid question ID",
            ErrorConstant.CATEGORY.TS,
            ErrorConstant.SEVERITY.I
        ));

    Assertions.assertThrows(ServiceException.class, () -> {
      prequalificationQuestionnaireFacade.uploadDocument(
          acceptLanguage, categoryCode, criteriaId, questionId, new MultipartFile[]{file});
    }, TestConstants.EXCEPTION_NOT_THROWN);
  }

  @Test
  void testActivityLogDocumentUploadThrowsExceptionForNullFileName() {
    MultipartFile file = mock(MultipartFile.class);
    when(file.getOriginalFilename()).thenReturn(null);
    when(file.getContentType()).thenReturn("application/pdf");

    Assertions.assertThrows(AssertionError.class, () -> {
      prequalificationQuestionnaireFacade.activityLogDocumentUpload(file, DocMaster.builder().build());
    }, TestConstants.EXCEPTION_NOT_THROWN);
  }


  @Test
  void testGetQuestions() {
    String acceptLanguage = TestConstants.LANGUAGE_CODE;
    UUID criteriaId = TestConstants.CRITERIA_ID;
    UUID categoryCode = TestConstants.CATEGORY_CODE;

    PqCriteriaMaster pqCriteriaMaster = PqCriteriaMaster.builder()
        .masterCriteriaId(criteriaId)
        .statusLookup(LookupConstants.Status.ACTIVE.getLookupCode())
        .build();
    PqCriteria pqCriteria = PqCriteria.builder()
        .id(TestConstants.ID)
        .pqCategoryId(criteriaId)
        .categoryCode(categoryCode)
        .build();
    PqQuestion pqQuestion = PqQuestion.builder()
        .id(TestConstants.ID)
        .pqQuestionId(UUID.randomUUID())
        .pqCriteria(pqCriteria)
        .questionText(TestConstants.QUESTION_TEXT)
        .isMandatory(true)
        .requiresDocument(false)
        .build();

    QuestionFilter questionFilter = QuestionFilter.builder()
        .isMandatory(Boolean.TRUE)
        .build();

    PaginationParams paginationParams = new PaginationParams();
    paginationParams.setPageNumber(1);
    paginationParams.setPageSize(10);

    Page<PqQuestion> pqQuestionsPage = new PageImpl<>(List.of(pqQuestion)); // Mock paginated result

    when(pqCriteriaMasterService.fetchActiveCriteriaFromCriteriaId(criteriaId)).thenReturn(pqCriteriaMaster);
    when(pqCriteriaService.fetchActiveCategory(pqCriteriaMaster, categoryCode)).thenReturn(pqCriteria);
    when(pqQuestionService.getQuestionsWithFilter(any(), any())).thenReturn(pqQuestionsPage); // Mock paginated service call

    CreateQuestionResponseDTO response = prequalificationQuestionnaireFacade.getQuestions(
        acceptLanguage, criteriaId, categoryCode, questionFilter, paginationParams);

    Assertions.assertNotNull(response, TestConstants.RESPONSE_NULL);
  }

  @Test
  void testGetQuestionsWithActiveQuestionsAndAttachments() {
    // Arrange
    String acceptLanguage = TestConstants.LANGUAGE_CODE;
    UUID criteriaId = TestConstants.CRITERIA_ID;
    UUID categoryCode = TestConstants.CATEGORY_CODE;

    PqCriteriaMaster pqCriteriaMaster = PqCriteriaMaster.builder()
        .masterCriteriaId(criteriaId)
        .statusLookup(LookupConstants.Status.ACTIVE.getLookupCode())
        .build();
    PqCriteria pqCriteria = PqCriteria.builder()
        .id(TestConstants.ID)
        .pqCategoryId(criteriaId)
        .categoryCode(categoryCode)
        .build();
    PqQuestion pqQuestion = PqQuestion.builder()
        .id(TestConstants.ID)
        .pqQuestionId(UUID.randomUUID())
        .pqCriteria(pqCriteria)
        .questionText(TestConstants.QUESTION_TEXT)
        .statusLookup(LookupConstants.Status.ACTIVE.getLookupCode())
        .docMaster(DocMaster.builder().build())
        .build();

    QuestionFilter questionFilter = QuestionFilter.builder()
        .isMandatory(Boolean.TRUE)
        .build();

    PaginationParams paginationParams = new PaginationParams();
    paginationParams.setPageNumber(1);
    paginationParams.setPageSize(10);

    Page<PqQuestion> pqQuestionsPage = new PageImpl<>(List.of(pqQuestion)); // Mock paginated result
    List<DocAttachment> docAttachments = List.of(DocAttachment.builder().attachmentId(UUID.randomUUID()).build());

    when(pqCriteriaMasterService.fetchActiveCriteriaFromCriteriaId(criteriaId)).thenReturn(pqCriteriaMaster);
    when(pqCriteriaService.fetchActiveCategory(pqCriteriaMaster, categoryCode)).thenReturn(pqCriteria);
    when(pqQuestionService.getQuestionsWithFilter(any(), any())).thenReturn(pqQuestionsPage); // Mock paginated service call
    when(docAttachmentService.fetchAllAttachmentsByQuestion(pqQuestion.getDocMaster()))
        .thenReturn(docAttachments);
    when(questionCreationTransformer.convertToQuestionResponseDTO(Mockito.any(), Mockito.any(), Mockito.any()))
        .thenReturn(QuestionResponseDTO.builder().build());

    // Act
    CreateQuestionResponseDTO response = prequalificationQuestionnaireFacade.getQuestions(
        acceptLanguage, criteriaId, categoryCode, questionFilter, paginationParams);

    // Assert
    Assertions.assertNotNull(response, TestConstants.RESPONSE_NULL);
    verify(pqCriteriaMasterService).fetchActiveCriteriaFromCriteriaId(criteriaId);
    verify(pqCriteriaService).fetchActiveCategory(pqCriteriaMaster, categoryCode);
    verify(pqQuestionService).getQuestionsWithFilter(any(), any());
    verify(docAttachmentService).fetchAllAttachmentsByQuestion(pqQuestion.getDocMaster());
    verify(questionCreationTransformer).convertToQuestionResponseDTO(Mockito.any(), Mockito.any(), Mockito.any());
  }

  @Test
  void testGetQuestionsWithNoActiveQuestions() {
    // Arrange
    String acceptLanguage = TestConstants.LANGUAGE_CODE;
    UUID criteriaId = TestConstants.CRITERIA_ID;
    UUID categoryCode = TestConstants.CATEGORY_CODE;

    PqCriteriaMaster pqCriteriaMaster = PqCriteriaMaster.builder()
        .masterCriteriaId(criteriaId)
        .statusLookup(LookupConstants.Status.ACTIVE.getLookupCode())
        .build();
    PqCriteria pqCriteria = PqCriteria.builder()
        .id(TestConstants.ID)
        .pqCategoryId(criteriaId)
        .categoryCode(categoryCode)
        .build();

    QuestionFilter questionFilter = QuestionFilter.builder()
        .isMandatory(Boolean.TRUE)
        .build();

    PaginationParams paginationParams = new PaginationParams();
    paginationParams.setPageNumber(1);
    paginationParams.setPageSize(10);

    Page<PqQuestion> pqQuestionsPage = new PageImpl<>(List.of()); // Mock empty paginated result

    // Mock behavior
    when(pqCriteriaMasterService.fetchActiveCriteriaFromCriteriaId(criteriaId)).thenReturn(pqCriteriaMaster);
    when(pqCriteriaService.fetchActiveCategory(pqCriteriaMaster, categoryCode)).thenReturn(pqCriteria);
    when(pqQuestionService.getQuestionsWithFilter(any(), any())).thenReturn(pqQuestionsPage);

    // Act
    CreateQuestionResponseDTO response =
        prequalificationQuestionnaireFacade.getQuestions(acceptLanguage, criteriaId, categoryCode, questionFilter, paginationParams);

    // Assert
    Assertions.assertNotNull(response, TestConstants.RESPONSE_NULL);
    verify(pqCriteriaMasterService).fetchActiveCriteriaFromCriteriaId(criteriaId);
    verify(pqCriteriaService).fetchActiveCategory(pqCriteriaMaster, categoryCode);
    verify(pqQuestionService).getQuestionsWithFilter(any(), any());
  }

  @Test
  void testGetQuestionsWithActiveQuestionsButNoAttachments() {
    // Arrange
    String acceptLanguage = TestConstants.LANGUAGE_CODE;
    UUID criteriaId = TestConstants.CRITERIA_ID;
    UUID categoryCode = TestConstants.CATEGORY_CODE;

    PqCriteriaMaster pqCriteriaMaster = PqCriteriaMaster.builder()
        .masterCriteriaId(criteriaId)
        .statusLookup(LookupConstants.Status.ACTIVE.getLookupCode())
        .build();

    PqCriteria pqCriteria = PqCriteria.builder()
        .id(TestConstants.ID)
        .pqCategoryId(criteriaId)
        .categoryCode(categoryCode)
        .build();

    PqQuestion pqQuestion = PqQuestion.builder()
        .id(TestConstants.ID)
        .pqQuestionId(UUID.randomUUID())
        .pqCriteria(pqCriteria)
        .questionText(TestConstants.QUESTION_TEXT)
        .statusLookup(LookupConstants.Status.ACTIVE.getLookupCode())
        .docMaster(null)
        .build();

    QuestionFilter questionFilter = QuestionFilter.builder()
        .isMandatory(Boolean.TRUE)
        .build();

    PaginationParams paginationParams = new PaginationParams();
    paginationParams.setPageNumber(1);
    paginationParams.setPageSize(10);

    Page<PqQuestion> pqQuestionsPage = new PageImpl<>(List.of(pqQuestion)); // Mock paginated result

    when(pqCriteriaMasterService.fetchActiveCriteriaFromCriteriaId(criteriaId)).thenReturn(pqCriteriaMaster);
    when(pqCriteriaService.fetchActiveCategory(pqCriteriaMaster, categoryCode)).thenReturn(pqCriteria);
    when(pqQuestionService.getQuestionsWithFilter(any(), any())).thenReturn(pqQuestionsPage); // Mock paginated service call
    when(questionCreationTransformer.convertToQuestionResponseDTO(Mockito.any(), Mockito.any(), Mockito.isNull()))
        .thenReturn(QuestionResponseDTO.builder().build());

    // Act
    CreateQuestionResponseDTO response = prequalificationQuestionnaireFacade.getQuestions(
        acceptLanguage, criteriaId, categoryCode, questionFilter, paginationParams);

    // Assert
    Assertions.assertNotNull(response, TestConstants.RESPONSE_NULL);
    verify(pqCriteriaMasterService).fetchActiveCriteriaFromCriteriaId(criteriaId);
    verify(pqCriteriaService).fetchActiveCategory(pqCriteriaMaster, categoryCode);
    verify(pqQuestionService).getQuestionsWithFilter(any(), any());
    verify(questionCreationTransformer).convertToQuestionResponseDTO(Mockito.any(), Mockito.any(), Mockito.isNull());
  }

  @Test
  void testDeleteQuestion() {
    String acceptLanguage = TestConstants.LANGUAGE_CODE;
    UUID categoryCode = TestConstants.CATEGORY_CODE;
    UUID questionId = UUID.randomUUID();
    UUID criteriaId = TestConstants.CRITERIA_ID;

    DocMaster docMaster = DocMaster.builder().documentId(UUID.randomUUID()).build();
    PqQuestion pqQuestion = PqQuestion.builder()
        .pqQuestionId(questionId)
        .docMaster(docMaster)
        .build();
    PqCriteria pqCriteria = PqCriteria.builder()
        .categoryCode(categoryCode)
        .build();

    PqCriteriaMaster pqCriteriaMaster = PqCriteriaMaster.builder()
        .masterCriteriaId(criteriaId)
        .statusLookup(LookupConstants.Status.ACTIVE.getLookupCode())
        .build();

    when(pqCriteriaMasterService.fetchActiveCriteriaFromCriteriaId(criteriaId)).thenReturn(pqCriteriaMaster);
    when(pqCriteriaService.fetchActiveCategory(pqCriteriaMaster, categoryCode)).thenReturn(pqCriteria);

    when(pqQuestionService.fetchQuestionByQuestionId(pqCriteria, questionId)).thenReturn(pqQuestion);

    MessageResponseDTO mockResponse = MessageResponseDTO.builder()
        .message(TestConstants.MESSAGE_UTILITY)
        .build();

    when(questionCreationTransformer.toDeleteQuestionMessageResponseDTO()).thenReturn(mockResponse);

    MessageResponseDTO response = prequalificationQuestionnaireFacade.deleteQuestion(acceptLanguage, categoryCode,criteriaId, questionId);

    Assertions.assertNotNull(response, TestConstants.RESPONSE_NULL);
  }

  @Test
  void testDeleteQuestionWithOptions() {
    String acceptLanguage = TestConstants.LANGUAGE_CODE;
    UUID categoryCode = TestConstants.CATEGORY_CODE;
    UUID questionId = UUID.randomUUID();
    UUID criteriaId = TestConstants.CRITERIA_ID;

    PqCriteriaMaster pqCriteriaMaster = PqCriteriaMaster.builder().build();
    PqCriteria pqCriteria = PqCriteria.builder().build();

    PqQuestion pqQuestion = PqQuestion.builder()
        .pqQuestionId(questionId)
        .build();

    List<PqOption> pqOptions = List.of(PqOption.builder().optionValue(TestConstants.OPTION_1).build());

    MessageResponseDTO mockResponse = MessageResponseDTO.builder()
        .message(TestConstants.MESSAGE_UTILITY)
        .build();

    when(pqCriteriaMasterService.fetchActiveCriteriaFromCriteriaId(criteriaId)).thenReturn(pqCriteriaMaster);
    when(pqCriteriaService.fetchActiveCategory(pqCriteriaMaster, categoryCode)).thenReturn(pqCriteria);
    when(pqQuestionService.fetchQuestionByQuestionId(pqCriteria, questionId)).thenReturn(pqQuestion);
    when(pqOptionService.fetchOptionByQuestion(pqQuestion)).thenReturn(pqOptions);
    doNothing().when(pqQuestionService).deleteQuestion(acceptLanguage, pqCriteria, questionId);
    doNothing().when(pqOptionService).deleteOptions(pqOptions);
    when(questionCreationTransformer.toDeleteQuestionMessageResponseDTO()).thenReturn(mockResponse);

    MessageResponseDTO response = prequalificationQuestionnaireFacade.deleteQuestion(acceptLanguage, categoryCode, criteriaId, questionId);

    Assertions.assertNotNull(response, TestConstants.RESPONSE_NULL);
  }

  @Test
  void testUpdateQuestionsWithSingleChoice() {
    String acceptLanguage = TestConstants.LANGUAGE_CODE;
    UUID criteriaId = TestConstants.CRITERIA_ID;
    UUID categoryCode = TestConstants.QUESTION_ID;
    UUID questionId = TestConstants.QUESTION_ID;

    PqCriteriaMaster pqCriteriaMaster = PqCriteriaMaster.builder().build();
    PqCriteria pqCriteria = PqCriteria.builder().build();

    when(pqCriteriaMasterService.fetchActiveCriteriaFromCriteriaId(criteriaId)).thenReturn(pqCriteriaMaster);
    when(pqCriteriaService.fetchActiveCategory(pqCriteriaMaster, categoryCode)).thenReturn(pqCriteria);

    QuestionUpdateRequestDTO request = QuestionUpdateRequestDTO.builder()
        .inputType(LookupConstants.INPUT_TYPE_SINGLE_CHOICE)
        .build();
    PqQuestion pqQuestion = PqQuestion.builder()
        .pqQuestionId(questionId)
        .build();

    List<PqOption> pqOptions = List.of(PqOption.builder().optionValue(TestConstants.OPTION_1).build());
    MessageResponseDTO responseDTO = MessageResponseDTO.builder()
        .message(TestConstants.MESSAGE_UTILITY)
        .build();

    when(pqQuestionService.fetchQuestionByQuestionId(pqCriteria, questionId)).thenReturn(pqQuestion);
    doNothing().when(pqQuestionService).updateQuestion(pqQuestion, request);
    when(pqOptionService.fetchOptionByQuestion(pqQuestion)).thenReturn(pqOptions);
    doNothing().when(pqOptionService).updateOptions(request, pqOptions);
    when(questionCreationTransformer.toUpdateQuestionMessageResponseDTO()).thenReturn(responseDTO);

    MessageResponseDTO result = prequalificationQuestionnaireFacade.updateQuestions(
        acceptLanguage, categoryCode, criteriaId, questionId, request);

    Assertions.assertNotNull(result, TestConstants.RESPONSE_NULL);
  }

  @Test
  void testUpdateQuestionsWithMultipleChoice() {
    String acceptLanguage = TestConstants.LANGUAGE_CODE;
    UUID categoryCode = TestConstants.CATEGORY_CODE;
    UUID questionId = TestConstants.QUESTION_ID;
    UUID criteriaId = TestConstants.CRITERIA_ID;

    // Fetch PqCriteria dynamically
    PqCriteriaMaster pqCriteriaMaster = PqCriteriaMaster.builder().build();
    PqCriteria pqCriteria = PqCriteria.builder().build();

    when(pqCriteriaMasterService.fetchActiveCriteriaFromCriteriaId(criteriaId)).thenReturn(pqCriteriaMaster);
    when(pqCriteriaService.fetchActiveCategory(pqCriteriaMaster, categoryCode)).thenReturn(pqCriteria);

    QuestionUpdateRequestDTO request = QuestionUpdateRequestDTO.builder()
        .inputType(LookupConstants.INPUT_TYPE_MULTIPLE_CHOICE)
        .build();
    PqQuestion pqQuestion = PqQuestion.builder()
        .pqQuestionId(questionId)
        .build();

    List<PqOption> pqOptions = List.of(PqOption.builder().optionValue(TestConstants.OPTION_1).build());

    MessageResponseDTO responseDTO = MessageResponseDTO.builder()
        .message(TestConstants.MESSAGE_UTILITY)
        .build();

    when(pqQuestionService.fetchQuestionByQuestionId(pqCriteria, questionId)).thenReturn(pqQuestion);
    doNothing().when(pqQuestionService).updateQuestion(pqQuestion, request);
    when(pqOptionService.fetchOptionByQuestion(pqQuestion)).thenReturn(pqOptions);
    doNothing().when(pqOptionService).updateOptions(request, pqOptions);
    when(questionCreationTransformer.toUpdateQuestionMessageResponseDTO()).thenReturn(responseDTO);

    MessageResponseDTO result = prequalificationQuestionnaireFacade.updateQuestions(
        acceptLanguage, categoryCode, criteriaId, questionId, request);

    Assertions.assertNotNull(result, TestConstants.RESPONSE_NULL);
  }


  @Test
  void testUpdateQuestionsWithOtherInputType() {
    String acceptLanguage = TestConstants.LANGUAGE_CODE;
    UUID categoryCode = TestConstants.CATEGORY_CODE;
    UUID questionId = TestConstants.QUESTION_ID;
    UUID criteriaId = TestConstants.CRITERIA_ID;

    PqCriteriaMaster pqCriteriaMaster = PqCriteriaMaster.builder().build();
    PqCriteria pqCriteria = PqCriteria.builder().build();

    when(pqCriteriaMasterService.fetchActiveCriteriaFromCriteriaId(criteriaId)).thenReturn(pqCriteriaMaster);
    when(pqCriteriaService.fetchActiveCategory(pqCriteriaMaster, categoryCode)).thenReturn(pqCriteria);

    QuestionUpdateRequestDTO request = QuestionUpdateRequestDTO.builder()
        .inputType(TestConstants.INPUT_TYPE)
        .build();
    PqQuestion pqQuestion = PqQuestion.builder()
        .pqQuestionId(questionId)
        .build();
    MessageResponseDTO responseDTO = MessageResponseDTO.builder()
        .message(TestConstants.MESSAGE_UTILITY)
        .build();

    when(pqQuestionService.fetchQuestionByQuestionId(pqCriteria, questionId)).thenReturn(pqQuestion);
    doNothing().when(pqQuestionService).updateQuestion(pqQuestion, request);
    when(questionCreationTransformer.toUpdateQuestionMessageResponseDTO()).thenReturn(responseDTO);

    MessageResponseDTO result = prequalificationQuestionnaireFacade.updateQuestions(
        acceptLanguage, categoryCode, criteriaId, questionId, request);

    Assertions.assertNotNull(result, TestConstants.RESPONSE_NULL);
  }

  @Test
  void testUploadDocumentSuccess() throws IOException {
    String acceptLanguage = TestConstants.LANGUAGE_CODE;
    UUID categoryCode = TestConstants.QUESTION_ID;
    UUID questionId = TestConstants.QUESTION_ID;
    UUID attachmentId = UUID.randomUUID();
    UUID criteriaId = TestConstants.CRITERIA_ID;

    // Fetch PqCriteria dynamically
    PqCriteriaMaster pqCriteriaMaster = PqCriteriaMaster.builder().build();
    PqCriteria pqCriteria = PqCriteria.builder().build();

    when(pqCriteriaMasterService.fetchActiveCriteriaFromCriteriaId(criteriaId)).thenReturn(pqCriteriaMaster);
    when(pqCriteriaService.fetchActiveCategory(pqCriteriaMaster, categoryCode)).thenReturn(pqCriteria);

    PqQuestion pqQuestion = PqQuestion.builder()
        .pqQuestionId(questionId)
        .build();
    CoreLookupDto lookupDto = new CoreLookupDto();
    lookupDto.setLookupCode(TestConstants.LOOKUP_CODE_PDF);
    UploadDocumentsResponseDTO uploadResponse = UploadDocumentsResponseDTO.builder()
        .attachmentsUploaded(List.of(attachmentId))
        .build();

    DocMaster docMaster = DocMaster.builder().build();

    when(pqQuestionService.fetchQuestionByQuestionId(pqCriteria, questionId)).thenReturn(pqQuestion);
    when(requestUtil.createRequestId()).thenReturn(attachmentId);
    when(documentServiceUtil.fileSizeCheck(file)).thenReturn(true);
    when(coreLookupService.findAllByLookupValueIgnoreCase(file.getContentType()))
        .thenReturn(List.of(lookupDto));
    when(requestUtil.createPathUploadDocument(any(), any(), any())).thenReturn("path/to/file");
    when(documentMasterService.saveDocumentMaster(attachmentId)).thenReturn(docMaster);
    doNothing().when(docAttachmentService).saveDocumentDetails(any(), any(), any(), any(), any(), any());
    lenient().when(s3AttachmentUtility.uploadMultipart(any(), any(), any(MultipartFile.class))).thenReturn(true);
    when(questionCreationTransformer.toUploadDocumentResponseDTO(any(), any())).thenReturn(uploadResponse);

    UploadDocumentsResponseDTO result = prequalificationQuestionnaireFacade.uploadDocument(
        acceptLanguage, categoryCode, criteriaId, questionId, new MultipartFile[]{file});

    Assertions.assertNotNull(result, TestConstants.RESPONSE_NULL);
  }

  @Test
  void testUploadDocumentThrowsExceptionWhenQuestionNotFound() {
    String acceptLanguage = TestConstants.LANGUAGE_CODE;
    UUID categoryCode = UUID.randomUUID();
    UUID questionId = UUID.randomUUID();
    UUID criteriaId = TestConstants.CRITERIA_ID;

    PqCriteriaMaster pqCriteriaMaster = PqCriteriaMaster.builder().build();
    PqCriteria pqCriteria = PqCriteria.builder().build();

    when(pqCriteriaMasterService.fetchActiveCriteriaFromCriteriaId(criteriaId)).thenReturn(pqCriteriaMaster);
    when(pqCriteriaService.fetchActiveCategory(pqCriteriaMaster, categoryCode)).thenReturn(pqCriteria);

    when(pqQuestionService.fetchQuestionByQuestionId(pqCriteria, questionId))
        .thenThrow(new ServiceException(
            ErrorMessageConstants.INVALID_QUESTION_ID,
            "Invalid question ID",
            ErrorConstant.CATEGORY.TS,
            ErrorConstant.SEVERITY.I
        ));

    Assertions.assertThrows(ServiceException.class, () -> {
      prequalificationQuestionnaireFacade.uploadDocument(
          acceptLanguage, categoryCode, criteriaId, questionId, new MultipartFile[]{file});
    }, TestConstants.EXCEPTION_NOT_THROWN);
  }

  @Test
  void testUploadDocumentThrowsExceptionWhenFileSizeCheckFails() {
    String acceptLanguage = TestConstants.LANGUAGE_CODE;
    UUID categoryCode = TestConstants.QUESTION_ID;
    UUID questionId = TestConstants.QUESTION_ID;
    UUID attachmentId = UUID.randomUUID();
    UUID criteriaId = TestConstants.CRITERIA_ID;

    PqCriteriaMaster pqCriteriaMaster = PqCriteriaMaster.builder().build();
    PqCriteria pqCriteria = PqCriteria.builder().build();

    when(pqCriteriaMasterService.fetchActiveCriteriaFromCriteriaId(criteriaId)).thenReturn(pqCriteriaMaster);
    when(pqCriteriaService.fetchActiveCategory(pqCriteriaMaster, categoryCode)).thenReturn(pqCriteria);

    PqQuestion pqQuestion = PqQuestion.builder()
        .pqQuestionId(questionId)
        .build();

    when(pqQuestionService.fetchQuestionByQuestionId(pqCriteria, questionId)).thenReturn(pqQuestion);
    when(requestUtil.createRequestId()).thenReturn(attachmentId);
    when(documentServiceUtil.fileSizeCheck(file)).thenThrow(new ServiceException(
        ErrorMessageConstants.DOCUMENT_UPLOAD_ERROR_MSG, ErrorMessageConstants.FILE_LIMIT_EXCEEDED,
        ErrorConstant.CATEGORY.TS, ErrorConstant.SEVERITY.I));

    Assertions.assertThrows(ServiceException.class, () -> {
      prequalificationQuestionnaireFacade.uploadDocument(
          acceptLanguage, categoryCode, criteriaId, questionId, new MultipartFile[]{file});
    }, TestConstants.EXCEPTION_NOT_THROWN);
  }

  @Test
  void testDeleteUploadedDocumentsSuccess() {
    String acceptLanguage = TestConstants.LANGUAGE_CODE;
    UUID categoryCode = TestConstants.CATEGORY_CODE;
    UUID questionId = TestConstants.QUESTION_ID;
    UUID attachmentId = UUID.randomUUID();
    UUID criteriaId = TestConstants.CRITERIA_ID;

    // Fetch PqCriteria dynamically
    PqCriteriaMaster pqCriteriaMaster = PqCriteriaMaster.builder().build();
    PqCriteria pqCriteria = PqCriteria.builder().build();

    when(pqCriteriaMasterService.fetchActiveCriteriaFromCriteriaId(criteriaId)).thenReturn(pqCriteriaMaster);
    when(pqCriteriaService.fetchActiveCategory(pqCriteriaMaster, categoryCode)).thenReturn(pqCriteria);

    PqQuestion pqQuestion = PqQuestion.builder()
        .pqQuestionId(questionId)
        .build();
    DocAttachment docAttachment = DocAttachment.builder()
        .attachmentId(attachmentId)
        .build();
    DeleteUploadedDocumentsResponseDTO responseDTO = DeleteUploadedDocumentsResponseDTO.builder()
        .attachmentId(attachmentId)
        .status(TestConstants.STATUS_LOOKUP)
        .build();

    when(pqQuestionService.fetchQuestionByQuestionId(pqCriteria, questionId)).thenReturn(pqQuestion);
    when(docAttachmentService.fetchAllAttachmentsByQuestion(pqQuestion.getDocMaster()))
        .thenReturn(List.of(docAttachment));
    doNothing().when(docAttachmentService).deleteDocumentByAttachmentId(attachmentId, pqQuestion.getDocMaster());
    when(questionCreationTransformer.toDeleteDocumentMessageResponseDTO(attachmentId)).thenReturn(responseDTO);

    DeleteUploadedDocumentsResponseDTO result = prequalificationQuestionnaireFacade.deleteUploadedDocuments(
        acceptLanguage, categoryCode, criteriaId, questionId, attachmentId);

    Assertions.assertNotNull(result, TestConstants.RESPONSE_NULL);
  }

  @Test
  void testDeleteCategoryQuestion_Success() {
    String acceptLanguage = "en";
    UUID criteriaId = UUID.randomUUID();
    UUID categoryCode = UUID.randomUUID();

    PqCriteriaMaster pqCriteriaMaster = PqCriteriaMaster.builder().build();
    PqCriteria pqCriteria = PqCriteria.builder().build();
    PqQuestion pqQuestion = PqQuestion.builder().build();
    List<PqQuestion> pqQuestionList = List.of(pqQuestion);
    MessageResponseDTO responseDTO = MessageResponseDTO.builder().message("Deleted").build();

    when(pqCriteriaMasterService.fetchActiveCriteriaFromCriteriaId(criteriaId)).thenReturn(pqCriteriaMaster);
    when(pqCriteriaService.fetchActiveCategory(pqCriteriaMaster, categoryCode)).thenReturn(pqCriteria);
    when(pqQuestionService.fetchQuestionByCriteria(pqCriteria)).thenReturn(pqQuestionList);
    doNothing().when(prequalificationQuestionnaireFacade).deleteAllOptions(pqQuestionList);
    doNothing().when(pqQuestionService).deleteAllQuestions(pqQuestionList);
    when(questionCreationTransformer.toDeleteCategoryQuestionMessageResponseDTO()).thenReturn(responseDTO);

    MessageResponseDTO result = prequalificationQuestionnaireFacade.deleteCategoryQuestion(
            acceptLanguage, criteriaId, categoryCode);

    assertNotNull(result);
    verify(pqCriteriaMasterService).fetchActiveCriteriaFromCriteriaId(criteriaId);
    verify(pqCriteriaService).fetchActiveCategory(pqCriteriaMaster, categoryCode);
    verify(pqQuestionService).fetchQuestionByCriteria(pqCriteria);
    verify(prequalificationQuestionnaireFacade).deleteAllOptions(pqQuestionList);
    verify(pqQuestionService).deleteAllQuestions(pqQuestionList);
    verify(questionCreationTransformer).toDeleteCategoryQuestionMessageResponseDTO();
  }

  @Test
  void testDeleteAllOptions() {
    // Arrange
    DocMaster docMaster = DocMaster.builder().documentId(UUID.randomUUID()).build();
    PqQuestion questionWithDoc = PqQuestion.builder().docMaster(docMaster).build();
    PqQuestion questionWithoutDoc = PqQuestion.builder().docMaster(null).build();

    List<PqQuestion> pqQuestionList = List.of(questionWithDoc, questionWithoutDoc);

    List<PqOption> options = List.of(PqOption.builder().build());
    List<DocAttachment> attachments = List.of(DocAttachment.builder().build());

    when(pqOptionService.fetchOptionByQuestion(questionWithDoc)).thenReturn(options);
    when(pqOptionService.fetchOptionByQuestion(questionWithoutDoc)).thenReturn(options);
    when(docAttachmentService.fetchAllAttachmentsByQuestion(docMaster)).thenReturn(attachments);

    // Act
    prequalificationQuestionnaireFacade.deleteAllOptions(pqQuestionList);

    // Assert
    verify(pqOptionService, times(2)).fetchOptionByQuestion(any());
    verify(pqOptionService, times(2)).deleteOptions(options);
    verify(docAttachmentService).fetchAllAttachmentsByQuestion(docMaster);
    verify(docAttachmentService).deleteDocumentMetadata(attachments);
  }

}
