
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * Pq Clarification Msg Repository: Contains DB function to fetch Pq clarification msg data.
 */
package in.gov.gem.app.fa.pq.service.impl;

import in.gov.gem.app.fa.pq.domain.entity.DocMaster;
import in.gov.gem.app.fa.pq.domain.entity.PqAssessment;
import in.gov.gem.app.fa.pq.domain.entity.PqChallenge;
import in.gov.gem.app.fa.pq.domain.entity.PqParticipant;
import in.gov.gem.app.fa.pq.domain.repository.PqChallengeRepository;
import in.gov.gem.app.fa.pq.request.ChallengeReqDTO;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class PqChallenegeServiceImpTest {

    @Mock
    private PqChallengeRepository pqChallengeRepository;

    @InjectMocks
    private PqChallenegeServiceImp pqChallenegeService;

    @Test
    void testCreateChallenege_shouldSaveAndReturnChallenge() {

        PqParticipant pqParticipant = new PqParticipant();
        PqAssessment pqAssessment = new PqAssessment();
        DocMaster docMaster = new DocMaster();
        ChallengeReqDTO challengeReqDTO = new ChallengeReqDTO();
        challengeReqDTO.setIssueRaised("Challenge issue here");
        String status = "ACTIVE";

        PqChallenge expectedChallenge = PqChallenge.builder()
                .ChallengeText("Challenge issue here")
                .pqParticipant(pqParticipant)
                .pqAssessment(pqAssessment)
                .docMaster(docMaster)
                .statusLookUp(status)
                .build();

        when(pqChallengeRepository.save(any(PqChallenge.class))).thenReturn(expectedChallenge);

        PqChallenge result = pqChallenegeService.createChallenege(pqParticipant, pqAssessment, challengeReqDTO, docMaster, status);

        assertNotNull(result);
        assertEquals("Challenge issue here", result.getChallengeText());
        assertEquals(status, result.getStatusLookUp());
        assertEquals(pqParticipant, result.getPqParticipant());
        assertEquals(pqAssessment, result.getPqAssessment());
        assertEquals(docMaster, result.getDocMaster());

        verify(pqChallengeRepository).save(any(PqChallenge.class));
    }
}
