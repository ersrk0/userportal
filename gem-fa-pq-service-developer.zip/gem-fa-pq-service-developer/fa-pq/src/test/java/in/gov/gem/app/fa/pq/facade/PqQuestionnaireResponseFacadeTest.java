
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * PqQuestionnaireResponseFacadeTest: Tests the facade layer functioning.
 */

package in.gov.gem.app.fa.pq.facade;

import in.gov.gem.app.exception.generic.InvalidInputException;
import in.gov.gem.app.exception.generic.ServiceException;
import in.gov.gem.app.exception.utility.ErrorConstant;
import in.gov.gem.app.fa.pq.constant.ErrorMessageConstants;
import in.gov.gem.app.fa.pq.constant.LookupConstants;
import in.gov.gem.app.fa.pq.constant.MessageConstants;
import in.gov.gem.app.fa.pq.constant.TestConstants;
import in.gov.gem.app.fa.pq.domain.entity.DocAttachment;
import in.gov.gem.app.fa.pq.domain.entity.DocMaster;
import in.gov.gem.app.fa.pq.domain.entity.PqCriteria;
import in.gov.gem.app.fa.pq.domain.entity.PqCriteriaMaster;
import in.gov.gem.app.fa.pq.domain.entity.PqOption;
import in.gov.gem.app.fa.pq.domain.entity.PqParticipant;
import in.gov.gem.app.fa.pq.domain.entity.PqQuestion;
import in.gov.gem.app.fa.pq.domain.entity.PqResponse;
import in.gov.gem.app.fa.pq.domain.entity.PqResponseOptionMap;
import in.gov.gem.app.fa.pq.domain.entity.PqSubmission;
import in.gov.gem.app.fa.pq.domain.repository.PqResponseRepository;
import in.gov.gem.app.fa.pq.facade.impl.PqQuestionnaireResponseFacade;
import in.gov.gem.app.fa.pq.request.QuestionnaireResponseSubmitDTO;
import in.gov.gem.app.fa.pq.request.QuestionnaireResponseUpdateDTO;
import in.gov.gem.app.fa.pq.request.SubmissionStatusReqDTO;
import in.gov.gem.app.fa.pq.request.UpdateSubmissionEvaluationDTO;
import in.gov.gem.app.fa.pq.response.CriteriaResponsesDTO;
import in.gov.gem.app.fa.pq.response.CriteriaResponsesDetailsDTO;
import in.gov.gem.app.fa.pq.response.MessageResponseDTO;
import in.gov.gem.app.fa.pq.response.MessageViewResponse;
import in.gov.gem.app.fa.pq.response.ParticipantSubmissionsResponseDTO;
import in.gov.gem.app.fa.pq.response.PqDocumentsAnswerDTO;
import in.gov.gem.app.fa.pq.response.PqQuestionResponseDTO;
import in.gov.gem.app.fa.pq.response.SubmitQuestionsResponseDTO;
import in.gov.gem.app.fa.pq.response.UpdateSubmissionEvaluationResponseDTO;
import in.gov.gem.app.fa.pq.service.DocAttachmentService;
import in.gov.gem.app.fa.pq.service.DocumentMasterService;
import in.gov.gem.app.fa.pq.service.DocumentServiceUtil;
import in.gov.gem.app.fa.pq.service.LanguageService;
import in.gov.gem.app.fa.pq.service.PqAssessmentService;
import in.gov.gem.app.fa.pq.service.PqCriteriaMasterService;
import in.gov.gem.app.fa.pq.service.PqCriteriaService;
import in.gov.gem.app.fa.pq.service.PqParticipateService;
import in.gov.gem.app.fa.pq.service.PqQuestionResponseService;
import in.gov.gem.app.fa.pq.service.PqQuestionService;
import in.gov.gem.app.fa.pq.service.PqResponseOptionMappingService;
import in.gov.gem.app.fa.pq.service.PqResponseService;
import in.gov.gem.app.fa.pq.service.PqSubmissionService;
import in.gov.gem.app.fa.pq.transformer.QuestionResponseTransformer;
import in.gov.gem.app.fa.pq.utility.RequestUtil;
import in.gov.gem.app.service.attachment.utility.S3AttachmentUtility;
import in.gov.gem.app.service.core.utility.MessageUtility;
import in.gov.gem.app.service.dto.CoreLookupDto;
import in.gov.gem.app.service.pack.service.interfaces.CoreLookupService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.times;

class PqQuestionnaireResponseFacadeTest {

  @InjectMocks
  private PqQuestionnaireResponseFacade pqQuestionnaireResponseFacade;

  @Mock private PqQuestionService pqQuestionService;
  @Mock private PqCriteriaService pqCriteriaService;
  @Mock private MessageUtility messageUtility;
  @Mock private QuestionResponseTransformer questionResponseTransformer;
  @Mock private PqQuestionResponseService pqQuestionResponseService;
  @Mock private RequestUtil requestUtil;
  @Mock private S3AttachmentUtility s3AttachmentUtility;
  @Mock private DocAttachmentService docAttachmentService;
  @Mock private CoreLookupService coreLookupService;
  @Mock private DocumentServiceUtil documentServiceUtil;
  @Mock private DocumentMasterService documentMasterService;
  @Mock private IResponseValidationFacade IResponseValidationFacade;
  @Mock private PqCriteriaMasterService pqCriteriaMasterService;
  @Mock private PqQuestion pqQuestion;
  @Mock private PqCriteria pqCriteria;
  @Mock private PqCriteriaMaster pqCriteriaMaster;
  @Mock private PqResponseService pqResponseService;
  @Mock private PqParticipateService pqParticipateService;
  @Mock private PqResponseRepository pqResponseRepository;
  @Mock private PqSubmissionService pqSubmissionService;
  @Mock private PqAssessmentService pqAssessmentService;
  @Mock private LanguageService languageService;
  @Mock private PqResponseOptionMappingService pqResponseOptionMappingService;



  private UUID questionId;
  private UUID criteriaId;
  private UUID submissionId;
  private UUID categoryCode;
  private String participantId;
  private PqParticipant pqParticipant;
  private PqResponse pqResponse;
  private UpdateSubmissionEvaluationDTO updateSubmissionEvaluationRequest;
  private String languageCode;


  @BeforeEach
  void setUp() {
    MockitoAnnotations.openMocks(this);

    questionId = TestConstants.QUESTION_ID;
    criteriaId = TestConstants.CRITERIA_ID;
    submissionId = UUID.randomUUID();
    categoryCode = UUID.randomUUID();
    participantId = UUID.randomUUID().toString();
    pqParticipant = mock(PqParticipant.class);
    pqResponse = mock(PqResponse.class);
    languageCode = TestConstants.LANGUAGE_CODE;

    updateSubmissionEvaluationRequest = new UpdateSubmissionEvaluationDTO(); // Initialize the object

    when(pqQuestionService.fetchQuestionByQuestionId(questionId)).thenReturn(pqQuestion);
    when(pqQuestion.getPqCriteria()).thenReturn(pqCriteria);
    when(pqCriteria.getPqCriteriaMaster()).thenReturn(pqCriteriaMaster);
    when(pqCriteriaMaster.getId()).thenReturn(TestConstants.ID);
    when(pqCriteriaMaster.getMasterCriteriaId()).thenReturn(criteriaId);
    when(pqParticipateService.fetchParticipantById(any(), any())).thenReturn(pqParticipant);
    when(pqResponseRepository.findByPqResponseId(any())).thenReturn(pqResponse);
  }

  @Test
  void testSubmitQuestionResponseShouldThrowExceptionWhenCriteriaIdOrCategoryCodeMismatch() {
    UUID wrongCategoryCode = UUID.randomUUID();
    UUID correctCategoryCode = UUID.randomUUID();
    UUID wrongCriteriaId = UUID.randomUUID();

    when(pqQuestionService.fetchQuestionByQuestionId(questionId)).thenReturn(pqQuestion);
    when(pqQuestion.getPqCriteria()).thenReturn(pqCriteria);
    when(pqCriteria.getPqCategoryId()).thenReturn(wrongCriteriaId);
    when(pqCriteria.getPqCriteriaMaster()).thenReturn(pqCriteriaMaster);
    when(pqCriteriaMaster.getId()).thenReturn(TestConstants.ID);

    when(pqCriteriaService.fetchByCriteriaIdAndCategoryId(any(), eq(criteriaId), eq(wrongCategoryCode))).thenReturn(pqCriteria);
    when(pqCriteria.getCategoryCode()).thenReturn(correctCategoryCode);

    when(messageUtility.getMessage(MessageConstants.INVALID_INPUT)).thenReturn("Invalid input");

    QuestionnaireResponseSubmitDTO dto = mock(QuestionnaireResponseSubmitDTO.class);

    Assertions.assertThrows(ServiceException.class, () ->
        pqQuestionnaireResponseFacade.submitQuestionResponse(criteriaId, questionId, dto, null,participantId));
  }

  @Test
  void testSubmitQuestionResponseShouldThrowExceptionWhenResponseValidationFails() {
    when(pqQuestionService.fetchQuestionByQuestionId(questionId)).thenReturn(pqQuestion);
    when(pqCriteriaMasterService.fetchActiveCriteriaFromCriteriaId(criteriaId)).thenReturn(pqCriteriaMaster);
    when(pqCriteriaMaster.getMasterCriteriaId()).thenReturn(UUID.randomUUID());
    when(pqQuestion.getPqCriteria()).thenReturn(pqCriteria);
    when(pqCriteria.getPqCriteriaMaster()).thenReturn(pqCriteriaMaster);

    when(IResponseValidationFacade.validate(eq(pqQuestion), any())).thenReturn(false);
    when(messageUtility.getMessage(MessageConstants.INVALID_RESPONSE)).thenReturn("Invalid response");

    QuestionnaireResponseSubmitDTO dto = mock(QuestionnaireResponseSubmitDTO.class);

    Assertions.assertThrows(ServiceException.class, () ->
        pqQuestionnaireResponseFacade.submitQuestionResponse(criteriaId, questionId, dto, null,participantId));
  }

  @Test
  void testSubmitQuestionResponseShouldThrowExceptionWhenResponseValidationFails2() {
    PqQuestion pqQuestion = mock(PqQuestion.class);
    PqCriteria pqCriteria = mock(PqCriteria.class);
    PqCriteriaMaster pqCriteriaMaster = mock(PqCriteriaMaster.class);

    when(pqQuestionService.fetchQuestionByQuestionId(questionId)).thenReturn(pqQuestion);
    when(pqQuestion.getPqCriteria()).thenReturn(pqCriteria);
    when(pqCriteria.getPqCriteriaMaster()).thenReturn(pqCriteriaMaster);
    when(pqCriteriaMasterService.fetchActiveCriteriaFromCriteriaId(criteriaId)).thenReturn(pqCriteriaMaster);

    when(pqCriteriaMaster.getMasterCriteriaId()).thenReturn(UUID.randomUUID());
    when(pqCriteriaMaster.getId()).thenReturn(TestConstants.ID);

    when(IResponseValidationFacade.validate(eq(pqQuestion), any())).thenReturn(false);
    when(messageUtility.getMessage(MessageConstants.INVALID_RESPONSE)).thenReturn(TestConstants.MESSAGE_UTILITY);

    QuestionnaireResponseSubmitDTO dto = mock(QuestionnaireResponseSubmitDTO.class);

    Assertions.assertThrows(ServiceException.class, () ->
        pqQuestionnaireResponseFacade.submitQuestionResponse(criteriaId, questionId, dto, null,participantId));
  }

  @Test
  void testSubmitQuestionResponseSuccessWithFiles() throws IOException {
    MultipartFile file = mock(MultipartFile.class);
    MultipartFile[] files = new MultipartFile[]{file};
    QuestionnaireResponseSubmitDTO dto = mock(QuestionnaireResponseSubmitDTO.class);
    PqResponse pqResponse = mock(PqResponse.class);
    PqQuestionResponseDTO responseDTO = new PqQuestionResponseDTO();
    UUID pqResponseId = UUID.randomUUID();
    when(pqQuestionService.fetchQuestionByQuestionId(any())).thenReturn(pqQuestion);
    when(IResponseValidationFacade.validate(any(), any())).thenReturn(true);
    when(requestUtil.generateRandomUUID()).thenReturn(submissionId);
    when(IResponseValidationFacade.buildPqResponse(any(), any(), any(),any(),any())).thenReturn(pqResponse);
    when(pqResponse.getPqResponseId()).thenReturn(pqResponseId);

    PqQuestionnaireResponseFacade spyFacade = Mockito.spy(pqQuestionnaireResponseFacade);
    doReturn(true).when(spyFacade).validateQuestionIdAndCriteriaId(any(), any());
    doReturn(null).when(spyFacade).addDocumentsToResponse(any(), any(), any(), any(),any());
    when(questionResponseTransformer.toPqQuestionResponseDTO(any())).thenReturn(responseDTO);

    PqQuestionResponseDTO result = spyFacade.submitQuestionResponse(criteriaId, questionId, dto, files,participantId);

    assertNotNull(result, TestConstants.RESPONSE_NULL);
  }

  @Test
  @Disabled
  void testSubmitQuestionResponseShouldReturnResponseDTOWhenValidInputAndFilesProvided() throws IOException {
    UUID categoryCode = UUID.randomUUID();
    UUID pqResponseId = UUID.randomUUID();

    PqResponse pqResponse = mock(PqResponse.class);
    PqQuestionResponseDTO responseDTO = mock(PqQuestionResponseDTO.class);

    MultipartFile file = mock(MultipartFile.class);
    MultipartFile[] files = new MultipartFile[]{file};

    QuestionnaireResponseSubmitDTO dto = mock(QuestionnaireResponseSubmitDTO.class);

    when(pqQuestionService.fetchQuestionByQuestionId(any())).thenReturn(pqQuestion);
    when(pqQuestion.getPqCriteria()).thenReturn(pqCriteria);
    when(pqCriteria.getPqCategoryId()).thenReturn(criteriaId);
    when(pqCriteria.getPqCriteriaMaster()).thenReturn(pqCriteriaMaster);
    when(pqCriteriaMaster.getId()).thenReturn(TestConstants.ID);
    when(pqCriteriaMaster.getMasterCriteriaId()).thenReturn(criteriaId);
    when(pqCriteriaService.fetchByCriteriaIdAndCategoryId(any(), any(), any())).thenReturn(pqCriteria);
    when(pqCriteria.getCategoryCode()).thenReturn(categoryCode);

    when(IResponseValidationFacade.validate(any(), any())).thenReturn(true);
    when(requestUtil.generateRandomUUID()).thenReturn(submissionId);
    when(IResponseValidationFacade.buildPqResponse(any(), any(), any(),any(),any())).thenReturn(pqResponse);
    when(pqResponse.getPqResponseId()).thenReturn(pqResponseId);

    PqQuestionnaireResponseFacade spyFacade = Mockito.spy(pqQuestionnaireResponseFacade);
    doReturn(null).when(spyFacade).addDocumentsToResponse(criteriaId, questionId, pqResponseId, files,participantId);

    when(questionResponseTransformer.toPqQuestionResponseDTO(pqResponse)).thenReturn(responseDTO);

    PqQuestionResponseDTO result = spyFacade.submitQuestionResponse(criteriaId, questionId, dto, files,participantId);
    assertNotNull(result, TestConstants.RESPONSE_NULL);
  }

  @Test
  @Disabled
  void testAddDocumentsToResponseEmptyFiles() throws IOException {
    MultipartFile[] files = new MultipartFile[0];
    PqResponse pqResponse = mock(PqResponse.class);

    when(pqQuestionResponseService.fetchResponseFromSubmissionId(submissionId)).thenReturn(pqResponse);
    when(pqQuestionResponseService.saveResponseEntity(any(List.class))).thenReturn(null);

    PqDocumentsAnswerDTO result =
        pqQuestionnaireResponseFacade.addDocumentsToResponse(questionId, criteriaId, submissionId, files,participantId);

    assertNotNull(result, TestConstants.RESPONSE_NULL);
  }

  @Test
  @Disabled
  void testDeleteSubmittedResponse() {
    String expected = TestConstants.MESSAGE_UTILITY;

    when(pqQuestionService.fetchQuestionByQuestionId(questionId)).thenReturn(pqQuestion);
    when(pqQuestion.getPqCriteria()).thenReturn(pqCriteria);
    when(pqCriteria.getPqCriteriaMaster()).thenReturn(pqCriteriaMaster);
    when(pqCriteriaMaster.getId()).thenReturn(TestConstants.ID);
    when(pqCriteriaMaster.getMasterCriteriaId()).thenReturn(criteriaId);
    when(pqQuestionResponseService.deleteSubmittedResponse(criteriaId, questionId, submissionId)).thenReturn(expected);

    String result = pqQuestionnaireResponseFacade.deleteSubmittedResponse(criteriaId, questionId, submissionId, participantId);

    Assertions.assertEquals(expected, result, TestConstants.VALUES_NOT_EQUAL);
  }

  @Test
  void testSaveAnswer() {
    PqResponse pqResponse = mock(PqResponse.class);
    PqResponse expected = mock(PqResponse.class);

    when(pqQuestionResponseService.saveResponseEntity(pqResponse)).thenReturn(expected);

    PqResponse result = pqQuestionnaireResponseFacade.saveAnswer(pqResponse);

    Assertions.assertEquals(expected, result, TestConstants.VALUES_NOT_EQUAL);
  }


  @Test
  void testActivityLogDocumentUploadSuccess() throws IOException {
    MultipartFile file = mock(MultipartFile.class);
    String fileName = TestConstants.FILE_NAME;
    String contentType = TestConstants.CONTENT_TYPE;
    long fileSize = TestConstants.FILE_SIZE;
    UUID attachmentId = UUID.randomUUID();
    String filePath = TestConstants.FILE_PATH;
    String docType = TestConstants.DOC_TYPE;

    CoreLookupDto lookupDto = new CoreLookupDto();
    lookupDto.setLookupCode(docType);
    DocMaster docMaster = mock(DocMaster.class);

    when(file.getOriginalFilename()).thenReturn(fileName);
    when(file.getContentType()).thenReturn(contentType);
    when(file.getSize()).thenReturn(fileSize);
    when(requestUtil.createRequestId()).thenReturn(attachmentId);
    when(documentServiceUtil.fileSizeCheck(file)).thenReturn(true);
    when(coreLookupService.findAllByLookupValueIgnoreCase(contentType)).thenReturn(List.of(lookupDto));
    when(requestUtil.createPath(any(), any(), any())).thenReturn(filePath);
    when(documentMasterService.saveDocumentMaster(attachmentId)).thenReturn(docMaster);
    doNothing().when(docAttachmentService).saveDocumentDetails(docMaster, filePath, docType, fileName, fileSize,
        attachmentId);
    when(s3AttachmentUtility.uploadMultipart(any(), eq(filePath), eq(file))).thenReturn(true);

  }

  @Test
  void testActivityLogDocumentUploadFileSizeCheckThrowsException() {
    MultipartFile file = mock(MultipartFile.class);
    String fileName = TestConstants.FILE_NAME;
    String contentType = TestConstants.CONTENT_TYPE;

    when(file.getOriginalFilename()).thenReturn(fileName);
    when(file.getContentType()).thenReturn(contentType);
    when(requestUtil.createRequestId()).thenReturn(UUID.randomUUID());
    when(documentServiceUtil.fileSizeCheck(any()))
        .thenThrow(new ServiceException(
            TestConstants.ERROR,
            TestConstants.FILE_TOO_LARGE,
            ErrorConstant.CATEGORY.TS,
            ErrorConstant.SEVERITY.I
        ));

    Assertions.assertThrows(ServiceException.class, () -> pqQuestionnaireResponseFacade.activityLogDocumentUpload(file,new DocMaster()));
  }

  @Test
  void testActivityLogDocumentUploadNullFileNameThrowsAssertionError() {
    MultipartFile file = mock(MultipartFile.class);
    when(file.getOriginalFilename()).thenReturn(null);

    Assertions.assertThrows(AssertionError.class, () -> pqQuestionnaireResponseFacade.activityLogDocumentUpload(file,new DocMaster()));
  }

  @Test
  void testActivityLogDocumentUpload_Success() throws IOException {
    MultipartFile file = mock(MultipartFile.class);
    DocMaster docMaster = mock(DocMaster.class);
    String fileName = "test.pdf";
    String contentType = "application/pdf";
    long fileSize = 12345L;
    UUID attachmentId = UUID.randomUUID();
    String filePath = "some/path/test.pdf";
    String docType = "DOC_TYPE";
    CoreLookupDto lookupDto = new CoreLookupDto();
    lookupDto.setLookupCode(docType);

    when(file.getOriginalFilename()).thenReturn(fileName);
    when(file.getContentType()).thenReturn(contentType);
    when(file.getSize()).thenReturn(fileSize);
    when(requestUtil.createRequestId()).thenReturn(attachmentId);
    when(documentServiceUtil.fileSizeCheck(file)).thenReturn(true);
    when(coreLookupService.findAllByLookupValueIgnoreCase(contentType)).thenReturn(List.of(lookupDto));
    when(requestUtil.createPath(any(), any(), any())).thenReturn(filePath);
    doNothing().when(docAttachmentService).saveDocumentDetails(docMaster, filePath, docType, fileName, fileSize, attachmentId);
    when(s3AttachmentUtility.uploadMultipart(any(), eq(filePath), eq(file))).thenReturn(true);
    UUID result = pqQuestionnaireResponseFacade.activityLogDocumentUpload(file, docMaster);

    Assertions.assertEquals(attachmentId, result, TestConstants.VALUES_NOT_EQUAL);
  }

  @Test
  @Disabled
  void testUpdateSubmittedResponseSuccess() throws IOException {
    UUID pqResponseId = UUID.randomUUID();

    MultipartFile file = mock(MultipartFile.class);
    MultipartFile[] files = new MultipartFile[]{file};

    QuestionnaireResponseUpdateDTO updateDTO = mock(QuestionnaireResponseUpdateDTO.class);
    PqResponse pqResponse = mock(PqResponse.class);

    when(file.getOriginalFilename()).thenReturn("testFile.pdf"); // Ensure valid filename
    when(file.getContentType()).thenReturn("application/pdf");
    when(file.getSize()).thenReturn(12345L);

    when(pqQuestionResponseService.fetchResponseFromSubmissionId(submissionId)).thenReturn(pqResponse);
    when(pqResponse.getPqResponseId()).thenReturn(pqResponseId);
    when(pqQuestionService.fetchQuestionByQuestionId(questionId)).thenReturn(pqQuestion);
    when(pqQuestion.getPqCriteria()).thenReturn(pqCriteria);
    when(pqCriteria.getPqCriteriaMaster()).thenReturn(pqCriteriaMaster);
    when(pqCriteriaMasterService.fetchActiveCriteriaFromCriteriaId(criteriaId)).thenReturn(pqCriteriaMaster);
    when(pqCriteriaMaster.getId()).thenReturn(TestConstants.ID);
    when(pqCriteriaMaster.getMasterCriteriaId()).thenReturn(criteriaId);

    when(updateDTO.getResponseType()).thenReturn("type");
    when(updateDTO.getResponseValue()).thenReturn(List.of("value"));
    when(IResponseValidationFacade.validate(eq(pqQuestion), any())).thenReturn(true);
    when(messageUtility.getMessage(MessageConstants.SUCCESS_MESSAGE)).thenReturn("Success");
    when(IResponseValidationFacade.updatePqResponse(eq(submissionId), eq(pqQuestion), any())).thenReturn(pqResponse);

    PqQuestionnaireResponseFacade spyFacade = Mockito.spy(pqQuestionnaireResponseFacade);
    doReturn(null).when(spyFacade).addDocumentsToResponse(questionId, criteriaId, submissionId, files, participantId);

    MessageResponseDTO result = spyFacade.updateSubmittedResponse(criteriaId, questionId, submissionId, files, updateDTO,participantId);

    Assertions.assertEquals("Success", result.getMessage());
  }


  @Test
  void testSaveAnswersSuccess() {
    List<PqResponse> responses = List.of(mock(PqResponse.class), mock(PqResponse.class));
    PqQuestionResponseDTO expectedResponseDTO = mock(PqQuestionResponseDTO.class);

    when(pqQuestionResponseService.saveResponseEntity(responses)).thenReturn(expectedResponseDTO);

    PqQuestionResponseDTO result = pqQuestionnaireResponseFacade.saveAnswers(responses);

    assertNotNull(result, TestConstants.RESPONSE_NULL);
  }

  @Test
  void testUpdateSubmittedResponseThrowsExceptionWhenValidationFails() {
    MultipartFile[] files = new MultipartFile[0];
    QuestionnaireResponseUpdateDTO updateDTO = mock(QuestionnaireResponseUpdateDTO.class);
    PqResponse pqResponse = mock(PqResponse.class);

    when(pqQuestionResponseService.fetchResponseFromSubmissionId(submissionId)).thenReturn(pqResponse);
    when(pqQuestionService.fetchQuestionByQuestionId(questionId)).thenReturn(pqQuestion);
    when(pqQuestion.getPqCriteria()).thenReturn(pqCriteria);
    when(pqCriteria.getPqCriteriaMaster()).thenReturn(pqCriteriaMaster);
    when(pqCriteriaMaster.getId()).thenReturn(TestConstants.ID);
    when(pqCriteriaMaster.getMasterCriteriaId()).thenReturn(criteriaId);

    when(updateDTO.getResponseType()).thenReturn("type");
    when(updateDTO.getResponseValue()).thenReturn(List.of("value"));
    when(IResponseValidationFacade.validate(eq(pqQuestion), any())).thenReturn(false);
    when(messageUtility.getMessage(MessageConstants.INVALID_RESPONSE)).thenReturn(TestConstants.MESSAGE_UTILITY);

    Assertions.assertThrows(ServiceException.class, () -> {
      pqQuestionnaireResponseFacade.updateSubmittedResponse(criteriaId, questionId, submissionId, files, updateDTO,participantId);
    });
  }


  @Test
  void testDeleteResponseAttachmentThrowsExceptionWhenCriteriaIdAndQuestionIdMismatch() {

    UUID responseId = UUID.randomUUID();
    UUID attachmentId = UUID.randomUUID();

    when(pqQuestionService.fetchQuestionByQuestionId(questionId)).thenReturn(null);
    when(messageUtility.getMessage(MessageConstants.INVALID_INPUT)).thenReturn("Invalid input");

    Assertions.assertThrows(ServiceException.class, () -> {
      pqQuestionnaireResponseFacade.deleteResponseAttachment(criteriaId, questionId, responseId, attachmentId);
    });
  }

  @Test
  void testSubmitResponseDraftThrowsExceptionWhenCriteriaMasterIsNull() {
    when(pqCriteriaMasterService.fetchActiveCriteriaFromCriteriaId(criteriaId)).thenReturn(null);

    Assertions.assertThrows(ServiceException.class, () ->
        pqQuestionnaireResponseFacade.submitResponseDraft(criteriaId, categoryCode, participantId,"en"));

  }

  @Test
  void testSubmitResponseDraftWithInactiveQuestions() {
    PqCriteriaMaster pqCriteriaMaster = mock(PqCriteriaMaster.class);
    PqCriteria pqCriteria = mock(PqCriteria.class);
    PqQuestion inactiveQuestion = mock(PqQuestion.class);

    when(pqCriteriaMasterService.fetchActiveCriteriaFromCriteriaId(criteriaId)).thenReturn(pqCriteriaMaster);
    when(pqCriteriaService.fetchActiveCategory(pqCriteriaMaster, categoryCode)).thenReturn(pqCriteria);
    when(pqQuestionService.fetchQuestionByCriteria(pqCriteria)).thenReturn(List.of(inactiveQuestion));
    when(pqResponseService.fetchPqResponsesByQuestion(inactiveQuestion)).thenReturn(new ArrayList<>());
    when(inactiveQuestion.getPqQuestionId()).thenReturn(UUID.randomUUID());

    SubmitQuestionsResponseDTO response = pqQuestionnaireResponseFacade.submitResponseDraft(criteriaId, categoryCode, participantId, "en");

    Assertions.assertNotNull(response);

  }

  @Test
  void testSubmitResponseDraftWithMissingDocuments() {
    PqCriteriaMaster pqCriteriaMaster = mock(PqCriteriaMaster.class);
    PqCriteria pqCriteria = mock(PqCriteria.class);
    PqQuestion questionWithMissingDoc = mock(PqQuestion.class);
    PqResponse pqResponse = mock(PqResponse.class);

    when(pqCriteriaMasterService.fetchActiveCriteriaFromCriteriaId(criteriaId)).thenReturn(pqCriteriaMaster);
    when(pqCriteriaService.fetchActiveCategory(pqCriteriaMaster, categoryCode)).thenReturn(pqCriteria);
    when(pqQuestionService.fetchQuestionByCriteria(pqCriteria)).thenReturn(List.of(questionWithMissingDoc));
    when(pqResponseService.fetchPqResponsesByQuestion(questionWithMissingDoc)).thenReturn(List.of(pqResponse));
    when(questionWithMissingDoc.getRequiresDocument()).thenReturn(true);
    when(questionWithMissingDoc.getDocMaster()).thenReturn(null);

    SubmitQuestionsResponseDTO response = pqQuestionnaireResponseFacade.submitResponseDraft(criteriaId, categoryCode, participantId,"en");

    Assertions.assertNotNull(response);

  }

  @Test
  void testSubmitResponseDraftSuccess() {
    PqCriteriaMaster pqCriteriaMaster = mock(PqCriteriaMaster.class);
    PqCriteria pqCriteria = mock(PqCriteria.class);
    PqQuestion activeQuestion = mock(PqQuestion.class);
    PqResponse pqResponse = mock(PqResponse.class);
    UUID submissionId = UUID.randomUUID();

    when(pqCriteriaMasterService.fetchActiveCriteriaFromCriteriaId(criteriaId)).thenReturn(pqCriteriaMaster);
    when(pqCriteriaService.fetchActiveCategory(any(), any())).thenReturn(pqCriteria);
    when(pqQuestionService.fetchQuestionByCriteria(pqCriteria)).thenReturn(List.of(activeQuestion));
    when(pqResponseService.fetchPqResponsesByQuestion(activeQuestion)).thenReturn(List.of(pqResponse));
    when(activeQuestion.getRequiresDocument()).thenReturn(false);
    when(requestUtil.createRequestId()).thenReturn(submissionId);

    SubmitQuestionsResponseDTO response = pqQuestionnaireResponseFacade.submitResponseDraft(criteriaId, categoryCode,participantId, "en");

    Assertions.assertNotNull(response);

  }

  @Test
  void testAddDocumentsToResponseShouldThrowExceptionWhenValidationFails() throws IOException {
    MultipartFile[] files = new MultipartFile[] { mock(MultipartFile.class) };

    PqQuestionnaireResponseFacade spyFacade = Mockito.spy(pqQuestionnaireResponseFacade);
    doReturn(false).when(spyFacade).validateQuestionIdAndCriteriaId(questionId, criteriaId);

    assertThrows(ServiceException.class, () ->
        spyFacade.addDocumentsToResponse(criteriaId, questionId, submissionId, files,participantId)
    );
  }

  @Test
  void testAddDocumentsToResponseShouldAttachDocumentsAndSave() throws IOException {
    MultipartFile file1 = mock(MultipartFile.class);
    MultipartFile file2 = mock(MultipartFile.class);
    MultipartFile[] files = new MultipartFile[] { file1, file2 };

    PqResponse pqResponse = mock(PqResponse.class);
    DocMaster docMaster = mock(DocMaster.class);
    UUID attachmentId1 = UUID.randomUUID();
    UUID attachmentId2 = UUID.randomUUID();

    PqQuestionnaireResponseFacade spyFacade = Mockito.spy(pqQuestionnaireResponseFacade);

    doReturn(true).when(spyFacade).validateQuestionIdAndCriteriaId(questionId, criteriaId);
    when(pqQuestionResponseService.fetchResponseFromSubmissionId(any())).thenReturn(pqResponse);
    when(documentMasterService.saveDocumentMaster(any())).thenReturn(docMaster);
    doReturn(attachmentId1).when(spyFacade).activityLogDocumentUpload(file1, docMaster);
    doReturn(attachmentId2).when(spyFacade).activityLogDocumentUpload(file2, docMaster);
    when(pqQuestionResponseService.saveResponseEntity(any(PqResponse.class))).thenReturn(pqResponse);

    PqDocumentsAnswerDTO result = spyFacade.addDocumentsToResponse(criteriaId, questionId, submissionId, files, participantId);

    assertNotNull(result, TestConstants.RESPONSE_NULL);

  }

  @Test
  void testAddDocumentsToResponseShouldHandleEmptyFilesArray() throws IOException {
    MultipartFile[] files = new MultipartFile[0];

    PqResponse pqResponse = mock(PqResponse.class);
    DocMaster docMaster = mock(DocMaster.class);

    PqQuestionnaireResponseFacade spyFacade = Mockito.spy(pqQuestionnaireResponseFacade);

    doReturn(true).when(spyFacade).validateQuestionIdAndCriteriaId(questionId, criteriaId);
    when(pqQuestionResponseService.fetchResponseFromSubmissionId(any())).thenReturn(pqResponse);
    when(documentMasterService.saveDocumentMaster(any())).thenReturn(docMaster);
    when(pqQuestionResponseService.saveResponseEntity(any(PqResponse.class))).thenReturn(pqResponse);

    PqDocumentsAnswerDTO result = spyFacade.addDocumentsToResponse(criteriaId, questionId, submissionId, files, participantId);

    assertNotNull(result, TestConstants.RESPONSE_NULL);
  }

  @Test
  void testDeleteSubmittedResponseThrowsExceptionWhenValidationFails() {
//    when(pqQuestionResponseService.validateParticipant(anyString(),any(UUID.class))).thenReturn(true);
    PqQuestionnaireResponseFacade spyFacade = Mockito.spy(pqQuestionnaireResponseFacade);
    doReturn(false).when(spyFacade).validateQuestionIdAndCriteriaId(questionId, criteriaId);

    when(messageUtility.getMessage(any())).thenReturn(TestConstants.MESSAGE_UTILITY);

    assertThrows(ServiceException.class, () ->
        spyFacade.deleteSubmittedResponse(criteriaId, questionId, submissionId,participantId)
    );
  }

  @Test
  void testDeleteSubmittedResponseReturnsExpectedValue() {
//    when(pqQuestionResponseService.validateParticipant(anyString(),any(UUID.class))).thenReturn(true);
    PqQuestionnaireResponseFacade spyFacade = Mockito.spy(pqQuestionnaireResponseFacade);
    doReturn(true).when(spyFacade).validateQuestionIdAndCriteriaId(questionId, criteriaId);

    String expected = TestConstants.MESSAGE_UTILITY;
    when(pqQuestionResponseService.deleteSubmittedResponse(criteriaId, questionId, submissionId)).thenReturn(expected);

    String result = spyFacade.deleteSubmittedResponse(criteriaId, questionId, submissionId, participantId);

    assertEquals(expected, result, TestConstants.VALUES_NOT_EQUAL);
  }

  @Test
  void testDeleteResponseAttachmentThrowsExceptionWhenValidationFails() {
    PqQuestionnaireResponseFacade spyFacade = Mockito.spy(pqQuestionnaireResponseFacade);
    doReturn(false).when(spyFacade).validateQuestionIdAndCriteriaId(questionId, criteriaId);
    when(messageUtility.getMessage(any())).thenReturn(TestConstants.MESSAGE_UTILITY);

    UUID responseId = UUID.randomUUID();
    UUID attachmentId = UUID.randomUUID();

    assertThrows(ServiceException.class, () ->
        spyFacade.deleteResponseAttachment(criteriaId, questionId, responseId, attachmentId)
    );
  }

  @Test
  void testDeleteResponseAttachmentThrowsExceptionWhenResponseNotFound() {
    PqQuestionnaireResponseFacade spyFacade = Mockito.spy(pqQuestionnaireResponseFacade);
    doReturn(true).when(spyFacade).validateQuestionIdAndCriteriaId(questionId, criteriaId);

    UUID responseId = UUID.randomUUID();
    UUID attachmentId = UUID.randomUUID();

    when(pqQuestionResponseService.fetchResponseFromSubmissionId(any())).thenReturn(null);
    when(messageUtility.getMessage(any())).thenReturn(TestConstants.MESSAGE_UTILITY);

    assertThrows(ServiceException.class, () ->
        spyFacade.deleteResponseAttachment(criteriaId, questionId, responseId, attachmentId)
    );
  }

  @Test
  void testDeleteResponseAttachmentThrowsExceptionWhenQuestionIdMismatch() {
    PqQuestionnaireResponseFacade spyFacade = Mockito.spy(pqQuestionnaireResponseFacade);
    doReturn(true).when(spyFacade).validateQuestionIdAndCriteriaId(questionId, criteriaId);

    UUID responseId = UUID.randomUUID();
    UUID attachmentId = UUID.randomUUID();

    PqResponse pqResponse = mock(PqResponse.class);
    PqQuestion otherQuestion = mock(PqQuestion.class);
    when(pqQuestionResponseService.fetchResponseFromSubmissionId(any())).thenReturn(pqResponse);
    when(pqResponse.getPqQuestionFk()).thenReturn(otherQuestion);
    when(otherQuestion.getPqQuestionId()).thenReturn(UUID.randomUUID());
    when(messageUtility.getMessage(any())).thenReturn(TestConstants.MESSAGE_UTILITY);

    assertThrows(ServiceException.class, () ->
        spyFacade.deleteResponseAttachment(criteriaId, questionId, responseId, attachmentId)
    );
  }

  @Test
  void testDeleteResponseAttachmentSuccess() {
    PqQuestionnaireResponseFacade spyFacade = Mockito.spy(pqQuestionnaireResponseFacade);
    doReturn(true).when(spyFacade).validateQuestionIdAndCriteriaId(questionId, criteriaId);

    UUID responseId = UUID.randomUUID();
    UUID attachmentId = UUID.randomUUID();

    PqResponse pqResponse = mock(PqResponse.class);
    DocMaster docMaster = mock(DocMaster.class);

    when(pqQuestionResponseService.fetchResponseFromSubmissionId(any())).thenReturn(pqResponse);
    when(pqResponse.getPqQuestionFk()).thenReturn(pqQuestion);
    when(pqQuestion.getPqQuestionId()).thenReturn(questionId);
    when(pqResponse.getDocMasterFk()).thenReturn(docMaster);
    doNothing().when(docAttachmentService).deleteDocumentByAttachmentId(attachmentId, docMaster);
    when(messageUtility.getMessage(any())).thenReturn(TestConstants.MESSAGE_UTILITY);

    MessageResponseDTO result = spyFacade.deleteResponseAttachment(criteriaId, questionId, responseId, attachmentId);

    assertNotNull(result, TestConstants.RESPONSE_NULL);

  }


  @Test
  void testUpdateSubmittedResponseThrowsExceptionWhenResponseIsNull() {
    MultipartFile[] files = new MultipartFile[0];
    QuestionnaireResponseUpdateDTO updateDTO = mock(QuestionnaireResponseUpdateDTO.class);

    when(pqQuestionResponseService.fetchResponseFromSubmissionId(any())).thenReturn(null);
    when(messageUtility.getMessage(any())).thenReturn(TestConstants.MESSAGE_UTILITY);

    assertThrows(ServiceException.class, () -> {
      pqQuestionnaireResponseFacade.updateSubmittedResponse(criteriaId, questionId, submissionId, files, updateDTO,participantId);
    });
  }

  @Test
  void testUpdateSubmittedResponseSuccessWithoutFiles() throws IOException {
    MultipartFile[] files = new MultipartFile[0];
    QuestionnaireResponseUpdateDTO updateDTO = mock(QuestionnaireResponseUpdateDTO.class);
    PqResponse pqResponse = mock(PqResponse.class);
//    when(pqQuestionResponseService.validateParticipant(anyString(),any(UUID.class))).thenReturn(true);
    when(pqQuestionResponseService.fetchResponseFromSubmissionId(any())).thenReturn(pqResponse);
    when(pqQuestionService.fetchQuestionByQuestionId(any())).thenReturn(pqQuestion);
    when(pqQuestion.getPqCriteria()).thenReturn(pqCriteria);
    when(pqCriteria.getPqCriteriaMaster()).thenReturn(pqCriteriaMaster);
    when(pqCriteriaMaster.getId()).thenReturn(TestConstants.ID);
    when(pqCriteriaMaster.getMasterCriteriaId()).thenReturn(criteriaId);
    when(updateDTO.getResponseType()).thenReturn("type");
    when(updateDTO.getResponseValue()).thenReturn(List.of("value"));
    when(IResponseValidationFacade.validate(any(), any())).thenReturn(true);
    when(messageUtility.getMessage(any())).thenReturn("Success");
    when(IResponseValidationFacade.updatePqResponse(any(), any(), any())).thenReturn(pqResponse);

    PqQuestionnaireResponseFacade spyFacade = Mockito.spy(pqQuestionnaireResponseFacade);
    doReturn(true).when(spyFacade).validateQuestionIdAndCriteriaId(any(), any());

    MessageResponseDTO result = spyFacade.updateSubmittedResponse(criteriaId, questionId, submissionId, files, updateDTO, participantId);

    assertEquals("Success", result.getMessage(), TestConstants.VALUES_NOT_EQUAL);
  }

  @Test
  void testUpdateSubmittedResponseSuccessWithFiles() throws IOException {
    MultipartFile file = mock(MultipartFile.class);
    MultipartFile[] files = new MultipartFile[]{file};
    QuestionnaireResponseUpdateDTO updateDTO = mock(QuestionnaireResponseUpdateDTO.class);
    PqResponse pqResponse = mock(PqResponse.class);

    when(pqQuestionResponseService.fetchResponseFromSubmissionId(any())).thenReturn(pqResponse);
    when(pqQuestionService.fetchQuestionByQuestionId(any())).thenReturn(pqQuestion);
    when(pqQuestion.getPqCriteria()).thenReturn(pqCriteria);
    when(pqCriteria.getPqCriteriaMaster()).thenReturn(pqCriteriaMaster);
    when(pqCriteriaMaster.getId()).thenReturn(TestConstants.ID);
    when(pqCriteriaMaster.getMasterCriteriaId()).thenReturn(criteriaId);

    when(updateDTO.getResponseType()).thenReturn("type");
    when(updateDTO.getResponseValue()).thenReturn(List.of("value"));
    when(IResponseValidationFacade.validate(any(), any())).thenReturn(true);
    when(messageUtility.getMessage(any())).thenReturn("Success");
    when(IResponseValidationFacade.updatePqResponse(any(), any(), any())).thenReturn(pqResponse);

    PqQuestionnaireResponseFacade spyFacade = Mockito.spy(pqQuestionnaireResponseFacade);
    doReturn(true).when(spyFacade).validateQuestionIdAndCriteriaId(any(), any());
    doReturn(null).when(spyFacade).addDocumentsToResponse(any(), any(), any(), any(), any());

    MessageResponseDTO result = spyFacade.updateSubmittedResponse(criteriaId, questionId, submissionId, files, updateDTO, participantId);

    assertEquals("Success", result.getMessage(), TestConstants.VALUES_NOT_EQUAL);
  }

  @Test
  void testFetchCriteriaResponsesSuccess() {
    when(pqCriteriaMasterService.fetchActiveCriteriaFromCriteriaId(any())).thenReturn(pqCriteriaMaster);
    when(pqCriteriaService.fetchActiveCategory(any(), any())).thenReturn(pqCriteria);
    when(pqParticipateService.fetchParticipantById(any(), any())).thenReturn(pqParticipant);
    when(pqQuestionService.fetchQuestionByCriteria(any())).thenReturn(List.of(pqQuestion));
    when(pqResponseService.fetchPqResponsesByQuestionAndParticipant(any(), any())).thenReturn(pqResponse);

    CriteriaResponsesDTO response = pqQuestionnaireResponseFacade.fetchCriteriaResponses(criteriaId, categoryCode, List.of(participantId), "en");

    assertNotNull(response, TestConstants.RESPONSE_NULL);

  }

  @Test
  void testFetchCriteriaResponsesThrowsExceptionWhenCriteriaNotFound() {
    when(pqCriteriaMasterService.fetchActiveCriteriaFromCriteriaId(criteriaId)).thenReturn(null);

    assertThrows(ServiceException.class, () ->
        pqQuestionnaireResponseFacade.fetchCriteriaResponses(criteriaId, categoryCode, List.of(participantId), languageCode));
  }

  @Test
  void testFetchCriteriaResponsesThrowsExceptionWhenCategoryNotFound() {
    when(pqCriteriaMasterService.fetchActiveCriteriaFromCriteriaId(any())).thenReturn(pqCriteriaMaster);
    when(pqCriteriaService.fetchActiveCategory(any(), any())).thenReturn(null);

    assertThrows(ServiceException.class, () ->
        pqQuestionnaireResponseFacade.fetchCriteriaResponses(criteriaId, categoryCode, List.of(participantId), languageCode));

  }

  @Test
  void testBuildFetchCriteriaResponsesSuccess() {
    DocAttachment docAttachment = mock(DocAttachment.class);
    PqSubmission pqSubmission = mock(PqSubmission.class);
    PqResponseOptionMap responseOptionMap = mock(PqResponseOptionMap.class);

    when(pqResponse.getDocMasterFk()).thenReturn(mock(DocMaster.class));
    when(docAttachmentService.fetchAllAttachmentsByQuestion(any())).thenReturn(List.of(docAttachment));
    when(docAttachment.getAttachmentName()).thenReturn("Test Document");
    when(docAttachment.getAttachmentPath()).thenReturn("path/to/document");
    when(pqSubmissionService.fetchSubmissionByCriteriaAndParticipantFk(pqCriteria, pqParticipant)).thenReturn(pqSubmission);
    when(pqSubmission.getSubmissionId()).thenReturn(UUID.randomUUID());
    when(pqResponseOptionMappingService.findAllByPqResponse(pqResponse)).thenReturn(List.of(responseOptionMap));
    when(responseOptionMap.getPqOption()).thenReturn(mock(PqOption.class));
    when(responseOptionMap.getPqOption().getOptionValue()).thenReturn("Option 1");

    List<CriteriaResponsesDetailsDTO> responseList = new ArrayList<>();
    pqQuestionnaireResponseFacade.buildFetchCriteriaResponses(pqQuestion, pqResponse, responseList);

    assertEquals(1, responseList.size());
  }

  @Test
  void testBuildFetchCriteriaResponsesHandlesEmptyAttachments() {
    when(pqResponse.getDocMasterFk()).thenReturn(null);
    when(docAttachmentService.fetchAllAttachmentsByQuestion(any())).thenReturn(new ArrayList<>());

    List<CriteriaResponsesDetailsDTO> responseList = new ArrayList<>();
    pqQuestionnaireResponseFacade.buildFetchCriteriaResponses(pqQuestion, pqResponse, responseList);

    assertEquals(1, responseList.size());

  }

  @Test
  @Disabled
  void testFetchParticipantSubmissionsSuccess() {
    PqParticipant participant = mock(PqParticipant.class);
    PqSubmission pqSubmission = mock(PqSubmission.class);

    when(pqCriteriaMasterService.fetchActiveCriteriaFromCriteriaId(any())).thenReturn(pqCriteriaMaster);
    when(pqCriteriaService.fetchActiveCategory(any(), any())).thenReturn(pqCriteria);
    when(pqParticipateService.fetchParticipantByCrtieria(any())).thenReturn(List.of(participant));
    when(pqSubmissionService.fetchSubmissionByCriteriaAndParticipantFk(any(), any())).thenReturn(pqSubmission);

    when(pqSubmission.getStatusLookup()).thenReturn(LookupConstants.Status.ACTIVE.getLookupCode());
    when(LookupConstants.getEnumStatusKeyByValue(LookupConstants.Status.ACTIVE.getLookupCode()))
        .thenReturn(LookupConstants.Status.ACTIVE.name());

    List<ParticipantSubmissionsResponseDTO> result = pqQuestionnaireResponseFacade.fetchParticipantSubmissions(criteriaId, categoryCode, languageCode);

    assertNotNull(result, TestConstants.RESPONSE_NULL);
  }


  @Test
  void testFetchParticipantSubmissionsNoParticipants() {
    when(pqCriteriaMasterService.fetchActiveCriteriaFromCriteriaId(criteriaId)).thenReturn(pqCriteriaMaster);
    when(pqCriteriaService.fetchActiveCategory(pqCriteriaMaster, categoryCode)).thenReturn(pqCriteria);
    when(pqParticipateService.fetchParticipantByCrtieria(pqCriteria)).thenReturn(new ArrayList<>());

    List<ParticipantSubmissionsResponseDTO> result = pqQuestionnaireResponseFacade.fetchParticipantSubmissions(criteriaId, categoryCode, languageCode);

    assertNotNull(result, TestConstants.RESPONSE_NULL);
  }

  @Test
  void testFetchParticipantSubmissionsNoSubmissionForParticipant() {
    PqParticipant participant = mock(PqParticipant.class);

    when(pqCriteriaMasterService.fetchActiveCriteriaFromCriteriaId(criteriaId)).thenReturn(pqCriteriaMaster);
    when(pqCriteriaService.fetchActiveCategory(pqCriteriaMaster, categoryCode)).thenReturn(pqCriteria);
    when(pqParticipateService.fetchParticipantByCrtieria(pqCriteria)).thenReturn(List.of(participant));
    when(pqSubmissionService.fetchSubmissionByCriteriaAndParticipantFk(pqCriteria, participant)).thenReturn(null);

    List<ParticipantSubmissionsResponseDTO> result = pqQuestionnaireResponseFacade.fetchParticipantSubmissions(criteriaId, categoryCode, languageCode);

    assertNotNull(result, TestConstants.RESPONSE_NULL);
  }

  @Test
  void testFetchParticipantSubmissionsThrowsExceptionWhenCriteriaMasterNotFound() {
    when(pqCriteriaMasterService.fetchActiveCriteriaFromCriteriaId(criteriaId)).thenReturn(null);

    Assertions.assertThrows(ServiceException.class, () ->
        pqQuestionnaireResponseFacade.fetchParticipantSubmissions(criteriaId, categoryCode, languageCode)
    );
  }

  @Test
  void testFetchParticipantSubmissionsThrowsExceptionWhenCategoryNotFound() {
    PqCriteriaMaster pqCriteriaMaster = mock(PqCriteriaMaster.class);

    when(pqCriteriaMasterService.fetchActiveCriteriaFromCriteriaId(criteriaId)).thenReturn(pqCriteriaMaster);
    when(pqCriteriaService.fetchActiveCategory(pqCriteriaMaster, categoryCode)).thenReturn(null);

    Assertions.assertThrows(ServiceException.class, () ->
        pqQuestionnaireResponseFacade.fetchParticipantSubmissions(criteriaId, categoryCode, languageCode)
    );
  }

  @Test
  void testUpdateSubmissionEvaluationThrowsExceptionWhenSubmissionNotFound() {
    when(pqSubmissionService.fetchSubmissionById(submissionId)).thenReturn(null);
    when(messageUtility.getMessage(MessageConstants.INVALID_INPUT)).thenReturn("Invalid input");

    assertThrows(ServiceException.class, () ->
        pqQuestionnaireResponseFacade.updateSubmissionEvaluation(submissionId, updateSubmissionEvaluationRequest, "en"));

  }

  @Test
  void testUpdateSubmissionEvaluationThrowsExceptionWhenInvalidStatus() {
    PqSubmission submission = mock(PqSubmission.class);
    when(pqSubmissionService.fetchSubmissionById(submissionId)).thenReturn(submission);
    updateSubmissionEvaluationRequest.setSubmissionStatus("INVALID_STATUS");
    when(messageUtility.getMessage(any())).thenReturn(TestConstants.MESSAGE_UTILITY);

    assertThrows(NullPointerException.class, () ->
        pqQuestionnaireResponseFacade.updateSubmissionEvaluation(submissionId, updateSubmissionEvaluationRequest, languageCode
            ));
  }

  @Test
  void testUpdateSubmissionEvaluationSuccess() {
    PqSubmission submission = mock(PqSubmission.class);
    when(pqSubmissionService.fetchSubmissionById(submissionId)).thenReturn(submission);
    updateSubmissionEvaluationRequest.setSubmissionStatus("ACTIVE");
    updateSubmissionEvaluationRequest.setRemarks("Approved");

    when(messageUtility.getMessage(MessageConstants.SUCCESS_MESSAGE)).thenReturn("Success");

    MessageViewResponse messageViewResponse = mock(MessageViewResponse.class);
    when(messageViewResponse.getMessage()).thenReturn("Success");
    when(languageService.messageView(MessageConstants.SUCCESS_MESSAGE)).thenReturn(messageViewResponse);

    UpdateSubmissionEvaluationResponseDTO response = pqQuestionnaireResponseFacade.updateSubmissionEvaluation(
        submissionId, updateSubmissionEvaluationRequest, languageCode);

    assertNotNull(response, TestConstants.RESPONSE_NULL);

  }
  @Test
  void testUpdateSubmissionStatusInvalidParticipant() {
    // Arrange
    UUID submissionId = UUID.randomUUID();
    UUID participantId = UUID.randomUUID();
    SubmissionStatusReqDTO requestDTO = SubmissionStatusReqDTO.builder()
            .status("ACTIVE")
            .build();

    PqSubmission pqSubmission = mock(PqSubmission.class);
    PqParticipant pqParticipant = mock(PqParticipant.class);

    when(pqSubmissionService.fetchSubmissionById(submissionId)).thenReturn(pqSubmission);
    when(pqSubmission.getPqParticipantFk()).thenReturn(pqParticipant);
    when(pqParticipant.getParticipantId()).thenReturn(UUID.randomUUID().toString());
    when(messageUtility.getMessage(ErrorMessageConstants.INVALID_PARTICIPANT)).thenReturn("Invalid participant");

    // Act & Assert
    ServiceException exception = assertThrows(ServiceException.class, () ->
            pqQuestionnaireResponseFacade.updateSubmissionStatus(submissionId, participantId, requestDTO, "en"));
    assertEquals("Invalid participant", exception.getMessage());
  }

  @Test
  void testUpdateSubmissionStatusInvalidStatus() {
    // Arrange
    UUID submissionId = UUID.randomUUID();
    UUID participantId = UUID.randomUUID();
    SubmissionStatusReqDTO requestDTO = SubmissionStatusReqDTO.builder()
            .status("INVALID_STATUS")
            .build();

    PqSubmission pqSubmission = mock(PqSubmission.class);
    PqParticipant pqParticipant = mock(PqParticipant.class);

    when(pqSubmissionService.fetchSubmissionById(submissionId)).thenReturn(pqSubmission);
    when(pqSubmission.getPqParticipantFk()).thenReturn(pqParticipant);
    when(pqParticipant.getParticipantId()).thenReturn(participantId.toString());
    when(messageUtility.getMessage(ErrorMessageConstants.INVALID_STATUS)).thenReturn("Invalid status");

    // Act & Assert
    InvalidInputException exception = assertThrows(InvalidInputException.class, () ->
            pqQuestionnaireResponseFacade.updateSubmissionStatus(submissionId, participantId, requestDTO, "en"));
    assertEquals("Invalid status", exception.getMessage());
  }
}