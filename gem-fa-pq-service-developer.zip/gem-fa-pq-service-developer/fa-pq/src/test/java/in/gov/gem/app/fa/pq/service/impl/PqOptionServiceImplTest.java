
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * PqOptionServiceImplTest: Tests the service layer functioning.
 */

package in.gov.gem.app.fa.pq.service.impl;

import in.gov.gem.app.fa.pq.constant.LookupConstants;
import in.gov.gem.app.fa.pq.constant.MessageConstants;
import in.gov.gem.app.fa.pq.constant.TestConstants;
import in.gov.gem.app.fa.pq.domain.entity.PqOption;
import in.gov.gem.app.fa.pq.domain.entity.PqQuestion;
import in.gov.gem.app.fa.pq.domain.repository.PqOptionRepository;
import in.gov.gem.app.fa.pq.request.QuestionCreateRequestDTO;
import in.gov.gem.app.fa.pq.request.QuestionUpdateRequestDTO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.*;

class PqOptionServiceImplTest {

  @Mock
  private PqOptionRepository pqOptionRepository;

  @InjectMocks
  private PqOptionServiceImpl pqOptionService;

  private PqQuestion pqQuestion;
  private QuestionCreateRequestDTO questionCreateRequestDTO;
  private QuestionUpdateRequestDTO questionUpdateRequestDTO;
  private PqOption pqOption;
  private List<PqOption> existingOptions;

  @BeforeEach
  void setUp() {
    MockitoAnnotations.openMocks(this);

    pqQuestion = PqQuestion.builder()
        .pqQuestionId(TestConstants.QUESTION_ID)
        .build();

    pqOption = PqOption.builder()
        .optionValue(TestConstants.OPTION_1)
        .pqQuestion(pqQuestion)
        .build();

    questionCreateRequestDTO = QuestionCreateRequestDTO.builder()
        .questionText(TestConstants.QUESTION_TEXT)
        .build();

    existingOptions = new ArrayList<>();
    for (int i = 0; i < 3; i++) {
      PqOption option = new PqOption();
      option.setOptionSequence(i + 1);
      option.setOptionValue("Option " + (i + 1));
      option.setStatusLookup(LookupConstants.Status.ACTIVE.getLookupCode());
      existingOptions.add(option);
    }

    questionUpdateRequestDTO = QuestionUpdateRequestDTO.builder()
        .options(List.of(TestConstants.OPTION_1, TestConstants.OPTION_2))
        .build();

  }

  @Test
  void testCreateOptions() {
    // Arrange
    List<String> optionValues = List.of("Option 1", "Option 2");
    QuestionCreateRequestDTO request = QuestionCreateRequestDTO.builder()
            .options(optionValues)
            .build();
    PqQuestion pqQuestion = PqQuestion.builder()
            .pqQuestionId(UUID.randomUUID())
            .build();

    List<PqOption> savedOptions = new ArrayList<>();
    for (int i = 0; i < optionValues.size(); i++) {
      PqOption option = new PqOption();
      option.setPqQuestion(pqQuestion);
      option.setOptionSequence(i + 1);
      option.setOptionValue(optionValues.get(i));
      option.setCreatedBy(MessageConstants.CREATED_BY);
      option.setStatusLookup(LookupConstants.Status.ACTIVE.getLookupCode());
      savedOptions.add(option);
    }

    when(pqOptionRepository.saveAll(anyList())).thenReturn(savedOptions);
    List<PqOption> result = pqOptionService.createOptions(request, pqQuestion);
    assertNotNull(result);
  }



  @Test
  void testFetchOptionByQuestion() {
    when(pqOptionRepository.findByPqQuestion(any())).thenReturn(List.of(pqOption));

    List<PqOption> result = pqOptionService.fetchOptionByQuestion(pqQuestion);

    assertNotNull(result, TestConstants.RESPONSE_NULL);
  }


  @Test
  void testUpdateOptionsWithMoreNewOptions() {
    questionUpdateRequestDTO = QuestionUpdateRequestDTO.builder()
        .options(List.of(TestConstants.OPTION_1, TestConstants.OPTION_2))
        .build();

    pqOptionService.updateOptions(questionUpdateRequestDTO, existingOptions);

    verify(pqOptionRepository, times(1)).saveAll(anyList());
  }


  @Test
  void testUpdateOptionsWithMoreNewOptionsThanExisting() {
    List<PqOption> existingOptions = new ArrayList<>();
    for (int i = 0; i < 2; i++) {
      PqOption option = new PqOption();
      option.setOptionSequence(i + 1);
      option.setOptionValue("Option " + (i + 1));
      option.setStatusLookup(LookupConstants.Status.ACTIVE.getLookupCode());
      option.setPqQuestion(pqQuestion);
      existingOptions.add(option);
    }
    QuestionUpdateRequestDTO request = QuestionUpdateRequestDTO.builder()
        .options(List.of(TestConstants.OPTION_1, TestConstants.OPTION_2))
        .build();

    when(pqOptionRepository.saveAll(anyList())).thenReturn(new ArrayList<>());

    pqOptionService.updateOptions(request, existingOptions);

    verify(pqOptionRepository, times(1)).saveAll(anyList());
  }

  @Test
  void testUpdateOptionsWithFewerNewOptions() {
    questionUpdateRequestDTO = QuestionUpdateRequestDTO.builder()
        .options(List.of(TestConstants.OPTION_1, TestConstants.OPTION_2))
        .build();

    pqOptionService.updateOptions(questionUpdateRequestDTO, existingOptions);

    assertEquals(3, existingOptions.size(), TestConstants.VALUES_NOT_EQUAL);
  }

  @Test
  void testUpdateOptionsWithSameNumberOfOptions() {
    questionUpdateRequestDTO = QuestionUpdateRequestDTO.builder()
        .options(List.of(TestConstants.OPTION_1))
        .build();

    pqOptionService.updateOptions(questionUpdateRequestDTO, existingOptions);

    assertEquals(3, existingOptions.size(), TestConstants.VALUES_NOT_EQUAL);
  }


  @Test
  void testDeleteOptions() {
    List<PqOption> options = new ArrayList<>();
    for (int i = 0; i < 2; i++) {
      PqOption option = new PqOption();
      option.setStatusLookup(LookupConstants.Status.ACTIVE.getLookupCode());
      options.add(option);
    }

    pqOptionService.deleteOptions(options);

    for (PqOption option : options) {
      assertEquals(LookupConstants.Status.INACTIVE.getLookupCode(), option.getStatusLookup());
    }
    verify(pqOptionRepository, times(1)).saveAll(options);
  }

  @Test
  void testFetchOptionByIdSuccess() {
    Long optionId = TestConstants.ID;
    PqOption pqOption = new PqOption();
    pqOption.setOptionValue(TestConstants.OPTION_1);
    pqOption.setStatusLookup(LookupConstants.Status.ACTIVE.getLookupCode());

    when(pqOptionRepository.findById(optionId)).thenReturn(Optional.of(pqOption));

    PqOption result = pqOptionService.fetchOptionById(optionId);

    assertNotNull(result, TestConstants.RESPONSE_NULL);
  }

}