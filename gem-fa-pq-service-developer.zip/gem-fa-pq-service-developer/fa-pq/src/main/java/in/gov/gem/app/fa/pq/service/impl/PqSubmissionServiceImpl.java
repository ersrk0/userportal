
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * PqResponseOptionMappingServiceImpl: Implements the service layer.
 */

package in.gov.gem.app.fa.pq.service.impl;

import in.gov.gem.app.fa.pq.constant.LookupConstants;
import in.gov.gem.app.fa.pq.domain.entity.PqCriteria;
import in.gov.gem.app.fa.pq.domain.entity.PqParticipant;
import in.gov.gem.app.fa.pq.domain.entity.PqSubmission;
import in.gov.gem.app.fa.pq.domain.repository.PqSubmissionRepository;
import in.gov.gem.app.fa.pq.service.PqSubmissionService;
import lombok.AllArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
@AllArgsConstructor
public class PqSubmissionServiceImpl implements PqSubmissionService {

  private PqSubmissionRepository pqSubmissionRepository;

  @Override
  public PqSubmission fetchSubmissionByCriteriaAndParticipantFk(PqCriteria pqCriteria, PqParticipant pqParticipant) {
      return pqSubmissionRepository.findByPqCriteriaAndPqParticipantFk(pqCriteria, pqParticipant);
  }
  @Override
  public PqSubmission fetchSubmissionById(UUID submissionId) {
    return pqSubmissionRepository.findBySubmissionIdAndIsDeleted(submissionId, false);
  }

  @Override
  public PqSubmission saveSubmission(PqSubmission pqSubmission) {
    return pqSubmissionRepository.save(pqSubmission);
  }

  @Override
  public Page<PqSubmission> fetchSubmissionByParticipantId(PqParticipant pqParticipant, Pageable pageable){
    return pqSubmissionRepository.findByPqParticipantFk(pqParticipant, pageable);
  }

  @Override
  public Optional<List<PqSubmission>> fetchSubmissionList(PqCriteria pqCriteria) {
    Optional<List<PqSubmission>> response = Optional.empty();
    if (pqCriteria != null) {
      response = pqSubmissionRepository.findByPqCriteriaAndStatusLookupIn(pqCriteria,
              List.of(LookupConstants.Status.PENDING.getLookupCode(),
                        LookupConstants.Status.APPROVED.getLookupCode(),
                        LookupConstants.Status.REJECTED.getLookupCode()
              ));
    }
    return response;
  }


}
