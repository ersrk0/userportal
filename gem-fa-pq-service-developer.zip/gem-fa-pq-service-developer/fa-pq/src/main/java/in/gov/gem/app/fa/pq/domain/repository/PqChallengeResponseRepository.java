package in.gov.gem.app.fa.pq.domain.repository;

import in.gov.gem.app.fa.pq.domain.entity.PqChallengeResponse;
import in.gov.gem.app.service.core.repository.BaseRepository;

public interface PqChallengeResponseRepository extends BaseRepository<PqChallengeResponse, Long> {

    // Additional query methods can be defined here if needed
}
