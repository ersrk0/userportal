package in.gov.gem.app.fa.pq.service;

import in.gov.gem.app.fa.pq.domain.entity.DocMaster;
import in.gov.gem.app.fa.pq.domain.entity.PqCriteria;
import in.gov.gem.app.fa.pq.domain.entity.PqParticipant;
import in.gov.gem.app.fa.pq.domain.entity.PqRepresentation;
import in.gov.gem.app.fa.pq.domain.entity.PqRepresentationResponse;
import in.gov.gem.app.fa.pq.request.RepresentationRequestDTO;
import in.gov.gem.app.fa.pq.request.RespondRepresentationRequestDTO;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
public interface PqRepresentationService {
  void raiseRepresentation(RepresentationRequestDTO request,
                           PqCriteria pqCriteria, DocMaster documentMaster, PqParticipant pqParticipation,
                           UUID representationId);

  void fetchRepresentation(PqCriteria pqCriteria);
  PqRepresentation fetchRepresentationByRepresentationId(UUID representationId);

  List<PqRepresentation> fetchRepresentationByPqCriteria(PqCriteria pqCriteria);

  void respondRepresentation(PqRepresentation pqRepresentation, RespondRepresentationRequestDTO request, DocMaster docMaster);

  PqRepresentationResponse fetchResponse(PqRepresentation representation);
}
