
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * Criteria Management ServiceImpl: Implements the Criteria Management service layer.
 */
package in.gov.gem.app.fa.pq.validation.response;

import in.gov.gem.app.fa.pq.domain.entity.PqParticipant;
import in.gov.gem.app.fa.pq.domain.entity.PqQuestion;
import in.gov.gem.app.fa.pq.domain.entity.PqResponse;
import java.util.List;
import java.util.UUID;

public interface ResponseValidation {

    boolean validate(PqQuestion pqQuestion, List<String> response);

    boolean canHandle(String questionTypeLookup);

    PqResponse buildPqResponse(UUID submissionId, PqQuestion pqQuestionEntity, List<String> response, String responseStatus, PqParticipant pqParticipant);

    PqResponse updatePqResponse(UUID submissionId, PqQuestion pqQuestionEntity, List<String> response);

}
