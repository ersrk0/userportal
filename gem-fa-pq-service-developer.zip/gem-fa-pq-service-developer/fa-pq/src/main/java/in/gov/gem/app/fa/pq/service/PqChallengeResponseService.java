package in.gov.gem.app.fa.pq.service;

import in.gov.gem.app.fa.pq.domain.entity.DocMaster;
import in.gov.gem.app.fa.pq.domain.entity.PqChallenge;
import in.gov.gem.app.fa.pq.domain.entity.PqChallengeResponse;
import in.gov.gem.app.fa.pq.request.ResponseOfChallengeReqDTO;
import org.springframework.stereotype.Service;

@Service
public interface PqChallengeResponseService {
    PqChallengeResponse createChallengeResponse(ResponseOfChallengeReqDTO responseOfChallengeReqDTO, PqChallenge pqChallenge, DocMaster documentMaster);
}
