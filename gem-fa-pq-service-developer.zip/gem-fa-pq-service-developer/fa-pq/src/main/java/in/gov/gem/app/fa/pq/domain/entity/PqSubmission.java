
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * Pq Assessment Entity: Specifies the attributes in the 'pq_assessment' table.
 */
package in.gov.gem.app.fa.pq.domain.entity;

import in.gov.gem.app.service.core.entity.BaseEntity;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.time.Instant;
import java.util.UUID;


@Entity
@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
@Table(name = "pq_submission")
public class PqSubmission extends BaseEntity{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "pq_criteria_fk", referencedColumnName = "id", nullable = false)
    private PqCriteria pqCriteria;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "pq_participant_fk", referencedColumnName = "id", nullable = false)
    private PqParticipant pqParticipantFk;

    @Column(name = "submission_id")
    private UUID submissionId;

    @Column(name = "status_lookup", length = 10)
    private String statusLookup;

    @Column(name = "submitted_at")
    private Instant submittedAt;

    @Column(name = "remark", length = 512)
    private String remarks;

    @Column(name = "category_score")
    private Integer categoryScore;

    @Column(name = "evaluated_at")
    private Instant evaluatedAt;

}
