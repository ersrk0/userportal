
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * Pq Clarification Msg Repository: Contains DB function to fetch Pq clarification msg data.
 */
package in.gov.gem.app.fa.pq.domain.entity;

import in.gov.gem.app.service.core.entity.BaseEntity;
import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.SuperBuilder;

@Entity
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
@Table(name = "pq_challenge", schema = "fa_pq_mgmt")
public class PqChallenge extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "pq_assessment_fk", nullable = false)
    private PqAssessment pqAssessment;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "pq_participant_fk", nullable = false)
    private PqParticipant pqParticipant;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "doc_master_fk", nullable = false)
    private DocMaster docMaster;

    @Column(name = "challenge_text",length = 512)
    private String ChallengeText;

    @Column(name = "status_lookup",length = 512)
    private String statusLookUp;
}
