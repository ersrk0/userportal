package in.gov.gem.app.fa.pq.service.impl;

import in.gov.gem.app.exception.generic.ServiceException;
import in.gov.gem.app.exception.utility.ErrorConstant;
import in.gov.gem.app.fa.pq.constant.Constants;
import in.gov.gem.app.fa.pq.constant.ErrorMessageConstants;
import in.gov.gem.app.fa.pq.service.DocumentServiceUtil;
import in.gov.gem.app.service.core.utility.MessageUtility;
import lombok.AllArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Service
@AllArgsConstructor
public class DocumentServiceUtilImpl implements DocumentServiceUtil {

  private static final Logger logger = LoggerFactory.getLogger(DocumentServiceUtilImpl.class);

  private final MessageUtility messageUtility;

  @Override
  public Boolean fileSizeCheck(MultipartFile file) {
    logger.info("Entering fileSizeCheck with file: {}", file.getOriginalFilename());

    Boolean fileSizeFlag = file.getSize() <= Constants.MIN_FILE_SIZE || file.getSize() > Constants.MAX_FILE_SIZE;
    logger.debug("File size check result for file {}: {}", file.getOriginalFilename(), fileSizeFlag);

    if (Boolean.TRUE.equals(fileSizeFlag)) {
      logger.error("File size validation failed for file: {}", file.getOriginalFilename());
      throw new ServiceException(ErrorMessageConstants.DOCUMENT_UPLOAD_ERROR_MSG, messageUtility.getMessage(
              ErrorMessageConstants.DOCUMENT_UPLOAD_ERROR_MSG),
              ErrorConstant.CATEGORY.TS, ErrorConstant.SEVERITY.I);
    }

    logger.info("Exiting fileSizeCheck with file: {}", file.getOriginalFilename());
    return fileSizeFlag;
  }
}