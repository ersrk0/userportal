package in.gov.gem.app.fa.pq.domain.entity;

import in.gov.gem.app.service.core.entity.BaseEntity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

@Entity
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
@Table(name = "pq_representation_response")
public class PqRepresentationResponse extends BaseEntity {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "pq_representation_fk", referencedColumnName = "id", nullable = false)
  private PqRepresentation pqRepresentation;

  @Column(name = "response_text", nullable = false, length = 300)
  private String responseText;

  @Column(name = "responded_by", nullable = false, length = 50)
  private String respondedBy;

  @OneToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "doc_master_fk", referencedColumnName = "id", nullable = false)
  private DocMaster docMaster;
}
