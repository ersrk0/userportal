/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * Temporal Service: Interface layer of the Temporal service.
 */

package in.gov.gem.app.fa.pq.service;

import in.gov.gem.app.fa.pq.request.AttachmentTemplate;
import in.gov.gem.app.fa.pq.response.CategoryResponseDTO;
import in.gov.gem.app.fa.pq.response.MessageResponseDTO;
import in.gov.gem.app.fa.pq.response.TemporalCriteriaResponseDTO;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
public interface TemporalService {
  TemporalCriteriaResponseDTO getTemporalCriteria(UUID offeringId);
  AttachmentTemplate viewAttachment(UUID attachmentId);
  MessageResponseDTO saveParticipants(UUID criteriaId, String languageCode);
  CategoryResponseDTO getTemporalCategory(UUID offeringId, UUID categoryCode);
}
