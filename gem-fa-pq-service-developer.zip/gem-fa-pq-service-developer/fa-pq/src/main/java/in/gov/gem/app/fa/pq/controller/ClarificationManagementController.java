
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM
 * Criteria Management Controller: Endpoint related to bank details.
 */

package in.gov.gem.app.fa.pq.controller;


import in.gov.gem.app.exception.generic.ServiceException;
import in.gov.gem.app.exception.utility.ErrorConstant;
import in.gov.gem.app.fa.pq.constant.Constants;
import in.gov.gem.app.fa.pq.constant.ErrorMessageConstants;
import in.gov.gem.app.fa.pq.constant.MessageConstants;
import in.gov.gem.app.fa.pq.facade.impl.ClarificationManagementFacade;
import in.gov.gem.app.fa.pq.request.ClarificationRequestDTO;
import in.gov.gem.app.fa.pq.response.GetClarificationResponseDTO;
import in.gov.gem.app.fa.pq.response.ReqClarificationResponseDTO;
import in.gov.gem.app.fa.pq.response.SubmitClarificationResponseDTO;
import in.gov.gem.app.service.core.utility.ApiResponseBuilder;
import in.gov.gem.app.service.core.utility.MessageUtility;
import in.gov.gem.app.service.dto.APIResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Valid;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import lombok.AllArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;

import java.io.IOException;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

@Tag(name = "Questionnaire Management Clarification", description = "Questionnare Management Clarification related endpoints")
@RestController
@RequestMapping("/v1/public/criteria")
@Validated
@AllArgsConstructor
public class ClarificationManagementController {

    private static final Logger logger = LoggerFactory.getLogger(ClarificationManagementController.class);

    private final MessageUtility messageUtility;
    private final ClarificationManagementFacade classificationManagementFacade;

    @PostMapping(path = "/responses/{responseId}/clarification/response",
            consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<APIResponse<SubmitClarificationResponseDTO>> submitClarification(
            @RequestHeader("Accept-Language") String acceptLanguage,
            @PathVariable UUID responseId,
            @ModelAttribute ClarificationRequestDTO submitClarificationDTO) throws IOException {

        logger.info("Entering submitClarification with responseId: {}", responseId);

        logger.debug("Request payload for submitClarification: {}", submitClarificationDTO);

        if(submitClarificationDTO.getFile()==null && submitClarificationDTO.getAdditionalQuery()==null)
        {
            logger.error("Validation failed: At least one of file or additionalQuery must be provided.");
            throw new ServiceException(ErrorMessageConstants.INVALID_INPUT, messageUtility.getMessage(
                    ErrorMessageConstants.INVALID_INPUT),
                    ErrorConstant.CATEGORY.TS, ErrorConstant.SEVERITY.I);
        }

        SubmitClarificationResponseDTO response = classificationManagementFacade.submitClarification(acceptLanguage,
                responseId,submitClarificationDTO.getFile(), submitClarificationDTO);

        logger.info("Exiting submitClarification with responseId: {}", responseId);
        return ResponseEntity.status(HttpStatus.CREATED).body(
                APIResponse.<SubmitClarificationResponseDTO>builder()
                        .status(HttpStatus.CREATED.getReasonPhrase())
                        .httpStatus(HttpStatus.CREATED.value())
                        .message(messageUtility.getMessage(MessageConstants.SUCCESS_MESSAGE))
                        .data(response)
                        .msId(Constants.MSID)
                        .build()
        );
    }

    @PostMapping(
            path = "/responses/{responseId}/clarification",
            consumes = MediaType.MULTIPART_FORM_DATA_VALUE
    )
    public ResponseEntity<APIResponse<ReqClarificationResponseDTO>> requestClarification(
            @RequestHeader("Accept-Language") String acceptLanguage,
            @PathVariable UUID responseId,
            //@RequestPart(name = "file", required = false) MultipartFile file,
            @ModelAttribute ClarificationRequestDTO clarificationRequestDTO
    ) throws IOException {

        logger.info("Entering requestClarification with responseId: {}", responseId);

        logger.debug("Request payload for requestClarification: {}", clarificationRequestDTO);

        if(clarificationRequestDTO.getFile()==null && clarificationRequestDTO.getAdditionalQuery()==null)
        {
            logger.error("Validation failed: At least one of file or additionalQuery must be provided.");
            throw new ServiceException(ErrorMessageConstants.INVALID_INPUT, messageUtility.getMessage(
                    ErrorMessageConstants.INVALID_INPUT),
                    ErrorConstant.CATEGORY.TS, ErrorConstant.SEVERITY.I);
        }


        ReqClarificationResponseDTO response = classificationManagementFacade.requestClarification(
                acceptLanguage, responseId,clarificationRequestDTO.getFile(), clarificationRequestDTO
        );

        logger.info("Exiting requestClarification with responseId: {}", responseId);
        return ResponseEntity.status(HttpStatus.CREATED).body(
                APIResponse.<ReqClarificationResponseDTO>builder()
                        .status(HttpStatus.CREATED.getReasonPhrase())
                        .httpStatus(HttpStatus.CREATED.value())
                        .message(messageUtility.getMessage(MessageConstants.SUCCESS_MESSAGE))
                        .data(response)
                        .msId(Constants.MSID)
                        .build()
        );
    }

    @GetMapping(path = "/responses/{responseId}/clarification")
    public ResponseEntity<APIResponse<GetClarificationResponseDTO>> getClarification(
            @RequestHeader("Accept-Language") String acceptLanguage,
            @PathVariable UUID responseId
    ) {
        logger.info("Entering getClarification with responseId: {}", responseId);

        GetClarificationResponseDTO response = classificationManagementFacade.getClarification(acceptLanguage, responseId);

        logger.debug("Fetched clarification response: {}", response);

        logger.info("Exiting getClarification with responseId: {}", responseId);

        return ResponseEntity.status(HttpStatus.OK)
                .body(ApiResponseBuilder.build(HttpStatus.OK, messageUtility
                        .getMessage(MessageConstants.SUCCESS_MESSAGE), response));
    }
}