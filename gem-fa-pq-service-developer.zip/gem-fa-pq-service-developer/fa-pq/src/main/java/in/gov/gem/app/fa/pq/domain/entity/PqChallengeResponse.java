package in.gov.gem.app.fa.pq.domain.entity;

import in.gov.gem.app.service.core.entity.BaseEntity;
import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.SuperBuilder;

@Entity
@Getter
@Setter
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = true)
@Table(name = "pq_challenge_response", schema = "fa_pq_mgmt")
public class PqChallengeResponse extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "pq_challenge_fk", nullable = false)
    private PqChallenge pqChallenge;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "doc_master_fk", nullable = false)
    private DocMaster docMaster;

    @Column(name = "response_text",length = 512)
    private String responseText;

    @Column(name = "responded_by",length = 512)
    private String respondedBy;

    @Column(name = "status_lookup",length = 512)
    private String statusLookUp;

}
