
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * Pq Response Repository: Contains DB function to fetch Pq Response data.
 */

package in.gov.gem.app.fa.pq.domain.repository;

import in.gov.gem.app.fa.pq.domain.entity.PqCriteria;
import in.gov.gem.app.fa.pq.domain.entity.PqRepresentation;
import in.gov.gem.app.service.core.repository.BaseRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface PqRepresentationRepository extends BaseRepository<PqRepresentation, Long> {

  PqRepresentation findByPqCriteriaAndStatusLookup(PqCriteria pqCriteria,
                                                            String statusLookup);

  List<PqRepresentation> findByPqCriteriaAndStatusLookupNot(PqCriteria pqCriteria,
                                                           String statusLookup);


  PqRepresentation findByRepresentationIdAndStatusLookup(UUID representationId, String lookupCode);
}