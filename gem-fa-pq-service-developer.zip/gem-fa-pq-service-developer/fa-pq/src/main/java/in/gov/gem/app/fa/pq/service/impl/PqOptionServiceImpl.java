package in.gov.gem.app.fa.pq.service.impl;

import in.gov.gem.app.exception.generic.ServiceException;
import in.gov.gem.app.exception.utility.ErrorConstant;
import in.gov.gem.app.fa.pq.constant.ErrorMessageConstants;
import in.gov.gem.app.fa.pq.constant.LookupConstants;
import in.gov.gem.app.fa.pq.constant.MessageConstants;
import in.gov.gem.app.fa.pq.domain.entity.PqOption;
import in.gov.gem.app.fa.pq.domain.entity.PqQuestion;
import in.gov.gem.app.fa.pq.domain.repository.PqOptionRepository;
import in.gov.gem.app.fa.pq.request.QuestionCreateRequestDTO;
import in.gov.gem.app.fa.pq.request.QuestionUpdateRequestDTO;
import in.gov.gem.app.fa.pq.service.PqOptionService;
import in.gov.gem.app.service.core.utility.MessageUtility;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.IntStream;

@Service
@AllArgsConstructor
public class PqOptionServiceImpl implements PqOptionService {

  private PqOptionRepository pqOptionRepository;
  private MessageUtility messageUtility;
  public List<PqOption> createOptions(QuestionCreateRequestDTO request, PqQuestion pqQuestion){

    List<String> options = request.getOptions();

    // Check for duplicate values in the options list
    if (options.size() != options.stream().distinct().count()) {
      throw new ServiceException(ErrorMessageConstants.INVALID_OPTIONS, messageUtility.getMessage(
          ErrorMessageConstants.INVALID_OPTIONS),
          ErrorConstant.CATEGORY.TS, ErrorConstant.SEVERITY.I);
    }
    List<PqOption> optionsToSave = IntStream.range(0, options.size())
        .mapToObj(i -> {
          PqOption pqOption = new PqOption();
          pqOption.setPqQuestion(pqQuestion);
          pqOption.setOptionSequence(i + 1);
          pqOption.setOptionValue(options.get(i));
          pqOption.setCreatedBy(MessageConstants.CREATED_BY);
          pqOption.setStatusLookup(LookupConstants.Status.ACTIVE.getLookupCode());
          return pqOption;
        }).toList();
    return pqOptionRepository.saveAll(optionsToSave);
  }

  public List<PqOption> fetchOptionByQuestion(PqQuestion pqQuestion){
    return pqOptionRepository.findByPqQuestion(pqQuestion);
  }

  public void updateOptions(QuestionUpdateRequestDTO request, List<PqOption> existingOptions){

    List<PqOption> optionsToSave = new ArrayList<>();
    List<String> newOptions = request.getOptions();

    // Update existing options and create new ones if needed
    for (int i = 0; i < newOptions.size(); i++) {
      String optionText = newOptions.get(i);
      PqOption pqOption;
      if (i < existingOptions.size()) {
        // Update existing option
        pqOption = existingOptions.get(i);
      } else {
        // Create new option if we have more new options than existing ones
        pqOption = new PqOption();
        pqOption.setPqQuestion(existingOptions.get(0).getPqQuestion());
      }
      pqOption.setOptionSequence(i + 1);
      pqOption.setOptionValue(optionText);
      pqOption.setStatusLookup(LookupConstants.Status.ACTIVE.getLookupCode());
      pqOption.setCreatedBy(MessageConstants.CREATED_BY);
      optionsToSave.add(pqOption);
    }
    if (newOptions.size() < existingOptions.size()) {
      List<PqOption> optionsToMarkInactive = existingOptions.subList(newOptions.size(), existingOptions.size());
      for (PqOption option : optionsToMarkInactive) {
        option.setStatusLookup(LookupConstants.Status.INACTIVE.getLookupCode());
      }
      optionsToSave.addAll(optionsToMarkInactive);
    }
    pqOptionRepository.saveAll(optionsToSave);
  }


  public void deleteOptions(List<PqOption> pqOption){
    for (PqOption option : pqOption) {
      option.setStatusLookup(LookupConstants.Status.INACTIVE.getLookupCode());
    }
    pqOptionRepository.saveAll(pqOption);
  }

  public PqOption fetchOptionById(Long optionId){
    return pqOptionRepository.findById(optionId).orElse(null);
  }

}
