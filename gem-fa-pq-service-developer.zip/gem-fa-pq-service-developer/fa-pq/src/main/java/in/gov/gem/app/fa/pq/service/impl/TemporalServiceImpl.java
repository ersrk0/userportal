
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * Temporal ServiceImpl: Implements the Temporal service layer.
 */

package in.gov.gem.app.fa.pq.service.impl;

import in.gov.gem.app.fa.pq.constant.ErrorMessageConstants;
import in.gov.gem.app.fa.pq.constant.LookupConstants;
import in.gov.gem.app.exception.generic.NotFoundException;
import in.gov.gem.app.fa.pq.constant.MessageConstants;
import in.gov.gem.app.fa.pq.domain.entity.PqCriteria;
import in.gov.gem.app.fa.pq.domain.entity.PqCriteriaMaster;
import in.gov.gem.app.fa.pq.domain.entity.PqParticipant;
import in.gov.gem.app.fa.pq.request.AttachmentTemplate;
import in.gov.gem.app.fa.pq.response.CategoryResponseDTO;
import in.gov.gem.app.fa.pq.response.MessageResponseDTO;
import in.gov.gem.app.fa.pq.response.TemporalCriteriaResponseDTO;
import in.gov.gem.app.fa.pq.service.DocAttachmentService;
import in.gov.gem.app.fa.pq.service.PqCriteriaMasterService;
import in.gov.gem.app.fa.pq.service.PqCriteriaService;
import in.gov.gem.app.fa.pq.service.PqParticipateService;
import in.gov.gem.app.fa.pq.service.TemporalService;
import in.gov.gem.app.fa.pq.utility.RequestUtil;
import in.gov.gem.app.service.core.utility.MessageUtility;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class TemporalServiceImpl implements TemporalService {

  private final MessageUtility messageUtility;
  private DocAttachmentService docAttachmentService;
  private PqCriteriaMasterService pqCriteriaMasterService;
  private PqCriteriaService pqCriteriaService;
  private RequestUtil requestUtil;
  private PqParticipateService pqParticipationService;

  private final Map<String, TemporalCriteriaResponseDTO> inMemoryData = new ConcurrentHashMap<>();

  public TemporalServiceImpl(MessageUtility messageUtility,DocAttachmentService docAttachmentService,
                             PqCriteriaMasterService pqCriteriaMasterService,
                             PqCriteriaService pqCriteriaService,
                             RequestUtil requestUtil, PqParticipateService pqParticipationService
                             ) {
    this.messageUtility = messageUtility;
    this.docAttachmentService = docAttachmentService;
    this.pqCriteriaMasterService = pqCriteriaMasterService;
    this.pqCriteriaService = pqCriteriaService;
    this.requestUtil = requestUtil;
    this.pqParticipationService = pqParticipationService;
    initializeInMemoryData();
  }

  private void initializeInMemoryData() {
    List<CategoryResponseDTO> categories1 = Arrays.asList(
        new CategoryResponseDTO(UUID.fromString("418810ff-b36c-418d-b29c-a638e24062f0"), "Technology", Boolean.TRUE),
        new CategoryResponseDTO(UUID.fromString("86ffd113-e8d6-4b9e-baa5-5f7b97a8f459"), "Finance", Boolean.TRUE),
        new CategoryResponseDTO(UUID.fromString("3c240e2d-9033-4fd0-85ab-5a76634eef72"),"Logistics", Boolean.TRUE),
        new CategoryResponseDTO(UUID.fromString("8bf6b8da-77fa-44e7-b7fc-016a8333ea56"), "Healthcare", Boolean.TRUE),
        new CategoryResponseDTO(UUID.fromString("0593b26b-ed67-4e3b-94e6-c2c3562900b0"), "Education", Boolean.TRUE),
        new CategoryResponseDTO(UUID.fromString("1ef9543a-202a-4945-9c85-63f00aeed7ac"), "PqDisabledDisEducation", Boolean.FALSE)

    );

    List<CategoryResponseDTO> categories2 = Arrays.asList(
        new CategoryResponseDTO(UUID.fromString("cdd7f830-0896-4899-b251-fba3584e3e63"), "Healthcare", Boolean.TRUE),
        new CategoryResponseDTO(UUID.fromString("2ded665e-3864-4003-bb7f-2509908d5990"), "Education", Boolean.TRUE)
    );

    List<CategoryResponseDTO> categories3 = Arrays.asList(
        new CategoryResponseDTO(UUID.fromString("92f08270-74b4-445d-8509-34b534943838"), "Retail", Boolean.TRUE),
        new CategoryResponseDTO(UUID.fromString("7f1524b0-0d0d-44fb-a0a1-3f6f89de6edf"), "Manufacturing", Boolean.TRUE)
    );

    inMemoryData.put("a6b46a3c-99ce-4d06-9775-7032b1fd24de", new TemporalCriteriaResponseDTO(
        UUID.fromString("a6b46a3c-99ce-4d06-9775-7032b1fd24de"),
        LocalDate.now().minusDays(3),
        LocalDate.now().plusDays(5),
        categories1,
        Boolean.TRUE,
        LookupConstants.Status.VALID_DRAFT.name()
    ));

    inMemoryData.put("c00fcf61-9a54-4a83-afd1-2e5ff29b724e", new TemporalCriteriaResponseDTO(
        UUID.fromString("c00fcf61-9a54-4a83-afd1-2e5ff29b724e"),
        LocalDate.now().minusDays(2),
        LocalDate.now().plusDays(3),
        categories2,
        Boolean.FALSE,
        LookupConstants.Status.PENDING.name()
    ));

    inMemoryData.put("8bf2816d-d9f3-45c9-b09d-d256c65b8c3f", new TemporalCriteriaResponseDTO(
        UUID.fromString("8bf2816d-d9f3-45c9-b09d-d256c65b8c3f"),
        LocalDate.now().minusDays(4),
        LocalDate.now().plusDays(9),
        categories3,
        Boolean.TRUE,
        LookupConstants.Status.PENDING.name()
    ));
  }

  @Override
  public TemporalCriteriaResponseDTO getTemporalCriteria(UUID offeringId) {
    Optional<TemporalCriteriaResponseDTO> criteria = Optional.ofNullable(inMemoryData.get(offeringId.toString()));
    if(criteria.isEmpty()){
      throw new NotFoundException(ErrorMessageConstants.CRITERIA_NOT_FOUND,
          messageUtility.getMessage(ErrorMessageConstants.CRITERIA_NOT_FOUND));
    }
    return criteria.get();
  }

  @Override
  public AttachmentTemplate viewAttachment(UUID attachmentId) {
    return docAttachmentService.viewAttachment(attachmentId);
  }

  @Override
  public MessageResponseDTO saveParticipants(UUID criteriaId, String languageCode) {
    PqCriteriaMaster pqCriteriaMaster = pqCriteriaMasterService.fetchCriteriaFromCriteriaId(criteriaId);
    List<PqCriteria> pqCriteriaList = pqCriteriaService.fetchCategories(pqCriteriaMaster);
    String participantId = String.valueOf(requestUtil.createRequestId());
    boolean isAllowedFlag = true;

    for(PqCriteria criteria : pqCriteriaList) {
      PqParticipant participant = PqParticipant.builder()
          .pqCriteria(criteria)
          .participantId(participantId)
          .isAllowed(isAllowedFlag)
          .isGovtUser(isAllowedFlag)
          .build();
      pqParticipationService.saveParticipant(participant);
      isAllowedFlag = !isAllowedFlag;
    }
    return MessageResponseDTO.builder()
        .message(messageUtility.getMessage(MessageConstants.SUCCESS_MESSAGE))
        .messageCode(MessageConstants.SUCCESS_MESSAGE)
        .build();
  }

  @Override
  public CategoryResponseDTO getTemporalCategory(UUID offeringId, UUID categoryCode) {
    TemporalCriteriaResponseDTO criteria = getTemporalCriteria(offeringId);
    if (criteria != null) {
      return criteria.getCategories().stream()
          .filter(category -> category.getCategoryCode().equals(categoryCode))
          .findFirst()
          .orElse(null);
    }
    return null;
  }

  public Map<String, TemporalCriteriaResponseDTO> getInMemoryData() {
    return inMemoryData;
  }


}
