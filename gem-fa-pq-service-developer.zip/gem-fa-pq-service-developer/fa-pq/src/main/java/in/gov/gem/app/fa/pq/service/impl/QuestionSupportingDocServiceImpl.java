package in.gov.gem.app.fa.pq.service.impl;

import in.gov.gem.app.fa.pq.constant.LookupConstants;
import in.gov.gem.app.fa.pq.constant.MessageConstants;
import in.gov.gem.app.fa.pq.domain.entity.PqQuestion;
import in.gov.gem.app.fa.pq.domain.entity.QuestionSupportingDoc;
import in.gov.gem.app.fa.pq.domain.repository.QuestionSupportingDocRepository;
import in.gov.gem.app.fa.pq.service.QuestionSupportingDocService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.UUID;

@Service
@AllArgsConstructor
public class QuestionSupportingDocServiceImpl implements QuestionSupportingDocService {

  private QuestionSupportingDocRepository questionSupportingDocRepository;
  @Override
  public void saveDocument(PqQuestion pqQuestion, String filePath, String docType, String fileName, UUID attachmentId){
    QuestionSupportingDoc supportingDoc= QuestionSupportingDoc.builder()
        .pqQuestion(pqQuestion)
        .documentPath(filePath)
        .fileType(docType)
        .documentId(attachmentId)
        .documentName(fileName)
        .statusLookup(LookupConstants.Status.ACTIVE.getLookupCode())
        .uploadedOn(Instant.now())
        .uploadedBy(MessageConstants.UPLOADED_BY)
        .createdBy(MessageConstants.CREATED_BY)
        .updatedBy(MessageConstants.CREATED_BY)
        .build();
    questionSupportingDocRepository.save(supportingDoc);
  }


  public QuestionSupportingDoc fetchDocumentByQuestionId(PqQuestion pqQuestion, UUID attachmentId){
    return questionSupportingDocRepository.findByPqQuestionAndDocumentId(pqQuestion, attachmentId);
  }


  public void deleteDocument(QuestionSupportingDoc supportingDoc){
    supportingDoc.setStatusLookup(LookupConstants.Status.INACTIVE.getLookupCode());
    questionSupportingDocRepository.save(supportingDoc);
  }

}
