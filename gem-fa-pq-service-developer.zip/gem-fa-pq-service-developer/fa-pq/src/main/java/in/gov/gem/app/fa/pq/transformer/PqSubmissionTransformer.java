package in.gov.gem.app.fa.pq.transformer;

import in.gov.gem.app.fa.pq.domain.entity.PqCriteria;
import in.gov.gem.app.fa.pq.domain.entity.PqSubmission;
import in.gov.gem.app.fa.pq.response.CategoriesSubmissionResponseDTO;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@AllArgsConstructor
public class PqSubmissionTransformer {


  public CategoriesSubmissionResponseDTO toCategoriesSubmissionResponseDTO(PqSubmission pqSubmission){
    return CategoriesSubmissionResponseDTO.builder()
        .categoryCode(pqSubmission.getPqCriteria().getCategoryCode())
        .auctioneerRemarks(pqSubmission.getRemarks())
        .categoryName(pqSubmission.getPqCriteria().getCriteriaName())
        .submissionId(pqSubmission.getSubmissionId())
        .statusLookup(pqSubmission.getStatusLookup())
        .categoryScore(pqSubmission.getCategoryScore())
        .submissionDateAndTime(pqSubmission.getSubmittedAt())
        .assessmentDateAndTime(pqSubmission.getEvaluatedAt())
        .build();
  }
}
