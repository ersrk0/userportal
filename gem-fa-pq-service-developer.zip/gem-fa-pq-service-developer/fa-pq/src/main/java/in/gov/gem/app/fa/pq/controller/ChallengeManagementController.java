
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * Pq Clarification Msg Repository: Contains DB function to fetch Pq clarification msg data.
 */

package in.gov.gem.app.fa.pq.controller;

import in.gov.gem.app.fa.pq.constant.Constants;
import in.gov.gem.app.fa.pq.constant.MessageConstants;
import in.gov.gem.app.fa.pq.facade.IPqChallengeManagementFacade;
import in.gov.gem.app.fa.pq.request.ChallengeReqDTO;
import in.gov.gem.app.fa.pq.request.ResponseOfChallengeReqDTO;
import in.gov.gem.app.fa.pq.response.ChallnegeResDTO;
import in.gov.gem.app.fa.pq.response.ResponseOfChallenegeDTO;
import in.gov.gem.app.service.core.utility.MessageUtility;
import in.gov.gem.app.service.dto.APIResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.UUID;

@Tag(name = "Challenge Response", description = "Challenge Management  related endpoints")
@RestController
@RequestMapping("/v1/public/criteria")
@Validated
@AllArgsConstructor
public class ChallengeManagementController {

    private final MessageUtility messageUtility;
    private final IPqChallengeManagementFacade challengeManagementFacade;

    @PostMapping(path = "/responses/{assessmentId}/challenge",
            consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<APIResponse<ChallnegeResDTO>> challengeResponse(
            @RequestHeader("Accept-Language") String acceptLanguage,
            @PathVariable UUID assessmentId,
            @ModelAttribute ChallengeReqDTO challengeReqDTO) throws IOException {

        ChallnegeResDTO response = challengeManagementFacade.challenegeResponse(assessmentId,challengeReqDTO);

        return ResponseEntity.status(HttpStatus.CREATED).body(
                APIResponse.<ChallnegeResDTO>builder()
                        .status(HttpStatus.CREATED.getReasonPhrase())
                        .httpStatus(HttpStatus.CREATED.value())
                        .message(messageUtility.getMessage(MessageConstants.SUCCESS_MESSAGE))
                        .data(response)
                        .msId(Constants.MSID)
                        .build()
        );
    }

    @PostMapping(path = "/responses/{challengeId}/challenge/response",
            consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<APIResponse<ResponseOfChallenegeDTO>> ResponseOfChallenge(
            @RequestHeader("Accept-Language") String acceptLanguage,
            @PathVariable long challengeId,
            @ModelAttribute ResponseOfChallengeReqDTO responseOfChallengeReqDTO) throws IOException {

        ResponseOfChallenegeDTO response = challengeManagementFacade.ResponseOfChallenge(challengeId,responseOfChallengeReqDTO);

        return ResponseEntity.status(HttpStatus.CREATED).body(
                APIResponse.<ResponseOfChallenegeDTO>builder()
                        .status(HttpStatus.CREATED.getReasonPhrase())
                        .httpStatus(HttpStatus.CREATED.value())
                        .message(messageUtility.getMessage(MessageConstants.SUCCESS_MESSAGE))
                        .data(response)
                        .msId(Constants.MSID)
                        .build()
        );
    }
}
