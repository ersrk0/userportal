package in.gov.gem.app.fa.pq.transformer;

import in.gov.gem.app.fa.pq.constant.MessageConstants;
import in.gov.gem.app.fa.pq.domain.entity.DocAttachment;
import in.gov.gem.app.fa.pq.domain.entity.DocMaster;
import in.gov.gem.app.fa.pq.domain.entity.PqOption;
import in.gov.gem.app.fa.pq.domain.entity.PqQuestion;
import in.gov.gem.app.fa.pq.request.QuestionCreateRequestDTO;
import in.gov.gem.app.fa.pq.response.CreateQuestionResponseDTO;
import in.gov.gem.app.fa.pq.response.DeleteUploadedDocumentsResponseDTO;
import in.gov.gem.app.fa.pq.response.DocAttachmentResponseDTO;
import in.gov.gem.app.fa.pq.response.MessageResponseDTO;
import in.gov.gem.app.fa.pq.response.QuestionResponseDTO;
import in.gov.gem.app.fa.pq.response.UploadDocumentsResponseDTO;
import in.gov.gem.app.service.core.utility.MessageUtility;
import lombok.AllArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

@Component
@AllArgsConstructor
public class QuestionCreationTransformer {

  private final MessageUtility messageUtility;
  private static final Logger logger = LoggerFactory.getLogger(QuestionCreationTransformer.class);
  public CreateQuestionResponseDTO toCreateQuestionResponseDTO(UUID criteriaId, QuestionCreateRequestDTO request,
                                                               PqQuestion pqQuestion, DocMaster docMaster,
                                                               List<DocAttachment> docAttachments, List<PqOption> pqOptions) {
    logger.info("Entering toCreateQuestionResponseDTO with criteriaId: {}, request: {}, pqQuestion: {}", criteriaId, request, pqQuestion);
    List<Map<String, Object>> options = pqOptions.stream()
            .map(option -> Map.<String, Object>of(
                    "id", option.getId(),
                    "value", option.getOptionValue()
            ))
            .collect(Collectors.toList());
    logger.debug("Mapped options: {}", options);

    List<QuestionResponseDTO> questionResponseDTOS = new ArrayList<>();
    QuestionResponseDTO questionResponseDTO = new QuestionResponseDTO();
    questionResponseDTO.setQuestionId(pqQuestion.getPqQuestionId());
    questionResponseDTO.setQuestionText(request.getQuestionText());
    questionResponseDTO.setInputType(request.getInputType());
    questionResponseDTO.setIsMandatory(request.getIsMandatory());
    questionResponseDTO.setOptions(options);
    questionResponseDTO.setDocumentId(docMaster.getDocumentId());
    questionResponseDTOS.add(questionResponseDTO);

    List<DocAttachmentResponseDTO> attachmentResponseDTOS = docAttachments.stream()
            .map(docAttachment -> DocAttachmentResponseDTO.builder()
                    .attachmentId(docAttachment.getAttachmentId())
                    .docType(docAttachment.getAttachmentTypeLookup())
                    .fileName(docAttachment.getAttachmentName())
                    .fileSize(docAttachment.getAttachmentSize())
                    .filePath(docAttachment.getAttachmentPath())
                    .build())
            .collect(Collectors.toList());
    logger.debug("Mapped attachments: {}", attachmentResponseDTOS);

    questionResponseDTO.setAttachments(attachmentResponseDTOS);

    CreateQuestionResponseDTO response = CreateQuestionResponseDTO.builder()
            .criteriaId(criteriaId)
            .questions(questionResponseDTOS)
            .build();
    logger.info("Exiting toCreateQuestionResponseDTO with response: {}", response);
    return response;
  }

  public CreateQuestionResponseDTO toQuestionResponseDTO(UUID criteriaId, QuestionCreateRequestDTO request,
                                                         PqQuestion pqQuestion, List<PqOption> pqOptions) {
    logger.info("Entering toQuestionResponseDTO with criteriaId: {}, request: {}, pqQuestion: {}", criteriaId, request, pqQuestion);
    List<Map<String, Object>> options = pqOptions.stream()
            .map(option -> Map.<String, Object>of(
                    "id", option.getId(),
                    "value", option.getOptionValue()
            ))
            .collect(Collectors.toList());
    logger.debug("Mapped options: {}", options);

    List<QuestionResponseDTO> questionResponseDTOS = new ArrayList<>();
    QuestionResponseDTO questionResponseDTO = new QuestionResponseDTO();
    questionResponseDTO.setQuestionId(pqQuestion.getPqQuestionId());
    questionResponseDTO.setQuestionText(request.getQuestionText());
    questionResponseDTO.setInputType(request.getInputType());
    questionResponseDTO.setIsMandatory(request.getIsMandatory());
    questionResponseDTO.setOptions(options);
    questionResponseDTOS.add(questionResponseDTO);

    CreateQuestionResponseDTO response = CreateQuestionResponseDTO.builder()
            .criteriaId(criteriaId)
            .questions(questionResponseDTOS)
            .build();
    logger.info("Exiting toQuestionResponseDTO with response: {}", response);
    return response;
  }

  public QuestionResponseDTO convertToQuestionResponseDTO(PqQuestion pqQuestion, List<Map<String, Object>> options, List<DocAttachmentResponseDTO> attachmentResponseDTOS) {
    logger.info("Entering convertToQuestionResponseDTO with pqQuestion: {}", pqQuestion);
    QuestionResponseDTO dto = new QuestionResponseDTO();
    dto.setQuestionId(pqQuestion.getPqQuestionId());
    dto.setQuestionText(pqQuestion.getQuestionText());
    dto.setInputType(pqQuestion.getQuestionTypeLookup());
    dto.setIsMandatory(pqQuestion.getIsMandatory());
    dto.setScore(pqQuestion.getWeightage());
    dto.setDocRequired(pqQuestion.getRequiresDocument());
    dto.setOptions(options);
    dto.setAttachments(attachmentResponseDTOS);
    logger.debug("Converted QuestionResponseDTO: {}", dto);
    logger.info("Exiting convertToQuestionResponseDTO");
    return dto;
  }

  public MessageResponseDTO toDeleteQuestionMessageResponseDTO() {
    logger.info("Entering toDeleteQuestionMessageResponseDTO");
    MessageResponseDTO response = MessageResponseDTO.builder()
            .messageCode(MessageConstants.DELETE_QUESTION)
            .message(messageUtility.getMessage(MessageConstants.DELETE_QUESTION))
            .build();
    logger.info("Exiting toDeleteQuestionMessageResponseDTO with response: {}", response);
    return response;
  }

  public MessageResponseDTO toUpdateQuestionMessageResponseDTO() {
    logger.info("Entering toUpdateQuestionMessageResponseDTO");
    MessageResponseDTO response = MessageResponseDTO.builder()
            .messageCode(MessageConstants.UPDATE_QUESTION)
            .message(messageUtility.getMessage(MessageConstants.UPDATE_QUESTION))
            .build();
    logger.info("Exiting toUpdateQuestionMessageResponseDTO with response: {}", response);
    return response;
  }

  public UploadDocumentsResponseDTO toUploadDocumentResponseDTO(List<UUID> attachmentIds, PqQuestion pqQuestion) {
    logger.info("Entering toUploadDocumentResponseDTO with attachmentIds: {} and pqQuestion: {}", attachmentIds, pqQuestion);
    UploadDocumentsResponseDTO response = UploadDocumentsResponseDTO.builder()
            .documentId(pqQuestion.getDocMaster().getDocumentId())
            .attachmentsUploaded(attachmentIds)
            .build();
    logger.info("Exiting toUploadDocumentResponseDTO with response: {}", response);
    return response;
  }

  public DeleteUploadedDocumentsResponseDTO toDeleteDocumentMessageResponseDTO(UUID attachmentId) {
    logger.info("Entering toDeleteDocumentMessageResponseDTO with attachmentId: {}", attachmentId);
    DeleteUploadedDocumentsResponseDTO response = DeleteUploadedDocumentsResponseDTO.builder()
            .attachmentId(attachmentId)
            .status(MessageConstants.SUCCESS_MESSAGE)
            .build();
    logger.info("Exiting toDeleteDocumentMessageResponseDTO with response: {}", response);
    return response;
  }

  public MessageResponseDTO toDeleteCategoryQuestionMessageResponseDTO() {
    logger.info("Entering toDeleteCategoryQuestionMessageResponseDTO");
    MessageResponseDTO response = MessageResponseDTO.builder()
            .message(messageUtility.getMessage(MessageConstants.CATEGORY_QUESTION_DELETED))
            .messageCode(MessageConstants.CATEGORY_QUESTION_DELETED)
            .build();
    logger.info("Exiting toDeleteCategoryQuestionMessageResponseDTO with response: {}", response);
    return response;
  }
}
