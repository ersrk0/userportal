
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * Pq Question Entity: Specifies the attributes in the 'pq_question' table.
 */
package in.gov.gem.app.fa.pq.domain.entity;

import in.gov.gem.app.service.core.entity.BaseEntity;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

@Entity
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
@Table(name = "pq_question")
public class PqQuestion extends BaseEntity {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @Column(name = "pq_question_id", nullable = false)
  private UUID pqQuestionId;

  @ManyToOne(fetch = FetchType.EAGER)
  @JoinColumn(name = "pq_criteria_fk", referencedColumnName = "id", nullable = false)
  private PqCriteria pqCriteria;

  @Column(name = "question_text", length = 1024)
  private String questionText;

  @Column(name = "question_type_lookup", length = 10)
  private String questionTypeLookup;

  @Column(name = "status_lookup", nullable = false, length = 10)
  private String statusLookup;

  @Column(name = "is_mandatory", nullable = false)
  private Boolean isMandatory;

  @Column(name = "is_document_required", nullable = false)
  private Boolean requiresDocument;

  @Column(name = "weightage")
  private BigDecimal weightage;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "doc_master_fk", referencedColumnName = "id", nullable = false)
  private DocMaster docMaster;

  @OneToMany(mappedBy = "pqQuestion", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
  private List<PqOption> options;

  @Column(name = "question_set_by", nullable = false, length = 50)
  private String questionSetBy;

}