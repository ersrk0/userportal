
/*
 * This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * Parent Criteria Management Transformer: Transformer layer to transform an entity to dto & vice versa.
 */

package in.gov.gem.app.fa.pq.transformer;

import in.gov.gem.app.fa.pq.domain.entity.PqCriteriaMaster;
import in.gov.gem.app.fa.pq.request.CriteriaIdRequestDTO;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.UUID;

@Component
@AllArgsConstructor
public class ParentCriteriaManagementTransformer {
  public PqCriteriaMaster toPqParentCriteria(CriteriaIdRequestDTO criteriaIdRequestDTO, UUID criteriaId) {
    return PqCriteriaMaster.builder()
        .masterCriteriaId(criteriaId)
        .offeringId(criteriaIdRequestDTO.getOfferingId())
        .statusLookup(criteriaIdRequestDTO.getStatus())
        .pqSubmissionStart(criteriaIdRequestDTO.getPqStartDate())
        .pqSubmissionEnd(criteriaIdRequestDTO.getPqEndDate())
        .createdBy("to_do")//TODO: fetch from session
        .build();
  }
}
