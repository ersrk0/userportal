
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * Criteria Management ServiceImpl: Implements the Criteria Management service layer.
 */
package in.gov.gem.app.fa.pq.service.impl;

import in.gov.gem.app.exception.generic.ServiceException;
import in.gov.gem.app.exception.utility.ErrorConstant;
import in.gov.gem.app.fa.pq.constant.ErrorMessageConstants;
import in.gov.gem.app.fa.pq.constant.LookupConstants;
import in.gov.gem.app.fa.pq.constant.MessageConstants;
import in.gov.gem.app.fa.pq.domain.entity.PqParticipant;
import in.gov.gem.app.fa.pq.domain.entity.PqQuestion;
import in.gov.gem.app.fa.pq.domain.entity.PqResponse;
import in.gov.gem.app.fa.pq.domain.repository.PqResponseRepository;
import in.gov.gem.app.fa.pq.response.PqQuestionResponseDTO;
import in.gov.gem.app.fa.pq.service.PqQuestionResponseService;
import in.gov.gem.app.service.core.utility.MessageUtility;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
@AllArgsConstructor
public class PqQuestionResponseServiceImpl implements PqQuestionResponseService {

    private PqResponseRepository pqResponseRepository;
    private MessageUtility messageUtility;

    public PqQuestionResponseDTO saveResponseEntity(List<PqResponse> pqResponseList){
        PqResponse savedPqResponse;
        List<UUID> submissionIds = new ArrayList<>();
        for(PqResponse pqResponse : pqResponseList){
            savedPqResponse = pqResponseRepository.save(pqResponse);
            submissionIds.add(savedPqResponse.getPqResponseId());
        }
        return PqQuestionResponseDTO.builder().submissionId(submissionIds.getFirst()).build();
    }

    public PqResponse saveResponseEntity(PqResponse pqResponse){
        return pqResponseRepository.save(pqResponse);
    }

    public PqResponse fetchResponseFromSubmissionId(UUID submissionId){
        return pqResponseRepository.findByPqResponseId(submissionId);
    }

    @Override
    public String deleteSubmittedResponse(UUID criteriaId, UUID questionId, UUID submissionId) {
        PqResponse existingResponses = pqResponseRepository.findByPqResponseId(submissionId);
        if(existingResponses == null){
            throw new ServiceException(ErrorMessageConstants.SUBMISSION_NOT_EXIST, messageUtility.getMessage(
                    ErrorMessageConstants.SUBMISSION_NOT_EXIST),
                    ErrorConstant.CATEGORY.TS, ErrorConstant.SEVERITY.I);
        }
        existingResponses.setStatusLookup(LookupConstants.Status.INACTIVE.getLookupCode());
        pqResponseRepository.save(existingResponses);
        return messageUtility.getMessage(MessageConstants.DELETE_SUBMISSION);
    }

    @Override
    public PqResponse fetchResponseFromResponseId(UUID responseId) {
        return pqResponseRepository.findByPqResponseId(responseId);
    }

    @Override
    public void validateParticipant(String participantId, UUID responseId) {
        PqResponse pqResponse = pqResponseRepository.findByPqResponseId(responseId);
        if(!pqResponse.getPqParticipantFk().getParticipantId().equals(participantId)){
            throw new ServiceException(ErrorMessageConstants.FORBIDDEN_PARTICIPANT, messageUtility.getMessage(
                    ErrorMessageConstants.FORBIDDEN_PARTICIPANT),
                    ErrorConstant.CATEGORY.TS, ErrorConstant.SEVERITY.I);
        }
    }

    @Override
    public PqResponse fetchResponseByQuestionAndParticipantAndStatusLookupIn(PqQuestion pqQuestion, PqParticipant participant, List<String> statusList) {

        return pqResponseRepository.findByPqQuestionFkAndPqParticipantFkAndStatusLookupIn(
                pqQuestion, participant,statusList
        ).orElse(null);

    }


}
