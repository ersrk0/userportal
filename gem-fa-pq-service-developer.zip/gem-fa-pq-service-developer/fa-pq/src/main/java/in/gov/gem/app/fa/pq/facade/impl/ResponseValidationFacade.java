
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * Criteria Management ServiceImpl: Implements the Criteria Management service layer.
 */
package in.gov.gem.app.fa.pq.facade.impl;

import in.gov.gem.app.fa.pq.domain.entity.PqParticipant;
import in.gov.gem.app.fa.pq.domain.entity.PqQuestion;
import in.gov.gem.app.fa.pq.domain.entity.PqResponse;
import in.gov.gem.app.fa.pq.facade.IResponseValidationFacade;
import in.gov.gem.app.fa.pq.request.QuestionnaireResponseSubmitDTO;
import in.gov.gem.app.fa.pq.service.PqQuestionResponseService;
import in.gov.gem.app.fa.pq.validation.response.ResponseValidation;
import org.springframework.stereotype.Component;
import java.util.List;
import java.util.UUID;

@Component
public class ResponseValidationFacade implements IResponseValidationFacade {

    private final List<ResponseValidation> responseValidationList;
    PqQuestionResponseService pqQuestionResponseService;

    public ResponseValidationFacade(List<ResponseValidation> responseValidationList, PqQuestionResponseService pqQuestionResponseService) {
        this.responseValidationList = responseValidationList;
        this.pqQuestionResponseService = pqQuestionResponseService;
    }

    @Override
    public boolean validate(PqQuestion pqQuestionEntity, QuestionnaireResponseSubmitDTO answerDto){
        for (ResponseValidation responseValidation : responseValidationList) {
            if(responseValidation.canHandle(answerDto.getResponseType()))
                return responseValidation.validate(pqQuestionEntity,answerDto.getResponseValue());
        }
        return false;
    }

    @Override
    public PqResponse buildPqResponse(UUID submissionId, PqQuestion pqQuestionEntity, QuestionnaireResponseSubmitDTO answerDto, String responseStatus, PqParticipant pqParticipant) {
        for (ResponseValidation responseValidation : responseValidationList) {
            if(responseValidation.canHandle(answerDto.getResponseType()))
                return responseValidation.buildPqResponse(submissionId,pqQuestionEntity,answerDto.getResponseValue(), responseStatus, pqParticipant);
        }
        throw new IllegalArgumentException("No suitable response validation found for response type: " + answerDto.getResponseType());
    }

    @Override
    public PqResponse updatePqResponse(UUID submissionId, PqQuestion pqQuestionEntity, QuestionnaireResponseSubmitDTO answerDto) {
        for (ResponseValidation responseValidation : responseValidationList) {
            if(responseValidation.canHandle(answerDto.getResponseType()))
                return responseValidation.updatePqResponse(submissionId,pqQuestionEntity,answerDto.getResponseValue());
        }
        throw new IllegalArgumentException("No suitable response validation found for response type: " + answerDto.getResponseType());

    }


}
