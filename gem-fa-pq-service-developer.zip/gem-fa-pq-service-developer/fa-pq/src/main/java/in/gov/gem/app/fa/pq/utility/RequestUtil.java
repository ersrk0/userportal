package in.gov.gem.app.fa.pq.utility;

import in.gov.gem.app.fa.pq.constant.LookupConstants;
import in.gov.gem.app.service.core.security.securityUtils.GemUtility;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.util.UUID;

@Component
@AllArgsConstructor
public class RequestUtil {

  private String langPref;

  public String createPath(String directoryName,UUID attachmentId, String fileName) {
    return LookupConstants.MODULE_PATH + attachmentId + directoryName+ fileName;
  }




  public String createPathUploadDocument(String directoryName, String fileName, UUID questionId){
    return LookupConstants.MODULE_PATH + directoryName + questionId + "/" + fileName ;
  }

  public UUID createRequestId(){
    return UUID.randomUUID();
  }

  public RequestUtil() {
    this.langPref = GemUtility.getGemContext().userContext.getLangPref();
  }

  public static String getLangPref() {
    String lang = GemUtility.getGemContext().getUserContext().getLangPref();
    if (lang == null) {
      lang = "eng";
    }
    return lang;
  }

  public UUID generateRandomUUID(){
    return UUID.randomUUID();
  }
  public boolean isFileValid(MultipartFile file)
    {
      if(file!=null && file.getSize()!=0)
        return true;
      return false;
    }

}
