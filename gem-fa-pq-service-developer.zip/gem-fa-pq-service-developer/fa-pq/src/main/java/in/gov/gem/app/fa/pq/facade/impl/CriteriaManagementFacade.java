
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM
 * Criteria Management Facade: Facade layer between Controller and Service.
 */

package in.gov.gem.app.fa.pq.facade.impl;

import in.gov.gem.app.fa.pq.constant.LookupConstants;
import in.gov.gem.app.fa.pq.domain.entity.DocMaster;
import in.gov.gem.app.fa.pq.domain.entity.PqCriteria;
import in.gov.gem.app.fa.pq.domain.entity.PqCriteriaMaster;
import in.gov.gem.app.fa.pq.domain.entity.PqSubmission;
import in.gov.gem.app.fa.pq.facade.ICriteriaManagementFacade;
import in.gov.gem.app.fa.pq.request.CriteriaIdRequestDTO;
import in.gov.gem.app.fa.pq.request.SubmitRepresentationReqDTO;
import in.gov.gem.app.fa.pq.response.*;
import in.gov.gem.app.fa.pq.service.*;
import in.gov.gem.app.fa.pq.transformer.CriteriaManagementTransformer;
import in.gov.gem.app.fa.pq.utility.RequestUtil;
import in.gov.gem.app.service.attachment.utility.S3AttachmentUtility;
import in.gov.gem.app.service.dto.CoreLookupDto;
import in.gov.gem.app.service.pack.service.interfaces.CoreLookupService;
import lombok.AllArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Component
@AllArgsConstructor
public class CriteriaManagementFacade implements ICriteriaManagementFacade {

  private static final Logger logger = LoggerFactory.getLogger(CriteriaManagementFacade.class);

  private final CriteriaManagementTransformer criteriaManagementTransformer;
  private final PqCriteriaService pqCriteriaService;
  private final PqCriteriaMasterService pqCriteriaMasterService;
  private final RequestUtil requestUtil;
  private final DocumentServiceUtil documentServiceUtil;
  private final CoreLookupService coreLookupService;
  private final DocAttachmentService docAttachmentService;
  private final S3AttachmentUtility s3AttachmentUtility;
  private final DocumentMasterService documentMasterService;
  private final PqSubmissionService pqSubmissionService;
  private final TemporalService temporalService;

  @Override
  public CriteriaIdResponseDTO createCriteria(String acceptLanguage, CriteriaIdRequestDTO criteriaIdRequestDTO) {
    logger.info("Entering createCriteria with acceptLanguage: {}", acceptLanguage);

    logger.debug("Request payload for createCriteria: {}", criteriaIdRequestDTO);
    UUID criteriaId = UUID.randomUUID();
    UUID categoryId = UUID.randomUUID();
    PqCriteriaMaster pqCriteriaMaster = pqCriteriaMasterService
            .createParentCriteria(acceptLanguage, criteriaIdRequestDTO, criteriaId);
    pqCriteriaService.createCriteria(acceptLanguage, criteriaIdRequestDTO, categoryId, pqCriteriaMaster);
    logger.debug("Created criteria with criteriaId: {} and categoryId: {}", criteriaId, categoryId);

    logger.info("Exiting createCriteria with criteriaId: {}", criteriaId);
    return criteriaManagementTransformer.toCriteriaIdResponseDTO(criteriaId, criteriaIdRequestDTO);
  }

  @Override
  public CriteriaIdResponseDTO fetchCriteria(String acceptLanguage, UUID offeringId) {
    logger.info("Entering fetchCriteria with offeringId: {}", offeringId);

    logger.debug("Fetching criteria with acceptLanguage: {}", acceptLanguage);
    PqCriteriaMaster pqCriteriaMaster = pqCriteriaMasterService.fetchCriteria(acceptLanguage, offeringId);
    List<PqCriteria> pqCriteriaList = pqCriteriaService.fetchCriteria(acceptLanguage, pqCriteriaMaster);
    logger.debug("Fetched criteria list: {}", pqCriteriaList);

    logger.info("Exiting fetchCriteria with offeringId: {}", offeringId);
    List<CategoryResponseDTO> categoryResponseDTOList = new ArrayList<>();
    for(PqCriteria pqCriteria : pqCriteriaList){
      CategoryResponseDTO temporalCategoryResponse = temporalService.getTemporalCategory(pqCriteria.getPqCriteriaMaster().getOfferingId(), pqCriteria.getCategoryCode());
      List<PqSubmission> pqSubmissionList = pqSubmissionService.fetchSubmissionList(pqCriteria).orElse(null);
      Boolean isCategorySubmitted = pqSubmissionList != null && !pqSubmissionList.isEmpty();
      CategoryResponseDTO categoryResponseDTO = CategoryResponseDTO.builder()
              .categoryCode(pqCriteria.getCategoryCode())
              .categoryName(pqCriteria.getCriteriaName())
              .isPqEnabled(temporalCategoryResponse.getIsPqEnabled())
              .isCategoryFilled(isCategorySubmitted)
              .build();
      categoryResponseDTOList.add(categoryResponseDTO);
    }
    return criteriaManagementTransformer.toCriteriaIdResponse(pqCriteriaMaster,categoryResponseDTOList);
  }

  @Override
  public MessageResponseDTO deleteCriteria(String acceptLanguage, UUID criteriaId) {
    logger.info("Entering deleteCriteria with criteriaId: {}", criteriaId);

    logger.debug("Deleting criteria with acceptLanguage: {}", acceptLanguage);
    PqCriteriaMaster pqCriteriaMaster = pqCriteriaMasterService.deleteParentCriteria(acceptLanguage, criteriaId);
    pqCriteriaService.deleteCriteria(acceptLanguage, pqCriteriaMaster);
    logger.debug("Deleted criteria with criteriaId: {}", criteriaId);

    logger.info("Exiting deleteCriteria with criteriaId: {}", criteriaId);
    return criteriaManagementTransformer.toDeleteCriteriaMessageResponseDTO();
  }

  @Override
  public MessageResponseDTO deleteCategory(String acceptLanguage, UUID criteriaId, UUID categoryCode) {
    logger.info("Entering deleteCategory with criteriaId: {} and categoryCode: {}", criteriaId, categoryCode);

    logger.debug("Deleting category with acceptLanguage: {}", acceptLanguage);
    PqCriteriaMaster pqCriteriaMaster = pqCriteriaMasterService.fetchCriteriaFromCriteriaId(criteriaId);
    pqCriteriaService.deleteCategory(acceptLanguage, pqCriteriaMaster, categoryCode);
    logger.debug("Deleted category with criteriaId: {} and categoryCode: {}", criteriaId, categoryCode);

    logger.info("Exiting deleteCategory with criteriaId: {} and categoryCode: {}", criteriaId, categoryCode);
    return criteriaManagementTransformer.toDeleteCategoryMessageResponseDTO();
  }

  @Override
  public MessageResponseDTO syncCriteria() {
    logger.info("Entering syncCriteria");
    MessageResponseDTO response = criteriaManagementTransformer.toSyncCriteriaMessageResponseDTO();
    logger.debug("Response from syncCriteria: {}", response);

    logger.info("Exiting syncCriteria");
    return response;
  }

  @Override
  public SubmitRepresentationResDTO submitRepresentationStatus(UUID criteriaId, SubmitRepresentationReqDTO submitRepresentationReqDTO, String acceptLanguage) throws IOException {
    logger.info("Entering submitRepresentationStatus with criteriaId: {}", criteriaId);


    logger.debug("Request payload for submitRepresentationStatus: {}", submitRepresentationReqDTO);
    PqCriteriaMaster pqCriteriaMaster = pqCriteriaMasterService.fetchActiveCriteriaFromCriteriaId(criteriaId);
    pqCriteriaMaster.setIsRepresentationAllowed(submitRepresentationReqDTO.getRepresentation());
    pqCriteriaMaster.setRemarks(submitRepresentationReqDTO.getRemarks());

    DocMaster documentMaster = null;
    MultipartFile file = submitRepresentationReqDTO.getFile();
    if (file != null) {
      documentMaster = this.documentUpload(file);
      pqCriteriaMaster.setDocMaster(documentMaster);
      logger.debug("Uploaded document for criteriaId: {}", criteriaId);
    }
    PqCriteriaMaster newPqCriteriaMaster = pqCriteriaMasterService.submitRepresentation(pqCriteriaMaster);
    logger.debug("Updated representation status for criteriaId: {}", criteriaId);

    logger.info("Exiting submitRepresentationStatus with criteriaId: {}", criteriaId);
    return criteriaManagementTransformer.toSubmitRepresentationDTO(newPqCriteriaMaster);
  }

  @Override
  public DocMaster documentUpload(MultipartFile file) throws IOException {
    logger.info("Entering documentUpload with file: {}", file.getOriginalFilename());

    logger.debug("File details - Name: {}, Size: {}", file.getOriginalFilename(), file.getSize());
    String fileName = file.getOriginalFilename();
    String docName = file.getContentType();
    assert fileName != null;
    UUID documentId = requestUtil.createRequestId();
    UUID attachmentId = requestUtil.createRequestId();
    documentServiceUtil.fileSizeCheck(file);
    CoreLookupDto lookupDto = coreLookupService.findAllByLookupValueIgnoreCase(docName).get(0);
    String docType = lookupDto.getLookupCode();
    String filePath = requestUtil.createPath(LookupConstants.QUESTION_CREATION, attachmentId, fileName);
    DocMaster documentMaster = documentMasterService.saveDocumentMaster(documentId);
    docAttachmentService.saveDocumentDetails(documentMaster, filePath, docType, fileName, file.getSize(), attachmentId);
    s3AttachmentUtility.uploadMultipart("gem-consent-service", filePath, file);
    logger.debug("Uploaded file to S3 with path: {}", filePath);

    logger.info("Exiting documentUpload with file: {}", file.getOriginalFilename());
    return documentMaster;
  }

  @Override
  public SubmitRepresentationResDTO getRepresentationStatus(UUID criteriaId, String acceptLanguage) {
    logger.info("Entering getRepresentationStatus with criteriaId: {}", criteriaId);

    logger.debug("Fetching representation status with acceptLanguage: {}", acceptLanguage);
    PqCriteriaMaster pqCriteriaMaster = pqCriteriaMasterService.fetchActiveCriteriaFromCriteriaId(criteriaId);
    logger.debug("Fetched representation status for criteriaId: {}", criteriaId);

    logger.info("Exiting getRepresentationStatus with criteriaId: {}", criteriaId);
    return criteriaManagementTransformer.toSubmitRepresentationDTO(pqCriteriaMaster);
  }


}