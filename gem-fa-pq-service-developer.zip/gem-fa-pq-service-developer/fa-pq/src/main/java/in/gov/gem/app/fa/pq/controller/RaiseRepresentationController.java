package in.gov.gem.app.fa.pq.controller;

import in.gov.gem.app.fa.pq.constant.Constants;
import in.gov.gem.app.fa.pq.constant.MessageConstants;
import in.gov.gem.app.fa.pq.facade.IRaiseRepresentationFacade;
import in.gov.gem.app.fa.pq.request.RepresentationRequestDTO;
import in.gov.gem.app.fa.pq.request.RespondRepresentationRequestDTO;
import in.gov.gem.app.fa.pq.response.RaiseRepresentationResponseDTO;
import in.gov.gem.app.fa.pq.response.RepresentationResponseDTO;
import in.gov.gem.app.fa.pq.response.RespondRepresentationResponseDTO;
import in.gov.gem.app.service.core.utility.MessageUtility;
import in.gov.gem.app.service.dto.APIResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.UUID;

@Tag(name = "Manage PQ Criteria Representation")
@RestController
@RequestMapping("/v1/public/criteria")
@Validated
@AllArgsConstructor
public class RaiseRepresentationController {

  private final IRaiseRepresentationFacade raiseRepresentationFacade;
  private final MessageUtility messageUtility;

  @PostMapping(value = "/{criteriaId}/representation/raise")
  public ResponseEntity<APIResponse<RaiseRepresentationResponseDTO>> raiseRepresentation(@RequestHeader(value = "Accept-Language") String acceptLanguage,
                                                                                         @Valid @PathVariable UUID criteriaId,
                                                                                         @Valid @RequestPart
                                                                                           RepresentationRequestDTO request,
                                                                                         @Valid @RequestPart(name = "file", required = false)
                                                                                         MultipartFile[] file) throws IOException {

    final RaiseRepresentationResponseDTO response = raiseRepresentationFacade.raiseRepresentation(acceptLanguage, criteriaId, request, file);
    return ResponseEntity.ok().body(APIResponse.<RaiseRepresentationResponseDTO>builder()
        .msId(Constants.MSID)
        .status(HttpStatus.OK.getReasonPhrase())
        .httpStatus(HttpStatus.OK.value())
        .message(messageUtility.getMessage(MessageConstants.RAISE_REPRESENTATION))
        .data(response)
        .build());
  }



  @GetMapping(path = "/{criteriaId}/representation/{categoryCode}")
  public ResponseEntity<APIResponse<RepresentationResponseDTO>> fetchRepresentation(
      @RequestHeader("Accept-Language") String acceptLanguage,
      @Valid @PathVariable UUID criteriaId, @Valid @PathVariable UUID categoryCode) {
    RepresentationResponseDTO response = raiseRepresentationFacade.fetchRepresentation(acceptLanguage, criteriaId, categoryCode);

    return ResponseEntity.status(HttpStatus.OK).body(
        APIResponse.<RepresentationResponseDTO>builder()
            .status(HttpStatus.OK.getReasonPhrase())
            .httpStatus(HttpStatus.OK.value())
            .message(messageUtility.getMessage(MessageConstants.SUCCESS_MESSAGE))
            .data(response)
            .msId(Constants.MSID)
            .build()
    );
  }


  @PostMapping(value = "/representation/respond")
  public ResponseEntity<APIResponse<RespondRepresentationResponseDTO>> responseRepresentation(@RequestHeader(value = "Accept-Language") String acceptLanguage,
                                                                                         @Valid @RequestPart
                                                                                            RespondRepresentationRequestDTO request,
                                                                                              @Valid @RequestPart(name = "file", required = false)
                                                                                                MultipartFile[] file) throws IOException {

    final RespondRepresentationResponseDTO response = raiseRepresentationFacade.responseRepresentation(acceptLanguage, request, file);
    return ResponseEntity.ok().body(APIResponse.<RespondRepresentationResponseDTO>builder()
        .msId(Constants.MSID)
        .status(HttpStatus.OK.getReasonPhrase())
        .httpStatus(HttpStatus.OK.value())
        .message(messageUtility.getMessage(MessageConstants.REPRESENTATION_RESPONSE))
        .data(response)
        .build());
  }
}
