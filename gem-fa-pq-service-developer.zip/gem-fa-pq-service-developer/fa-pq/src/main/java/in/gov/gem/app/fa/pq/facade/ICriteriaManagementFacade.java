
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM
 * Criteria Management Facade: Facade layer between Controller and Service.
 */

package in.gov.gem.app.fa.pq.facade;

import in.gov.gem.app.fa.pq.domain.entity.DocMaster;
import in.gov.gem.app.fa.pq.request.CriteriaIdRequestDTO;
import in.gov.gem.app.fa.pq.request.SubmitRepresentationReqDTO;
import in.gov.gem.app.fa.pq.response.CriteriaIdResponseDTO;
import in.gov.gem.app.fa.pq.response.MessageResponseDTO;
import in.gov.gem.app.fa.pq.response.SubmitRepresentationResDTO;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.UUID;

public interface ICriteriaManagementFacade {

  CriteriaIdResponseDTO createCriteria(String acceptLanguage, CriteriaIdRequestDTO criteriaIdRequestDTO);


  CriteriaIdResponseDTO fetchCriteria(String acceptLanguage, UUID offeringId);

  MessageResponseDTO deleteCriteria(String acceptLanguage, UUID criteriaId);

  MessageResponseDTO deleteCategory(String acceptLanguage, UUID criteriaId, UUID categoryId);

  MessageResponseDTO syncCriteria();

    SubmitRepresentationResDTO submitRepresentationStatus(UUID criteriaId, SubmitRepresentationReqDTO submitRepresentationReqDTO, String acceptLanguage) throws IOException;

  DocMaster documentUpload(MultipartFile file) throws IOException, IOException;

  SubmitRepresentationResDTO getRepresentationStatus(UUID criteriaId, String acceptLanguage);
}
