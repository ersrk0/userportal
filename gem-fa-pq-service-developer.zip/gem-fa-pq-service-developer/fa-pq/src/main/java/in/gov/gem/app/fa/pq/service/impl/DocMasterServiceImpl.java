package in.gov.gem.app.fa.pq.service.impl;

import in.gov.gem.app.fa.pq.domain.entity.DocMaster;
import in.gov.gem.app.fa.pq.domain.repository.DocMasterRepository;
import in.gov.gem.app.fa.pq.service.DocumentMasterService;
import lombok.AllArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
@AllArgsConstructor
public class DocMasterServiceImpl implements DocumentMasterService {

  private static final Logger logger = LoggerFactory.getLogger(DocMasterServiceImpl.class);

  private DocMasterRepository docMasterRepository;

  @Override
  public DocMaster saveDocumentMaster(UUID attachmentId) {
    logger.info("Entering saveDocumentMaster with attachmentId: {}", attachmentId);

    DocMaster docMaster = DocMaster.builder()
            .documentId(attachmentId)
            .build();
    logger.debug("Created DocMaster object: {}", docMaster);

    DocMaster savedDocMaster = docMasterRepository.save(docMaster);
    logger.info("Saved DocMaster with documentId: {}", savedDocMaster.getDocumentId());

    logger.info("Exiting saveDocumentMaster");
    return savedDocMaster;
  }
}


