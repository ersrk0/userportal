//package in.gov.gem.app.fa.pq.service.impl;
//
//import in.gov.gem.app.fa.pq.entity.DocMaster;
//import in.gov.gem.app.fa.pq.entity.PqClarification;
//import in.gov.gem.app.fa.pq.entity.PqResponse;
//import in.gov.gem.app.fa.pq.repository.PqClarificationMsgRepository;
//import in.gov.gem.app.fa.pq.repository.PqClarificationRepository;
//import in.gov.gem.app.fa.pq.repository.PqClarificationThreadRepository;
//import in.gov.gem.app.fa.pq.request.ClarificationRequestDTO;
//import in.gov.gem.app.fa.pq.service.ClassificationManagementService;
//import in.gov.gem.app.fa.pq.utility.RequestUtil;
//import in.gov.gem.app.service.core.utility.MessageUtility;
//import lombok.AllArgsConstructor;
//import org.springframework.stereotype.Service;
//
//import java.util.UUID;
//
//@Service
//@AllArgsConstructor
//public class ClarificationManagementServiceImpl implements ClassificationManagementService {
//
//    private PqClarificationRepository pqClarificationRepository;
//    private PqClarificationThreadRepository pqClarificationThreadRepository;
//    private PqClarificationMsgRepository pqClarificationMsgRepository;
//    private PqQuestionResponseServiceImpl pqQuestionResponseService;
//    private MessageUtility messageUtility;
//    private RequestUtil requestUtil;
//
//
//    @Override
//    public PqClarification submitClarification(String acceptLanguage, UUID criteriaId, UUID responseId,DocMaster documentMaster, ClarificationRequestDTO submitClarificationRequestDTO) {
//        PqResponse pqResponse=pqQuestionResponseService.fetchResponseFromResponseId(responseId);
//
//        PqClarification pqClarification=pqClarificationRepository.findByPqResponse(pqResponse);
//        pqClarification.setClarificationResponse(submitClarificationRequestDTO.getAdditionalQuery());
//        pqClarification.setDocMaster(documentMaster);
//        return pqClarificationRepository.save(pqClarification);
//    }
//
//    @Override
//    public PqClarification getClarification(String acceptLanguage, UUID criteriaId, UUID responseId) {
//
//        PqResponse pqResponse=pqQuestionResponseService.fetchResponseFromResponseId(responseId);
//        PqClarification tempPqClarification = pqClarificationRepository.findByPqResponse(pqResponse);
//        return tempPqClarification;
//    }
//
//}
