
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * Criteria Management ServiceImpl: Implements the Criteria Management service layer.
 */
package in.gov.gem.app.fa.pq.transformer;

import in.gov.gem.app.fa.pq.domain.entity.*;
import in.gov.gem.app.fa.pq.request.SubmissionStatusReqDTO;
import in.gov.gem.app.fa.pq.response.PqQuestionResponseDTO;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.UUID;

import static in.gov.gem.app.fa.pq.constant.LookupConstants.SAVE_RESPONSE;

@Component
@AllArgsConstructor
public class QuestionResponseTransformer {

    public PqResponse toPqResponseEntityForSelection(UUID submissionId, PqQuestion pqQuestion, PqOption pqOption) {

        return PqResponse.builder()
                .pqResponseId(submissionId)
                .pqQuestionFk(pqQuestion)
                .responseText("SEED_DATA")
                .statusLookup(SAVE_RESPONSE)
                .build();
    }

    public PqResponse toPqResponseEntityForSelectedOptions(UUID submissionId,PqQuestion pqQuestion,String responseStatus, PqParticipant pqParticipant) {

        return PqResponse.builder()
                .pqResponseId(submissionId)
                .pqQuestionFk(pqQuestion)
                .responseText("SEED_DATA")
                .pqParticipantFk(pqParticipant)
                .statusLookup(responseStatus)
                .build();
    }

    public PqResponse toPqResponseEntityForInput(UUID submissionId, PqQuestion pqQuestion, String data, String responseStatus, PqParticipant pqParticipant) {

        return PqResponse.builder()
                .pqResponseId(submissionId)
                .pqQuestionFk(pqQuestion)
                .responseText(data)
                .statusLookup(responseStatus)
                .pqParticipantFk(pqParticipant)
                .build();
    }

    public PqQuestionResponseDTO toPqQuestionResponseDTO(PqResponse pqResponse){
        return PqQuestionResponseDTO.builder().submissionId(pqResponse.getPqResponseId()).build();
    }

    public SubmissionStatusReqDTO toSubmissionStatusReqDTO(PqSubmission pqSubmission) {
        return SubmissionStatusReqDTO.builder().status(pqSubmission.getStatusLookup()).build();
    }
}
