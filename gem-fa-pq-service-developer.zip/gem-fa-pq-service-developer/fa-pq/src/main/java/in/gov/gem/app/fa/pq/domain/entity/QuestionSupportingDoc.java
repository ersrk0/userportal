package in.gov.gem.app.fa.pq.domain.entity;

import in.gov.gem.app.service.core.entity.BaseEntity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

import java.time.Instant;
import java.util.UUID;


@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
@Table(name = "question_supporting_doc")
public class QuestionSupportingDoc extends BaseEntity {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @OneToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "pq_question_fk", referencedColumnName = "id", nullable = false)
  private PqQuestion pqQuestion;

  @Column(name = "document_name", nullable = false)
  private String documentName;

  @Column(name = "document_path", nullable = false)
  private String documentPath;

  @Column(name = "file_type", nullable = false)
  private String fileType;

  @Column(name = "uploaded_by")
  private String uploadedBy;

  @Column(name = "uploaded_on")
  private Instant uploadedOn;

  @Column(name = "document_id")
  private UUID documentId;

  @Column(name = "status_lookup")
  private String statusLookup;

}
