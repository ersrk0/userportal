
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * Pq Question Repository: Contains DB function to fetch Pq Question data.
 */

package in.gov.gem.app.fa.pq.domain.repository;

import in.gov.gem.app.fa.pq.domain.entity.PqCriteria;
import in.gov.gem.app.fa.pq.domain.entity.PqQuestion;
import in.gov.gem.app.service.core.repository.BaseRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface PqQuestionRepository extends BaseRepository<PqQuestion, Long>, JpaSpecificationExecutor<PqQuestion> {
  List<PqQuestion> findAllByPqCriteriaAndStatusLookup(PqCriteria pqCriteria, String lookupStatus);

  Page<PqQuestion> findAllByPqCriteria(Specification<PqQuestion> specification, Pageable pageable);

  PqQuestion findByPqCriteriaAndPqQuestionIdAndStatusLookup(PqCriteria pqCriteria, UUID questionId, String lookupStatus);

  Optional<PqQuestion> findByPqQuestionId(UUID questionId);
}