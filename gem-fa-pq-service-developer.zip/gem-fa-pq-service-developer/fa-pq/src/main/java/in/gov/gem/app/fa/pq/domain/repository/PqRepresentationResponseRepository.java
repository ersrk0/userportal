package in.gov.gem.app.fa.pq.domain.repository;

import in.gov.gem.app.fa.pq.domain.entity.PqRepresentation;
import in.gov.gem.app.fa.pq.domain.entity.PqRepresentationResponse;
import in.gov.gem.app.service.core.repository.BaseRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PqRepresentationResponseRepository extends BaseRepository<PqRepresentationResponse, Long> {
  PqRepresentationResponse findByPqRepresentation(PqRepresentation pqRepresentation);
}
