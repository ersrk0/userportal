package in.gov.gem.app.fa.pq.service;

import in.gov.gem.app.fa.pq.domain.entity.PqOption;
import in.gov.gem.app.fa.pq.domain.entity.PqQuestion;
import in.gov.gem.app.fa.pq.request.QuestionCreateRequestDTO;
import in.gov.gem.app.fa.pq.request.QuestionUpdateRequestDTO;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface PqOptionService {

  List<PqOption> createOptions(QuestionCreateRequestDTO request, PqQuestion pqQuestion);
  List<PqOption> fetchOptionByQuestion(PqQuestion pqQuestion);

  void updateOptions(QuestionUpdateRequestDTO request, List<PqOption> pqOption);

  void deleteOptions(List<PqOption> pqOption);

  PqOption fetchOptionById(Long optionId);
}
