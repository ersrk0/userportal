/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * PqSubmissionService: Implements the service layer.
 */
package in.gov.gem.app.fa.pq.service;

import in.gov.gem.app.fa.pq.domain.entity.PqCriteria;
import in.gov.gem.app.fa.pq.domain.entity.PqParticipant;
import in.gov.gem.app.fa.pq.domain.entity.PqSubmission;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface PqSubmissionService {

  PqSubmission fetchSubmissionByCriteriaAndParticipantFk(PqCriteria pqCriteria, PqParticipant pqParticipant);
  PqSubmission fetchSubmissionById(UUID submissionId);
  PqSubmission saveSubmission(PqSubmission pqSubmission);
  Page<PqSubmission> fetchSubmissionByParticipantId(PqParticipant pqParticipant, Pageable pageable);
  Optional<List<PqSubmission>> fetchSubmissionList(PqCriteria pqCriteria);
}
