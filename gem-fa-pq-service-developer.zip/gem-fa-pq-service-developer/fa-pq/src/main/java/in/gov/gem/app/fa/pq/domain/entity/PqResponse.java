
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * Pq Response Entity: Specifies the attributes in the 'pq_response' table.
 */
package in.gov.gem.app.fa.pq.domain.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import in.gov.gem.app.service.core.entity.BaseEntity;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

import java.util.List;
import java.util.UUID;

@Entity
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
@Table(name = "pq_response")
@JsonIgnoreProperties
public class PqResponse extends BaseEntity {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @Column(name = "pq_response_id", nullable = false)
  private UUID pqResponseId;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "pq_question_fk", referencedColumnName = "id", nullable = false)
  private PqQuestion pqQuestionFk;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "pq_participant_fk", referencedColumnName = "id", nullable = false)
  private PqParticipant pqParticipantFk;

  @Column(name = "response_text", length = 255)
  private String responseText;

  @Column(name = "status_lookup", length = 10)
  private String statusLookup;

  @OneToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "doc_master_fk", referencedColumnName = "id")
  private DocMaster docMasterFk;

  @Column(name = "evaluator_score")
  private Integer evaluatorScore;

  @OneToMany(mappedBy = "pqResponse", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
  private List<PqResponseOptionMap> selectedOptions;
}
