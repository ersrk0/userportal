package in.gov.gem.app.fa.pq.domain.repository;

import in.gov.gem.app.fa.pq.domain.entity.DocMaster;
import in.gov.gem.app.service.core.repository.BaseRepository;
import org.springframework.stereotype.Repository;

import java.util.UUID;

@Repository
public interface DocMasterRepository extends BaseRepository<DocMaster, Long> {

  DocMaster findByDocumentId(UUID attachmentId);


}
