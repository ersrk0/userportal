package in.gov.gem.app.fa.pq.domain.repository;

import in.gov.gem.app.fa.pq.domain.entity.MessageLog;
import in.gov.gem.app.service.core.repository.BaseRepository;
import org.springframework.stereotype.Repository;
 @Repository
  public interface MessageLogRepository extends BaseRepository<MessageLog, Long> {
    MessageLog findByMessageCode(String messageCode);
  }

