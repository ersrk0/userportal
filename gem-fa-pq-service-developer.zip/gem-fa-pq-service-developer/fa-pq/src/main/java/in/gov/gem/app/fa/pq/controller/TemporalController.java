/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM
 * Temporal Controller: Temporary Endpoint.
 */

package in.gov.gem.app.fa.pq.controller;

import in.gov.gem.app.fa.pq.constant.Constants;
import in.gov.gem.app.fa.pq.constant.MessageConstants;
import in.gov.gem.app.fa.pq.request.AttachmentTemplate;
import in.gov.gem.app.fa.pq.response.MessageResponseDTO;
import in.gov.gem.app.fa.pq.response.TemporalCriteriaResponseDTO;
import in.gov.gem.app.fa.pq.service.TemporalService;
import in.gov.gem.app.service.core.utility.MessageUtility;
import in.gov.gem.app.service.dto.APIResponse;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.UUID;

@RestController
@RequestMapping("/v1/temporal")
@Validated
@AllArgsConstructor
public class TemporalController {

  private TemporalService temporalService;
  private MessageUtility messageUtility;

  @GetMapping(path = "/criteria/public/{offeringId}")
  public ResponseEntity<APIResponse<TemporalCriteriaResponseDTO>> getCriteria(@PathVariable UUID offeringId,
                                                          @Valid @RequestHeader
                                                              (name = "Accept-Language")
                                                          String languageCode){
    TemporalCriteriaResponseDTO response = temporalService.getTemporalCriteria(offeringId);

    return ResponseEntity.ok().body(APIResponse.<TemporalCriteriaResponseDTO>builder()
            .msId(Constants.MSID)
            .status(HttpStatus.OK.getReasonPhrase())
            .httpStatus(HttpStatus.OK.value())
            .message(messageUtility.getMessage(MessageConstants.SUCCESS_MESSAGE))
            .data(response)
            .build());
  }

  @GetMapping(path = "/criteria/public/view/attachment/{attachmentId}")
  public ResponseEntity<Object> viewAttachment(@PathVariable UUID attachmentId){
    AttachmentTemplate response = temporalService.viewAttachment(attachmentId);
    return ResponseEntity.ok()
            .header("Content-Type", response.getAttachmentType())
            .body(response.getByteArray());
  }

  @PostMapping(path = "/public/criteria/{criteriaId}/participants")
  public ResponseEntity<APIResponse<MessageResponseDTO>> saveParticipants(@PathVariable UUID criteriaId,
                                                                                @Valid @RequestHeader
                                                                                   (name = "Accept-Language")
                                                                               String languageCode){
    MessageResponseDTO response = temporalService.saveParticipants(criteriaId, languageCode);

    return ResponseEntity.ok().body(APIResponse.<MessageResponseDTO>builder()
        .msId(Constants.MSID)
        .status(HttpStatus.OK.getReasonPhrase())
        .httpStatus(HttpStatus.OK.value())
        .message(messageUtility.getMessage(MessageConstants.SUCCESS_MESSAGE))
        .data(response)
        .build());
  }

}
