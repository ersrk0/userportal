package in.gov.gem.app.fa.pq.service;

import in.gov.gem.app.fa.pq.domain.entity.DocMaster;
import in.gov.gem.app.fa.pq.domain.entity.PqClarification;
import in.gov.gem.app.fa.pq.request.ClarificationRequestDTO;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
public interface ClassificationManagementService {


    PqClarification submitClarification(String acceptLanguage, UUID criteriaId, UUID responseId,DocMaster documentMaster,
                                        ClarificationRequestDTO submitClarificationRequestDTO);

    PqClarification getClarification(String acceptLanguage, UUID criteriaId, UUID responseId);
}
