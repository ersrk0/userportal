
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * PqClarificationMsgService: Implements the clarification msg service layer.
 */

package in.gov.gem.app.fa.pq.service;

import in.gov.gem.app.fa.pq.domain.entity.DocMaster;
import in.gov.gem.app.fa.pq.domain.entity.PqClarificationMsg;
import in.gov.gem.app.fa.pq.domain.entity.PqClarificationThread;
import org.springframework.stereotype.Service;

@Service
public interface PqClarificationMsgService {
  PqClarificationMsg saveMsg(PqClarificationThread pqClarificationThread, String msgText, DocMaster docMaster);

  PqClarificationMsg saveSubmissionMsg(PqClarificationThread pqClarificationThread, String additionalInfo,
                                       DocMaster documentMaster);
  PqClarificationMsg[] fetchClarificationMsgByThread(PqClarificationThread pqClarificationThread);
}
