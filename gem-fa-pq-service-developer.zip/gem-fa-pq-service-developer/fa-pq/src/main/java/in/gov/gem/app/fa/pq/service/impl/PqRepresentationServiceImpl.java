package in.gov.gem.app.fa.pq.service.impl;

import in.gov.gem.app.exception.generic.InvalidInputException;
import in.gov.gem.app.fa.pq.constant.ErrorMessageConstants;
import in.gov.gem.app.fa.pq.constant.LookupConstants;
import in.gov.gem.app.fa.pq.constant.MessageConstants;
import in.gov.gem.app.fa.pq.domain.entity.*;
import in.gov.gem.app.fa.pq.domain.repository.PqRepresentationRepository;
import in.gov.gem.app.fa.pq.domain.repository.PqRepresentationResponseRepository;
import in.gov.gem.app.fa.pq.request.RepresentationRequestDTO;
import in.gov.gem.app.fa.pq.request.RespondRepresentationRequestDTO;
import in.gov.gem.app.fa.pq.service.PqRepresentationService;
import in.gov.gem.app.service.core.utility.MessageUtility;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
@AllArgsConstructor
public class PqRepresentationServiceImpl implements PqRepresentationService {

  private PqRepresentationRepository pqRepresentationRepository;
  private PqRepresentationResponseRepository pqRepresentationResponseRepository;
  private MessageUtility messageUtility;

  @Override
  public void raiseRepresentation(RepresentationRequestDTO request,
                                  PqCriteria pqCriteria, DocMaster documentMaster, PqParticipant pqParticipant,
                                  UUID representationId) {
    PqRepresentation pqRepresentation = PqRepresentation.builder()
        .representationId(representationId)
        .pqCriteria(pqCriteria)
        .pqParticipant(pqParticipant)
        .docMaster(documentMaster)
        .statusLookup(LookupConstants.Status.PENDING.getLookupCode())
        .createdBy(MessageConstants.CREATED_BY)
        .build();

    if (request.getRepresentationText()!=null)
    {
      pqRepresentation.setRepresentationText(request.getRepresentationText());
    }
      pqRepresentationRepository.save(pqRepresentation);
  }


  @Override
  public void fetchRepresentation(PqCriteria pqCriteria) {
    PqRepresentation pqRepresentation = pqRepresentationRepository
        .findByPqCriteriaAndStatusLookup(pqCriteria, LookupConstants.Status.PENDING.getLookupCode());
    if (pqRepresentation != null) {
      throw new InvalidInputException(ErrorMessageConstants.REPRESENTATION_ALREADY_EXISTS,
          messageUtility.getMessage(ErrorMessageConstants.REPRESENTATION_ALREADY_EXISTS));
    }
  }


  @Override
  public PqRepresentation fetchRepresentationByRepresentationId(UUID representationId) {
    PqRepresentation pqRepresentation = pqRepresentationRepository.findByRepresentationIdAndStatusLookup(representationId, LookupConstants.Status.PENDING.getLookupCode());
    if (pqRepresentation==null){
      throw new InvalidInputException(ErrorMessageConstants.REPRESENTATION_NOT_FOUND,
          messageUtility.getMessage(ErrorMessageConstants.REPRESENTATION_NOT_FOUND));
    }
    return pqRepresentation;
  }

  @Override
  public void respondRepresentation(PqRepresentation pqRepresentation, RespondRepresentationRequestDTO request,DocMaster docMaster) {
    PqRepresentationResponse pqRepresentationResponse = new PqRepresentationResponse();
    pqRepresentationResponse.setPqRepresentation(pqRepresentation);
    pqRepresentationResponse.setResponseText(request.getResponseText());
    pqRepresentationResponse.setRespondedBy(MessageConstants.CREATED_BY);
    pqRepresentationResponse.setDocMaster(docMaster);
    pqRepresentationResponseRepository.save(pqRepresentationResponse);
  }

  @Override
  public List<PqRepresentation> fetchRepresentationByPqCriteria(PqCriteria pqCriteria){
    return pqRepresentationRepository.findByPqCriteriaAndStatusLookupNot(pqCriteria, LookupConstants.Status.INACTIVE.getLookupCode());
  }

  @Override
  public PqRepresentationResponse fetchResponse(PqRepresentation pqRepresentation){
    return pqRepresentationResponseRepository.findByPqRepresentation(pqRepresentation);
  }
}

