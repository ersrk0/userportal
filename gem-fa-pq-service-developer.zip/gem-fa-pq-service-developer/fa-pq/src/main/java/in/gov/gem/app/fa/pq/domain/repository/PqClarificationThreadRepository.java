
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * Pq Clarification Repository: Contains DB function to fetch Pq clarification thread data.
 */

package in.gov.gem.app.fa.pq.domain.repository;

import in.gov.gem.app.fa.pq.domain.entity.PqClarificationThread;
import in.gov.gem.app.fa.pq.domain.entity.PqResponse;
import in.gov.gem.app.service.core.repository.BaseRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PqClarificationThreadRepository extends BaseRepository<PqClarificationThread, Long> {

  PqClarificationThread findByPqResponse(PqResponse pqResponse);
}

