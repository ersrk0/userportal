package in.gov.gem.app.fa.pq.service.impl;

import in.gov.gem.app.exception.generic.ServiceException;
import in.gov.gem.app.exception.utility.ErrorConstant;
import in.gov.gem.app.fa.pq.constant.LookupConstants;
import in.gov.gem.app.fa.pq.constant.MessageConstants;
import in.gov.gem.app.fa.pq.domain.entity.DocMaster;
import in.gov.gem.app.fa.pq.domain.entity.DocAttachment;
import in.gov.gem.app.fa.pq.domain.entity.PqClarification;
import in.gov.gem.app.fa.pq.domain.repository.DocAttachmentRepository;
import in.gov.gem.app.fa.pq.request.AttachmentTemplate;
import in.gov.gem.app.fa.pq.service.DocAttachmentService;
import in.gov.gem.app.service.attachment.utility.S3AttachmentUtility;
import in.gov.gem.app.service.core.utility.MessageUtility;
import in.gov.gem.app.service.pack.service.interfaces.CoreLookupService;
import lombok.AllArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
@AllArgsConstructor
public class DocAttachmentServiceImpl implements DocAttachmentService {

    private static final Logger logger = LoggerFactory.getLogger(DocAttachmentServiceImpl.class);

    private DocAttachmentRepository docAttachmentRepository;
    private S3AttachmentUtility s3AttachmentUtility;
    private final MessageUtility messageUtility;
    private CoreLookupService coreLookupService;

    @Override
    public void saveDocumentDetails(DocMaster docMaster, String filePath, String docType,
                                    String fileName, Long fileSize, UUID attachmentId) {
        logger.info("Entering saveDocumentDetails with fileName: {}", fileName);

        DocAttachment docAttachment = DocAttachment.builder()
                .attachmentId(attachmentId)
                .docMaster(docMaster)
                .attachmentName(fileName)
                .uploadedBy(MessageConstants.UPLOADED_BY)
                .attachmentPath(filePath)
                .attachmentTypeLookup(docType)
                .attachmentSize(fileSize)
                .statusLookup(LookupConstants.Status.ACTIVE.getLookupCode())
                .build();
        logger.debug("Constructed DocAttachment: {}", docAttachment);

        docAttachmentRepository.save(docAttachment);
        logger.info("Saved DocAttachment with attachmentId: {}", attachmentId);

        logger.info("Exiting saveDocumentDetails");
    }

    @Override
    public void deleteDocumentMetadata(List<DocAttachment> docAttachments) {
        logger.info("Entering deleteDocumentMetadata");

        for (DocAttachment docAttachment : docAttachments) {
            logger.debug("Marking DocAttachment as inactive: {}", docAttachment);
            docAttachment.setStatusLookup(LookupConstants.Status.INACTIVE.getLookupCode());
            docAttachmentRepository.save(docAttachment);
        }

        logger.info("Exiting deleteDocumentMetadata");
    }

    @Override
    public void deleteDocumentByAttachmentId(UUID attachmentId, DocMaster docMaster) {
        logger.info("Entering deleteDocumentByAttachmentId with attachmentId: {}", attachmentId);

        DocAttachment docAttachment = docAttachmentRepository.findByAttachmentIdAndDocMaster(attachmentId, docMaster);
        logger.debug("Fetched DocAttachment: {}", docAttachment);

        docAttachment.setStatusLookup(LookupConstants.Status.INACTIVE.getLookupCode());
        docAttachmentRepository.save(docAttachment);
        logger.info("Marked DocAttachment as inactive for attachmentId: {}", attachmentId);

        logger.info("Exiting deleteDocumentByAttachmentId");
    }

    @Override
    public List<DocAttachment> fetchAllAttachmentsByQuestion(DocMaster docMaster) {
        logger.info("Entering fetchAllAttachmentsByQuestion");

        List<DocAttachment> attachments = docAttachmentRepository.findAllByDocMaster(docMaster);
        logger.debug("Fetched attachments: {}", attachments);

        logger.info("Exiting fetchAllAttachmentsByQuestion");
        return attachments;
    }

    @Override
    public DocAttachment fetchDocumentMaster(PqClarification pqClarification) {
        logger.info("Entering fetchDocumentMaster");

        DocAttachment docAttachment = docAttachmentRepository.findByDocMaster(pqClarification.getDocMaster());
        logger.debug("Fetched DocAttachment: {}", docAttachment);

        logger.info("Exiting fetchDocumentMaster");
        return docAttachment;
    }

    @Override
    public AttachmentTemplate viewAttachment(UUID attachmentId) {
        logger.info("Entering viewAttachment with attachmentId: {}", attachmentId);

        DocAttachment docAttachment = docAttachmentRepository.findByAttachmentIdAndStatusLookup(attachmentId,
                LookupConstants.Status.ACTIVE.getLookupCode());
        logger.debug("Fetched DocAttachment: {}", docAttachment);

        String contentType = coreLookupService.findByLookupCode(docAttachment.getAttachmentTypeLookup()).getLookupValue();
        byte[] file = s3AttachmentUtility.downloadAsBytes("gem-consent-service", docAttachment.getAttachmentPath());
        logger.debug("Downloaded file from S3 for attachmentId: {}", attachmentId);

        AttachmentTemplate attachmentTemplate = AttachmentTemplate.builder()
                .attachmentType(contentType)
                .byteArray(file)
                .fileName(docAttachment.getAttachmentName())
                .build();
        logger.debug("Constructed AttachmentTemplate: {}", attachmentTemplate);

        logger.info("Exiting viewAttachment");
        return attachmentTemplate;
    }

    @Override
    public DocAttachment fetchDocAttachmentByDocMaster(UUID attachmentId, DocMaster docMaster) {
        logger.info("Entering fetchDocAttachmentByDocMaster with attachmentId: {}", attachmentId);

        DocAttachment docAttachment = docAttachmentRepository.findByAttachmentIdAndDocMaster(attachmentId, docMaster);
        if (docAttachment == null) {
            logger.error("DocAttachment not found for attachmentId: {}", attachmentId);
            throw new ServiceException(MessageConstants.INVALID_INPUT,
                    messageUtility.getMessage(MessageConstants.INVALID_INPUT),
                    ErrorConstant.CATEGORY.BV,
                    ErrorConstant.SEVERITY.C);
        }
        logger.debug("Fetched DocAttachment: {}", docAttachment);

        logger.info("Exiting fetchDocAttachmentByDocMaster");
        return docAttachment;
    }

    @Override
    public List<DocAttachment> fetchAllActiveAttachmentsByQuestion(DocMaster docMaster) {
        logger.info("Entering fetchAllActiveAttachmentsByQuestion");

        List<DocAttachment> attachments = docAttachmentRepository.findAllByDocMasterAndStatusLookup(docMaster,
            LookupConstants.Status.ACTIVE.getLookupCode());
        logger.debug("Fetched attachments: {}", attachments);

        logger.info("Exiting fetchAllActiveAttachmentsByQuestion");
        return attachments;
    }
}