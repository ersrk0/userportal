package in.gov.gem.app.fa.pq.validation.response.specification;

import in.gov.gem.app.fa.pq.domain.entity.PqCriteria;
import in.gov.gem.app.fa.pq.domain.entity.PqQuestion;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Root;
import org.springframework.data.jpa.domain.Specification;

import java.util.List;

public class PqQuestionSpecification {
  public static Specification<PqQuestion> isDocumentRequired(boolean isRequired) {
    return (Root<PqQuestion> root, CriteriaQuery<?> query, CriteriaBuilder builder) ->
        builder.equal(root.get("requiresDocument"), isRequired);
  }

  public static Specification<PqQuestion> isMandatory(boolean isMandatory) {
    return (Root<PqQuestion> root, CriteriaQuery<?> query, CriteriaBuilder builder) ->
        builder.equal(root.get("isMandatory"), isMandatory);
  }

  public static Specification<PqQuestion> inStatus(List<String> statusList) {
    return (Root<PqQuestion> root, CriteriaQuery<?> query, CriteriaBuilder builder) ->
        root.get("statusLookup").in(statusList);
  }

  public static Specification<PqQuestion> criteria(PqCriteria pqCriteria) {
    return (Root<PqQuestion> root, CriteriaQuery<?> query, CriteriaBuilder builder) ->
        builder.equal(root.get("pqCriteria"), pqCriteria);
  }
}
