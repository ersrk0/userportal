
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * Pq Assessment Entity: Specifies the attributes in the 'pq_assessment' table.
 */

package in.gov.gem.app.fa.pq.domain.entity;

import in.gov.gem.app.service.core.entity.BaseEntity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import lombok.*;
import lombok.experimental.SuperBuilder;

@Entity
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
@Table(name = "pq_clarification")
public class PqClarification extends BaseEntity {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @OneToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "pq_response_fk",referencedColumnName = "id")
  private PqResponse pqResponse;

  @OneToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "pq_criteria_fk",referencedColumnName = "id")
  private PqCriteria pqCriteria;

  @Column(name = "clarification_text", length = 1024)
  private String clarificationText;

  @Column(name = "clarification_response", length = 1024)
  private String clarificationResponse;

  @OneToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "doc_master_fk",referencedColumnName = "id")
  private DocMaster docMaster;

  @Column(name = "status_lookup", length = 10)
  private String statusLookup;


}
