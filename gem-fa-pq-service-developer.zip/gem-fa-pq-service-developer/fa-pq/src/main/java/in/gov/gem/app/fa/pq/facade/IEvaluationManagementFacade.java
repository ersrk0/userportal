
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * Pq Clarification Msg Repository: Contains DB function to fetch Pq clarification msg data.
 */
package in.gov.gem.app.fa.pq.facade;

import in.gov.gem.app.fa.pq.request.ScoreRequestDto;
import in.gov.gem.app.fa.pq.response.CategoriesSubmissionResponseDTO;
import in.gov.gem.app.fa.pq.response.SubmissionListResponseDTO;
import in.gov.gem.app.service.dto.PaginationParams;

import java.util.UUID;

public interface IEvaluationManagementFacade {
    String saveScore(UUID questionId, String participationId, ScoreRequestDto scoreRequestDto, String acceptLanguage);

    SubmissionListResponseDTO fetchCategoriesSubmission(UUID criteriaId, String participationId, String acceptLanguage, PaginationParams paginationParams);
}
