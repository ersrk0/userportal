
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * Pq Criteria Entity: Specifies the attributes in the 'pq_criteria' table.
 */

package in.gov.gem.app.fa.pq.domain.entity;

import in.gov.gem.app.service.core.entity.BaseEntity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

import java.util.UUID;

@Entity
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
@Table(name = "pq_criteria")
public class PqCriteria extends BaseEntity {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @Column(name = "pq_criteria_id", nullable = false)
  private UUID pqCategoryId;

  @Column(name = "category_code", nullable = false)
  private UUID categoryCode;

  @ManyToOne(fetch = FetchType.EAGER)
  @JoinColumn(name = "pq_criteria_master_fk", referencedColumnName = "id", nullable = false)
  private PqCriteriaMaster pqCriteriaMaster;

  @Column(name = "criteria_name", length = 255)
  private String criteriaName;

  @Column(name = "criteria_set_by", length = 50)
  private String criteriaSetBy;

  @Column(name = "pq_evaluator", length = 50)
  private String evaluator;

  @Column(name = "status_lookup", length = 10)
  private String statusLookup;

}
