package in.gov.gem.app.fa.pq.transformer;

import in.gov.gem.app.fa.pq.constant.MessageConstants;
import in.gov.gem.app.fa.pq.domain.entity.DocAttachment;
import in.gov.gem.app.fa.pq.domain.entity.DocMaster;
import in.gov.gem.app.fa.pq.domain.entity.PqCriteria;
import in.gov.gem.app.fa.pq.domain.entity.PqRepresentation;
import in.gov.gem.app.fa.pq.domain.entity.PqRepresentationResponse;
import in.gov.gem.app.fa.pq.request.RepresentationRequestDTO;
import in.gov.gem.app.fa.pq.response.CriteriaRepresentationResponseDTO;
import in.gov.gem.app.fa.pq.response.DocAttachmentResponseDTO;
import in.gov.gem.app.fa.pq.response.RaiseRepresentationResponseDTO;
import in.gov.gem.app.fa.pq.response.RespondRepresentationResponseDTO;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Component
@AllArgsConstructor
public class PqRepresentationTransformer {

  public RaiseRepresentationResponseDTO toRaiseRepresentationResponseDTO(List<DocAttachment> docAttachments,
                                                                         DocMaster docMaster,
                                                                         RepresentationRequestDTO request, UUID representationId) {
    RaiseRepresentationResponseDTO raiseRepresentationResponseDTO = new RaiseRepresentationResponseDTO();
    if (docMaster != null) {
      List<DocAttachmentResponseDTO> attachmentResponseDTOS = docAttachments.stream()
          .map(docAttachment -> DocAttachmentResponseDTO.builder()
              .attachmentId(docAttachment.getAttachmentId())
              .docType(docAttachment.getAttachmentTypeLookup())
              .fileName(docAttachment.getAttachmentName())
              .fileSize(docAttachment.getAttachmentSize())
              .filePath(docAttachment.getAttachmentPath())
              .build())
          .collect(Collectors.toList());
      raiseRepresentationResponseDTO.setDocumentId(docMaster.getDocumentId());
      raiseRepresentationResponseDTO.setAttachmentsUploaded(attachmentResponseDTOS);
    }
    raiseRepresentationResponseDTO.setRepresentationText(request.getRepresentationText());
    raiseRepresentationResponseDTO.setParticipantId(request.getParticipantId());
    raiseRepresentationResponseDTO.setRepresentationId(representationId);
    return raiseRepresentationResponseDTO;
  }


  public CriteriaRepresentationResponseDTO toCriteriaRepresentationResponseDTO(
      PqCriteria pqCriteria,
      PqRepresentation representation, PqRepresentationResponse pqRepresentationResponse, List<DocAttachmentResponseDTO> raiseDocument, List<DocAttachmentResponseDTO> responseDocument){
//
//    CriteriaRepresentationResponseDTO criteriaRepresentationResponseDTO = CriteriaRepresentationResponseDTO.builder()
//        .raisedBy(representation.getPqParticipant().getParticipantId())
//        .raisedAt(representation.getCreatedTimestamp())
//        .raiseRepresentationDocuments(raiseDocument)
//        .status(representation.getStatusLookup())
//        .representationText(representation.getRepresentationText())
//        .categoryCode(pqCriteria.getCategoryCode())
//        .build();
//
//    if (representation.getDocMaster()!=null){
//      CriteriaRepresentationResponseDTO.builder()
//          .documentId(representation.getDocMaster().getDocumentId())
//          .build();
//
//    }
//    if (pqRepresentationResponse!=null){
//      CriteriaRepresentationResponseDTO.builder()
//          .response(pqRepresentationResponse.getResponseText())
//          .responseRepresentationDocuments(responseDocument)
//          .responseBy(pqRepresentationResponse.getRespondedBy())
//          .reponseAt(pqRepresentationResponse.getCreatedTimestamp())
//          .build();
//    }

    CriteriaRepresentationResponseDTO criteriaRepresentationResponseDTO = new CriteriaRepresentationResponseDTO();
    criteriaRepresentationResponseDTO.setRaisedBy(representation.getPqParticipant().getParticipantId());
    criteriaRepresentationResponseDTO.setRaisedAt(representation.getCreatedTimestamp());
    criteriaRepresentationResponseDTO.setRaiseRepresentationDocuments(raiseDocument);
    criteriaRepresentationResponseDTO.setStatus(representation.getStatusLookup());
    criteriaRepresentationResponseDTO.setRepresentationText(representation.getRepresentationText());
    criteriaRepresentationResponseDTO.setCategoryCode(pqCriteria.getCategoryCode());

    if (representation.getDocMaster()!=null){
      criteriaRepresentationResponseDTO.setDocumentId(representation.getDocMaster().getDocumentId());

    }
    if (pqRepresentationResponse!=null){

      criteriaRepresentationResponseDTO.setResponse(pqRepresentationResponse.getResponseText());
      criteriaRepresentationResponseDTO.setResponseRepresentationDocuments(responseDocument);
      criteriaRepresentationResponseDTO.setResponseBy(pqRepresentationResponse.getRespondedBy());
      criteriaRepresentationResponseDTO.setReponseAt(pqRepresentationResponse.getCreatedTimestamp());

    }


    return criteriaRepresentationResponseDTO;
  }

  public RespondRepresentationResponseDTO toRespondRepresentationResponseDTO(UUID representationId) {
    return RespondRepresentationResponseDTO.builder()
        .representationId(representationId)
        .message(MessageConstants.REPRESENTATION_RESPONSE)
        .build();
  }
}