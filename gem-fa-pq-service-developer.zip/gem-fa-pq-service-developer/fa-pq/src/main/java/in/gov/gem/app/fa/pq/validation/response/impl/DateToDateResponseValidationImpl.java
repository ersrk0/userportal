
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * Criteria Management ServiceImpl: Implements the Criteria Management service layer.
 */
package in.gov.gem.app.fa.pq.validation.response.impl;

import in.gov.gem.app.fa.pq.domain.entity.PqParticipant;
import in.gov.gem.app.fa.pq.domain.entity.PqQuestion;
import in.gov.gem.app.fa.pq.domain.entity.PqResponse;
import in.gov.gem.app.fa.pq.service.PqQuestionResponseService;
import in.gov.gem.app.fa.pq.transformer.QuestionResponseTransformer;
import org.springframework.stereotype.Component;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.UUID;
import static in.gov.gem.app.fa.pq.constant.Constants.UTC_FORMAT;
import static in.gov.gem.app.fa.pq.constant.LookupConstants.INPUT_TYPE_DATE_TO_DATE;
@Component
public class DateToDateResponseValidationImpl extends ResponseValidationAbstract{

    private static final String questionnaireType = INPUT_TYPE_DATE_TO_DATE ;
    private final QuestionResponseTransformer questionResponseTransformer;
    private final PqQuestionResponseService pqQuestionResponseService;

    DateToDateResponseValidationImpl(QuestionResponseTransformer questionResponseTransformer,
                               PqQuestionResponseService pqQuestionResponseService
    ) {
        super(questionnaireType);
        this.questionResponseTransformer = questionResponseTransformer;
        this.pqQuestionResponseService = pqQuestionResponseService;
    }

    @Override
    public boolean validate(PqQuestion pqQuestion, List<String> response) {
        return super.checkOptionAreNotNull(response) && isValidDate(response.getFirst(),UTC_FORMAT)
                && isValidDate(response.getLast(),UTC_FORMAT);
    }

    public boolean isValidDate(String date,String format){
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(format).withZone(ZoneOffset.UTC);
        try{
            LocalDate.parse(date,formatter);
            return true;
        }catch (DateTimeParseException e){
            return false;
        }
    }

    public PqResponse buildPqResponse(UUID submissionId, PqQuestion pqQuestionEntity,List<String> responses, String responseStatus, PqParticipant pqParticipant) {
        String dateToDate = String.join(",",responses);
        PqResponse pqResponse = questionResponseTransformer.toPqResponseEntityForInput(submissionId,pqQuestionEntity,dateToDate, responseStatus, pqParticipant);
        return pqQuestionResponseService.saveResponseEntity(pqResponse);
    }

    @Override
    public PqResponse updatePqResponse(UUID submissionId, PqQuestion pqQuestionEntity, List<String> responseList) {
        String dateToDate = String.join(",",responseList);
        PqResponse pqResponse = pqQuestionResponseService.fetchResponseFromSubmissionId(submissionId);
        pqResponse.setResponseText(dateToDate);
        return pqQuestionResponseService.saveResponseEntity(pqResponse);
    }
}
