
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * Criteria Management ServiceImpl: Implements the Criteria Management service layer.
 */
package in.gov.gem.app.fa.pq.service.impl;

import in.gov.gem.app.fa.pq.domain.entity.PqResponse;
import in.gov.gem.app.fa.pq.domain.entity.PqResponseOptionMap;
import in.gov.gem.app.fa.pq.domain.repository.PqResponseOptionMapRepository;
import in.gov.gem.app.fa.pq.service.PqResponseOptionMappingService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@AllArgsConstructor
public class PqResponseOptionMappingServiceImpl implements PqResponseOptionMappingService {

    private PqResponseOptionMapRepository pqResponseOptionMapRepository;

    @Override
    public void savePqResponseOptionMapping(PqResponseOptionMap pqResponseOptionMap) {
        pqResponseOptionMapRepository.save(pqResponseOptionMap);
    }

    @Override
    public void deleteById(Long id) {
        pqResponseOptionMapRepository.deleteById(id);
    }

    @Override
    public List<PqResponseOptionMap> findAllByPqResponse(PqResponse pqResponse) {
        return pqResponseOptionMapRepository.findAllByPqResponse(pqResponse);
    }


}
