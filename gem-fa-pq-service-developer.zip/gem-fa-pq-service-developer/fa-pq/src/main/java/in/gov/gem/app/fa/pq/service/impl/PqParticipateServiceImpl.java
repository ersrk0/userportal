package in.gov.gem.app.fa.pq.service.impl;

import in.gov.gem.app.exception.generic.InvalidInputException;
import in.gov.gem.app.fa.pq.constant.ErrorMessageConstants;
import in.gov.gem.app.fa.pq.domain.entity.PqCriteria;
import in.gov.gem.app.fa.pq.domain.entity.PqParticipant;
import in.gov.gem.app.fa.pq.domain.repository.PqParticipationRepository;
import in.gov.gem.app.fa.pq.service.PqParticipateService;
import in.gov.gem.app.service.core.utility.MessageUtility;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@AllArgsConstructor
public class PqParticipateServiceImpl implements PqParticipateService {

  private final PqParticipationRepository pqParticipationRepository;
  private final MessageUtility messageUtility;

  @Override
  public PqParticipant fetchParticipantById(String participationId, PqCriteria pqCriteria){
    return pqParticipationRepository.findByParticipantIdAndPqCriteriaAndIsAllowed(participationId, pqCriteria, Boolean.TRUE)
        .orElseThrow(() -> new InvalidInputException(ErrorMessageConstants.INVALID_PARTICIPANT,
            messageUtility.getMessage(ErrorMessageConstants.INVALID_PARTICIPANT)));
  }

  @Override
  public List<PqParticipant> fetchParticipantByCrtieria(PqCriteria pqCriteria) {
    return pqParticipationRepository.findByPqCriteria(pqCriteria);
  }

  @Override
  public void saveParticipant(PqParticipant pqParticipant) {
    pqParticipationRepository.save(pqParticipant);
  }


}
