package in.gov.gem.app.fa.pq.transformer;

import in.gov.gem.app.fa.pq.constant.LookupConstants;
import in.gov.gem.app.fa.pq.domain.entity.*;
import in.gov.gem.app.fa.pq.response.*;
import in.gov.gem.app.fa.pq.service.DocAttachmentService;
import in.gov.gem.app.fa.pq.service.PqResponseOptionMappingService;
import in.gov.gem.app.fa.pq.service.impl.PqQuestionResponseServiceImpl;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.time.format.DateTimeFormatter;
@Component
@AllArgsConstructor
public class ClassificationManagementTransformer {

    private PqQuestionResponseServiceImpl pqQuestionResponseService;
    private PqResponseOptionMappingService pqResponseOptionMappingService;
    private DocAttachmentService docAttachmentService;


    public SubmitClarificationResponseDTO toSubmitClarificationResponseDTO(PqClarificationMsg pqClarification) {

        return SubmitClarificationResponseDTO.builder()
                .additionalInfoId(pqClarification.getId())
                .status("submitted")
                .responseBy(LookupConstants.SenderType.BIDDER.toString())
                .build();
    }

    public GetClarificationResponseDTO toGetClarificationResponseDTO(PqClarificationMsg[] pqClarificationMsgs,UUID responseId) {

        PqResponse pqResponse=pqQuestionResponseService.fetchResponseFromResponseId(responseId);
        String questionTypeLookup=pqResponse.getPqQuestionFk().getQuestionTypeLookup();
        String tempResponse="";

        if(questionTypeLookup.equalsIgnoreCase(LookupConstants.INPUT_TYPE_SINGLE_CHOICE)  || questionTypeLookup.equalsIgnoreCase(LookupConstants.INPUT_TYPE_MULTIPLE_CHOICE))
        {
            List<PqResponseOptionMap> pqResponseOptionMap= pqResponseOptionMappingService.findAllByPqResponse(pqResponse);
            List<String> options = new ArrayList<>();
            for (PqResponseOptionMap responseOptionMap : pqResponseOptionMap) {
                options.add(responseOptionMap.getPqOption().getOptionValue());
            }
            tempResponse= String.join(", ", options);
        }
        else
        {
            tempResponse = pqResponse.getResponseText();
        }

        List<ClarificationDTO> clarifications = new ArrayList<>();
        for( PqClarificationMsg pqClarification : pqClarificationMsgs) {

            String createDate=String.valueOf(pqClarification.getCreatedTimestamp());
            String updateDate= String.valueOf(pqClarification.getUpdateTimestamp());



            ClarificationDTO clarificationDTO = ClarificationDTO.builder()
                    .clarificationId(String.valueOf(pqClarification.getId()))
                    .responsBy(pqClarification.getSenderTypeLookup().equals(LookupConstants.SenderType.BIDDER.getLookupCode()) ? "Bidder" : "Auctioneer")
                    .responseText(pqClarification.getMsgText())
                    .createdDate(toUTCTimeZone(createDate))
                    .lastUpdatedDate(toUTCTimeZone(updateDate))
                    .build();

            if (pqClarification.getDocMaster() != null) {
                DocMaster docMaster = pqClarification.getDocMaster();
                List<DocAttachment> docAttachment = docAttachmentService.fetchAllAttachmentsByQuestion(docMaster);

                List<ClarificationAttachmentDTO> clarificationAttachmentDTOS = new ArrayList<>();
                for(DocAttachment tempDocAttachment: docAttachment) {
                    ClarificationAttachmentDTO clarificationAttachmentDTO = ClarificationAttachmentDTO.builder()
                            .attachmentID(tempDocAttachment.getAttachmentId())
                            .fileName(tempDocAttachment.getAttachmentName())
                            .fileUrl(tempDocAttachment.getAttachmentPath())
                            .build();
                    clarificationAttachmentDTOS.add(clarificationAttachmentDTO);
                }
                clarificationDTO.setAttachments(clarificationAttachmentDTOS);
            }

            clarifications.add(clarificationDTO);
        }
        return GetClarificationResponseDTO.builder()
                .responseID(responseId)
                .response(tempResponse)
                .clarification(clarifications)
                .build();
    }

    public ReqClarificationResponseDTO toReqClarificationResponseDTO(PqClarificationMsg pqClarificationMsg) {

        return ReqClarificationResponseDTO.builder()
                .clarificationId(pqClarificationMsg.getId())
                .status(LookupConstants.Status.PENDING.name())
                .responseBy(LookupConstants.SenderType.AUCTIONER.toString())
                .build();

    }

    public String toUTCTimeZone(String input)
    {
        Instant instant = Instant.parse(input);
        String output = DateTimeFormatter.ISO_INSTANT
                .format(instant.truncatedTo(ChronoUnit.MILLIS));
        return output;
    }
}
