
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * Criteria Management ServiceImpl: Implements the Criteria Management service layer.
 */
package in.gov.gem.app.fa.pq.validation.response.impl;

import in.gov.gem.app.fa.pq.domain.entity.PqParticipant;
import in.gov.gem.app.fa.pq.domain.entity.PqQuestion;
import in.gov.gem.app.fa.pq.domain.entity.PqResponse;
import in.gov.gem.app.fa.pq.service.PqQuestionResponseService;
import in.gov.gem.app.fa.pq.transformer.QuestionResponseTransformer;
import org.springframework.stereotype.Component;
import java.util.List;
import java.util.UUID;
import java.util.regex.Pattern;

import static in.gov.gem.app.fa.pq.constant.LookupConstants.INPUT_TYPE_FREETEXT;
import static in.gov.gem.app.fa.pq.constant.Regex.FREE_TEXT_PATTERN;

@Component
public class FreeTextResponseValidationImpl extends ResponseValidationAbstract{
    //For Question Type FREE_TEXT
    private static final String questionnaireType = INPUT_TYPE_FREETEXT;
    private final QuestionResponseTransformer questionResponseTransformer;
    private final PqQuestionResponseService pqQuestionResponseService;

    FreeTextResponseValidationImpl(QuestionResponseTransformer questionResponseTransformer,
                                   PqQuestionResponseService pqQuestionResponseService) {
        super(questionnaireType);
        this.questionResponseTransformer = questionResponseTransformer;
        this.pqQuestionResponseService = pqQuestionResponseService;
    }

    @Override
    public boolean validate(PqQuestion pqQuestion, List<String> response) {
        return super.checkOptionAreNotNull(response) && validateFreeText(response.getFirst());
    }
    public static boolean validateFreeText(String freeText) {

        if (freeText.isEmpty() || freeText.length() > 255) {
            return false;
        }
        return Pattern.matches(FREE_TEXT_PATTERN, freeText);
    }

    public PqResponse buildPqResponse(UUID submissionId, PqQuestion pqQuestionEntity, List<String> responses, String responseStatus, PqParticipant pqParticipant) {
        PqResponse pqResponse = questionResponseTransformer.toPqResponseEntityForInput(submissionId,pqQuestionEntity,responses.getFirst(),responseStatus, pqParticipant);
        return pqQuestionResponseService.saveResponseEntity(pqResponse);
    }

    @Override
    public PqResponse updatePqResponse(UUID submissionId, PqQuestion pqQuestionEntity, List<String> responseList) {
        PqResponse pqResponse = pqQuestionResponseService.fetchResponseFromSubmissionId(submissionId);
        pqResponse.setResponseText(responseList.getFirst());
        return pqQuestionResponseService.saveResponseEntity(pqResponse);
    }

}
