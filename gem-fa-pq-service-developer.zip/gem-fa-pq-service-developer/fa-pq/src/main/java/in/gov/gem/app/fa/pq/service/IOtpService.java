package in.gov.gem.app.fa.pq.service;

public interface IOtpService {

}
