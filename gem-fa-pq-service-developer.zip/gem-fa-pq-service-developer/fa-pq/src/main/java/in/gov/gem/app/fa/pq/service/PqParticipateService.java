package in.gov.gem.app.fa.pq.service;

import in.gov.gem.app.fa.pq.domain.entity.PqCriteria;
import in.gov.gem.app.fa.pq.domain.entity.PqParticipant;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public interface PqParticipateService {

    void saveParticipant(PqParticipant pqParticipant);

    PqParticipant fetchParticipantById(String participationId, PqCriteria pqCriteria);

    List<PqParticipant> fetchParticipantByCrtieria(PqCriteria pqCriteria);
}
