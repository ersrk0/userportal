/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * Criteria Management Service: Service for Criteria Management details endpoint.
 */

package in.gov.gem.app.fa.pq.service;

import in.gov.gem.app.fa.pq.domain.entity.PqCriteria;
import in.gov.gem.app.fa.pq.domain.entity.PqCriteriaMaster;
import in.gov.gem.app.fa.pq.request.CriteriaIdRequestDTO;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
public interface PqCriteriaService {

  void createCriteria(String acceptLanguage, CriteriaIdRequestDTO criteriaIdRequestDTO
      , UUID categoryId, PqCriteriaMaster pqCriteriaMaster);

  List<PqCriteria> fetchCriteria(String acceptLanguage,PqCriteriaMaster pqCriteriaMaster);

  void deleteCriteria(String acceptLanguage, PqCriteriaMaster pqCriteriaMaster);

  void deleteCategory(String acceptLanguage, PqCriteriaMaster pqCriteriaMaster, UUID categoryId);

  PqCriteria fetchByCriteriaIdAndCategoryId(String acceptLanguage, UUID criteriaId, UUID categoryCode);

  PqCriteria fetchCategory(String acceptLanguage, UUID categoryCode);

  PqCriteria fetchByCriteriaId(String acceptLanguage, UUID criteriaId);

  PqCriteria fetchActiveCategory(PqCriteriaMaster pqCriteriaMaster, UUID categoryCode);

  List<PqCriteria> fetchCategories(PqCriteriaMaster pqCriteriaMaster);


}

