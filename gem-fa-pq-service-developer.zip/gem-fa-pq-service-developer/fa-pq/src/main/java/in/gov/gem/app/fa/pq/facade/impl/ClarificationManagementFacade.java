
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM
 * ClassificationManagementFacade: Facade layer between Controller and Service.
 */

package in.gov.gem.app.fa.pq.facade.impl;

import in.gov.gem.app.fa.pq.constant.LookupConstants;
import in.gov.gem.app.fa.pq.domain.entity.DocMaster;
import in.gov.gem.app.fa.pq.domain.entity.PqClarificationMsg;
import in.gov.gem.app.fa.pq.domain.entity.PqClarificationThread;
import in.gov.gem.app.fa.pq.domain.entity.PqResponse;
import in.gov.gem.app.fa.pq.facade.IClarificationManagementFacade;
import in.gov.gem.app.fa.pq.request.ClarificationRequestDTO;
import in.gov.gem.app.fa.pq.response.GetClarificationResponseDTO;
import in.gov.gem.app.fa.pq.response.ReqClarificationResponseDTO;
import in.gov.gem.app.fa.pq.response.SubmitClarificationResponseDTO;
import in.gov.gem.app.fa.pq.service.DocAttachmentService;
import in.gov.gem.app.fa.pq.service.DocumentMasterService;
import in.gov.gem.app.fa.pq.service.DocumentServiceUtil;
import in.gov.gem.app.fa.pq.service.PqClarificationMsgService;
import in.gov.gem.app.fa.pq.service.PqClarificationThreadService;
import in.gov.gem.app.fa.pq.service.PqResponseService;
import in.gov.gem.app.fa.pq.transformer.ClassificationManagementTransformer;
import in.gov.gem.app.fa.pq.utility.RequestUtil;
import in.gov.gem.app.service.attachment.utility.S3AttachmentUtility;
import in.gov.gem.app.service.dto.CoreLookupDto;
import in.gov.gem.app.service.pack.service.interfaces.CoreLookupService;
import lombok.AllArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.UUID;

@Component
@AllArgsConstructor
public class ClarificationManagementFacade implements IClarificationManagementFacade {

  private static final Logger logger = LoggerFactory.getLogger(ClarificationManagementFacade.class);

  private final ClassificationManagementTransformer classificationManagementTransformer;
  private final RequestUtil requestUtil;
  private final DocumentServiceUtil documentServiceUtil;
  private final CoreLookupService coreLookupService;
  private final DocumentMasterService documentMasterService;
  private final DocAttachmentService docAttachmentService;
  private final PqResponseService pqResponseService;
  private final PqClarificationThreadService pqClarificationThreadService;
  private final PqClarificationMsgService pqClarificationMsgService;
  private final S3AttachmentUtility s3AttachmentUtility;

  @Transactional
  public SubmitClarificationResponseDTO submitClarification(String acceptLanguage, UUID responseId,
                                                            MultipartFile file,
                                                            ClarificationRequestDTO submitClarificationRequestDTO)
          throws IOException {
    logger.info("Entering submitClarification with responseId: {}", responseId);

    logger.debug("Request payload for submitClarification: {}", submitClarificationRequestDTO);

    DocMaster documentMaster = null;

    if (requestUtil.isFileValid(file) ) {
      documentMaster = this.documentUpload(file);
      logger.debug("Uploaded document: {}", documentMaster);
    }
    PqResponse pqResponse = pqResponseService.fetchPqResponseById(responseId);
    logger.debug("Fetched PqResponse: {}", pqResponse);

    PqClarificationThread thread =
            pqClarificationThreadService.fetchThread(acceptLanguage, pqResponse);
    logger.debug("Fetched PqClarificationThread: {}", thread);

    PqClarificationMsg pqClarificationMsg = pqClarificationMsgService.saveSubmissionMsg(thread,
            submitClarificationRequestDTO.getAdditionalQuery(), documentMaster);
    logger.debug("Saved PqClarificationMsg: {}", pqClarificationMsg);

    logger.info("Exiting submitClarification with responseId: {}", responseId);
    return classificationManagementTransformer.toSubmitClarificationResponseDTO(pqClarificationMsg);
  }

  @Transactional
  public ReqClarificationResponseDTO requestClarification(String acceptLanguage,
                                                          UUID responseId, MultipartFile file,
                                                          ClarificationRequestDTO clarificationRequestDTO)
          throws IOException {
    logger.info("Entering requestClarification with responseId: {}", responseId);

    logger.debug("Request payload for requestClarification: {}", clarificationRequestDTO);

    DocMaster documentMaster = null;
    if (requestUtil.isFileValid(file) )
    //if(file!=null && file.getSize()!=0)
    {
      documentMaster = this.documentUpload(file);
      logger.debug("Uploaded document: {}", documentMaster);
    }
    PqResponse pqResponse = pqResponseService.fetchPqResponseById(responseId);
    logger.debug("Fetched PqResponse: {}", pqResponse);

    PqClarificationThread pqClarificationThread =
            pqClarificationThreadService.saveThread(acceptLanguage, pqResponse);
    logger.debug("Saved PqClarificationThread: {}", pqClarificationThread);

    PqClarificationMsg pqClarificationMsg = pqClarificationMsgService.saveMsg(pqClarificationThread,
            clarificationRequestDTO.getAdditionalQuery(), documentMaster);
    logger.debug("Saved PqClarificationMsg: {}", pqClarificationMsg);

    logger.info("Exiting requestClarification with responseId: {}", responseId);
    return classificationManagementTransformer.toReqClarificationResponseDTO(pqClarificationMsg);
  }

  @Transactional
  public GetClarificationResponseDTO getClarification(String acceptLanguage, UUID responseId) {
    logger.info("Entering getClarification with responseId: {}", responseId);

    PqResponse pqResponse = pqResponseService.fetchPqResponseById(responseId);
    logger.debug("Fetched PqResponse: {}", pqResponse);

    PqClarificationThread pqClarificationThread = pqClarificationThreadService.fetchThread(acceptLanguage, pqResponse);
    logger.debug("Fetched PqClarificationThread: {}", pqClarificationThread);

    PqClarificationMsg[] pqClarificationMsgs = pqClarificationMsgService.fetchClarificationMsgByThread(pqClarificationThread);
    logger.debug("Fetched PqClarificationMsgs: {}", (Object[]) pqClarificationMsgs);

    logger.info("Exiting getClarification with responseId: {}", responseId);
    return classificationManagementTransformer.toGetClarificationResponseDTO(pqClarificationMsgs, responseId);
  }

  @Transactional
  public DocMaster documentUpload(MultipartFile file)
          throws IOException {
    logger.info("Entering documentUpload with file: {}", file.getOriginalFilename());

    String fileName = file.getOriginalFilename();
    String docName = file.getContentType();
    assert fileName != null;
    UUID documentId = requestUtil.createRequestId();
    UUID attachmentId = requestUtil.createRequestId();
    documentServiceUtil.fileSizeCheck(file);
    logger.debug("File size check passed for file: {}", fileName);

    CoreLookupDto lookupDto = coreLookupService.findAllByLookupValueIgnoreCase(docName).get(0);
    String docType = lookupDto.getLookupCode();
    String filePath = requestUtil.createPath(LookupConstants.QUESTION_CREATION, attachmentId, fileName);
    logger.debug("Generated file path: {}", filePath);

    DocMaster documentMaster = documentMasterService.saveDocumentMaster(documentId);
    logger.debug("Saved document master: {}", documentMaster);

    docAttachmentService.saveDocumentDetails(documentMaster, filePath, docType, fileName, file.getSize(), attachmentId);
    logger.debug("Saved document details for file: {}", fileName);

    s3AttachmentUtility.uploadMultipart("gem-consent-service", filePath, file);
    logger.info("Uploaded file to S3: {}", filePath);

    logger.info("Exiting documentUpload with documentId: {}", documentId);
    return documentMaster;
  }
}