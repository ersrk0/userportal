
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * PqClarificationThreadServiceImpl: Implements the clarification thread service layer.
 */

package in.gov.gem.app.fa.pq.service.impl;

import in.gov.gem.app.exception.generic.ServiceException;
import in.gov.gem.app.exception.utility.ErrorConstant;
import in.gov.gem.app.fa.pq.constant.LookupConstants;
import in.gov.gem.app.fa.pq.constant.MessageConstants;
import in.gov.gem.app.fa.pq.domain.entity.PqClarificationThread;
import in.gov.gem.app.fa.pq.domain.entity.PqResponse;
import in.gov.gem.app.fa.pq.domain.repository.PqClarificationThreadRepository;
import in.gov.gem.app.fa.pq.service.PqClarificationThreadService;
import in.gov.gem.app.fa.pq.utility.RequestUtil;
import in.gov.gem.app.service.core.utility.MessageUtility;
import lombok.AllArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
@AllArgsConstructor
public class PqClarificationThreadServiceImpl implements PqClarificationThreadService {

  private static final Logger logger = LoggerFactory.getLogger(PqClarificationThreadServiceImpl.class);

  private final PqClarificationThreadRepository pqClarificationThreadRepository;
  private final RequestUtil requestUtil;
  private final MessageUtility messageUtility;

  @Override
  public PqClarificationThread saveThread(String acceptLanguage, PqResponse pqResponse) {
    logger.info("Entering saveThread with PqResponse: {}", pqResponse);

    PqClarificationThread pqClarificationThread = pqClarificationThreadRepository.findByPqResponse(pqResponse);
    if (pqClarificationThread == null) {
      UUID threadId = requestUtil.createRequestId();
      logger.debug("Generated new threadId: {}", threadId);

      pqClarificationThread = PqClarificationThread.builder()
              .threadId(threadId)
              .pqResponse(pqResponse)
              .statusLookup(LookupConstants.Status.ACTIVE.getLookupCode())
              .build();
      pqClarificationThreadRepository.save(pqClarificationThread);
      logger.info("Saved new PqClarificationThread: {}", pqClarificationThread);
    } else {
      logger.debug("Existing PqClarificationThread found: {}", pqClarificationThread);
    }

    logger.info("Exiting saveThread");
    return pqClarificationThread;
  }

  @Override
  public PqClarificationThread fetchThread(String acceptLanguage, PqResponse pqResponse) {
    logger.info("Entering fetchThread with PqResponse: {}", pqResponse);

    PqClarificationThread pqClarificationThread = pqClarificationThreadRepository.findByPqResponse(pqResponse);
    if (pqClarificationThread == null) {
      logger.error("PqClarificationThread not found for PqResponse: {}", pqResponse);
      throw new ServiceException(MessageConstants.INVALID_INPUT,
              messageUtility.getMessage(MessageConstants.INVALID_INPUT),
              ErrorConstant.CATEGORY.BV,
              ErrorConstant.SEVERITY.C);
    }

    logger.debug("Fetched PqClarificationThread: {}", pqClarificationThread);

    logger.info("Exiting fetchThread");
    return pqClarificationThread;
  }
}


