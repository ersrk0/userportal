
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM
 * Main Application
 */

package in.gov.gem.app.fa.pq;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;

import static in.gov.gem.app.constant.BaseConstant.BASE_PACKAGE;


@SpringBootApplication(scanBasePackages = BASE_PACKAGE)
@ComponentScan(BASE_PACKAGE)
@EntityScan(basePackages = BASE_PACKAGE)
public class FaPqApplication {
    /**
     * The entry point of application.
     *
     * @param args the input arguments
     */
    public static void main(String[] args) {
        SpringApplication.run(FaPqApplication.class, args);
    }
}