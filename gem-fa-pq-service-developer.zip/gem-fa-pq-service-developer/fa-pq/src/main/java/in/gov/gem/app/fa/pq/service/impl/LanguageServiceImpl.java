package in.gov.gem.app.fa.pq.service.impl;

import in.gov.gem.app.fa.pq.domain.entity.MessageLog;
import in.gov.gem.app.fa.pq.domain.repository.MessageLogRepository;
import in.gov.gem.app.fa.pq.response.MessageViewResponse;
import in.gov.gem.app.fa.pq.service.LanguageService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class LanguageServiceImpl implements LanguageService {

  private final MessageLogRepository messageLogRepository;

  @Override
  public MessageViewResponse messageView(String messageCode) {
    MessageLog byMessageCode = messageLogRepository.findByMessageCode(messageCode);
    String message = byMessageCode.getMessage();
    return MessageViewResponse.builder()
        .message(message)
        .build();
  }
}
