package in.gov.gem.app.fa.pq.domain.repository;

import in.gov.gem.app.fa.pq.domain.entity.PqCriteria;
import in.gov.gem.app.fa.pq.domain.entity.PqParticipant;
import in.gov.gem.app.service.core.repository.BaseRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface PqParticipationRepository extends BaseRepository<PqParticipant, Long> {

  Optional<PqParticipant> findByParticipantIdAndPqCriteriaAndIsAllowed(String participationId, PqCriteria pqCriteria, Boolean aTrue);

  List<PqParticipant> findByPqCriteria(PqCriteria pqCriteria);

  Optional<List<PqParticipant>> findAllByParticipantIdAndPqCriteriaAndIsAllowed(String participationId, PqCriteria pqCriteria, Boolean isAllowed);

}
