
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM
 * Criteria Management Facade: Facade layer between Controller and Service.
 */

package in.gov.gem.app.fa.pq.facade;

import in.gov.gem.app.fa.pq.domain.entity.DocMaster;
import in.gov.gem.app.fa.pq.domain.entity.PqResponse;
import in.gov.gem.app.fa.pq.request.QuestionnaireResponseSubmitDTO;
import in.gov.gem.app.fa.pq.request.QuestionnaireResponseUpdateDTO;
import in.gov.gem.app.fa.pq.request.SubmissionStatusReqDTO;
import in.gov.gem.app.fa.pq.request.UpdateSubmissionEvaluationDTO;
import in.gov.gem.app.fa.pq.response.CriteriaResponsesDTO;
import in.gov.gem.app.fa.pq.response.MessageResponseDTO;
import in.gov.gem.app.fa.pq.response.ParticipantSubmissionsResponseDTO;
import in.gov.gem.app.fa.pq.response.PqDocumentsAnswerDTO;
import in.gov.gem.app.fa.pq.response.PqQuestionResponseDTO;
import in.gov.gem.app.fa.pq.response.SubmitQuestionsResponseDTO;
import in.gov.gem.app.fa.pq.response.UpdateSubmissionEvaluationResponseDTO;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.UUID;

public interface IPqQuestionnaireResponseFacade {

     PqQuestionResponseDTO submitQuestionResponse(
        UUID criteriaId, UUID questionId,
        QuestionnaireResponseSubmitDTO questionnaireResponseSubmitDTO,
        MultipartFile[] files,
        String participationId
    ) throws IOException;

     PqDocumentsAnswerDTO addDocumentsToResponse(UUID criteriaId, UUID questionId, UUID submissionIds,MultipartFile[] files, String participantId) throws IOException;

     PqQuestionResponseDTO saveAnswers(List<PqResponse> responses);

     PqResponse saveAnswer(PqResponse response);

     String deleteSubmittedResponse(UUID criteriaId, UUID questionId, UUID submissionId, String participationId);

     UUID activityLogDocumentUpload(MultipartFile file, DocMaster documentMaster) throws IOException;

    MessageResponseDTO updateSubmittedResponse(
            UUID criteriaId, UUID questionId, UUID submissionId,
            MultipartFile[] files, QuestionnaireResponseUpdateDTO questionnaireResponseUpdateDTO,
            String participationId
    ) throws IOException;

  MessageResponseDTO deleteResponseAttachment(UUID criteriaId, UUID questionId, UUID responseId, UUID attachmentId);

  CriteriaResponsesDTO fetchCriteriaResponses(UUID criteriaId, UUID categoryCode, List<String> participants, String acceptLanguage);

  SubmitQuestionsResponseDTO submitResponseDraft(UUID criteriaId, UUID categoryCode,String participantId, String acceptLanguage);

  List<ParticipantSubmissionsResponseDTO> fetchParticipantSubmissions(UUID criteriaId, UUID categoryCode, String acceptLanguage);

  UpdateSubmissionEvaluationResponseDTO updateSubmissionEvaluation(UUID submissionId, UpdateSubmissionEvaluationDTO updateSubmissionEvaluationRequest,
                                                                   String acceptLanguage);

    SubmissionStatusReqDTO updateSubmissionStatus(UUID submissionId, UUID participantId, SubmissionStatusReqDTO submissionStatusReqDTO, String acceptLanguage);
}