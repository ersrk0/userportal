
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM
 * Criteria Management Facade: Facade layer between Controller and Service.
 */

package in.gov.gem.app.fa.pq.facade;

import in.gov.gem.app.fa.pq.request.QuestionCreateRequestDTO;
import in.gov.gem.app.fa.pq.request.QuestionFilter;
import in.gov.gem.app.fa.pq.request.QuestionUpdateRequestDTO;
import in.gov.gem.app.fa.pq.response.CreateQuestionResponseDTO;
import in.gov.gem.app.fa.pq.response.DeleteUploadedDocumentsResponseDTO;
import in.gov.gem.app.fa.pq.response.MessageResponseDTO;
import in.gov.gem.app.fa.pq.response.UploadDocumentsResponseDTO;
import in.gov.gem.app.service.dto.PaginationParams;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.UUID;

public interface IPrequalificationQuestionnaireFacade {


   CreateQuestionResponseDTO createQuestion(String acceptLanguage, UUID criteriaId, UUID categoryCode, MultipartFile[] file, QuestionCreateRequestDTO request) throws IOException;

   CreateQuestionResponseDTO getQuestions(String acceptLanguage, UUID criteriaId, UUID categoryCode, QuestionFilter questionFilter, PaginationParams paginationParams);

   MessageResponseDTO deleteQuestion(String acceptLanguage, UUID categoryCode, UUID criteriaId, UUID questionId);

   MessageResponseDTO updateQuestions(String acceptLanguage, UUID categoryCode, UUID criteriaId, UUID questionsId,
                                      QuestionUpdateRequestDTO requests);

   UploadDocumentsResponseDTO uploadDocument(String acceptLanguage, UUID categoryCode, UUID criteriaId, UUID questionsId,
                                             MultipartFile[] file) throws IOException;


   DeleteUploadedDocumentsResponseDTO deleteUploadedDocuments(String acceptLanguage, UUID categoryCode, UUID criteriaId,
                                                              UUID questionId, UUID attachmentId);

  MessageResponseDTO deleteCategoryQuestion(String acceptLanguage, UUID criteriaId, UUID categoryCode);
}
