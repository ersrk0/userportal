
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * PqClarificationMsgServiceImpl: Implements the clarification msg service layer.
 */

package in.gov.gem.app.fa.pq.service.impl;

import in.gov.gem.app.fa.pq.constant.Constants;
import in.gov.gem.app.fa.pq.constant.LookupConstants;
import in.gov.gem.app.fa.pq.domain.entity.DocMaster;
import in.gov.gem.app.fa.pq.domain.entity.PqClarificationMsg;
import in.gov.gem.app.fa.pq.domain.entity.PqClarificationThread;
import in.gov.gem.app.fa.pq.domain.repository.PqClarificationMsgRepository;
import in.gov.gem.app.fa.pq.service.PqClarificationMsgService;
import lombok.AllArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class PqClarificationMsgServiceImpl implements PqClarificationMsgService {

  private static final Logger logger = LoggerFactory.getLogger(PqClarificationMsgServiceImpl.class);

  private final PqClarificationMsgRepository pqClarificationMsgRepository;

  @Override
  public PqClarificationMsg saveMsg(PqClarificationThread pqClarificationThread, String msgText, DocMaster docMaster) {
    logger.info("Entering saveMsg with PqClarificationThread: {} and msgText: {}", pqClarificationThread, msgText);

    PqClarificationMsg pqClarificationMsg = PqClarificationMsg.builder()
            .pqClarificationThread(pqClarificationThread)
            .senderTypeLookup(LookupConstants.SenderType.AUCTIONER.getLookupCode())
            .msgText(msgText)
            .sentBy(Constants.AUCTIONER)
            .docMaster(docMaster)
            .build();
    logger.debug("Constructed PqClarificationMsg: {}", pqClarificationMsg);

    PqClarificationMsg savedMsg = pqClarificationMsgRepository.save(pqClarificationMsg);

    logger.info("Exiting saveMsg");
    return savedMsg;
  }

  @Override
  public PqClarificationMsg saveSubmissionMsg(PqClarificationThread thread, String additionalInfo, DocMaster docMaster) {
    logger.info("Entering saveSubmissionMsg with PqClarificationThread: {} and additionalInfo: {}", thread, additionalInfo);

    PqClarificationMsg pqClarificationMsg = PqClarificationMsg.builder()
            .pqClarificationThread(thread)
            .senderTypeLookup(LookupConstants.SenderType.BIDDER.getLookupCode())
            .msgText(additionalInfo)
            .sentBy(Constants.AUCTIONER)
            .docMaster(docMaster)
            .build();
    logger.debug("Constructed PqClarificationMsg: {}", pqClarificationMsg);

    PqClarificationMsg savedMsg = pqClarificationMsgRepository.save(pqClarificationMsg);

    logger.info("Exiting saveSubmissionMsg");
    return savedMsg;
  }

  @Override
  public PqClarificationMsg[] fetchClarificationMsgByThread(PqClarificationThread pqClarificationThread) {
    logger.info("Entering fetchClarificationMsgByThread with PqClarificationThread: {}", pqClarificationThread);

    PqClarificationMsg[] messages = pqClarificationMsgRepository.findAllByPqClarificationThread(pqClarificationThread);
    logger.debug("Fetched PqClarificationMsgs: {}", (Object[]) messages);

    logger.info("Exiting fetchClarificationMsgByThread");
    return messages;
  }
}

