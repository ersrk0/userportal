
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * Parent Criteria Management ServiceImpl: Implements the Parent Criteria Management service layer.
 */

package in.gov.gem.app.fa.pq.service.impl;

import in.gov.gem.app.exception.generic.InvalidInputException;
import in.gov.gem.app.fa.pq.constant.ErrorMessageConstants;
import in.gov.gem.app.fa.pq.constant.LookupConstants;
import in.gov.gem.app.fa.pq.domain.entity.PqCriteriaMaster;
import in.gov.gem.app.fa.pq.domain.repository.PqCriteriaMasterRepository;
import in.gov.gem.app.fa.pq.request.CriteriaIdRequestDTO;
import in.gov.gem.app.fa.pq.service.PqCriteriaMasterService;
import in.gov.gem.app.fa.pq.transformer.ParentCriteriaManagementTransformer;
import in.gov.gem.app.service.core.utility.MessageUtility;
import lombok.AllArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
@AllArgsConstructor
public class PqCriteriaMasterServiceImpl implements PqCriteriaMasterService {

  private static final Logger logger = LoggerFactory.getLogger(PqCriteriaMasterServiceImpl.class);

  private final MessageUtility messageUtility;
  private final PqCriteriaMasterRepository pqCriteriaMasterRepository;
  private final ParentCriteriaManagementTransformer parentCriteriaManagementTransformer;

  @Override
  public PqCriteriaMaster createParentCriteria(String acceptLanguage, CriteriaIdRequestDTO criteriaIdRequestDTO, UUID criteriaId) {
    logger.info("Entering createParentCriteria with acceptLanguage: {}, criteriaId: {}", acceptLanguage, criteriaId);

    logger.debug("Request payload for createParentCriteria: {}", criteriaIdRequestDTO);

    PqCriteriaMaster criteria = pqCriteriaMasterRepository.findByStatusLookupAndOfferingId(
            LookupConstants.Status.ACTIVE.getLookupCode(), criteriaIdRequestDTO.getOfferingId());
    if (criteria != null) {
      logger.info("Criteria already exists for offeringId: {}", criteriaIdRequestDTO.getOfferingId());
      return criteria;
    }

    PqCriteriaMaster pqCriteriaMaster = parentCriteriaManagementTransformer
            .toPqParentCriteria(criteriaIdRequestDTO, criteriaId);
    logger.debug("Transformed PqCriteriaMaster: {}", pqCriteriaMaster);

    PqCriteriaMaster savedCriteria = pqCriteriaMasterRepository.save(pqCriteriaMaster);
    logger.info("Exiting createParentCriteria with savedCriteriaId: {}", savedCriteria.getMasterCriteriaId());
    return savedCriteria;
  }

  @Override
  public PqCriteriaMaster deleteParentCriteria(String acceptLanguage, UUID criteriaId) {
    logger.info("Entering deleteParentCriteria with criteriaId: {}", criteriaId);

    PqCriteriaMaster pqCriteriaMaster = pqCriteriaMasterRepository.findByMasterCriteriaId(criteriaId)
            .orElseThrow(() -> {
              logger.error("Criteria not found for criteriaId: {}", criteriaId);
              return new InvalidInputException(ErrorMessageConstants.CRITERIA_NOT_FOUND,
                      messageUtility.getMessage(ErrorMessageConstants.CRITERIA_NOT_FOUND));
            });

    logger.debug("Fetched PqCriteriaMaster for deletion: {}", pqCriteriaMaster);

    pqCriteriaMaster.setStatusLookup(LookupConstants.Status.INACTIVE.getLookupCode());
    PqCriteriaMaster updatedCriteria = pqCriteriaMasterRepository.save(pqCriteriaMaster);

    logger.info("Exiting deleteParentCriteria with updatedCriteriaId: {}", updatedCriteria.getMasterCriteriaId());
    return updatedCriteria;
  }

  @Override
  public PqCriteriaMaster fetchCriteria(String acceptLanguage, UUID offeringId) {
    logger.info("Fetching criteria for offeringId: {}", offeringId);
    PqCriteriaMaster criteria = pqCriteriaMasterRepository.findByStatusLookupAndOfferingId(
            LookupConstants.Status.ACTIVE.getLookupCode(), offeringId);
    logger.debug("Fetched criteria: {}", criteria);
    return criteria;
  }

  @Override
  public PqCriteriaMaster fetchCriteriaFromCriteriaId(UUID criteriaId) {
    logger.info("Fetching criteria for criteriaId: {}", criteriaId);
    PqCriteriaMaster criteria = pqCriteriaMasterRepository.findByMasterCriteriaId(criteriaId)
            .orElseThrow(() -> {
              logger.error("Criteria not found for criteriaId: {}", criteriaId);
              return new InvalidInputException(ErrorMessageConstants.CRITERIA_NOT_FOUND,
                      messageUtility.getMessage(ErrorMessageConstants.CRITERIA_NOT_FOUND));
            });
    logger.debug("Fetched criteria: {}", criteria);
    return criteria;
  }

  @Override
  public PqCriteriaMaster fetchActiveCriteriaFromCriteriaId(UUID criteriaId) {
    logger.info("Fetching active criteria for criteriaId: {}", criteriaId);
    PqCriteriaMaster criteria = pqCriteriaMasterRepository.findByStatusLookupAndMasterCriteriaId(
                    LookupConstants.Status.ACTIVE.getLookupCode(), criteriaId)
            .orElseThrow(() -> {
              logger.error("Active criteria not found for criteriaId: {}", criteriaId);
              return new InvalidInputException(ErrorMessageConstants.ACTIVE_CRITERIA_NOT_FOUND,
                      messageUtility.getMessage(ErrorMessageConstants.ACTIVE_CRITERIA_NOT_FOUND));
            });
    logger.debug("Fetched active criteria: {}", criteria);
    return criteria;
  }

  @Override
  public PqCriteriaMaster submitRepresentation(PqCriteriaMaster pqCriteriaMaster) {
    logger.info("Submitting representation for criteriaId: {}", pqCriteriaMaster.getMasterCriteriaId());

    logger.debug("PqCriteriaMaster before submission: {}", pqCriteriaMaster);

    PqCriteriaMaster updatedCriteria = pqCriteriaMasterRepository.save(pqCriteriaMaster);

    logger.info("Exiting submitRepresentation with updatedCriteriaId: {}", updatedCriteria.getMasterCriteriaId());
    return updatedCriteria;
  }
}
