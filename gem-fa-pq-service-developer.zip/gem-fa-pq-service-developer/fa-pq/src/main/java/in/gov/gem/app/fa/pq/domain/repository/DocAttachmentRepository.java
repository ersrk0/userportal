package in.gov.gem.app.fa.pq.domain.repository;

import in.gov.gem.app.fa.pq.domain.entity.DocMaster;
import in.gov.gem.app.fa.pq.domain.entity.DocAttachment;
import in.gov.gem.app.service.core.repository.BaseRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface DocAttachmentRepository extends BaseRepository<DocAttachment, Long> {

  DocAttachment findByDocMaster(DocMaster docMaster);

  List<DocAttachment> findAllByDocMaster(DocMaster docMaster);

  DocAttachment findByAttachmentIdAndDocMaster(UUID attachmentId, DocMaster docMaster);

  DocAttachment findByAttachmentIdAndStatusLookup(UUID attachmentId, String statusLookup);

  DocAttachment findByDocMasterAndAttachmentId(DocMaster docMaster, UUID attachmentId);

  List<DocAttachment> findAllByDocMasterAndStatusLookup(DocMaster docMaster, String statusLookup);
}
