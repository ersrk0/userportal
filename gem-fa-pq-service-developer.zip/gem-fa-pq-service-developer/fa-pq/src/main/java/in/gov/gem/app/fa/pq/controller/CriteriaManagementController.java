
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM
 * Criteria Management Controller: Endpoint related to bank details.
 */

package in.gov.gem.app.fa.pq.controller;

import in.gov.gem.app.fa.pq.constant.Constants;
import in.gov.gem.app.fa.pq.constant.MessageConstants;
import in.gov.gem.app.fa.pq.facade.impl.CriteriaManagementFacade;
import in.gov.gem.app.fa.pq.request.CriteriaIdRequestDTO;
import in.gov.gem.app.fa.pq.request.SubmitRepresentationReqDTO;
import in.gov.gem.app.fa.pq.response.CriteriaIdResponseDTO;
import in.gov.gem.app.fa.pq.response.MessageResponseDTO;
import in.gov.gem.app.fa.pq.response.SubmitRepresentationResDTO;
import in.gov.gem.app.service.core.utility.MessageUtility;
import in.gov.gem.app.service.dto.APIResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.UUID;

@Tag(name = "Criteria Management", description = "Criteria Management related endpoints")
@RestController
@RequestMapping("/v1/public/criteria")
@Validated
@AllArgsConstructor
public class CriteriaManagementController {

  private static final Logger logger = LoggerFactory.getLogger(CriteriaManagementController.class);

  private final MessageUtility messageUtility;
  private final CriteriaManagementFacade criteriaManagementFacade;

  @PostMapping(path = "")
  public ResponseEntity<APIResponse<CriteriaIdResponseDTO>> createCriteria(
          @RequestHeader("Accept-Language") String acceptLanguage,
          @Valid @RequestBody CriteriaIdRequestDTO criteriaIdRequestDTO) {
    logger.info("Entering createCriteria with acceptLanguage: {}", acceptLanguage);

    logger.debug("Request payload for createCriteria: {}", criteriaIdRequestDTO);
    CriteriaIdResponseDTO response = criteriaManagementFacade.createCriteria(acceptLanguage, criteriaIdRequestDTO);
    logger.debug("Response from createCriteria: {}", response);

    logger.info("Exiting createCriteria with response: {}", response);

    return ResponseEntity.status(HttpStatus.CREATED).body(
            APIResponse.<CriteriaIdResponseDTO>builder()
                    .status(HttpStatus.CREATED.getReasonPhrase())
                    .httpStatus(HttpStatus.CREATED.value())
                    .message(messageUtility.getMessage(MessageConstants.SUCCESS_MESSAGE))
                    .data(response)
                    .msId(Constants.MSID)
                    .build()
    );
  }

  @GetMapping(path = "")
  public ResponseEntity<APIResponse<CriteriaIdResponseDTO>> fetchCriteria(
          @RequestHeader("Accept-Language") String acceptLanguage,
          @Valid @RequestParam UUID offeringId ) {
    logger.info("Entering fetchCriteria with offeringId: {}", offeringId);

    logger.debug("Fetching criteria with acceptLanguage: {}", acceptLanguage);
    CriteriaIdResponseDTO response = criteriaManagementFacade.fetchCriteria(acceptLanguage, offeringId);
    logger.debug("Response from fetchCriteria: {}", response);

    logger.info("Exiting fetchCriteria with response: {}", response);

    return ResponseEntity.status(HttpStatus.OK).body(
            APIResponse.<CriteriaIdResponseDTO>builder()
                    .status(HttpStatus.OK.getReasonPhrase())
                    .httpStatus(HttpStatus.OK.value())
                    .message(messageUtility.getMessage(MessageConstants.SUCCESS_MESSAGE))
                    .data(response)
                    .msId(Constants.MSID)
                    .build()
    );
  }

  @DeleteMapping(path = "/{criteriaId}")
  public ResponseEntity<APIResponse<MessageResponseDTO>> deleteCriteria(
          @RequestHeader("Accept-Language") String acceptLanguage,
          @PathVariable UUID criteriaId) {
    logger.info("Entering deleteCriteria with criteriaId: {}", criteriaId);

    logger.debug("Deleting criteria with acceptLanguage: {}", acceptLanguage);
    MessageResponseDTO response = criteriaManagementFacade.deleteCriteria(acceptLanguage, criteriaId);
    logger.debug("Response from deleteCriteria: {}", response);

    logger.info("Exiting deleteCriteria with response: {}", response);

    return ResponseEntity.status(HttpStatus.OK).body(
            APIResponse.<MessageResponseDTO>builder()
                    .status(HttpStatus.OK.getReasonPhrase())
                    .httpStatus(HttpStatus.OK.value())
                    .message(messageUtility.getMessage(MessageConstants.SUCCESS_MESSAGE))
                    .data(response)
                    .msId(Constants.MSID)
                    .build()
    );
  }

  @DeleteMapping(path = "/{criteriaId}/category/{categoryCode}")
  public ResponseEntity<APIResponse<MessageResponseDTO>> deleteCategory(
          @RequestHeader("Accept-Language") String acceptLanguage,
          @PathVariable UUID criteriaId,
          @PathVariable UUID categoryCode) {
    logger.info("Entering deleteCategory with criteriaId: {} and categoryCode: {}", criteriaId, categoryCode);

    logger.debug("Deleting category with acceptLanguage: {}", acceptLanguage);
    MessageResponseDTO response = criteriaManagementFacade.deleteCategory(acceptLanguage, criteriaId, categoryCode);
    logger.debug("Response from deleteCategory: {}", response);

    logger.info("Exiting deleteCategory with response: {}", response);

    return ResponseEntity.status(HttpStatus.OK).body(
            APIResponse.<MessageResponseDTO>builder()
                    .status(HttpStatus.OK.getReasonPhrase())
                    .httpStatus(HttpStatus.OK.value())
                    .message(messageUtility.getMessage(MessageConstants.SUCCESS_MESSAGE))
                    .data(response)
                    .msId(Constants.MSID)
                    .build()
    );
  }

  @PutMapping(path = "")
  public ResponseEntity<APIResponse<MessageResponseDTO>> syncCriteria(){
    logger.info("Entering syncCriteria");
    MessageResponseDTO response = criteriaManagementFacade.syncCriteria();
    logger.debug("Response from syncCriteria: {}", response);

    logger.info("Exiting syncCriteria with response: {}", response);

    return ResponseEntity.status(HttpStatus.OK).body(
            APIResponse.<MessageResponseDTO>builder()
                    .status(HttpStatus.OK.getReasonPhrase())
                    .httpStatus(HttpStatus.OK.value())
                    .message(messageUtility.getMessage(MessageConstants.SUCCESS_MESSAGE))
                    .data(response)
                    .msId(Constants.MSID)
                    .build()
    );
  }

  @PutMapping(path = "/{criteriaId}/submitRepresentationStatus")
  public ResponseEntity<APIResponse<SubmitRepresentationResDTO>> submitRepresentation(
          @RequestHeader("Accept-Language") String acceptLanguage,
          @PathVariable UUID criteriaId,
          @ModelAttribute(name = "updateRepresentationReqDTO") SubmitRepresentationReqDTO submitRepresentationReqDTO
  ) throws IOException {
    logger.info("Entering submitRepresentation with criteriaId: {}", criteriaId);

    logger.debug("Request payload for submitRepresentation: {}", submitRepresentationReqDTO);
    SubmitRepresentationResDTO response = criteriaManagementFacade.submitRepresentationStatus(criteriaId, submitRepresentationReqDTO, acceptLanguage);
    logger.debug("Response from submitRepresentation: {}", response);

    logger.info("Exiting submitRepresentation with response: {}", response);

    return ResponseEntity.status(HttpStatus.OK).body(
            APIResponse.<SubmitRepresentationResDTO>builder()
                    .status(HttpStatus.OK.getReasonPhrase())
                    .httpStatus(HttpStatus.OK.value())
                    .message(messageUtility.getMessage(MessageConstants.SUCCESS_MESSAGE))
                    .data(response)
                    .msId(Constants.MSID)
                    .build()
    );
  }

  @GetMapping(path = "/{criteriaId}/getRepresentationStatus")
  public ResponseEntity<APIResponse<SubmitRepresentationResDTO>> getRepresentation(
          @RequestHeader("Accept-Language") String acceptLanguage,
          @PathVariable UUID criteriaId) {
    logger.info("Entering getRepresentation with criteriaId: {}", criteriaId);

    logger.debug("Fetching representation status with acceptLanguage: {}", acceptLanguage);
    SubmitRepresentationResDTO response = criteriaManagementFacade.getRepresentationStatus(criteriaId, acceptLanguage);
    logger.debug("Response from getRepresentation: {}", response);

    logger.info("Exiting getRepresentation with response: {}", response);

    return ResponseEntity.status(HttpStatus.OK).body(
            APIResponse.<SubmitRepresentationResDTO>builder()
                    .status(HttpStatus.OK.getReasonPhrase())
                    .httpStatus(HttpStatus.OK.value())
                    .message(messageUtility.getMessage(MessageConstants.SUCCESS_MESSAGE))
                    .data(response)
                    .msId(Constants.MSID)
                    .build()
    );
  }
}