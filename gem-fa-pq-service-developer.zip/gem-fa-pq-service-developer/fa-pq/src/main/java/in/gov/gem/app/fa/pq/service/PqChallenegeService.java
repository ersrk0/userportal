
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * Pq Clarification Msg Repository: Contains DB function to fetch Pq clarification msg data.
 */
package in.gov.gem.app.fa.pq.service;

import in.gov.gem.app.fa.pq.domain.entity.DocMaster;
import in.gov.gem.app.fa.pq.domain.entity.PqAssessment;
import in.gov.gem.app.fa.pq.domain.entity.PqChallenge;
import in.gov.gem.app.fa.pq.domain.entity.PqParticipant;
import in.gov.gem.app.fa.pq.request.ChallengeReqDTO;

public interface PqChallenegeService {

    PqChallenge createChallenege(PqParticipant pqParticipant, PqAssessment pqAssessment, ChallengeReqDTO challengeReqDTO, DocMaster docMaster, String status);

    PqChallenge fetchChallengeById(Long challengeId);
}
