package in.gov.gem.app.fa.pq.service;

import in.gov.gem.app.fa.pq.domain.entity.DocMaster;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
public interface DocumentMasterService {

  DocMaster saveDocumentMaster(UUID attachmentId);

}
