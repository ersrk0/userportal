
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * Pq Parent Criteria Entity: Specifies the attributes in the 'pq_parent_criteria' table.
 */

package in.gov.gem.app.fa.pq.domain.entity;

import in.gov.gem.app.service.core.entity.BaseEntity;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

@Entity
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
@Table(name = "pq_criteria_master")
public class PqCriteriaMaster extends BaseEntity {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @Column(name = "master_criteria_id", nullable = false)
  private UUID masterCriteriaId;

  @Column(name = "auction_id", nullable = false)
  private UUID offeringId;

  @Column(name = "status_lookup", length = 10)
  private String statusLookup;

  @Column(name = "pq_submission_start")
  private Instant pqSubmissionStart;

  @Column(name = "pq_submission_end")
  private Instant pqSubmissionEnd;

  @OneToMany(mappedBy = "pqCriteriaMaster", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
  private List<PqCriteria> pqCriteria;

  @Column(name = "is_representation_allowed")
  private Boolean isRepresentationAllowed;

  @OneToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "doc_master_fk", referencedColumnName = "id", nullable = false)
  private DocMaster docMaster;

  @Column(name = "remark", length = 512)
  private String remarks;

}
