package in.gov.gem.app.fa.pq.service;

import in.gov.gem.app.fa.pq.response.MessageViewResponse;
import org.springframework.stereotype.Service;

@Service
public interface LanguageService {

  MessageViewResponse messageView(String messageCode);

}
