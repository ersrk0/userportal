package in.gov.gem.app.fa.pq.service;

import in.gov.gem.app.fa.pq.domain.entity.PqQuestion;
import in.gov.gem.app.fa.pq.domain.entity.QuestionSupportingDoc;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
public interface QuestionSupportingDocService {
  void deleteDocument(QuestionSupportingDoc supportingDoc);

  void saveDocument(PqQuestion pqQuestion, String filePath, String docType, String fileName, UUID attachmentId);

  QuestionSupportingDoc fetchDocumentByQuestionId(PqQuestion pqQuestion, UUID attachmentId);
}
