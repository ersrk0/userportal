package in.gov.gem.app.fa.pq.domain.repository;

import in.gov.gem.app.fa.pq.domain.entity.PqQuestion;
import in.gov.gem.app.fa.pq.domain.entity.QuestionSupportingDoc;
import in.gov.gem.app.service.core.repository.BaseRepository;
import org.springframework.stereotype.Repository;

import java.util.UUID;

@Repository
public interface QuestionSupportingDocRepository extends BaseRepository<QuestionSupportingDoc, Long> {

  QuestionSupportingDoc findByPqQuestionAndDocumentId(PqQuestion pqQuestion, UUID attachmentId);
}
