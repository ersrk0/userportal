package in.gov.gem.app.fa.pq.domain.repository;

import in.gov.gem.app.fa.pq.domain.entity.PqCriteria;
import in.gov.gem.app.fa.pq.domain.entity.PqParticipant;
import in.gov.gem.app.service.core.repository.BaseRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface PqParticipantRepository extends BaseRepository<PqParticipant, Long> {
    Optional<PqParticipant> findByParticipantIdAndPqCriteria(String participationId, PqCriteria PqCriteria);
}
