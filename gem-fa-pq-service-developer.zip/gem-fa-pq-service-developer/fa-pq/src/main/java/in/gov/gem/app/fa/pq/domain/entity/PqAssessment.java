
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * Pq Assessment Entity: Specifies the attributes in the 'pq_assessment' table.
 */

package in.gov.gem.app.fa.pq.domain.entity;


import in.gov.gem.app.service.core.entity.BaseEntity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

import java.util.UUID;

@Entity
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
@Table(name = "pq_assessment")
public class PqAssessment extends BaseEntity {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @OneToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "pq_submission_fk", nullable = false)
  private PqSubmission pqSubmission;

//  @OneToOne(fetch = FetchType.LAZY)
//  @JoinColumn(name = "pq_criteria_fk", referencedColumnName = "id")
//  private PqCriteria pqCriteria;

  @Column(name = "assessment_id",length = 12)
  private UUID assessmentID;

  @Column(name = "assessment_status_lookup", length = 10)
  private String assessmentStatusLookup;

  @Column(name = "is_otp_verified", nullable = false)
  private Boolean isOtpVerified;

  @Column(name = "assessment_remark", length = 255)
  private String assessmentRemark;

  @Column(name = "assessment_score")
  private Long assessmentScore;

  @Column(name = "assessed_by")
  private Long assessedBy;

  @Column(name = "is_qualified")
  private boolean isQualified;


}
