package in.gov.gem.app.fa.pq.service.impl;

import org.springframework.stereotype.Service;

@Service
public class OtpService {
}
