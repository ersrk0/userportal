

/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * PqCriteriaServiceImplTest: Tests the service layer functioning.
 */
package in.gov.gem.app.fa.pq.service.impl;

import in.gov.gem.app.fa.pq.domain.entity.DocMaster;
import in.gov.gem.app.fa.pq.domain.entity.PqChallenge;
import in.gov.gem.app.fa.pq.domain.entity.PqChallengeResponse;
import in.gov.gem.app.fa.pq.domain.repository.PqChallengeResponseRepository;
import in.gov.gem.app.fa.pq.request.ResponseOfChallengeReqDTO;
import in.gov.gem.app.fa.pq.service.PqChallengeResponseService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class PqChallengeResponseImpl implements PqChallengeResponseService {

    private final PqChallengeResponseRepository pqChallengeResponseRepository;

    @Override
    public PqChallengeResponse createChallengeResponse(ResponseOfChallengeReqDTO responseOfChallengeReqDTO, PqChallenge pqChallenge, DocMaster documentMaster) {
        PqChallengeResponse pqChallengeResponse = PqChallengeResponse.builder()
                .responseText(responseOfChallengeReqDTO.getResponseText())
                .pqChallenge(pqChallenge)
                .docMaster(documentMaster)
                .statusLookUp(pqChallenge.getStatusLookUp())
                .respondedBy("Not Known Yet")
                .build();
        return pqChallengeResponseRepository.save(pqChallengeResponse);
    }
}
