package in.gov.gem.app.fa.pq.service;

import in.gov.gem.app.fa.pq.domain.entity.DocMaster;
import in.gov.gem.app.fa.pq.domain.entity.DocAttachment;
import in.gov.gem.app.fa.pq.domain.entity.PqClarification;
import in.gov.gem.app.fa.pq.request.AttachmentTemplate;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
public interface DocAttachmentService {

  void saveDocumentDetails(DocMaster docMaster, String filePath, String docType, String fileName,
                           Long fileSize, UUID attachmentId);

  void deleteDocumentMetadata(List<DocAttachment> docAttachments);
  void deleteDocumentByAttachmentId(UUID attachmentId, DocMaster docMaster);
  List<DocAttachment> fetchAllAttachmentsByQuestion(DocMaster docMaster);
  DocAttachment fetchDocumentMaster(PqClarification pqClarification);
  AttachmentTemplate viewAttachment(UUID attachmentId);
  DocAttachment fetchDocAttachmentByDocMaster(UUID attachmentId, DocMaster docMaster);
  List<DocAttachment> fetchAllActiveAttachmentsByQuestion(DocMaster docMaster);

}
