
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * Criteria Management ServiceImpl: Implements the Criteria Management service layer.
 */
package in.gov.gem.app.fa.pq.service;

import in.gov.gem.app.fa.pq.domain.entity.DocMaster;
import in.gov.gem.app.fa.pq.domain.entity.PqCriteria;
import in.gov.gem.app.fa.pq.domain.entity.PqQuestion;
import in.gov.gem.app.fa.pq.request.QuestionCreateRequestDTO;
import in.gov.gem.app.fa.pq.request.QuestionUpdateRequestDTO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
public interface PqQuestionService {

  List<PqQuestion> fetchQuestionByCriteria(PqCriteria pqCriteria);

  PqQuestion createQuestion(String acceptLanguage, QuestionCreateRequestDTO request,
                            PqCriteria pqCriteria, UUID questionId, DocMaster docMaster);

  void saveDocument(DocMaster docMaster, PqQuestion pqQuestion);

  void deleteQuestion(String acceptLanguage, PqCriteria pqCriteria, UUID questionId);
  PqQuestion fetchQuestionByQuestionId(PqCriteria pqCriteria, UUID questionId);
  void updateQuestion(PqQuestion pqQuestion, QuestionUpdateRequestDTO questionUpdateRequestDTO);
  PqQuestion fetchQuestionByQuestionId(UUID questionId);

  void deleteAllQuestions(List<PqQuestion> pqQuestionList);

  void saveQuestion(PqQuestion pqQuestion);

  Page<PqQuestion> getQuestionsWithFilter(Specification<PqQuestion> specification, Pageable pageable);
}
