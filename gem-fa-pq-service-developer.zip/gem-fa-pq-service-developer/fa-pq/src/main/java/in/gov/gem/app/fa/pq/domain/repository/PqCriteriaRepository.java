
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * Pq Criteria Repository: Contains DB function to fetch Pq Criteria data.
 */
package in.gov.gem.app.fa.pq.domain.repository;

import in.gov.gem.app.fa.pq.domain.entity.PqCriteria;
import in.gov.gem.app.fa.pq.domain.entity.PqCriteriaMaster;
import in.gov.gem.app.service.core.repository.BaseRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface PqCriteriaRepository extends BaseRepository<PqCriteria, Long> {

//  List<PqCriteria> findByStatusLookupAndPqCriteriaMaster(String statusLookup
//      , UUID offeringId, PqCriteriaMaster pqCriteriaMasterId);

  List<PqCriteria> findByStatusLookupAndPqCriteriaMaster(String statusLookup, PqCriteriaMaster pqCriteriaMasterId);

  PqCriteria findByCategoryCodeAndStatusLookup(UUID categoryCode, String statusLookup);

  PqCriteria findByPqCategoryIdAndCategoryCode(UUID criteriaId, UUID categoryId);

  PqCriteria findByPqCategoryIdAndCategoryCodeAndStatusLookup(UUID criteriaId, UUID categoryId, String statusActive);

  PqCriteria findByPqCategoryId(UUID criteriaId);

  Optional<PqCriteria> findByStatusLookupAndPqCriteriaMasterAndCategoryCode(
      String statusLookup, PqCriteriaMaster pqCriteriaMasterId, UUID categoryCode);

}