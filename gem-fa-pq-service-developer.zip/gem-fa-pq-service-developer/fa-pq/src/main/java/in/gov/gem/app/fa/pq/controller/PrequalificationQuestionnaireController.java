package in.gov.gem.app.fa.pq.controller;

import in.gov.gem.app.fa.pq.constant.Constants;
import in.gov.gem.app.fa.pq.constant.MessageConstants;
import in.gov.gem.app.fa.pq.facade.IPrequalificationQuestionnaireFacade;
import in.gov.gem.app.fa.pq.request.QuestionCreateRequestDTO;
import in.gov.gem.app.fa.pq.request.QuestionFilter;
import in.gov.gem.app.fa.pq.request.QuestionUpdateRequestDTO;
import in.gov.gem.app.fa.pq.response.CreateQuestionResponseDTO;
import in.gov.gem.app.fa.pq.response.DeleteUploadedDocumentsResponseDTO;
import in.gov.gem.app.fa.pq.response.MessageResponseDTO;
import in.gov.gem.app.fa.pq.response.UploadDocumentsResponseDTO;
import in.gov.gem.app.service.core.utility.ApiResponseBuilder;
import in.gov.gem.app.service.core.utility.MessageUtility;
import in.gov.gem.app.service.dto.APIResponse;
import in.gov.gem.app.service.dto.PaginationParams;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.UUID;

@Tag(name = "Prequalification-Questionnaire")
@RestController
@RequestMapping("/v1/public/criteria")
@Validated
@AllArgsConstructor
public class PrequalificationQuestionnaireController {
  private final IPrequalificationQuestionnaireFacade prequalificationQuestionnaireFacade;
  private final MessageUtility messageUtility;
  private static final Logger logger = LoggerFactory.getLogger(PrequalificationQuestionnaireController.class);


  @Operation(summary = "Creating Questions.",
      description = "Creating Questions on the basis of criteria id and category code."
      , security = @SecurityRequirement(name = "BearerAuthentication"))
  @Parameter(name = "acceptLanguage", description = "Default Language is English",
      in = ParameterIn.HEADER, example = "eng", schema = @Schema(minLength = 2, maxLength = 6))
  @ApiResponse(responseCode = "200", description = "OK",
      useReturnTypeSchema = true)
  @ApiResponse(responseCode = "400",
      description = "Invalid input",
      content = @Content)
  @ApiResponse(responseCode = "401",
      description = " Unauthorized - Invalid or missing token",
      content = @Content)
  @ApiResponse(responseCode = "403",
      description = "Forbidden - Token does not have the required permissions",
      content = @Content)
  @ApiResponse(responseCode = "404",
      description = "resource not found",
      content = @Content)
  @ApiResponse(responseCode = "500",
      description = "Internal Server Error",
      content = @Content)
  @PostMapping(value = "/{criteriaId}/categories/{categoryCode}/questions")
  public ResponseEntity<APIResponse<CreateQuestionResponseDTO>> createQuestion(@RequestHeader(value = "Accept-Language") String acceptLanguage,
                                                                               @Valid @PathVariable UUID criteriaId,
                                                                               @Valid @PathVariable UUID categoryCode,
                                                                               @Valid @RequestPart(name = "file", required = false)
                                                                                 MultipartFile[] file, @Valid @RequestPart
                                                                                QuestionCreateRequestDTO request
  ) throws IOException {

    logger.info("Entering createQuestion with criteriaId: {} and categoryCode: {}", criteriaId, categoryCode);
    logger.debug("Request payload for createQuestion: {}", request);

    final CreateQuestionResponseDTO response = prequalificationQuestionnaireFacade.createQuestion(acceptLanguage, criteriaId, categoryCode, file, request);

    logger.debug("Response from createQuestion: {}", response);
    logger.info("Exiting createQuestion with response: {}", response);

    return ResponseEntity.ok().body(APIResponse.<CreateQuestionResponseDTO>builder()
        .msId(Constants.MSID)
        .status(HttpStatus.OK.getReasonPhrase())
        .httpStatus(HttpStatus.OK.value())
        .message(messageUtility.getMessage(MessageConstants.QUESTION_CREATED))
        .data(response)
        .build());
  }


  @GetMapping("/{criteriaId}/categories/{categoryCode}/questions")
  public ResponseEntity<APIResponse<CreateQuestionResponseDTO>> getQuestions(
      @RequestHeader(value = "Accept-Language", defaultValue = "eng") String acceptLanguage,
      @Valid @PathVariable UUID criteriaId,
      @Valid @PathVariable UUID categoryCode,
      @RequestParam(required = false) Boolean isRequired,
      @RequestParam(required = false) Boolean isMandatory, PaginationParams paginationParams) {

    logger.info("Entering getQuestions with criteriaId: {} and categoryCode: {}", criteriaId, categoryCode);
    logger.debug("Fetching questions with filters: isRequired={}, isMandatory={}", isRequired, isMandatory);

    QuestionFilter questionFilter = new QuestionFilter();
    questionFilter.setIsRequired(isRequired);
    questionFilter.setIsMandatory(isMandatory);

    final CreateQuestionResponseDTO response = prequalificationQuestionnaireFacade.getQuestions(acceptLanguage,
        criteriaId, categoryCode, questionFilter, paginationParams);

    logger.debug("Response from getQuestions: {}", response);
    logger.info("Exiting getQuestions with response: {}", response);

    return ResponseEntity.status(HttpStatus.OK)
        .body(ApiResponseBuilder.build(HttpStatus.OK, messageUtility
            .getMessage(MessageConstants.SUCCESS_MESSAGE), response));
  }


  @DeleteMapping(path = "{criteriaId}/categories/{categoryCode}/questions/{questionId}")
  public ResponseEntity<APIResponse<MessageResponseDTO>> deleteQuestion(
      @RequestHeader("Accept-Language") String acceptLanguage,
      @Valid @PathVariable UUID categoryCode, @Valid @PathVariable UUID criteriaId, @Valid @PathVariable UUID questionId) {

    logger.info("Entering deleteQuestion with criteriaId: {}, categoryCode: {}, and questionId: {}", criteriaId, categoryCode, questionId);

    MessageResponseDTO response = prequalificationQuestionnaireFacade.deleteQuestion(
        acceptLanguage, categoryCode,criteriaId, questionId);

    logger.debug("Response from deleteQuestion: {}", response);
    logger.info("Exiting deleteQuestion with response: {}", response);

    return ResponseEntity.status(HttpStatus.OK).body(
        APIResponse.<MessageResponseDTO>builder()
            .status(HttpStatus.OK.getReasonPhrase())
            .httpStatus(HttpStatus.OK.value())
            .message(messageUtility.getMessage(MessageConstants.SUCCESS_MESSAGE))
            .data(response)
            .msId(Constants.MSID)
            .build()
    );
  }

  @PutMapping("{criteriaId}/categories/{categoryCode}/questions/{questionsId}")
  public ResponseEntity<APIResponse<MessageResponseDTO>> updateQuestions(
      @RequestHeader(value = "Accept-Language", defaultValue = "eng") String acceptLanguage,
      @PathVariable UUID  categoryCode,
      @PathVariable UUID criteriaId,
      @PathVariable UUID questionsId,
      @RequestBody @Valid QuestionUpdateRequestDTO requests) {

    logger.info("Entering updateQuestions with criteriaId: {}, categoryCode: {}, and questionsId: {}", criteriaId, categoryCode, questionsId);
    logger.debug("Request payload for updateQuestions: {}", requests);

    final MessageResponseDTO response = prequalificationQuestionnaireFacade.updateQuestions(acceptLanguage, categoryCode, criteriaId, questionsId, requests);

    logger.debug("Response from updateQuestions: {}", response);
    logger.info("Exiting updateQuestions with response: {}", response);

    return ResponseEntity.status(HttpStatus.OK).body(
        APIResponse.<MessageResponseDTO>builder()
            .status(HttpStatus.OK.getReasonPhrase())
            .httpStatus(HttpStatus.OK.value())
            .message(messageUtility.getMessage(MessageConstants.SUCCESS_MESSAGE))
            .data(response)
            .msId(Constants.MSID)
            .build()
    );
  }

  @PostMapping(value = "{criteriaId}/categories/{categoryCode}/questions/{questionId}/attachment")
  public ResponseEntity<APIResponse<UploadDocumentsResponseDTO>> uploadDocument(@RequestHeader(value = "Accept-Language") String acceptLanguage,
                                                                               @Valid @PathVariable UUID categoryCode,
                                                                               @Valid @PathVariable UUID criteriaId,
                                                                               @Valid @PathVariable UUID questionId,
                                                                               @Valid @RequestPart("file")
                                                                               MultipartFile[] file) throws IOException {

    logger.info("Entering uploadDocument with criteriaId: {}, categoryCode: {}, and questionId: {}", criteriaId, categoryCode, questionId);

    final UploadDocumentsResponseDTO response = prequalificationQuestionnaireFacade.uploadDocument(acceptLanguage, categoryCode, criteriaId, questionId, file);

    logger.debug("Response from uploadDocument: {}", response);
    logger.info("Exiting uploadDocument with response: {}", response);

    return ResponseEntity.ok().body(APIResponse.<UploadDocumentsResponseDTO>builder()
        .msId(Constants.MSID)
        .status(HttpStatus.OK.getReasonPhrase())
        .httpStatus(HttpStatus.OK.value())
        .message(messageUtility.getMessage(MessageConstants.UPLOAD_DOCUMENTS))
        .data(response)
        .build());
  }


  @DeleteMapping(path = "{criteriaId}/categories/{categoryCode}/questions/{questionId}/attachment/{attachmentId}")
  public ResponseEntity<APIResponse<DeleteUploadedDocumentsResponseDTO>> deleteUploadedDocuments(
      @RequestHeader("Accept-Language") String acceptLanguage,
      @Valid @PathVariable UUID categoryCode,
      @Valid @PathVariable UUID criteriaId,
      @Valid @PathVariable UUID questionId,
      @Valid @PathVariable UUID attachmentId) {

    logger.info("Entering deleteUploadedDocuments with criteriaId: {}, categoryCode: {}, questionId: {}, and attachmentId: {}", criteriaId, categoryCode, questionId, attachmentId);

    DeleteUploadedDocumentsResponseDTO response = prequalificationQuestionnaireFacade.deleteUploadedDocuments(
        acceptLanguage, categoryCode, criteriaId, questionId, attachmentId);

    logger.debug("Response from deleteUploadedDocuments: {}", response);
    logger.info("Exiting deleteUploadedDocuments with response: {}", response);

    return ResponseEntity.status(HttpStatus.OK).body(
        APIResponse.<DeleteUploadedDocumentsResponseDTO>builder()
            .status(HttpStatus.OK.getReasonPhrase())
            .httpStatus(HttpStatus.OK.value())
            .message(messageUtility.getMessage(MessageConstants.DELETE_DOCUMENT))
            .data(response)
            .msId(Constants.MSID)
            .build()
    );
  }

  @DeleteMapping("/{criteriaId}/categories/{categoryCode}/questions")
  public ResponseEntity<APIResponse<MessageResponseDTO>> deleteCategoryQuestions(
      @RequestHeader(value = "Accept-Language", defaultValue = "eng") String acceptLanguage,
      @Valid @PathVariable UUID criteriaId,
      @Valid @PathVariable UUID categoryCode) {

    logger.info("Entering deleteCategoryQuestions with criteriaId: {} and categoryCode: {}", criteriaId, categoryCode);

    MessageResponseDTO response = prequalificationQuestionnaireFacade
        .deleteCategoryQuestion(acceptLanguage, criteriaId, categoryCode);

    logger.debug("Response from deleteCategoryQuestions: {}", response);
    logger.info("Exiting deleteCategoryQuestions with response: {}", response);

    return ResponseEntity.status(HttpStatus.OK).body(
        APIResponse.<MessageResponseDTO>builder()
            .status(HttpStatus.OK.getReasonPhrase())
            .httpStatus(HttpStatus.OK.value())
            .message(messageUtility.getMessage(MessageConstants.SUCCESS_MESSAGE))
            .data(response)
            .msId(Constants.MSID)
            .build()
    );
  }
}
