
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * Criteria Management ServiceImpl: Implements the Criteria Management service layer.
 */

package in.gov.gem.app.fa.pq.service.impl;

import in.gov.gem.app.exception.generic.InvalidInputException;
import in.gov.gem.app.fa.pq.constant.ErrorMessageConstants;
import in.gov.gem.app.fa.pq.constant.LookupConstants;
import in.gov.gem.app.exception.generic.NotFoundException;
import in.gov.gem.app.fa.pq.domain.entity.PqCriteria;
import in.gov.gem.app.fa.pq.domain.entity.PqCriteriaMaster;
import in.gov.gem.app.fa.pq.domain.repository.PqCriteriaRepository;
import in.gov.gem.app.fa.pq.request.CriteriaIdRequestDTO;
import in.gov.gem.app.fa.pq.response.CategoryResponseDTO;
import in.gov.gem.app.fa.pq.service.PqCriteriaService;
import in.gov.gem.app.fa.pq.transformer.CriteriaManagementTransformer;
import in.gov.gem.app.service.core.utility.MessageUtility;
import lombok.AllArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
@AllArgsConstructor
public class PqCriteriaServiceImpl implements PqCriteriaService {

  private static final Logger logger = LoggerFactory.getLogger(PqCriteriaServiceImpl.class);

  private PqCriteriaRepository pqCriteriaRepository;
  private MessageUtility messageUtility;
  private final CriteriaManagementTransformer criteriaManagementTransformer;

  @Override
  public void createCriteria(String acceptLanguage, CriteriaIdRequestDTO criteriaIdRequestDTO, UUID categoryId, PqCriteriaMaster pqCriteriaMaster) {
    logger.info("Entering createCriteria with acceptLanguage: {}, categoryId: {}", acceptLanguage, categoryId);

    logger.debug("Request payload for createCriteria: {}", criteriaIdRequestDTO);

    if (criteriaIdRequestDTO.getCategories() == null || criteriaIdRequestDTO.getCategories().isEmpty()) {
      return;
    }

    for (CategoryResponseDTO categoryResponseDTO : criteriaIdRequestDTO.getCategories()) {
      logger.debug("Processing categoryResponseDTO: {}", categoryResponseDTO);
      PqCriteria pqCriteria = criteriaManagementTransformer.toPqCriteria(categoryId, criteriaIdRequestDTO, categoryResponseDTO, pqCriteriaMaster);
      if (pqCriteria.getCategoryCode() == null) {
        throw new NotFoundException(ErrorMessageConstants.ACTIVE_CATEGORY_NOT_FOUND, messageUtility.getMessage(ErrorMessageConstants.ACTIVE_CATEGORY_NOT_FOUND));
      }
      PqCriteria existingCriteria = pqCriteriaRepository.findByCategoryCodeAndStatusLookup(pqCriteria.getCategoryCode(), LookupConstants.Status.ACTIVE.getLookupCode());
      if (existingCriteria == null) {
        pqCriteriaRepository.save(pqCriteria);
        logger.info("Saved new PqCriteria: {}", pqCriteria);
      }
    }

    logger.info("Exiting createCriteria");
  }

  @Override
  public List<PqCriteria> fetchCriteria(String acceptLanguage, PqCriteriaMaster pqCriteriaMaster) {
    logger.info("Fetching criteria for PqCriteriaMaster: {}", pqCriteriaMaster);
    List<PqCriteria> pqCriteriaList = pqCriteriaRepository.findByStatusLookupAndPqCriteriaMaster(LookupConstants.Status.ACTIVE.getLookupCode(), pqCriteriaMaster);
    logger.debug("Fetched criteria list: {}", pqCriteriaList);
    return pqCriteriaList;
  }

  @Override
  public void deleteCriteria(String acceptLanguage, PqCriteriaMaster pqCriteriaMaster) {
    logger.info("Deleting criteria for PqCriteriaMaster: {}", pqCriteriaMaster);
    List<PqCriteria> pqCriteriaList = pqCriteriaRepository.findByStatusLookupAndPqCriteriaMaster(LookupConstants.Status.ACTIVE.getLookupCode(), pqCriteriaMaster);
    for (PqCriteria pqCriteria : pqCriteriaList) {
      logger.debug("Marking PqCriteria as inactive: {}", pqCriteria);
      pqCriteria.setStatusLookup(LookupConstants.Status.INACTIVE.getLookupCode());
      pqCriteriaRepository.save(pqCriteria);
      logger.info("Marked PqCriteria as inactive: {}", pqCriteria);
    }
  }

  @Override
  public void deleteCategory(String acceptLanguage, PqCriteriaMaster pqCriteriaMaster, UUID categoryId) {
    logger.info("Deleting category with categoryId: {} for PqCriteriaMaster: {}", categoryId, pqCriteriaMaster);
    PqCriteria pqCriteria = pqCriteriaRepository.findByPqCategoryIdAndCategoryCodeAndStatusLookup(pqCriteriaMaster.getMasterCriteriaId(), categoryId, LookupConstants.Status.ACTIVE.getLookupCode());
    logger.debug("Marking category as inactive: {}", pqCriteria);
    pqCriteria.setStatusLookup(LookupConstants.Status.INACTIVE.getLookupCode());
    pqCriteriaRepository.save(pqCriteria);
    logger.info("Marked category as inactive: {}", pqCriteria);
  }

  @Override
  public PqCriteria fetchByCriteriaIdAndCategoryId(String acceptLanguage, UUID criteriaId, UUID categoryCode) {
    logger.info("Fetching PqCriteria by criteriaId: {} and categoryCode: {}", criteriaId, categoryCode);
    PqCriteria pqCriteria = pqCriteriaRepository.findByPqCategoryIdAndCategoryCode(criteriaId, categoryCode);
    if (pqCriteria == null) {
      throw new NotFoundException(ErrorMessageConstants.CRITERIA_NOT_FOUND, messageUtility.getMessage(ErrorMessageConstants.CRITERIA_NOT_FOUND));
    }
    logger.debug("Fetched PqCriteria: {}", pqCriteria);
    return pqCriteria;
  }

  @Override
  public PqCriteria fetchCategory(String acceptLanguage, UUID categoryCode) {
    logger.info("Fetching category by categoryCode: {}", categoryCode);
    PqCriteria pqCriteria = pqCriteriaRepository.findByCategoryCodeAndStatusLookup(categoryCode, LookupConstants.Status.ACTIVE.getLookupCode());
    logger.debug("Fetched category: {}", pqCriteria);
    return pqCriteria;
  }

  @Override
  public PqCriteria fetchByCriteriaId(String acceptLanguage, UUID criteriaId) {
    logger.info("Fetching PqCriteria by criteriaId: {}", criteriaId);
    PqCriteria pqCriteria = pqCriteriaRepository.findByPqCategoryId(criteriaId);
    logger.debug("Fetched PqCriteria: {}", pqCriteria);
    return pqCriteria;
  }

  @Override
  public PqCriteria fetchActiveCategory(PqCriteriaMaster pqCriteriaMaster, UUID categoryCode) {
    logger.info("Fetching active category by categoryCode: {} for PqCriteriaMaster: {}", categoryCode, pqCriteriaMaster);
    PqCriteria pqCriteria = pqCriteriaRepository.findByStatusLookupAndPqCriteriaMasterAndCategoryCode(LookupConstants.Status.ACTIVE.getLookupCode(), pqCriteriaMaster, categoryCode)
            .orElseThrow(() -> {
              return new InvalidInputException(ErrorMessageConstants.ACTIVE_CATEGORY_NOT_FOUND, messageUtility.getMessage(ErrorMessageConstants.ACTIVE_CATEGORY_NOT_FOUND));
            });
    logger.debug("Fetched active category: {}", pqCriteria);
    return pqCriteria;
  }

  @Override
  public List<PqCriteria> fetchCategories(PqCriteriaMaster pqCriteriaMaster) {
    logger.info("Fetching categories for PqCriteriaMaster: {}", pqCriteriaMaster);
    List<PqCriteria> pqCriteriaList = pqCriteriaRepository.findByStatusLookupAndPqCriteriaMaster(LookupConstants.Status.ACTIVE.getLookupCode(), pqCriteriaMaster);
    if (pqCriteriaList.isEmpty()) {
      throw new NotFoundException(ErrorMessageConstants.CRITERIA_NOT_FOUND, messageUtility.getMessage(ErrorMessageConstants.CRITERIA_NOT_FOUND));
    }
    logger.debug("Fetched categories: {}", pqCriteriaList);
    return pqCriteriaList;
  }
}