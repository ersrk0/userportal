
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * Criteria Management ServiceImpl: Implements the Criteria Management service layer.
 */
package in.gov.gem.app.fa.pq.service;

import in.gov.gem.app.fa.pq.domain.entity.PqResponse;
import in.gov.gem.app.fa.pq.domain.entity.PqResponseOptionMap;

import java.util.List;

public interface PqResponseOptionMappingService {
     void savePqResponseOptionMapping(PqResponseOptionMap pqResponseOptionMap);
     void deleteById(Long id);
     List<PqResponseOptionMap> findAllByPqResponse(PqResponse pqResponse);

}
