package in.gov.gem.app.fa.pq.facade;

import in.gov.gem.app.fa.pq.request.RepresentationRequestDTO;
import in.gov.gem.app.fa.pq.request.RespondRepresentationRequestDTO;
import in.gov.gem.app.fa.pq.response.RaiseRepresentationResponseDTO;
import in.gov.gem.app.fa.pq.response.RepresentationResponseDTO;
import in.gov.gem.app.fa.pq.response.RespondRepresentationResponseDTO;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.UUID;

public interface IRaiseRepresentationFacade {

  RaiseRepresentationResponseDTO raiseRepresentation(String acceptLanguage, UUID criteriaId,
                                                     RepresentationRequestDTO request, MultipartFile[] file) throws IOException;

  RepresentationResponseDTO fetchRepresentation(String acceptLanguage, UUID criteriaId, UUID categoryCode);

  RespondRepresentationResponseDTO responseRepresentation(String acceptLanguage, RespondRepresentationRequestDTO request, MultipartFile[] file) throws IOException;
}
