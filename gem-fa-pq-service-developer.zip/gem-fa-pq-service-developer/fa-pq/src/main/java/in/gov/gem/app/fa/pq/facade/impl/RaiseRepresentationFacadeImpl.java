package in.gov.gem.app.fa.pq.facade.impl;

import in.gov.gem.app.exception.generic.InvalidInputException;
import in.gov.gem.app.exception.generic.ServiceException;
import in.gov.gem.app.exception.utility.ErrorConstant;
import in.gov.gem.app.fa.pq.constant.ErrorMessageConstants;
import in.gov.gem.app.fa.pq.constant.LookupConstants;
import in.gov.gem.app.fa.pq.domain.entity.*;
import in.gov.gem.app.fa.pq.facade.IRaiseRepresentationFacade;
import in.gov.gem.app.fa.pq.request.RepresentationRequestDTO;
import in.gov.gem.app.fa.pq.request.RespondRepresentationRequestDTO;
import in.gov.gem.app.fa.pq.response.CriteriaRepresentationResponseDTO;
import in.gov.gem.app.fa.pq.response.DocAttachmentResponseDTO;
import in.gov.gem.app.fa.pq.response.RaiseRepresentationResponseDTO;
import in.gov.gem.app.fa.pq.response.RepresentationResponseDTO;
import in.gov.gem.app.fa.pq.response.RespondRepresentationResponseDTO;
import in.gov.gem.app.fa.pq.service.DocumentMasterService;
import in.gov.gem.app.fa.pq.service.DocAttachmentService;
import in.gov.gem.app.fa.pq.service.DocumentServiceUtil;
import in.gov.gem.app.fa.pq.service.PqCriteriaMasterService;
import in.gov.gem.app.fa.pq.service.PqCriteriaService;
import in.gov.gem.app.fa.pq.service.PqParticipateService;
import in.gov.gem.app.fa.pq.service.PqRepresentationService;
import in.gov.gem.app.fa.pq.transformer.PqRepresentationTransformer;
import in.gov.gem.app.fa.pq.utility.RequestUtil;
import in.gov.gem.app.service.attachment.utility.S3AttachmentUtility;
import in.gov.gem.app.service.core.utility.MessageUtility;
import in.gov.gem.app.service.dto.CoreLookupDto;
import in.gov.gem.app.service.pack.service.interfaces.CoreLookupService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Component
@AllArgsConstructor
public class RaiseRepresentationFacadeImpl implements IRaiseRepresentationFacade {

  private final PqCriteriaService pqCriteriaService;
  private final DocumentServiceUtil documentServiceUtil;
  private final RequestUtil requestUtil;
  private final CoreLookupService coreLookupService;
  private final DocAttachmentService docAttachmentService;
  private final S3AttachmentUtility s3AttachmentUtility;
  private final PqRepresentationService pqRepresentationService;
  private final PqRepresentationTransformer pqRepresentationTransformer;
  private final PqCriteriaMasterService pqCriteriaMasterService;
  private final DocumentMasterService documentMasterService;
  private final MessageUtility messageUtility;
  private final PqParticipateService pqParticipateService;


  @Override
  @Transactional
  public RaiseRepresentationResponseDTO raiseRepresentation(String acceptLanguage, UUID criteriaId,
                                                            RepresentationRequestDTO request, MultipartFile[] file) throws IOException {
    PqCriteriaMaster pqCriteriaMaster = pqCriteriaMasterService.fetchActiveCriteriaFromCriteriaId(criteriaId);
    PqCriteria pqCriteria = pqCriteriaService.fetchActiveCategory(pqCriteriaMaster, request.getGinCode());
    if (pqCriteriaMaster.getIsRepresentationAllowed() == null || !pqCriteriaMaster.getIsRepresentationAllowed()) {
      throw new InvalidInputException(ErrorMessageConstants.REPRESENTATION_NOT_ALLOWED,
          messageUtility.getMessage(ErrorMessageConstants.REPRESENTATION_NOT_ALLOWED));
    }
    PqParticipant pqParticipant = pqParticipateService.fetchParticipantById(request.getParticipantId(), pqCriteria);
    UUID representationId = requestUtil.generateRandomUUID();
    DocMaster docMaster = null;

    if (file != null) {
      UUID documentId = requestUtil.createRequestId();
      docMaster = documentMasterService.saveDocumentMaster(documentId);
      for (MultipartFile files : file) {
        this.activityLogDocumentUpload(files, docMaster);
      }
    }
    pqRepresentationService.raiseRepresentation(request, pqCriteria, docMaster, pqParticipant, representationId);
    List<DocAttachment> docAttachments = docAttachmentService.fetchAllAttachmentsByQuestion(docMaster);
    return pqRepresentationTransformer.toRaiseRepresentationResponseDTO(docAttachments, docMaster, request, representationId);
  }


  @Override
  @Transactional(readOnly = true)
  public RepresentationResponseDTO fetchRepresentation(String acceptLanguage, UUID criteriaId, UUID categoryCode) {
    PqCriteriaMaster pqCriteriaMaster = pqCriteriaMasterService.fetchActiveCriteriaFromCriteriaId(criteriaId);
    PqCriteria pqCriteria = pqCriteriaService.fetchActiveCategory(pqCriteriaMaster, categoryCode);

    List<PqRepresentation> pqRepresentations = pqRepresentationService.fetchRepresentationByPqCriteria(pqCriteria);

    List<CriteriaRepresentationResponseDTO> representations = pqRepresentations.stream()
        .map(representation -> {
          List<DocAttachmentResponseDTO> attachmentsUploaded = null;
          if (representation.getDocMaster() != null) {
            List<DocAttachment> docAttachments = docAttachmentService.fetchAllAttachmentsByQuestion(representation.getDocMaster());
            attachmentsUploaded = docAttachments.stream()
                .filter(docAttachment -> LookupConstants.Status.ACTIVE.getLookupCode().equals(docAttachment.getStatusLookup()))
                .map(docAttachment -> DocAttachmentResponseDTO.builder()
                    .attachmentId(docAttachment.getAttachmentId())
                    .docType(docAttachment.getAttachmentTypeLookup())
                    .fileName(docAttachment.getAttachmentName())
                    .fileSize(docAttachment.getAttachmentSize())
                    .filePath("/" + LookupConstants.MODULE_PATH + "v1/temporal/criteria/public/view/attachment/" + docAttachment.getAttachmentId())
                    .build())
                .collect(Collectors.toList());
          }
          PqRepresentationResponse pqRepresentationResponse = pqRepresentationService.fetchResponse(representation);
          List<DocAttachmentResponseDTO> responseAttachmentsUploaded = null;
          if (pqRepresentationResponse!=null) {
            if (pqRepresentationResponse.getDocMaster() != null) {
              List<DocAttachment> docAttachments = docAttachmentService.fetchAllAttachmentsByQuestion(representation.getDocMaster());
              responseAttachmentsUploaded = docAttachments.stream()
                  .filter(docAttachment -> LookupConstants.Status.ACTIVE.getLookupCode().equals(docAttachment.getStatusLookup()))
                  .map(docAttachment -> DocAttachmentResponseDTO.builder()
                      .attachmentId(docAttachment.getAttachmentId())
                      .docType(docAttachment.getAttachmentTypeLookup())
                      .fileName(docAttachment.getAttachmentName())
                      .fileSize(docAttachment.getAttachmentSize())
                      .filePath("/" + LookupConstants.MODULE_PATH + "v1/temporal/criteria/public/view/attachment/" + docAttachment.getAttachmentId())
                      .build())
                  .collect(Collectors.toList());
            }
          }
          return pqRepresentationTransformer.toCriteriaRepresentationResponseDTO(pqCriteria, representation, pqRepresentationResponse, attachmentsUploaded, responseAttachmentsUploaded);
        })
        .collect(Collectors.toList());


    return RepresentationResponseDTO.builder()
        .criteriaId(criteriaId)
        .representations(representations)
        .build();
  }



  @Override
  @Transactional
  public RespondRepresentationResponseDTO responseRepresentation(String acceptLanguage, RespondRepresentationRequestDTO request, MultipartFile[] file) throws IOException {
    PqRepresentation pqRepresentation = pqRepresentationService.fetchRepresentationByRepresentationId(request.getRepresentationId());
    pqRepresentation.setStatusLookup(LookupConstants.REPRESENTATION_ANSWERED);

    DocMaster docMaster = null;
    if (file != null) {
      UUID documentId = requestUtil.createRequestId();
      docMaster = documentMasterService.saveDocumentMaster(documentId);
      for (MultipartFile files : file) {
        this.activityLogDocumentUpload(files, docMaster);
      }
    }
    pqRepresentationService.respondRepresentation(pqRepresentation, request, docMaster);

    return pqRepresentationTransformer.toRespondRepresentationResponseDTO(request.getRepresentationId());
  }

  public void activityLogDocumentUpload(MultipartFile file, DocMaster documentMaster)
      throws IOException {
    String fileName = file.getOriginalFilename();
    String docName = file.getContentType();
    assert fileName != null;
    UUID attachmentId = requestUtil.createRequestId();
    documentServiceUtil.fileSizeCheck(file);
    CoreLookupDto lookupDto = null;
    try{
      lookupDto = coreLookupService.findAllByLookupValueIgnoreCase(docName).getFirst();
    }catch (Exception e){
      throw new ServiceException(ErrorMessageConstants.INVALID_FILE_TYPE, messageUtility.getMessage(
          ErrorMessageConstants.INVALID_FILE_TYPE),
          ErrorConstant.CATEGORY.TS, ErrorConstant.SEVERITY.I);
    }

    String docType = lookupDto.getLookupCode();
    String filePath = requestUtil.createPath(LookupConstants.QUESTION_CREATION,attachmentId, fileName);
    docAttachmentService.saveDocumentDetails(documentMaster, filePath, docType, fileName, file.getSize(), attachmentId);
    s3AttachmentUtility.uploadMultipart("gem-consent-service", filePath, file);
  }

}
