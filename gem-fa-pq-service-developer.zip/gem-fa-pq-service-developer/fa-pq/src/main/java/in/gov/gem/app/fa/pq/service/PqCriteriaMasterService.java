
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * Parent Criteria Management Service: Service for Parent Criteria Management details endpoint.
 */

package in.gov.gem.app.fa.pq.service;

import in.gov.gem.app.fa.pq.domain.entity.PqCriteriaMaster;
import in.gov.gem.app.fa.pq.request.CriteriaIdRequestDTO;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
public interface PqCriteriaMasterService {
  PqCriteriaMaster createParentCriteria(String acceptLanguage
      , CriteriaIdRequestDTO criteriaIdRequestDTO, UUID criteriaId);

  PqCriteriaMaster deleteParentCriteria(String acceptLanguage, UUID criteriaId);

  PqCriteriaMaster fetchCriteria(String acceptLanguage, UUID offeringId);

  PqCriteriaMaster fetchCriteriaFromCriteriaId(UUID criteriaId);

  PqCriteriaMaster fetchActiveCriteriaFromCriteriaId(UUID criteriaId);

    PqCriteriaMaster submitRepresentation(PqCriteriaMaster pqCriteriaMaster);
}
