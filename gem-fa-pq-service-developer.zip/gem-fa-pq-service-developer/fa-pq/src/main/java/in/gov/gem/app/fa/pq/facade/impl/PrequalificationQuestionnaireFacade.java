
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * Criteria Management ServiceImpl: Implements the Criteria Management service layer.
 */

package in.gov.gem.app.fa.pq.facade.impl;

import in.gov.gem.app.exception.generic.ServiceException;
import in.gov.gem.app.exception.utility.ErrorConstant;
import in.gov.gem.app.fa.pq.constant.ErrorMessageConstants;
import in.gov.gem.app.fa.pq.constant.LookupConstants;
import in.gov.gem.app.fa.pq.domain.entity.DocAttachment;
import in.gov.gem.app.fa.pq.domain.entity.DocMaster;
import in.gov.gem.app.fa.pq.domain.entity.PqCriteria;
import in.gov.gem.app.fa.pq.domain.entity.PqCriteriaMaster;
import in.gov.gem.app.fa.pq.domain.entity.PqOption;
import in.gov.gem.app.fa.pq.domain.entity.PqQuestion;
import in.gov.gem.app.fa.pq.facade.IPrequalificationQuestionnaireFacade;
import in.gov.gem.app.fa.pq.request.QuestionCreateRequestDTO;
import in.gov.gem.app.fa.pq.request.QuestionFilter;
import in.gov.gem.app.fa.pq.request.QuestionUpdateRequestDTO;
import in.gov.gem.app.fa.pq.response.CreateQuestionResponseDTO;
import in.gov.gem.app.fa.pq.response.DeleteUploadedDocumentsResponseDTO;
import in.gov.gem.app.fa.pq.response.DocAttachmentResponseDTO;
import in.gov.gem.app.fa.pq.response.MessageResponseDTO;
import in.gov.gem.app.fa.pq.response.QuestionResponseDTO;
import in.gov.gem.app.fa.pq.response.UploadDocumentsResponseDTO;
import in.gov.gem.app.fa.pq.service.DocAttachmentService;
import in.gov.gem.app.fa.pq.service.DocumentMasterService;
import in.gov.gem.app.fa.pq.service.DocumentServiceUtil;
import in.gov.gem.app.fa.pq.service.PqCriteriaMasterService;
import in.gov.gem.app.fa.pq.service.PqCriteriaService;
import in.gov.gem.app.fa.pq.service.PqOptionService;
import in.gov.gem.app.fa.pq.service.PqQuestionService;
import in.gov.gem.app.fa.pq.transformer.QuestionCreationTransformer;
import in.gov.gem.app.fa.pq.utility.RequestUtil;
import in.gov.gem.app.fa.pq.validation.response.specification.PqQuestionSpecification;
import in.gov.gem.app.service.attachment.utility.S3AttachmentUtility;
import in.gov.gem.app.service.core.utility.MessageUtility;
import in.gov.gem.app.service.dto.CoreLookupDto;
import in.gov.gem.app.service.dto.PaginationParams;
import in.gov.gem.app.service.pack.service.interfaces.CoreLookupService;
import jakarta.persistence.EntityManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;


@Component
public class PrequalificationQuestionnaireFacade implements IPrequalificationQuestionnaireFacade {

  private final PqCriteriaService pqCriteriaService;
  private final PqCriteriaMasterService pqCriteriaMasterService;
  private final PqQuestionService pqQuestionService;
  private final PqOptionService pqOptionService;
  private final DocumentServiceUtil documentServiceUtil;
  private final CoreLookupService coreLookupService;
  private final DocumentMasterService documentMasterService;
  private final DocAttachmentService docAttachmentService;
  private final RequestUtil requestUtil;
  private final S3AttachmentUtility s3AttachmentUtility;
  private final QuestionCreationTransformer questionCreationTransformer;
  private final MessageUtility messageUtility;
  private static final Logger logger = LoggerFactory.getLogger(PrequalificationQuestionnaireFacade.class);


  public PrequalificationQuestionnaireFacade(PqCriteriaService pqCriteriaService, PqCriteriaMasterService pqCriteriaMasterService, PqQuestionService pqQuestionService,
                                             PqOptionService pqOptionService, CoreLookupService coreLookupService,
                                             DocumentServiceUtil documentServiceUtil,
                                             DocumentMasterService documentMasterService,
                                             DocAttachmentService docAttachmentService, RequestUtil requestUtil,
                                             S3AttachmentUtility s3AttachmentUtility,
                                             QuestionCreationTransformer questionCreationTransformer, MessageUtility messageUtility) {
    this.pqCriteriaService = pqCriteriaService;
    this.pqCriteriaMasterService = pqCriteriaMasterService;
    this.pqQuestionService = pqQuestionService;
    this.pqOptionService = pqOptionService;
    this.coreLookupService = coreLookupService;
    this.documentServiceUtil = documentServiceUtil;
    this.documentMasterService = documentMasterService;
    this.docAttachmentService = docAttachmentService;
    this.requestUtil = requestUtil;
    this.s3AttachmentUtility = s3AttachmentUtility;
    this.questionCreationTransformer = questionCreationTransformer;
    this.messageUtility = messageUtility;
  }


  @Override
  @Transactional(rollbackFor = Exception.class)
  public CreateQuestionResponseDTO createQuestion(String acceptLanguage, UUID criteriaId, UUID categoryCode,
                                                  MultipartFile[] file, QuestionCreateRequestDTO request) throws IOException {

    logger.info("Entering createQuestion with criteriaId: {}, categoryCode: {}, and request: {}", criteriaId, categoryCode, request);

    PqCriteriaMaster pqCriteriaMaster = pqCriteriaMasterService.fetchActiveCriteriaFromCriteriaId(criteriaId);
    PqCriteria pqCriteria = pqCriteriaService.fetchActiveCategory(pqCriteriaMaster, categoryCode);

    logger.debug("Fetched PqCriteriaMaster: {} and PqCriteria: {}", pqCriteriaMaster, pqCriteria);

    List<PqQuestion> pqQuestions = pqQuestionService.fetchQuestionByCriteria(pqCriteria);
    if (!pqQuestions.isEmpty()) {
      int totalScore = pqQuestions.stream()
          .map(PqQuestion::getWeightage)
          .mapToInt(BigDecimal::intValue)
          .sum();
      logger.debug("Total score of existing questions: {}", totalScore);

      if (totalScore >= 100) {
        throw new ServiceException(ErrorMessageConstants.INVALID_QUESTION, messageUtility.getMessage(
            ErrorMessageConstants.INVALID_QUESTION),
            ErrorConstant.CATEGORY.TS, ErrorConstant.SEVERITY.I);
      }
      if (request.getScore()!=null&&BigDecimal.valueOf(totalScore).add(request.getScore()).compareTo(BigDecimal.valueOf(100)) > 0) {
        throw new ServiceException(ErrorMessageConstants.INVALID_QUESTION_SCORE, messageUtility.getMessage(
            ErrorMessageConstants.INVALID_QUESTION_SCORE),
            ErrorConstant.CATEGORY.TS, ErrorConstant.SEVERITY.I);
      }
    }

    UUID questionId = requestUtil.createRequestId();
    logger.debug("Generated questionId: {}", questionId);

    DocMaster docMaster = null;

    if (file != null) {
      UUID documentId = requestUtil.createRequestId();
      docMaster = documentMasterService.saveDocumentMaster(documentId);
      logger.debug("Saved document master with documentId: {}", documentId);

      for (MultipartFile files : file) {
        this.activityLogDocumentUpload(files, docMaster);
      }
    }

    if (request.getInputType().equals(LookupConstants.INPUT_TYPE_DATE)&&request.getIsDateRange().equals(Boolean.TRUE)){
      request.setInputType(LookupConstants.INPUT_TYPE_DATE_TO_DATE);
    }
    else {
      if (request.getInputType().equals(LookupConstants.INPUT_TYPE_DATE)&&request.getIsDateRange().equals(Boolean.FALSE))
      {
        request.setInputType(LookupConstants.INPUT_TYPE_FIXED_DATE);
      }
    }

    PqQuestion savedQuestion = pqQuestionService.createQuestion(acceptLanguage, request,
        pqCriteria, questionId, docMaster);
    logger.debug("Saved question: {}", savedQuestion);

    List<PqOption> pqOption = new ArrayList<>();
    if (request.getInputType().equals(LookupConstants.INPUT_TYPE_SINGLE_CHOICE) ||
        request.getInputType().equals(LookupConstants.INPUT_TYPE_MULTIPLE_CHOICE)) {
      pqOption = pqOptionService.createOptions(request, savedQuestion);
      logger.debug("Created options for question: {}", pqOption);
    }

    List<DocAttachment> docAttachments = docAttachmentService.fetchAllAttachmentsByQuestion(docMaster);
    logger.debug("Fetched document attachments: {}", docAttachments);

    CreateQuestionResponseDTO response;
    if (docMaster != null) {
      response = questionCreationTransformer.toCreateQuestionResponseDTO(criteriaId, request, savedQuestion, docMaster, docAttachments, pqOption);
    } else {
      response = questionCreationTransformer.toQuestionResponseDTO(criteriaId, request, savedQuestion, pqOption);
    }

    logger.info("Exiting createQuestion with response: {}", response);
    return response;
  }

  public void activityLogDocumentUpload(MultipartFile file, DocMaster documentMaster)
      throws IOException {
    logger.info("Entering activityLogDocumentUpload with file: {} and documentMaster: {}", file.getOriginalFilename(), documentMaster);

    String fileName = file.getOriginalFilename();
    String docName = file.getContentType();
    assert fileName != null;
    UUID attachmentId = requestUtil.createRequestId();
    logger.debug("Generated attachmentId: {}", attachmentId);

    documentServiceUtil.fileSizeCheck(file);
    logger.debug("File size check passed for file: {}", fileName);

    CoreLookupDto lookupDto = null;
    try{
      lookupDto = coreLookupService.findAllByLookupValueIgnoreCase(docName).getFirst();
    }catch (Exception e){
      logger.error("Invalid file type: {}", docName, e);
      throw new ServiceException(ErrorMessageConstants.INVALID_FILE_TYPE, messageUtility.getMessage(
          ErrorMessageConstants.INVALID_FILE_TYPE),
          ErrorConstant.CATEGORY.TS, ErrorConstant.SEVERITY.I);
    }

    String docType = lookupDto.getLookupCode();
    String filePath = requestUtil.createPath(LookupConstants.QUESTION_CREATION,attachmentId, fileName);
    logger.debug("Generated file path: {}", filePath);

    docAttachmentService.saveDocumentDetails(documentMaster, filePath, docType, fileName, file.getSize(), attachmentId);
    logger.debug("Saved document details for file: {}", fileName);

    s3AttachmentUtility.uploadMultipart("gem-consent-service", filePath, file);
    logger.info("Uploaded file to S3: {}", filePath);

    logger.info("Exiting activityLogDocumentUpload");
  }


  @Override
  @Transactional(readOnly = true)
  public CreateQuestionResponseDTO getQuestions(String acceptLanguage, UUID criteriaId, UUID categoryCode, QuestionFilter questionFilter, PaginationParams paginationParams) {
    logger.info("Entering getQuestions with criteriaId: {}, categoryCode: {}, and filters: {}", criteriaId, categoryCode, questionFilter);

    PqCriteriaMaster pqCriteriaMaster = pqCriteriaMasterService.fetchActiveCriteriaFromCriteriaId(criteriaId);
    PqCriteria pqCriteria = pqCriteriaService.fetchActiveCategory(pqCriteriaMaster, categoryCode);

    logger.info("Entering getQuestions with criteriaId: {}, categoryCode: {}, and filters: {}", criteriaId, categoryCode, questionFilter);

    var filterSpecs = PqQuestionSpecification.criteria(pqCriteria)
            .and(PqQuestionSpecification.inStatus(List.of(LookupConstants.Status.ACTIVE.getLookupCode())));


    if (questionFilter.getIsRequired() != null) {
      filterSpecs = filterSpecs.and(PqQuestionSpecification.isDocumentRequired(questionFilter.getIsRequired()));
    }
    if (questionFilter.getIsMandatory() != null) {
      filterSpecs = filterSpecs.and(PqQuestionSpecification.isMandatory(questionFilter.getIsMandatory()));
    }

    logger.debug("Applied filter specifications: {}", filterSpecs);

    final Pageable pageRequest = PageRequest.of(paginationParams.getPageNumber(), paginationParams.getPageSize(),
        Sort.by(paginationParams.getSortOrder(), paginationParams.getSortBy()));
    var test = pqQuestionService.getQuestionsWithFilter(filterSpecs, pageRequest);

    logger.debug("Fetched questions with pagination: {}", test);

    List<QuestionResponseDTO> questionResponseDTOS = test.stream()
        .map(question -> {
          List<PqOption> pqOptions = pqOptionService.fetchOptionByQuestion(question);
          List<Map<String, Object>> optionValues = pqOptions.stream()
              .map(option -> Map.<String, Object>of(
                  "id", option.getId(),
                  "value", option.getOptionValue()
              ))
              .toList();

          List<DocAttachmentResponseDTO> attachmentResponseDTOS = null;
          if (question.getDocMaster() != null) {
            List<DocAttachment> docAttachments = docAttachmentService.fetchAllAttachmentsByQuestion(question.getDocMaster());
            attachmentResponseDTOS = docAttachments.stream()
                .filter(docAttachment -> LookupConstants.Status.ACTIVE.getLookupCode().equals(docAttachment.getStatusLookup()))
                .map(docAttachment -> DocAttachmentResponseDTO.builder()
                    .attachmentId(docAttachment.getAttachmentId())
                    .docType(docAttachment.getAttachmentTypeLookup())
                    .fileName(docAttachment.getAttachmentName())
                    .fileSize(docAttachment.getAttachmentSize())
                    .filePath("/"+LookupConstants.MODULE_PATH+"v1/temporal/criteria/public/view/attachment/"+ docAttachment.getAttachmentId())
                    .build())
                .collect(Collectors.toList());
          }

          return questionCreationTransformer.convertToQuestionResponseDTO(question, optionValues, attachmentResponseDTOS);
        })
        .toList();

    CreateQuestionResponseDTO createQuestionResponseDTO = new CreateQuestionResponseDTO();
    createQuestionResponseDTO.setCriteriaId(criteriaId);
    createQuestionResponseDTO.setQuestions(questionResponseDTOS);

    logger.info("Exiting getQuestions with response: {}", createQuestionResponseDTO);
    return createQuestionResponseDTO;
  }


  @Override
  @Transactional
  public MessageResponseDTO deleteQuestion(String acceptLanguage, UUID categoryCode, UUID criteriaId, UUID questionId) {
    logger.info("Entering deleteQuestion with criteriaId: {}, categoryCode: {}, and questionId: {}", criteriaId, categoryCode, questionId);

    PqCriteriaMaster pqCriteriaMaster = pqCriteriaMasterService.fetchActiveCriteriaFromCriteriaId(criteriaId);
    PqCriteria pqCriteria = pqCriteriaService.fetchActiveCategory(pqCriteriaMaster, categoryCode);
    PqQuestion pqQuestion = pqQuestionService.fetchQuestionByQuestionId(pqCriteria, questionId);

    logger.debug("Fetched PqCriteriaMaster: {}, PqCriteria: {}, and PqQuestion: {}", pqCriteriaMaster, pqCriteria, pqQuestion);

    List<PqOption> pqOption = pqOptionService.fetchOptionByQuestion(pqQuestion);
    if(!pqOption.isEmpty()) {
      pqOptionService.deleteOptions(pqOption);
      logger.debug("Deleted options for questionId: {}", questionId);
    }
    if (pqQuestion.getDocMaster() != null) {
      List<DocAttachment> docAttachments = docAttachmentService.fetchAllAttachmentsByQuestion(pqQuestion.getDocMaster());
      docAttachmentService.deleteDocumentMetadata(docAttachments);
      logger.debug("Deleted document metadata for questionId: {}", questionId);
    }
    pqQuestionService.deleteQuestion(acceptLanguage, pqCriteria, questionId);
    logger.info("Deleted question with questionId: {}", questionId);

    MessageResponseDTO response = questionCreationTransformer.toDeleteQuestionMessageResponseDTO();
    logger.info("Exiting deleteQuestion with response: {}", response);
    return response;
  }

  @Override
  @Transactional
  public MessageResponseDTO updateQuestions(String acceptLanguage, UUID categoryCode,UUID criteriaId, UUID questionsId, QuestionUpdateRequestDTO requests) {
    logger.info("Entering updateQuestions with criteriaId: {}, categoryCode: {}, and questionsId: {}", criteriaId, categoryCode, questionsId);
    logger.debug("Request payload for updateQuestions: {}", requests);

    PqCriteriaMaster pqCriteriaMaster = pqCriteriaMasterService.fetchActiveCriteriaFromCriteriaId(criteriaId);
    PqCriteria pqCriteria = pqCriteriaService.fetchActiveCategory(pqCriteriaMaster, categoryCode);
    PqQuestion pqQuestion = pqQuestionService.fetchQuestionByQuestionId(pqCriteria, questionsId);

    logger.debug("Fetched PqCriteriaMaster: {}, PqCriteria: {}, and PqQuestion: {}", pqCriteriaMaster, pqCriteria, pqQuestion);

    pqQuestionService.updateQuestion(pqQuestion, requests);
    logger.debug("Updated question with questionsId: {}", questionsId);

    if (requests.getInputType().equals(LookupConstants.INPUT_TYPE_SINGLE_CHOICE) ||
        requests.getInputType().equals(LookupConstants.INPUT_TYPE_MULTIPLE_CHOICE)) {
      List<PqOption> pqOptions = pqOptionService.fetchOptionByQuestion(pqQuestion);
      pqOptionService.updateOptions(requests, pqOptions);
      logger.debug("Updated options for questionId: {}", questionsId);
    }

    MessageResponseDTO response = questionCreationTransformer.toUpdateQuestionMessageResponseDTO();
    logger.info("Exiting updateQuestions with response: {}", response);
    return response;
  }

  @Override
  @Transactional(rollbackFor = Exception.class)
  public UploadDocumentsResponseDTO uploadDocument(String acceptLanguage,
                                                   UUID categoryCode, UUID criteriaId, UUID questionsId, MultipartFile[] file)
      throws IOException {
    logger.info("Entering uploadDocument with criteriaId: {}, categoryCode: {}, and questionsId: {}", criteriaId, categoryCode, questionsId);

    PqCriteriaMaster pqCriteriaMaster = pqCriteriaMasterService.fetchActiveCriteriaFromCriteriaId(criteriaId);
    PqCriteria pqCriteria = pqCriteriaService.fetchActiveCategory(pqCriteriaMaster, categoryCode);
    PqQuestion pqQuestion = pqQuestionService.fetchQuestionByQuestionId(pqCriteria, questionsId);

    logger.debug("Fetched PqCriteriaMaster: {}, PqCriteria: {}, and PqQuestion: {}", pqCriteriaMaster, pqCriteria, pqQuestion);

    if (pqQuestion.getDocMaster()==null) {
      UUID documentId = requestUtil.createRequestId();
      DocMaster documentMaster = documentMasterService.saveDocumentMaster(documentId);
      pqQuestionService.saveDocument(documentMaster, pqQuestion);
      logger.debug("Saved document master for questionId: {}", questionsId);
    }
    List<UUID> attachmentIds = new ArrayList<>();
    for (MultipartFile files : file) {
      UUID attachmentId = requestUtil.createRequestId();
      String fileName = files.getOriginalFilename();
      String docName = files.getContentType();
      assert fileName != null;

      documentServiceUtil.fileSizeCheck(files);
      logger.debug("File size check passed for file: {}", fileName);

      CoreLookupDto lookupDto = null;
      try{
        lookupDto = coreLookupService.findAllByLookupValueIgnoreCase(docName).getFirst();
      }catch (Exception e){
        logger.error("Invalid file type: {}", docName, e);
        throw new ServiceException(ErrorMessageConstants.INVALID_FILE_TYPE, messageUtility.getMessage(
            ErrorMessageConstants.INVALID_FILE_TYPE),
            ErrorConstant.CATEGORY.TS, ErrorConstant.SEVERITY.I);
      }
      String docType = lookupDto.getLookupCode();
      String filePath = requestUtil.createPathUploadDocument(LookupConstants.QUESTION_CREATION, fileName, questionsId);

      docAttachmentService.saveDocumentDetails(pqQuestion.getDocMaster(), filePath, docType, fileName, files.getSize(), attachmentId);
      s3AttachmentUtility.uploadMultipart("gem-consent-service", filePath, file);
      attachmentIds.add(attachmentId);
      logger.debug("Uploaded file to S3 with filePath: {}", filePath);
    }
    UploadDocumentsResponseDTO response = questionCreationTransformer.toUploadDocumentResponseDTO(attachmentIds, pqQuestion);
    logger.info("Exiting uploadDocument with response: {}", response);
    return response;
  }


  @Override
  @Transactional
  public DeleteUploadedDocumentsResponseDTO deleteUploadedDocuments(String acceptLanguage, UUID categoryCode, UUID criteriaId, UUID questionId, UUID attachmentId) {
    logger.info("Entering deleteUploadedDocuments with criteriaId: {}, categoryCode: {}, questionId: {}, and attachmentId: {}", criteriaId, categoryCode, questionId, attachmentId);

    PqCriteriaMaster pqCriteriaMaster = pqCriteriaMasterService.fetchActiveCriteriaFromCriteriaId(criteriaId);
    PqCriteria pqCriteria = pqCriteriaService.fetchActiveCategory(pqCriteriaMaster, categoryCode);
    PqQuestion pqQuestion = pqQuestionService.fetchQuestionByQuestionId(pqCriteria, questionId);

    logger.debug("Fetched PqCriteriaMaster: {}, PqCriteria: {}, and PqQuestion: {}", pqCriteriaMaster, pqCriteria, pqQuestion);

    List<DocAttachment> docAttachments = docAttachmentService.fetchAllAttachmentsByQuestion(pqQuestion.getDocMaster());
    DocAttachment matchingAttachment = docAttachments.stream()
            .filter(docAttachment -> docAttachment.getAttachmentId().equals(attachmentId))
            .findFirst()
            .orElse(null);

    assert matchingAttachment != null;
    docAttachmentService.deleteDocumentByAttachmentId(matchingAttachment.getAttachmentId(), pqQuestion.getDocMaster());
    logger.debug("Deleted document attachment with attachmentId: {}", attachmentId);

    DeleteUploadedDocumentsResponseDTO response = questionCreationTransformer.toDeleteDocumentMessageResponseDTO(attachmentId);
    logger.info("Exiting deleteUploadedDocuments with response: {}", response);
    return response;
  }

  @Override
  @Transactional
  public MessageResponseDTO deleteCategoryQuestion(String acceptLanguage, UUID criteriaId, UUID categoryCode) {
    logger.info("Entering deleteCategoryQuestion with criteriaId: {} and categoryCode: {}", criteriaId, categoryCode);

    PqCriteriaMaster pqCriteriaMaster = pqCriteriaMasterService.fetchActiveCriteriaFromCriteriaId(criteriaId);
    PqCriteria pqCriteria = pqCriteriaService.fetchActiveCategory(pqCriteriaMaster, categoryCode);
    List<PqQuestion> pqQuestionList = pqQuestionService.fetchQuestionByCriteria(pqCriteria);

    logger.debug("Fetched PqCriteriaMaster: {}, PqCriteria: {}, and PqQuestionList: {}", pqCriteriaMaster, pqCriteria, pqQuestionList);

    deleteAllOptions(pqQuestionList);
    pqQuestionService.deleteAllQuestions(pqQuestionList);
    logger.debug("Deleted all questions and options for categoryCode: {}", categoryCode);

    MessageResponseDTO response = questionCreationTransformer.toDeleteCategoryQuestionMessageResponseDTO();
    logger.info("Exiting deleteCategoryQuestion with response: {}", response);
    return response;
  }

  public void deleteAllOptions(List<PqQuestion> pqQuestionList) {
    logger.info("Entering deleteAllOptions for PqQuestionList: {}", pqQuestionList);

    for (PqQuestion pqQuestion : pqQuestionList) {
      List<PqOption> pqOption = pqOptionService.fetchOptionByQuestion(pqQuestion);
      if (!pqOption.isEmpty()) {
        pqOptionService.deleteOptions(pqOption);
        logger.debug("Deleted options for questionId: {}", pqQuestion.getId());
      }
      if (pqQuestion.getDocMaster() != null) {
        List<DocAttachment> docAttachments = docAttachmentService.fetchAllAttachmentsByQuestion(pqQuestion.getDocMaster());
        docAttachmentService.deleteDocumentMetadata(docAttachments);
        logger.debug("Deleted document metadata for questionId: {}", pqQuestion.getId());
      }
    }

    logger.info("Exiting deleteAllOptions");
  }
}
