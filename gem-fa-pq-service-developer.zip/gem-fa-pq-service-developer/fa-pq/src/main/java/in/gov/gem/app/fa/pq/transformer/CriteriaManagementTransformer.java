
/*
 * This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * Criteria Management Transformer: Transformer layer to transform an entity to dto & vice versa.
 */

package in.gov.gem.app.fa.pq.transformer;

import in.gov.gem.app.fa.pq.constant.LookupConstants;
import in.gov.gem.app.fa.pq.constant.MessageConstants;
import in.gov.gem.app.fa.pq.domain.entity.DocAttachment;
import in.gov.gem.app.fa.pq.domain.entity.DocMaster;
import in.gov.gem.app.fa.pq.domain.entity.PqCriteria;
import in.gov.gem.app.fa.pq.domain.entity.PqCriteriaMaster;
import in.gov.gem.app.fa.pq.request.CriteriaIdRequestDTO;
import in.gov.gem.app.fa.pq.response.*;
import in.gov.gem.app.fa.pq.service.DocAttachmentService;
import in.gov.gem.app.service.core.utility.MessageUtility;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Component
@AllArgsConstructor
public class CriteriaManagementTransformer {

  private final MessageUtility messageUtility;
  private final DocAttachmentService docAttachmentService;


  public CriteriaIdResponseDTO toCriteriaIdResponseDTO(UUID criteriaId, CriteriaIdRequestDTO criteriaIdRequestDTO) {
    return CriteriaIdResponseDTO.builder()
        .criteriaId(criteriaId)
        .offeringId(criteriaIdRequestDTO.getOfferingId())
        .pqStartDate(criteriaIdRequestDTO.getPqStartDate())
        .pqEndDate(criteriaIdRequestDTO.getPqEndDate())
        .categories(criteriaIdRequestDTO.getCategories())
        .representationAllowed(criteriaIdRequestDTO.getRepresentationAllowed())
        .status(criteriaIdRequestDTO.getStatus())
        .build();
  }

  public CriteriaIdResponseDTO toCriteriaIdResponse(PqCriteriaMaster pqCriteriaMaster,
                                                     List<CategoryResponseDTO> categoryResponseDTOList) {
    return CriteriaIdResponseDTO.builder()
        .criteriaId(pqCriteriaMaster.getMasterCriteriaId())
        .offeringId(pqCriteriaMaster.getOfferingId())
        .pqStartDate(pqCriteriaMaster.getPqSubmissionStart())
        .pqEndDate(pqCriteriaMaster.getPqSubmissionEnd())
        .categories(categoryResponseDTOList)
        .status(pqCriteriaMaster.getStatusLookup())
        .representationAllowed(pqCriteriaMaster.getIsRepresentationAllowed())
        .build();
  }

  public MessageResponseDTO toDeleteCriteriaMessageResponseDTO() {
    return MessageResponseDTO.builder()
        .messageCode(MessageConstants.DELETE_CRITERIA)
        .message(messageUtility.getMessage(MessageConstants.DELETE_CRITERIA))
        .build();
  }

  public MessageResponseDTO toDeleteCategoryMessageResponseDTO() {
    return MessageResponseDTO.builder()
        .messageCode(MessageConstants.DELETE_CATEGORY)
        .message(messageUtility.getMessage(MessageConstants.DELETE_CATEGORY))
        .build();
  }

  public PqCriteria toPqCriteria(UUID categoryId, CriteriaIdRequestDTO criteriaIdRequestDTO
      , CategoryResponseDTO categoryResponseDTO, PqCriteriaMaster pqCriteriaMaster) {
    return PqCriteria.builder()
        .pqCategoryId(categoryId)
        .categoryCode(categoryResponseDTO.getCategoryCode())
        .pqCriteriaMaster(pqCriteriaMaster)
        .criteriaSetBy("to_do")
        .evaluator("to_do") //TODO: fetch from session
        .criteriaName(categoryResponseDTO.getCategoryName())
        .statusLookup(criteriaIdRequestDTO.getStatus())
        .createdBy("to_do")//TODO: fetch from session
        .build();
  }

  public MessageResponseDTO toSyncCriteriaMessageResponseDTO() {
    return MessageResponseDTO.builder()
        .messageCode(MessageConstants.CRITERIA_SYNCED)
        .message(messageUtility.getMessage(MessageConstants.CRITERIA_SYNCED))
        .build();
  }

  public SubmitRepresentationResDTO toSubmitRepresentationDTO(PqCriteriaMaster pqCriteriaMaster)
  {
    SubmitRepresentationResDTO submitRepresentationResDTO =new SubmitRepresentationResDTO();

    if (pqCriteriaMaster.getDocMaster() != null) {
      DocMaster docMaster = pqCriteriaMaster.getDocMaster();
      List<DocAttachment> docAttachment = docAttachmentService.fetchAllAttachmentsByQuestion(docMaster);

      List<RepresentationAttachmentDTO> RepresentationAttachments = new ArrayList<>();
      for(DocAttachment tempDocAttachment: docAttachment) {
        RepresentationAttachmentDTO representationAttachmentDTO = RepresentationAttachmentDTO.builder()
                .fileName(tempDocAttachment.getAttachmentName())
                .fileUrl(LookupConstants.DOCUMENT_PATH + tempDocAttachment.getAttachmentId())
                .attachmentID(tempDocAttachment.getAttachmentId())
                .fileSize(tempDocAttachment.getAttachmentSize())
                .build();
        RepresentationAttachments.add(representationAttachmentDTO);
      }
      submitRepresentationResDTO.setRepresentationAttachmentDTOList( RepresentationAttachments);
    }
    submitRepresentationResDTO.setRemarks(pqCriteriaMaster.getRemarks());
    submitRepresentationResDTO.setRepresentation(pqCriteriaMaster.getIsRepresentationAllowed());
    return submitRepresentationResDTO;
  }

}
