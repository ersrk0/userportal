
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * Pq Clarification Msg Repository: Contains DB function to fetch Pq clarification msg data.
 */
package in.gov.gem.app.fa.pq.facade.impl;

import in.gov.gem.app.fa.pq.constant.LookupConstants;
import in.gov.gem.app.fa.pq.domain.entity.*;
import in.gov.gem.app.fa.pq.facade.IPqChallengeManagementFacade;
import in.gov.gem.app.fa.pq.request.ChallengeReqDTO;
import in.gov.gem.app.fa.pq.request.ResponseOfChallengeReqDTO;
import in.gov.gem.app.fa.pq.response.ChallnegeResDTO;
import in.gov.gem.app.fa.pq.response.ResponseOfChallenegeDTO;
import in.gov.gem.app.fa.pq.service.*;
import in.gov.gem.app.fa.pq.service.impl.PqChallenegeServiceImp;
import in.gov.gem.app.fa.pq.transformer.PqChallengeTransformer;
import in.gov.gem.app.fa.pq.utility.RequestUtil;
import in.gov.gem.app.service.attachment.utility.S3AttachmentUtility;
import in.gov.gem.app.service.dto.CoreLookupDto;
import in.gov.gem.app.service.pack.service.interfaces.CoreLookupService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.UUID;
@Component
@AllArgsConstructor
public class PqChallengeManagementFacade implements IPqChallengeManagementFacade {

    private final RequestUtil requestUtil;
    private final DocumentServiceUtil documentServiceUtil;
    private final CoreLookupService coreLookupService;
    private final DocumentMasterService documentMasterService;
    private final DocAttachmentService docAttachmentService;
    private final S3AttachmentUtility s3AttachmentUtility;
    private final PqAssessmentService pqAssessmentService;
    private final PqChallenegeServiceImp pqChallenegeService;
    private final PqChallengeTransformer pqChallengeTransformer;
    private final PqChallengeResponseService pqChallengeResponseService;

    @Override
    @Transactional
    public ChallnegeResDTO challenegeResponse(UUID assessmentId, ChallengeReqDTO challengeReqDTO) throws IOException {

        DocMaster documentMaster = null;
        MultipartFile file = challengeReqDTO.getSupportingDocuments();
        if (file != null) {
            documentMaster = this.documentUpload(file);
        }

        PqAssessment pqAssessment = pqAssessmentService.fetchAssessmentByAssessmentId(assessmentId);
        PqParticipant pqParticipant = pqAssessment.getPqSubmission().getPqParticipantFk();
        PqChallenge pqChallenge = pqChallenegeService.createChallenege(pqParticipant, pqAssessment, challengeReqDTO, documentMaster,pqAssessment.getAssessmentStatusLookup());

        return pqChallengeTransformer.toChallengeResDTO(pqChallenge);
    }

    @Override
    public DocMaster documentUpload(MultipartFile file) throws IOException {
        String fileName = file.getOriginalFilename();
        String docName = file.getContentType();
        assert fileName != null;
        UUID documentId = requestUtil.createRequestId();
        UUID attachmentId = requestUtil.createRequestId();
        documentServiceUtil.fileSizeCheck(file);
        CoreLookupDto lookupDto = coreLookupService.findAllByLookupValueIgnoreCase(docName).get(0);
        String docType = lookupDto.getLookupCode();
        String filePath = requestUtil.createPath(LookupConstants.QUESTION_CREATION,attachmentId, fileName);
        DocMaster documentMaster = documentMasterService.saveDocumentMaster(documentId);
        docAttachmentService.saveDocumentDetails(documentMaster, filePath, docType, fileName, file.getSize(),attachmentId);
        s3AttachmentUtility.uploadMultipart("gem-consent-service", filePath, file);
        return documentMaster;

    }

    @Override
    public ResponseOfChallenegeDTO ResponseOfChallenge(long challengeId, ResponseOfChallengeReqDTO responseOfChallengeReqDTO) throws IOException {

        DocMaster documentMaster = null;
        MultipartFile file = responseOfChallengeReqDTO.getFile();
        if (file != null) {
            documentMaster = this.documentUpload(file);
        }

        PqChallenge pqChallenge=pqChallenegeService.fetchChallengeById(challengeId);
        PqChallengeResponse pqChallengeResponse= pqChallengeResponseService.createChallengeResponse(responseOfChallengeReqDTO,pqChallenge,documentMaster);
        return pqChallengeTransformer.toResponseOfChallenegeDTO(pqChallengeResponse,pqChallenge);

    }
}
