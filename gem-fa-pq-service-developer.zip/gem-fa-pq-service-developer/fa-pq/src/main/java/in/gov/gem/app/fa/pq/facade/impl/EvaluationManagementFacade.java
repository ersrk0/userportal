
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * Pq Clarification Msg Repository: Contains DB function to fetch Pq clarification msg data.
 */
package in.gov.gem.app.fa.pq.facade.impl;

import in.gov.gem.app.fa.pq.constant.MessageConstants;
import in.gov.gem.app.fa.pq.domain.entity.PqCriteria;
import in.gov.gem.app.fa.pq.domain.entity.PqCriteriaMaster;
import in.gov.gem.app.fa.pq.domain.entity.PqParticipant;
import in.gov.gem.app.fa.pq.domain.entity.PqQuestion;
import in.gov.gem.app.fa.pq.domain.entity.PqResponse;
import in.gov.gem.app.fa.pq.domain.entity.PqSubmission;
import in.gov.gem.app.fa.pq.facade.IEvaluationManagementFacade;
import in.gov.gem.app.fa.pq.request.ScoreRequestDto;
import in.gov.gem.app.fa.pq.response.CategoriesSubmissionResponseDTO;
import in.gov.gem.app.fa.pq.response.CriteriaRepresentationResponseDTO;
import in.gov.gem.app.fa.pq.response.SubmissionListResponseDTO;
import in.gov.gem.app.fa.pq.service.IEvaluationManagementService;
import in.gov.gem.app.fa.pq.service.PqCriteriaMasterService;
import in.gov.gem.app.fa.pq.service.PqCriteriaService;
import in.gov.gem.app.fa.pq.service.PqParticipateService;
import in.gov.gem.app.fa.pq.service.PqQuestionService;
import in.gov.gem.app.fa.pq.service.PqResponseService;
import in.gov.gem.app.fa.pq.service.PqSubmissionService;
import in.gov.gem.app.fa.pq.transformer.PqSubmissionTransformer;
import in.gov.gem.app.service.core.utility.MessageUtility;
import in.gov.gem.app.service.dto.PaginationParams;
import lombok.AllArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Component
@AllArgsConstructor
public class EvaluationManagementFacade implements IEvaluationManagementFacade {

    private final IEvaluationManagementService evaluationManagementService;
    private PqResponseService pqResponseService;
    private PqQuestionService pqQuestionService;
    private PqParticipateService pqParticipateService;
    private final MessageUtility messageUtility;
    private final PqCriteriaMasterService pqCriteriaMasterService;
    private final PqCriteriaService pqCriteriaService;
    private final PqSubmissionService pqSubmissionService;
    private final PqSubmissionTransformer pqSubmissionTransformer;


    /**
     * @param questionId
     * @param participationId
     * @param scoreRequestDto
     * @param acceptLanguage
     * @return
     */

    /**
     * @param questionId
     * @param participationId
     * @param scoreRequestDto
     * @param acceptLanguage
     * @return
     */
    @Override
    public String saveScore(UUID questionId, String participationId, ScoreRequestDto scoreRequestDto, String acceptLanguage) {
        PqQuestion pqQuestion = pqQuestionService.fetchQuestionByQuestionId(questionId);
        PqParticipant pqParticipant = pqParticipateService.fetchParticipantById(participationId, pqQuestion.getPqCriteria());
        PqResponse pqResponse = pqResponseService.fetchPqResponsesByQuestionAndParticipant(pqQuestion, pqParticipant);
        evaluationManagementService.saveScore(scoreRequestDto, acceptLanguage, pqResponse);
        return messageUtility.getMessage(MessageConstants.SUCCESS_MESSAGE);
    }


    @Override
    public SubmissionListResponseDTO fetchCategoriesSubmission(UUID criteriaId, String participationId, String acceptLanguage, PaginationParams paginationParams) {
        PqCriteriaMaster pqCriteriaMaster = pqCriteriaMasterService.fetchActiveCriteriaFromCriteriaId(criteriaId);
        List<PqCriteria> pqCriteriaList = pqCriteriaService.fetchCategories(pqCriteriaMaster);

        List<PqParticipant> pqParticipants = pqCriteriaList.stream()
            .map(pqCriteria -> pqParticipateService.fetchParticipantById(participationId, pqCriteria))
            .toList();

        final Pageable pageRequest = PageRequest.of(paginationParams.getPageNumber(), paginationParams.getPageSize(),
            Sort.by(paginationParams.getSortOrder(), paginationParams.getSortBy()));
        List<PqSubmission> pqSubmissions = pqParticipants.stream()
            .flatMap(participant -> pqSubmissionService.fetchSubmissionByParticipantId(participant, pageRequest).stream())
            .toList();


        List<CategoriesSubmissionResponseDTO> submissions = pqSubmissions.stream()
            .map(pqSubmissionTransformer::toCategoriesSubmissionResponseDTO).toList();

        return SubmissionListResponseDTO.builder()
            .criteriaId(criteriaId)
            .categoriesSubmissionResponseDTOS(submissions)
            .build();
    }
}
