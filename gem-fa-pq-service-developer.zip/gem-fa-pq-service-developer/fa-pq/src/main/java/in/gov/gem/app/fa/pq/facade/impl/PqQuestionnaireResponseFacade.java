
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * Criteria Management ServiceImpl: Implements the Criteria Management service layer.
 */

package in.gov.gem.app.fa.pq.facade.impl;

import in.gov.gem.app.exception.generic.InvalidInputException;
import in.gov.gem.app.exception.generic.ServiceException;
import in.gov.gem.app.exception.utility.ErrorConstant;
import in.gov.gem.app.fa.pq.constant.Constants;
import in.gov.gem.app.fa.pq.constant.ErrorMessageConstants;
import in.gov.gem.app.fa.pq.constant.LookupConstants;
import in.gov.gem.app.fa.pq.constant.MessageConstants;
import in.gov.gem.app.fa.pq.domain.entity.DocAttachment;
import in.gov.gem.app.fa.pq.domain.entity.DocMaster;
import in.gov.gem.app.fa.pq.domain.entity.PqAssessment;
import in.gov.gem.app.fa.pq.domain.entity.PqCriteria;
import in.gov.gem.app.fa.pq.domain.entity.PqCriteriaMaster;
import in.gov.gem.app.fa.pq.domain.entity.PqParticipant;
import in.gov.gem.app.fa.pq.domain.entity.PqQuestion;
import in.gov.gem.app.fa.pq.domain.entity.PqResponse;
import in.gov.gem.app.fa.pq.domain.entity.PqResponseOptionMap;
import in.gov.gem.app.fa.pq.domain.entity.PqSubmission;
import in.gov.gem.app.fa.pq.facade.IPqQuestionnaireResponseFacade;
import in.gov.gem.app.fa.pq.facade.IResponseValidationFacade;
import in.gov.gem.app.fa.pq.request.QuestionnaireResponseSubmitDTO;
import in.gov.gem.app.fa.pq.request.QuestionnaireResponseUpdateDTO;
import in.gov.gem.app.fa.pq.request.SubmissionStatusReqDTO;
import in.gov.gem.app.fa.pq.request.UpdateSubmissionEvaluationDTO;
import in.gov.gem.app.fa.pq.response.AttachmentDetailsResponseDTO;
import in.gov.gem.app.fa.pq.response.CriteriaResponsesDTO;
import in.gov.gem.app.fa.pq.response.CriteriaResponsesDetailsDTO;
import in.gov.gem.app.fa.pq.response.MessageResponseDTO;
import in.gov.gem.app.fa.pq.response.ParticipantCriteriaResponseDTO;
import in.gov.gem.app.fa.pq.response.ParticipantSubmissionsResponseDTO;
import in.gov.gem.app.fa.pq.response.PqDocumentsAnswerDTO;
import in.gov.gem.app.fa.pq.response.PqQuestionResponseDTO;
import in.gov.gem.app.fa.pq.response.SubmitQuestionsResponseDTO;
import in.gov.gem.app.fa.pq.response.UpdateSubmissionEvaluationResponseDTO;
import in.gov.gem.app.fa.pq.service.DocAttachmentService;
import in.gov.gem.app.fa.pq.service.DocumentMasterService;
import in.gov.gem.app.fa.pq.service.DocumentServiceUtil;
import in.gov.gem.app.fa.pq.service.LanguageService;
import in.gov.gem.app.fa.pq.service.PqAssessmentService;
import in.gov.gem.app.fa.pq.service.PqCriteriaMasterService;
import in.gov.gem.app.fa.pq.service.PqCriteriaService;
import in.gov.gem.app.fa.pq.service.PqParticipateService;
import in.gov.gem.app.fa.pq.service.PqQuestionResponseService;
import in.gov.gem.app.fa.pq.service.PqQuestionService;
import in.gov.gem.app.fa.pq.service.PqResponseOptionMappingService;
import in.gov.gem.app.fa.pq.service.PqResponseService;
import in.gov.gem.app.fa.pq.service.PqSubmissionService;
import in.gov.gem.app.fa.pq.transformer.QuestionResponseTransformer;
import in.gov.gem.app.fa.pq.utility.RequestUtil;
import in.gov.gem.app.service.attachment.utility.S3AttachmentUtility;
import in.gov.gem.app.service.core.utility.MessageUtility;
import in.gov.gem.app.service.dto.CoreLookupDto;
import in.gov.gem.app.service.pack.service.interfaces.CoreLookupService;
import jakarta.transaction.Transactional;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

@Component
@AllArgsConstructor
public class PqQuestionnaireResponseFacade implements IPqQuestionnaireResponseFacade {

  private PqQuestionService pqQuestionService;
  private IResponseValidationFacade IResponseValidationFacade;
  private MessageUtility messageUtility;
  private QuestionResponseTransformer questionResponseTransformer;
  private PqQuestionResponseService pqQuestionResponseService;
  private RequestUtil requestUtil;
  private S3AttachmentUtility s3AttachmentUtility;
  private DocAttachmentService docAttachmentService;
  private CoreLookupService coreLookupService;
  private DocumentServiceUtil documentServiceUtil;
  private DocumentMasterService documentMasterService;
  private PqCriteriaMasterService pqCriteriaMasterService;
  private PqCriteriaService pqCriteriaService;
  private PqResponseService pqResponseService;
  private PqParticipateService pqParticipateService;
  private PqSubmissionService pqSubmissionService;
  private PqResponseOptionMappingService pqResponseOptionMappingService;
  private PqAssessmentService pqAssessmentService;
  private LanguageService languageService;



  @Override
  @Transactional
  public PqQuestionResponseDTO submitQuestionResponse(
      UUID criteriaId, UUID questionId,
      QuestionnaireResponseSubmitDTO questionnaireResponseSubmitDTO,
      MultipartFile[] files,
      String participationId
  ) throws IOException {

    PqQuestion pqQuestion = pqQuestionService.fetchQuestionByQuestionId(questionId);
    PqCriteria pqCriteria = pqQuestion.getPqCriteria();
    PqParticipant pqParticipant = pqParticipateService.fetchParticipantById(participationId,pqCriteria);
    PqResponse existingPqResponse = pqQuestionResponseService.fetchResponseByQuestionAndParticipantAndStatusLookupIn(pqQuestion, pqParticipant,
          List.of(LookupConstants.Status.VALID_DRAFT.getLookupCode(),
          LookupConstants.Status.INVALID_DRAFT.getLookupCode(),
          LookupConstants.Status.ACTIVE.getLookupCode()
          )
    );
    if(existingPqResponse != null){
      throw new ServiceException(ErrorMessageConstants.RESPONSE_ALREADY_EXISTS,
              messageUtility.getMessage(ErrorMessageConstants.RESPONSE_ALREADY_EXISTS),
              ErrorConstant.CATEGORY.BV,
              ErrorConstant.SEVERITY.C);
    }
      if(!validateQuestionIdAndCriteriaId(questionId, criteriaId)){
          throw new ServiceException(MessageConstants.INVALID_INPUT,
              messageUtility.getMessage(MessageConstants.INVALID_INPUT),
              ErrorConstant.CATEGORY.BV,
              ErrorConstant.SEVERITY.C);
      }
    UUID submissionId = requestUtil.generateRandomUUID();
    PqResponse pqResponse = null;
    if(!IResponseValidationFacade.validate(pqQuestion,questionnaireResponseSubmitDTO)){
       pqResponse = IResponseValidationFacade.buildPqResponse(submissionId, pqQuestion, questionnaireResponseSubmitDTO,LookupConstants.Status.INVALID_DRAFT.getLookupCode(), pqParticipant);
    }else{
      pqResponse = IResponseValidationFacade.buildPqResponse(submissionId, pqQuestion, questionnaireResponseSubmitDTO,LookupConstants.Status.VALID_DRAFT.getLookupCode(), pqParticipant);
    }
    if(files != null && files.length != 0){
      addDocumentsToResponse(criteriaId,questionId,pqResponse.getPqResponseId(), files,participationId);
    }
      return questionResponseTransformer.toPqQuestionResponseDTO(pqResponse);
  }

  @Override
  @Transactional
  public PqDocumentsAnswerDTO addDocumentsToResponse(UUID criteriaId, UUID questionId, UUID submissionIds,MultipartFile[] files, String participantId) throws IOException {
    pqQuestionResponseService.validateParticipant(participantId, submissionIds);
    if(!validateQuestionIdAndCriteriaId(questionId, criteriaId)){
      throw new ServiceException(MessageConstants.INVALID_INPUT,
              messageUtility.getMessage(MessageConstants.INVALID_INPUT),
              ErrorConstant.CATEGORY.BV,
              ErrorConstant.SEVERITY.C);
    }
    PqResponse pqResponses = pqQuestionResponseService.fetchResponseFromSubmissionId(submissionIds);
    DocMaster docMaster = documentMasterService.saveDocumentMaster(UUID.randomUUID());
    List<UUID> attachmentIds = new ArrayList<>();
    for(MultipartFile file : files){
      attachmentIds.add(activityLogDocumentUpload(file,docMaster));
    }
    pqResponses.setDocMasterFk(docMaster);
    saveAnswer(pqResponses);
    return PqDocumentsAnswerDTO.builder().documentAttachmentId(attachmentIds).build();

  }

  @Override
  public PqQuestionResponseDTO saveAnswers(List<PqResponse> responses) {
    return  pqQuestionResponseService.saveResponseEntity(responses);
  }


  public PqResponse saveAnswer(PqResponse response) {
    return  pqQuestionResponseService.saveResponseEntity(response);
  }

  @Override
  public String deleteSubmittedResponse(UUID criteriaId, UUID questionId, UUID submissionId, String participantId) {
    pqQuestionResponseService.validateParticipant(participantId, submissionId);
    if(!validateQuestionIdAndCriteriaId(questionId, criteriaId)){
      throw new ServiceException(MessageConstants.INVALID_INPUT,
              messageUtility.getMessage(MessageConstants.INVALID_INPUT),
              ErrorConstant.CATEGORY.BV,
              ErrorConstant.SEVERITY.C);
    }
    return pqQuestionResponseService.deleteSubmittedResponse(criteriaId,questionId,submissionId);
  }

  public UUID activityLogDocumentUpload(MultipartFile file, DocMaster documentMaster) throws IOException {
    String fileName = file.getOriginalFilename();
    String docName = file.getContentType();
    assert fileName != null;
    UUID attachmentId = requestUtil.createRequestId();
    documentServiceUtil.fileSizeCheck(file);

    List<CoreLookupDto> lookupDtos = coreLookupService.findAllByLookupValueIgnoreCase(docName);
    if (lookupDtos.isEmpty()) {
      throw new ServiceException(MessageConstants.INVALID_INPUT,
          messageUtility.getMessage(MessageConstants.INVALID_INPUT),
          ErrorConstant.CATEGORY.BV,
          ErrorConstant.SEVERITY.C);
    }

    String docType = lookupDtos.get(0).getLookupCode();
    String filePath = requestUtil.createPath(LookupConstants.QUESTION_CREATION,attachmentId, fileName);
    docAttachmentService.saveDocumentDetails(documentMaster, filePath, docType, fileName, file.getSize(), attachmentId);
    s3AttachmentUtility.uploadMultipart("gem-consent-service", filePath, file);
    return attachmentId;
  }


  @Override
  public MessageResponseDTO updateSubmittedResponse(UUID criteriaId, UUID questionId, UUID submissionId,
                                                    MultipartFile[] files,QuestionnaireResponseUpdateDTO questionnaireResponseUpdateDTO,
                                                    String participantId) throws IOException {
    pqQuestionResponseService.validateParticipant(participantId, submissionId);
    PqResponse pqResponse = pqQuestionResponseService.fetchResponseFromSubmissionId(submissionId);
    if(pqResponse == null){
      throw new ServiceException(MessageConstants.INVALID_INPUT,
          messageUtility.getMessage(MessageConstants.INVALID_INPUT),
          ErrorConstant.CATEGORY.BV,
          ErrorConstant.SEVERITY.C);
    }
    if(!validateQuestionIdAndCriteriaId(questionId, criteriaId)){
      throw new ServiceException(MessageConstants.INVALID_INPUT,
              messageUtility.getMessage(MessageConstants.INVALID_INPUT),
              ErrorConstant.CATEGORY.BV,
              ErrorConstant.SEVERITY.C);
    }

    PqQuestion pqQuestion = pqQuestionService.fetchQuestionByQuestionId(questionId);

    if(!IResponseValidationFacade.validate(pqQuestion,
            QuestionnaireResponseSubmitDTO.builder()
                    .responseType(questionnaireResponseUpdateDTO.getResponseType())
                    .responseValue(questionnaireResponseUpdateDTO.getResponseValue())
                    .build())){

      throw new ServiceException(MessageConstants.INVALID_RESPONSE,
              messageUtility.getMessage(MessageConstants.INVALID_RESPONSE),
              ErrorConstant.CATEGORY.BV,
              ErrorConstant.SEVERITY.C);
    }
    IResponseValidationFacade.updatePqResponse(submissionId, pqQuestion, QuestionnaireResponseSubmitDTO.builder()
            .responseValue(questionnaireResponseUpdateDTO.getResponseValue())
            .responseType(questionnaireResponseUpdateDTO.getResponseType())
            .build());

    if(files != null && files.length != 0){
      addDocumentsToResponse(criteriaId,questionId,pqResponse.getPqResponseId(), files,participantId);
    }
    return MessageResponseDTO.builder()
            .message(messageUtility.getMessage(MessageConstants.SUCCESS_MESSAGE))
            .messageCode(MessageConstants.SUCCESS_MESSAGE)
            .build();

  }

  public boolean validateQuestionIdAndCriteriaId(UUID questionId, UUID criteriaId) {
    PqQuestion pqQuestion = pqQuestionService.fetchQuestionByQuestionId(questionId);
    if (pqQuestion == null) {
      throw new ServiceException(MessageConstants.INVALID_INPUT,
          messageUtility.getMessage(MessageConstants.INVALID_INPUT),
          ErrorConstant.CATEGORY.BV,
          ErrorConstant.SEVERITY.C);
    }

    PqCriteria pqCriteria = pqQuestion.getPqCriteria();
    if (pqCriteria == null || pqCriteria.getPqCriteriaMaster() == null) {
      throw new ServiceException(MessageConstants.INVALID_INPUT,
          messageUtility.getMessage(MessageConstants.INVALID_INPUT),
          ErrorConstant.CATEGORY.BV,
          ErrorConstant.SEVERITY.C);
    }

    PqCriteriaMaster pqCriteriaMaster = pqCriteriaMasterService.fetchActiveCriteriaFromCriteriaId(criteriaId);
    if (pqCriteriaMaster == null) {
      throw new ServiceException(MessageConstants.INVALID_INPUT,
          messageUtility.getMessage(MessageConstants.INVALID_INPUT),
          ErrorConstant.CATEGORY.BV,
          ErrorConstant.SEVERITY.C);
    }

    UUID criteriaMasterId = pqCriteriaMaster.getMasterCriteriaId();
    Long questionCriteriaMasterId = pqCriteria.getPqCriteriaMaster().getId();

    return pqCriteriaMaster.getId().equals(questionCriteriaMasterId) && criteriaMasterId.equals(criteriaId);
  }

  @Override
  public MessageResponseDTO deleteResponseAttachment(UUID criteriaId, UUID questionId, UUID responseId,
                                                     UUID attachmentId) {
    if(!validateQuestionIdAndCriteriaId(questionId, criteriaId)){
      throw new ServiceException(MessageConstants.INVALID_INPUT,
              messageUtility.getMessage(MessageConstants.INVALID_INPUT),
              ErrorConstant.CATEGORY.BV,
              ErrorConstant.SEVERITY.C);
    }
    PqResponse pqResponse = pqQuestionResponseService.fetchResponseFromSubmissionId(responseId);
    if (pqResponse == null) {
      throw new ServiceException(MessageConstants.INVALID_INPUT,
          messageUtility.getMessage(MessageConstants.INVALID_INPUT),
          ErrorConstant.CATEGORY.BV,
          ErrorConstant.SEVERITY.C);
    }
    if(pqResponse.getPqQuestionFk().getPqQuestionId().equals(questionId)) {
      docAttachmentService.deleteDocumentByAttachmentId(attachmentId, pqResponse.getDocMasterFk());
    } else {
      throw new ServiceException(MessageConstants.INVALID_INPUT,
          messageUtility.getMessage(MessageConstants.INVALID_INPUT),
          ErrorConstant.CATEGORY.BV,
          ErrorConstant.SEVERITY.C);
    }
    return MessageResponseDTO.builder()
        .message(messageUtility.getMessage(MessageConstants.SUCCESS_MESSAGE))
        .messageCode(MessageConstants.SUCCESS_MESSAGE)
        .build();
  }

  @Override
  public SubmitQuestionsResponseDTO submitResponseDraft(UUID criteriaId, UUID categoryCode, String participantId,
                                                        String acceptLanguage) {
    PqCriteriaMaster pqCriteriaMaster = pqCriteriaMasterService.fetchActiveCriteriaFromCriteriaId(criteriaId);
    if (pqCriteriaMaster == null) {
      throw new ServiceException(MessageConstants.INVALID_INPUT,
          messageUtility.getMessage(MessageConstants.INVALID_INPUT),
          ErrorConstant.CATEGORY.BV,
          ErrorConstant.SEVERITY.C);
    }
    PqCriteria pqCriteria = pqCriteriaService.fetchActiveCategory(pqCriteriaMaster, categoryCode);
    List<PqQuestion> questionList = pqQuestionService.fetchQuestionByCriteria(pqCriteria);
    PqParticipant pqParticipant = pqParticipateService.fetchParticipantById(participantId, pqCriteria);
    List<UUID> inactiveQuestions = new ArrayList<>();
    boolean hasInactiveResponse = false;
    for(PqQuestion question : questionList) {
      PqResponse pqResponses = pqResponseService.fetchPqResponsesByQuestionAndParticipant(question,pqParticipant);
      if(pqResponses == null) {
        hasInactiveResponse = true;
        inactiveQuestions.add(question.getPqQuestionId());
        continue;
      }
      if(question.getRequiresDocument() && pqResponses.getDocMasterFk() == null) {
        hasInactiveResponse = true;
        pqResponses.setStatusLookup(LookupConstants.Status.INVALID_DRAFT.getLookupCode());
        inactiveQuestions.add(question.getPqQuestionId());
      } else {
        pqResponses.setStatusLookup(LookupConstants.Status.VALID_DRAFT.getLookupCode());
      }
    }
    UUID submissionId = null;
    PqSubmission existingPqSubmission = pqSubmissionService.fetchSubmissionByCriteriaAndParticipantFk(pqCriteria,pqParticipant);
    if (existingPqSubmission != null && !hasInactiveResponse) {
      UUID existingSubmissionId = existingPqSubmission.getSubmissionId();
      existingPqSubmission.setStatusLookup(LookupConstants.Status.PENDING.getLookupCode());
      existingPqSubmission.setSubmittedAt(Instant.now());
      pqSubmissionService.saveSubmission(existingPqSubmission);
      submissionId = existingSubmissionId;
    }else{

      UUID newSubmissionId = requestUtil.createRequestId();
      PqSubmission newSubmission = PqSubmission.builder()
              .submissionId(newSubmissionId)
              .pqCriteria(pqCriteria)
              .pqParticipantFk(pqParticipant)
              .submittedAt(Instant.now())
              .statusLookup(LookupConstants.Status.INVALID_DRAFT.getLookupCode())
              .build();
      pqSubmissionService.saveSubmission(newSubmission);
      submissionId = newSubmissionId;
    }

    return SubmitQuestionsResponseDTO.builder()
        .pendingQuestions(inactiveQuestions)
        .submissionId(submissionId)
        .build();
  }

  public CriteriaResponsesDTO fetchCriteriaResponses(UUID criteriaId, UUID categoryCode, List<String> participants,
                                                     String acceptLanguage) {
    PqCriteriaMaster pqCriteriaMaster = pqCriteriaMasterService.fetchActiveCriteriaFromCriteriaId(criteriaId);
    PqCriteria pqCriteria = pqCriteriaService.fetchActiveCategory(pqCriteriaMaster, categoryCode);
    if (pqCriteria == null) {
      throw new ServiceException(MessageConstants.INVALID_INPUT,
          messageUtility.getMessage(MessageConstants.INVALID_INPUT),
          ErrorConstant.CATEGORY.BV,
          ErrorConstant.SEVERITY.C);
    }
    List<PqParticipant> pqParticipants = new ArrayList<>();
    for(String participant : participants) {
      PqParticipant pqParticipant = pqParticipateService.fetchParticipantById(participant, pqCriteria);
      if (pqParticipant == null) {
        throw new ServiceException(MessageConstants.INVALID_INPUT,
            messageUtility.getMessage(MessageConstants.INVALID_INPUT),
            ErrorConstant.CATEGORY.BV,
            ErrorConstant.SEVERITY.C);
      }
      pqParticipants.add(pqParticipant);
    }
    List<PqQuestion> questions = pqQuestionService.fetchQuestionByCriteria(pqCriteria);
    List<CriteriaResponsesDetailsDTO> responseList = new ArrayList<>();
    List<ParticipantCriteriaResponseDTO> participantSubmissions = new ArrayList<>();


    for(PqParticipant pqParticipant : pqParticipants) {
      for(PqQuestion question : questions) {
        PqResponse pqResponse = pqResponseService.fetchPqResponsesByQuestionAndParticipant(question, pqParticipant);
        if(pqResponse == null) {
          continue;
        }
        buildFetchCriteriaResponses(question, pqResponse, responseList);
      }
      PqSubmission pqSubmission = pqSubmissionService.fetchSubmissionByCriteriaAndParticipantFk(pqCriteria, pqParticipant);
      ParticipantCriteriaResponseDTO participantCriteriaResponse = new ParticipantCriteriaResponseDTO();
      participantCriteriaResponse.setParticipantId(pqParticipant.getParticipantId());
      participantCriteriaResponse.setQuestionDetails(responseList);
      if (pqSubmission != null) {
        participantCriteriaResponse.setEvaluatorRemarks(pqSubmission.getRemarks());
        participantCriteriaResponse.setSubmissionId(pqSubmission.getSubmissionId());
        participantCriteriaResponse.setSubmittedAt(pqSubmission.getSubmittedAt());
      }
      participantSubmissions.add(participantCriteriaResponse);
    }
    return CriteriaResponsesDTO.builder()
        .criteriaId(criteriaId)
        .categoryId(categoryCode)
        .participantSubmissions(participantSubmissions)
        .build();

  }

  public void buildFetchCriteriaResponses(PqQuestion question, PqResponse pqResponse, List<CriteriaResponsesDetailsDTO> responseList) {
    List<AttachmentDetailsResponseDTO> attachments = new ArrayList<>();
    List<DocAttachment> docAttachments = docAttachmentService.fetchAllActiveAttachmentsByQuestion(pqResponse.getDocMasterFk());
    for (DocAttachment attachment : docAttachments) {
      AttachmentDetailsResponseDTO attachmentDetails = AttachmentDetailsResponseDTO.builder()
          .attachmentId(attachment.getAttachmentId())
          .attachmentName(attachment.getAttachmentName())
          .attachmentUrl(Constants.SLASH + LookupConstants.MODULE_PATH + Constants.ATTACHMENT_BASE_URL + attachment.getAttachmentId())
          .attachmentSize(attachment.getAttachmentSize())
          .build();
      attachments.add(attachmentDetails);
    }
    List<PqResponseOptionMap> responseOptions = pqResponseOptionMappingService.findAllByPqResponse(pqResponse);
    List<String> options = new ArrayList<>();
    for (PqResponseOptionMap responseOption : responseOptions) {
      if (responseOption.getPqOption() != null) {
        options.add(String.valueOf(responseOption.getPqOption().getId()));
      }
    }
    String questionType = question.getQuestionTypeLookup();
    if (questionType != null && (questionType.equals(LookupConstants.INPUT_TYPE_FREETEXT) ||
        questionType.equals(LookupConstants.INPUT_TYPE_NUMERIC) ||
        questionType.equals(LookupConstants.INPUT_TYPE_FIXED_DATE) ||
        questionType.equals(LookupConstants.INPUT_TYPE_DATE_TO_DATE))) {
      if(questionType.equals(LookupConstants.INPUT_TYPE_DATE_TO_DATE)) {
        options = Arrays.asList(pqResponse.getResponseText().split(Constants.COMMA));
      } else {
        options.add(pqResponse.getResponseText());
      }

    }
    CriteriaResponsesDetailsDTO criteriaResponsesDetailsDTO = CriteriaResponsesDetailsDTO.builder()
        .responseId(pqResponse.getPqResponseId())
        .questionId(question.getPqQuestionId())
        .evaluatorScore(pqResponse.getEvaluatorScore())
        .questionType(questionType)
        .options(options)
        .attachments(attachments)
        .build();
    responseList.add(criteriaResponsesDetailsDTO);
  }


  @Override
  public List<ParticipantSubmissionsResponseDTO> fetchParticipantSubmissions(UUID criteriaId, UUID categoryCode, String acceptLanguage) {
    PqCriteriaMaster pqCriteriaMaster = pqCriteriaMasterService.fetchActiveCriteriaFromCriteriaId(criteriaId);
    if (pqCriteriaMaster == null) {
      throw new ServiceException(MessageConstants.INVALID_INPUT,
          messageUtility.getMessage(MessageConstants.INVALID_INPUT),
          ErrorConstant.CATEGORY.BV,
          ErrorConstant.SEVERITY.C);
    }
    PqCriteria pqCriteria = pqCriteriaService.fetchActiveCategory(pqCriteriaMaster, categoryCode);
    if (pqCriteria == null) {
      throw new ServiceException(MessageConstants.INVALID_INPUT,
          messageUtility.getMessage(MessageConstants.INVALID_INPUT),
          ErrorConstant.CATEGORY.BV,
          ErrorConstant.SEVERITY.C);
    }
    List<PqParticipant> pqParticipants = pqParticipateService.fetchParticipantByCrtieria(pqCriteria);
    List<ParticipantSubmissionsResponseDTO> responseList = new ArrayList<>();

    for(PqParticipant participant : pqParticipants) {
      PqSubmission pqSubmission = pqSubmissionService.fetchSubmissionByCriteriaAndParticipantFk(pqCriteria, participant);
      if(pqSubmission == null) {
        continue;
      }
      ParticipantSubmissionsResponseDTO participantSubmission = ParticipantSubmissionsResponseDTO.builder()
          .submissionId(pqSubmission.getSubmissionId())
          .bidder(participant.getParticipantId())
          .pqSubmissionDateAndTime(pqSubmission.getSubmittedAt())
          .pqAssessmentDate(pqSubmission.getEvaluatedAt() != null ? pqSubmission.getEvaluatedAt() : null)
          .status(LookupConstants.getEnumStatusKeyByValue(pqSubmission.getStatusLookup()))
          .build();
      responseList.add(participantSubmission);
    }
    return responseList;

  }

  @Override
  public UpdateSubmissionEvaluationResponseDTO updateSubmissionEvaluation(UUID submissionId,
                                                                          UpdateSubmissionEvaluationDTO
                                                                              updateSubmissionEvaluationRequest,
                                                                          String acceptLanguage) {
    PqSubmission submission = pqSubmissionService.fetchSubmissionById(submissionId);
    if(submission == null) {
      throw new ServiceException(MessageConstants.INVALID_INPUT,
          messageUtility.getMessage(MessageConstants.INVALID_INPUT),
          ErrorConstant.CATEGORY.BV,
          ErrorConstant.SEVERITY.C);
    }
    String submissionStatus = updateSubmissionEvaluationRequest.getSubmissionStatus().toUpperCase();
    if(LookupConstants.containsStatus(submissionStatus)) {
          submission.setSubmissionId(submissionId);
          submission.setPqCriteria(submission.getPqCriteria());
          submission.setPqParticipantFk(submission.getPqParticipantFk());
          submission.setRemarks(updateSubmissionEvaluationRequest.getRemarks());
          submission.setSubmittedAt(submission.getSubmittedAt());
//          .score(updateSubmissionEvaluationRequest.getScore())
          submission.setStatusLookup(LookupConstants.Status.valueOf(submissionStatus).getLookupCode());
      pqSubmissionService.saveSubmission(submission);
    }
    return UpdateSubmissionEvaluationResponseDTO.builder()
        .message(messageUtility.getMessage(MessageConstants.SUCCESS_MESSAGE))
        .status(languageService.messageView(MessageConstants.SUCCESS_MESSAGE).getMessage())
        .submissionId(submissionId)
        .build();
  }

  @Override
  public SubmissionStatusReqDTO updateSubmissionStatus(UUID submissionId, UUID participantId, SubmissionStatusReqDTO submissionStatusReqDTO, String acceptLanguage){

    PqSubmission pqSubmission = pqSubmissionService.fetchSubmissionById(submissionId);
    if(!pqSubmission.getPqParticipantFk().getParticipantId().equalsIgnoreCase(String.valueOf(participantId)))
    {
      throw new ServiceException(ErrorMessageConstants.INVALID_PARTICIPANT, messageUtility.getMessage(
              ErrorMessageConstants.INVALID_PARTICIPANT),
              ErrorConstant.CATEGORY.TS, ErrorConstant.SEVERITY.I);
    }

    if(Arrays.stream(LookupConstants.Status.values()).anyMatch(status -> status.getLookupCode().equalsIgnoreCase(submissionStatusReqDTO.getStatus())))
    {
      pqSubmission.setStatusLookup(submissionStatusReqDTO.getStatus());
      pqSubmissionService.saveSubmission(pqSubmission);
      return questionResponseTransformer.toSubmissionStatusReqDTO(pqSubmission);
    }
    else {
      throw new InvalidInputException(ErrorMessageConstants.INVALID_STATUS, messageUtility.getMessage(
              ErrorMessageConstants.INVALID_STATUS)
      );
    }
  }

}
