
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * Criteria Management ServiceImpl: Implements the Criteria Management service layer.
 */
package in.gov.gem.app.fa.pq.validation.response.impl;

import in.gov.gem.app.fa.pq.domain.entity.*;
import in.gov.gem.app.fa.pq.service.PqOptionService;
import in.gov.gem.app.fa.pq.service.PqQuestionResponseService;
import in.gov.gem.app.fa.pq.service.PqResponseOptionMappingService;
import in.gov.gem.app.fa.pq.transformer.QuestionResponseTransformer;
import org.springframework.stereotype.Component;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static in.gov.gem.app.fa.pq.constant.LookupConstants.INPUT_TYPE_MULTIPLE_CHOICE;

@Component
public class MultiResponseValidationImpl extends ResponseValidationAbstract{

    private static final String questionnaireType = INPUT_TYPE_MULTIPLE_CHOICE;

    private final QuestionResponseTransformer questionResponseTransformer;
    private final PqQuestionResponseService pqQuestionResponseService;
    private final PqOptionService pqOptionService;
    private final PqResponseOptionMappingService pqResponseOptionMappingService;

    MultiResponseValidationImpl(PqResponseOptionMappingService pqResponseOptionMappingService,
                                 QuestionResponseTransformer questionResponseTransformer,
                                 PqQuestionResponseService pqQuestionResponseService,
                                 PqOptionService pqOptionService) {
        super(questionnaireType);
        this.pqResponseOptionMappingService = pqResponseOptionMappingService;
        this.questionResponseTransformer = questionResponseTransformer;
        this.pqQuestionResponseService = pqQuestionResponseService;
        this.pqOptionService = pqOptionService;
    }


    @Override
    public boolean validate(PqQuestion pqQuestion, List<String> response) {
        return super.checkOptionAreNotNull(response)
                && validateOptions(pqQuestion,response);
    }

    public boolean validateOptions(PqQuestion pqQuestion, List<String> response) {
        List<PqOption> options = pqQuestion.getOptions();
        List<String> optionsList = new ArrayList<>();
        for(PqOption pqOption : options){
            optionsList.add(String.valueOf(pqOption.getId()));
        }
        for(String responseOptions : response){
            if(!optionsList.contains(responseOptions)){
                return false;
            }
        }
        return true;
    }

    public PqResponse buildPqResponse(UUID submissionId, PqQuestion pqQuestionEntity, List<String> responses, String responseStatus, PqParticipant pqParticipant) {
        PqResponse pqResponse = questionResponseTransformer.toPqResponseEntityForSelectedOptions(submissionId,pqQuestionEntity,responseStatus, pqParticipant);
        PqResponse savedPqResponse = pqQuestionResponseService.saveResponseEntity(pqResponse);
        for(String response : responses) {
            PqOption pqOption = pqOptionService.fetchOptionById(Long.parseLong(response));
            savePqResponseOptionMapping(pqResponse, pqOption);
        }
        return savedPqResponse;
    }

    @Override
    public PqResponse updatePqResponse(UUID submissionId, PqQuestion pqQuestionEntity, List<String> responseList) {
        PqResponse pqResponse = pqQuestionResponseService.fetchResponseFromSubmissionId(submissionId);
        List<PqResponseOptionMap> pqResponseOptionMaps = pqResponse.getSelectedOptions();
        List<Long> optionsIds = new ArrayList<>();
        for(PqResponseOptionMap pqResponseOptionMap : pqResponseOptionMaps){
            Long optionId = pqResponseOptionMap.getPqOption().getId();
            optionsIds.add(optionId);
            //TODO :- Deleting it temporary because status table not present
            pqResponseOptionMappingService.deleteById(pqResponseOptionMap.getId());
        }

        for(String response : responseList) {
            PqOption pqOption = pqOptionService.fetchOptionById(Long.parseLong(response));
            savePqResponseOptionMapping(pqResponse, pqOption);
        }
        return null;
    }

    private void savePqResponseOptionMapping(PqResponse pqResponse, PqOption pqOption){
        PqResponseOptionMap pqResponseOptionMap = new PqResponseOptionMap();
        pqResponseOptionMap.setPqResponse(pqResponse);
        pqResponseOptionMap.setPqOption(pqOption);
        pqResponseOptionMappingService.savePqResponseOptionMapping(pqResponseOptionMap);
    }

}
