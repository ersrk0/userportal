
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * Criteria Management ServiceImpl: Implements the Criteria Management service layer.
 */
package in.gov.gem.app.fa.pq.validation.response.impl;

import in.gov.gem.app.fa.pq.validation.response.ResponseValidation;
import java.util.List;


public abstract class ResponseValidationAbstract implements ResponseValidation {

    private final String questionnaireType;


    ResponseValidationAbstract(String questionnaireType){
        this.questionnaireType = questionnaireType;
    }

    protected boolean checkOptionAreNotNull(List<String> response){
        return !response.isEmpty();
    }

    @Override
    public boolean canHandle(String questionTypeLookup){
        return questionnaireType.equals(questionTypeLookup);
    }





}