
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * Pq Option Entity: Specifies the attributes in the 'pq_option' table.
 */
package in.gov.gem.app.fa.pq.domain.entity;

import in.gov.gem.app.service.core.entity.BaseEntity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

@Entity
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
@Table(name = "pq_option")
public class PqOption extends BaseEntity {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @Column(name = "option_sequence", nullable = false)
  private Integer optionSequence;

  @Column(name = "option_value", length = 25)
  private String optionValue;

  @Column(name = "status_lookup", length = 10)
  private String statusLookup;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "pq_question_fk", referencedColumnName = "id", nullable = false)
  private PqQuestion pqQuestion;

}
