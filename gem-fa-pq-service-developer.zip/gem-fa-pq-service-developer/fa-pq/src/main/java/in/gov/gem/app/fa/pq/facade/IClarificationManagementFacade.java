
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM
 * IClassificationManagementFacade: Facade layer between Controller and Service.
 */

package in.gov.gem.app.fa.pq.facade;

import in.gov.gem.app.fa.pq.domain.entity.DocMaster;
import in.gov.gem.app.fa.pq.request.ClarificationRequestDTO;
import in.gov.gem.app.fa.pq.response.GetClarificationResponseDTO;
import in.gov.gem.app.fa.pq.response.ReqClarificationResponseDTO;
import in.gov.gem.app.fa.pq.response.SubmitClarificationResponseDTO;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.UUID;

public interface IClarificationManagementFacade {

   SubmitClarificationResponseDTO submitClarification(String acceptLanguage, UUID responseId,
                                                      MultipartFile file,
                                                      ClarificationRequestDTO submitClarificationRequestDTO)
       throws IOException;

   ReqClarificationResponseDTO requestClarification(String acceptLanguage, UUID responseId,
                                                    MultipartFile file,
                                                    ClarificationRequestDTO clarificationRequestDTO)
       throws IOException;

   GetClarificationResponseDTO getClarification(String acceptLanguage, UUID responseId);

   DocMaster documentUpload(MultipartFile file) throws IOException;
}

