package in.gov.gem.app.fa.pq.service.impl;

import in.gov.gem.app.exception.generic.ServiceException;
import in.gov.gem.app.exception.utility.ErrorConstant;
import in.gov.gem.app.fa.pq.constant.ErrorMessageConstants;
import in.gov.gem.app.fa.pq.constant.LookupConstants;
import in.gov.gem.app.fa.pq.constant.MessageConstants;
import in.gov.gem.app.fa.pq.domain.entity.DocMaster;
import in.gov.gem.app.fa.pq.domain.entity.PqCriteria;
import in.gov.gem.app.fa.pq.domain.entity.PqQuestion;
import in.gov.gem.app.fa.pq.domain.repository.PqQuestionRepository;
import in.gov.gem.app.fa.pq.request.QuestionCreateRequestDTO;
import in.gov.gem.app.fa.pq.request.QuestionUpdateRequestDTO;
import in.gov.gem.app.fa.pq.service.LanguageService;
import in.gov.gem.app.fa.pq.service.PqQuestionService;
import lombok.AllArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
@AllArgsConstructor
public class PqQuestionServiceImpl implements PqQuestionService {

  private PqQuestionRepository pqQuestionRepository;
  private final LanguageService languageService;
  private static final Logger logger = LoggerFactory.getLogger(PqQuestionServiceImpl.class);



  @Override
  public List<PqQuestion> fetchQuestionByCriteria(PqCriteria pqCriteria) {
    logger.info("Entering fetchQuestionByCriteria with PqCriteria: {}", pqCriteria);
    List<PqQuestion> questions = pqQuestionRepository.findAllByPqCriteriaAndStatusLookup(pqCriteria, LookupConstants.Status.ACTIVE.getLookupCode());
    logger.debug("Fetched questions: {}", questions);
    logger.info("Exiting fetchQuestionByCriteria");
    return questions;
  }

  @Override
  public PqQuestion createQuestion(String acceptLanguage, QuestionCreateRequestDTO request, PqCriteria pqCriteria,
                                   UUID questionId, DocMaster docMaster) {
    logger.info("Entering createQuestion with acceptLanguage: {}, request: {}, criteriaId: {}, questionId: {}", acceptLanguage, request, pqCriteria.getId(), questionId);
    PqQuestion question = PqQuestion.builder()
            .pqQuestionId(questionId)
            .pqCriteria(pqCriteria)
            .docMaster(docMaster)
            .statusLookup(LookupConstants.Status.ACTIVE.getLookupCode())
            .questionText(request.getQuestionText())
            .isMandatory(request.getIsMandatory())
            .questionTypeLookup(request.getInputType())
            .requiresDocument(request.getDocRequired())
            .weightage(request.getScore())
            .questionSetBy(MessageConstants.CREATED_BY)
            .build();
    pqQuestionRepository.save(question);
    logger.debug("Created and saved question: {}", question);
    logger.info("Exiting createQuestion");
    return question;
  }

  public void saveDocument(DocMaster docMaster, PqQuestion pqQuestion) {
    logger.info("Entering saveDocument with DocMaster: {} and PqQuestion: {}", docMaster, pqQuestion);
    pqQuestion.setDocMaster(docMaster);
    pqQuestionRepository.save(pqQuestion);
    logger.debug("Saved document for question: {}", pqQuestion);
    logger.info("Exiting saveDocument");
  }

  public void deleteQuestion(String acceptLanguage, PqCriteria pqCriteria, UUID questionId) {
    logger.info("Entering deleteQuestion with acceptLanguage: {}, criteriaId: {}, questionId: {}", acceptLanguage, pqCriteria.getId(), questionId);
    PqQuestion pqQuestion = pqQuestionRepository.findByPqCriteriaAndPqQuestionIdAndStatusLookup(pqCriteria, questionId, LookupConstants.Status.ACTIVE.getLookupCode());
    pqQuestion.setStatusLookup(LookupConstants.Status.INACTIVE.getLookupCode());
    pqQuestionRepository.save(pqQuestion);
    logger.debug("Deleted question by marking it inactive: {}", pqQuestion);
    logger.info("Exiting deleteQuestion");
  }

  public PqQuestion fetchQuestionByQuestionId(PqCriteria pqCriteria, UUID questionId) {
    logger.info("Entering fetchQuestionByQuestionId with criteriaId: {} and questionId: {}", pqCriteria.getId(), questionId);
    PqQuestion pqQuestion = pqQuestionRepository.findByPqCriteriaAndPqQuestionIdAndStatusLookup(pqCriteria, questionId, LookupConstants.Status.ACTIVE.getLookupCode());
    if (pqQuestion == null) {
      logger.error("Question not found for criteriaId: {} and questionId: {}", pqCriteria.getId(), questionId);
      throw new ServiceException(ErrorMessageConstants.INVALID_QUESTION_ID,
              languageService.messageView(ErrorMessageConstants.INVALID_QUESTION_ID).getMessage(),
              ErrorConstant.CATEGORY.TS, ErrorConstant.SEVERITY.I);
    }
    logger.debug("Fetched question: {}", pqQuestion);
    logger.info("Exiting fetchQuestionByQuestionId");
    return pqQuestion;
  }

  public PqQuestion fetchQuestionByQuestionId(UUID questionId) {
    logger.info("Entering fetchQuestionByQuestionId with questionId: {}", questionId);
    PqQuestion pqQuestion = pqQuestionRepository.findByPqQuestionId(questionId).orElse(null);
    logger.debug("Fetched question: {}", pqQuestion);
    logger.info("Exiting fetchQuestionByQuestionId");
    return pqQuestion;
  }

  @Override
  public void deleteAllQuestions(List<PqQuestion> pqQuestionList) {
    logger.info("Entering deleteAllQuestions with question list: {}", pqQuestionList);
    for (PqQuestion pqQuestion : pqQuestionList) {
      pqQuestion.setStatusLookup(LookupConstants.Status.INACTIVE.getLookupCode());
      pqQuestionRepository.save(pqQuestion);
      logger.debug("Marked question as inactive: {}", pqQuestion);
    }
    logger.info("Exiting deleteAllQuestions");
  }

  @Override
  public void saveQuestion(PqQuestion pqQuestion) {
    logger.info("Entering saveQuestion with PqQuestion: {}", pqQuestion);
    pqQuestionRepository.save(pqQuestion);
    logger.debug("Saved question: {}", pqQuestion);
    logger.info("Exiting saveQuestion");
  }

  public void updateQuestion(PqQuestion pqQuestion, QuestionUpdateRequestDTO questionUpdateRequestDTO) {
    logger.info("Entering updateQuestion with PqQuestion: {} and updateRequest: {}", pqQuestion, questionUpdateRequestDTO);
    pqQuestion.setQuestionText(questionUpdateRequestDTO.getQuestionText());
    pqQuestion.setQuestionTypeLookup(questionUpdateRequestDTO.getInputType());
    pqQuestion.setIsMandatory(questionUpdateRequestDTO.getIsMandatory());
    pqQuestion.setRequiresDocument(questionUpdateRequestDTO.getDocRequired());
    pqQuestion.setWeightage(questionUpdateRequestDTO.getScore());
    pqQuestionRepository.save(pqQuestion);
    logger.debug("Updated question: {}", pqQuestion);
    logger.info("Exiting updateQuestion");
  }

  @Override
  public Page<PqQuestion> getQuestionsWithFilter(Specification<PqQuestion> specification, Pageable pageable) {
    logger.info("Entering getQuestionsWithFilter with specification: {} and pageable: {}", specification, pageable);
    Page<PqQuestion> questions = pqQuestionRepository.findAll(specification, pageable);
    logger.debug("Fetched questions with filter: {}", questions);
    logger.info("Exiting getQuestionsWithFilter");
    return questions;
  }
}

