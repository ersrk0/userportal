
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM.
 * PqResponseOptionMappingServiceImpl: Implements the service layer.
 */

package in.gov.gem.app.fa.pq.service.impl;

import in.gov.gem.app.exception.generic.ServiceException;
import in.gov.gem.app.exception.utility.ErrorConstant;
import in.gov.gem.app.fa.pq.constant.MessageConstants;
import in.gov.gem.app.fa.pq.domain.entity.PqParticipant;
import in.gov.gem.app.fa.pq.domain.entity.PqQuestion;
import in.gov.gem.app.fa.pq.domain.entity.PqResponse;
import in.gov.gem.app.fa.pq.domain.repository.PqResponseRepository;
import in.gov.gem.app.fa.pq.service.PqResponseService;
import in.gov.gem.app.service.core.utility.MessageUtility;
import lombok.AllArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
@AllArgsConstructor
public class PqResponseServiceImpl implements PqResponseService {

  private static final Logger logger = LoggerFactory.getLogger(PqResponseServiceImpl.class);

  private PqResponseRepository pqResponseRepository;
  private MessageUtility messageUtility;

  @Override
  public PqResponse fetchPqResponseById(UUID responseId) {
    logger.info("Entering fetchPqResponseById with responseId: {}", responseId);

    PqResponse pqResponse = pqResponseRepository.findByPqResponseId(responseId);
    if (pqResponse == null) {
      logger.error("PqResponse not found for responseId: {}", responseId);
      throw new ServiceException(MessageConstants.INVALID_INPUT,
              messageUtility.getMessage(MessageConstants.INVALID_INPUT),
              ErrorConstant.CATEGORY.BV,
              ErrorConstant.SEVERITY.C);
    }

    logger.debug("Fetched PqResponse: {}", pqResponse);

    logger.info("Exiting fetchPqResponseById with responseId: {}", responseId);
    return pqResponse;
  }

  @Override
  public List<PqResponse> fetchPqResponsesByQuestion(PqQuestion pqQuestion) {
    logger.info("Entering fetchPqResponsesByQuestion with pqQuestion: {}", pqQuestion);

    List<PqResponse> pqResponses = pqResponseRepository.findByPqQuestionFk(pqQuestion);
    logger.debug("Fetched PqResponses: {}", pqResponses);

    logger.info("Exiting fetchPqResponsesByQuestion");
    return pqResponses;
  }

  @Override
  public PqResponse fetchPqResponsesByQuestionAndParticipant(PqQuestion pqQuestion, PqParticipant pqParticipant) {
    logger.info("Entering fetchPqResponsesByQuestionAndParticipant with pqQuestion: {} and pqParticipant: {}", pqQuestion, pqParticipant);

    PqResponse pqResponse = pqResponseRepository.findByPqQuestionFkAndPqParticipantFk(pqQuestion, pqParticipant).orElse(null);
    logger.debug("Fetched PqResponse: {}", pqResponse);

    logger.info("Exiting fetchPqResponsesByQuestionAndParticipant");
    return pqResponse;
  }
}
