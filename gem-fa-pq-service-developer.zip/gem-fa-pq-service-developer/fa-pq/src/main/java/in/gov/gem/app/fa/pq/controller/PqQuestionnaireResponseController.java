
/*
 *This source code and all associated intellectual property
 * rights are exclusively owned by Government e-Marketplace (GeM)
 * and are protected under applicable intellectual property laws.
 * Any unauthorized use, reproduction, modification, or distribution
 * of this code, in whole or in part, is strictly prohibited
 * without the express prior written consent of GeM
 * Criteria Management Controller: Endpoint related to bank details.
 */

package in.gov.gem.app.fa.pq.controller;

import in.gov.gem.app.fa.pq.constant.Constants;
import in.gov.gem.app.fa.pq.constant.MessageConstants;
import in.gov.gem.app.fa.pq.facade.IPqQuestionnaireResponseFacade;
import in.gov.gem.app.fa.pq.request.QuestionnaireResponseSubmitDTO;
import in.gov.gem.app.fa.pq.request.QuestionnaireResponseUpdateDTO;
import in.gov.gem.app.fa.pq.request.SubmissionStatusReqDTO;
import in.gov.gem.app.fa.pq.request.UpdateSubmissionEvaluationDTO;
import in.gov.gem.app.fa.pq.response.CriteriaResponsesDTO;
import in.gov.gem.app.fa.pq.response.MessageResponseDTO;
import in.gov.gem.app.fa.pq.response.ParticipantSubmissionsResponseDTO;
import in.gov.gem.app.fa.pq.response.PqDocumentsAnswerDTO;
import in.gov.gem.app.fa.pq.response.PqQuestionResponseDTO;
import in.gov.gem.app.fa.pq.response.SubmitQuestionsResponseDTO;
import in.gov.gem.app.fa.pq.response.UpdateSubmissionEvaluationResponseDTO;
import in.gov.gem.app.service.core.utility.MessageUtility;
import in.gov.gem.app.service.dto.APIResponse;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.UUID;

@RestController
@AllArgsConstructor
@RequestMapping("/v1/public/criteria")
public class PqQuestionnaireResponseController {

    private MessageUtility messageUtility;
    private IPqQuestionnaireResponseFacade paQuestionnaireResponseFacade;

    @PostMapping("/{criteriaId}/questions/{questionId}/participants/{participantId}/responses")
    public ResponseEntity<APIResponse<PqQuestionResponseDTO>> submitQuestionResponse(@PathVariable UUID criteriaId,
                                                                                     @PathVariable UUID questionId,
                                                                                     @PathVariable String participantId,
                                                                                     @RequestPart(name = "file", required = false) MultipartFile[] files,
                                                                                     @RequestPart QuestionnaireResponseSubmitDTO questionnaireResponseSubmit) throws IOException {
        PqQuestionResponseDTO response = paQuestionnaireResponseFacade.submitQuestionResponse(criteriaId,questionId,questionnaireResponseSubmit,files,participantId);
        return ResponseEntity.status(HttpStatus.OK).body(
                APIResponse.<PqQuestionResponseDTO>builder()
                        .status(HttpStatus.OK.getReasonPhrase())
                        .httpStatus(HttpStatus.OK.value())
                        .message(messageUtility.getMessage(MessageConstants.SUCCESS_MESSAGE))
                        .data(response)
                        .msId(Constants.MSID)
                        .build()
        );
    }

    @PostMapping("/{criteriaId}/questions/{questionId}/participants/{participantId}/responses/{submissionId}")
    public ResponseEntity<APIResponse<PqDocumentsAnswerDTO>> submitDocumentsOnResponse(@PathVariable UUID criteriaId,
                                                                                       @PathVariable UUID questionId,
                                                                                       @PathVariable String participantId,
                                                                                       @PathVariable UUID submissionId,
                                                                                       @RequestPart(name = "file") MultipartFile[] files) throws IOException {
        PqDocumentsAnswerDTO pqDocumentsAnswerDTO = paQuestionnaireResponseFacade.addDocumentsToResponse(criteriaId,questionId,submissionId,files,participantId);
        return ResponseEntity.status(HttpStatus.OK).body(
                APIResponse.<PqDocumentsAnswerDTO>builder()
                        .status(HttpStatus.OK.getReasonPhrase())
                        .httpStatus(HttpStatus.OK.value())
                        .message(messageUtility.getMessage(MessageConstants.SUCCESS_MESSAGE))
                        .data(pqDocumentsAnswerDTO)
                        .msId(Constants.MSID)
                        .build()
        );
    }

    @DeleteMapping("/{criteriaId}/questions/{questionId}/participants/{participantId}/responses/{submissionId}")
    public ResponseEntity<APIResponse<String>> deleteSubmittedResponse(@PathVariable UUID criteriaId,
                                                                       @PathVariable UUID questionId,
                                                                       @PathVariable String participantId,
                                                                       @PathVariable UUID submissionId){
        String response = paQuestionnaireResponseFacade.deleteSubmittedResponse(criteriaId,questionId,submissionId,participantId);
        return ResponseEntity.status(HttpStatus.OK).body(
                APIResponse.<String>builder()
                        .status(HttpStatus.OK.getReasonPhrase())
                        .httpStatus(HttpStatus.OK.value())
                        .message(messageUtility.getMessage(MessageConstants.DELETE_SUBMISSION))
                        .data(response)
                        .msId(Constants.MSID)
                        .build()
        );
    }

    @PutMapping(value = "{criteriaId}/questions/{questionId}/participants/{participantId}/responses/{submissionId}",consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<APIResponse<MessageResponseDTO>> updateSubmittedResponse(@PathVariable UUID criteriaId,
                                                                                   @PathVariable UUID questionId,
                                                                                   @PathVariable String participantId,
                                                                                   @PathVariable UUID submissionId,
                                                                                   @RequestPart(name = "file", required = false) MultipartFile[] files,
                                                                                   @RequestPart QuestionnaireResponseUpdateDTO questionnaireResponseUpdateDTO) throws IOException {

        MessageResponseDTO messageResponseDTO = paQuestionnaireResponseFacade.updateSubmittedResponse(criteriaId,questionId,submissionId,files,questionnaireResponseUpdateDTO,participantId);
        return ResponseEntity.status(HttpStatus.OK).body(
                APIResponse.<MessageResponseDTO>builder()
                        .status(HttpStatus.OK.getReasonPhrase())
                        .httpStatus(HttpStatus.OK.value())
                        .message(messageUtility.getMessage(MessageConstants.SUCCESS_MESSAGE))
                        .data(messageResponseDTO)
                        .msId(Constants.MSID)
                        .build()
        );
    }

    @DeleteMapping(value = "/{criteriaId}/questions/{questionId}/participants/{participantId}/responses/{responseId}/attachment/{attachmentId}")
    public ResponseEntity<APIResponse<MessageResponseDTO>> deleteResponseAttachment(@PathVariable UUID criteriaId,
                                                                                    @PathVariable UUID questionId,
                                                                                    @PathVariable String participantId,
                                                                                    @PathVariable UUID responseId,
                                                                                    @PathVariable UUID attachmentId)
        throws IOException {

        MessageResponseDTO messageResponseDTO =
            paQuestionnaireResponseFacade.deleteResponseAttachment(criteriaId, questionId,responseId, attachmentId);
        return ResponseEntity.status(HttpStatus.OK).body(
            APIResponse.<MessageResponseDTO>builder()
                .status(HttpStatus.OK.getReasonPhrase())
                .httpStatus(HttpStatus.OK.value())
                .message(messageUtility.getMessage(MessageConstants.SUCCESS_MESSAGE))
                .data(messageResponseDTO)
                .msId(Constants.MSID)
                .build()
        );
    }

    @PutMapping(value = "/{criteriaId}/category/{categoryCode}/participants/{participantId}/submission")
    public ResponseEntity<APIResponse<SubmitQuestionsResponseDTO>> submitResponseDraft(@PathVariable UUID criteriaId,
                                                                                       @PathVariable UUID categoryCode,
                                                                                       @PathVariable String participantId,
                                                                                       @RequestHeader(name="Accept-Language") String acceptLanguage)
        throws IOException {

        SubmitQuestionsResponseDTO submitResponseDraft =
            paQuestionnaireResponseFacade.submitResponseDraft(criteriaId, categoryCode, participantId, acceptLanguage);
        return ResponseEntity.status(HttpStatus.OK).body(
            APIResponse.<SubmitQuestionsResponseDTO>builder()
                .status(HttpStatus.OK.getReasonPhrase())
                .httpStatus(HttpStatus.OK.value())
                .message(messageUtility.getMessage(MessageConstants.SUCCESS_MESSAGE))
                .data(submitResponseDraft)
                .msId(Constants.MSID)
                .build()
        );
    }


    @GetMapping(value = "/{criteriaId}/category/{categoryCode}/participants/responses")
    public ResponseEntity<APIResponse<CriteriaResponsesDTO>> fetchCriteriaResponses(@PathVariable UUID criteriaId,
                                                                                    @PathVariable UUID categoryCode,
                                                                                    @RequestParam List<String> participants,
                                                                                    @RequestHeader(name="Accept-Language")
                                                                                    String acceptLanguage)
        throws IOException {

        CriteriaResponsesDTO response =
            paQuestionnaireResponseFacade.fetchCriteriaResponses(criteriaId, categoryCode, participants, acceptLanguage);
        return ResponseEntity.status(HttpStatus.OK).body(
            APIResponse.<CriteriaResponsesDTO>builder()
                .status(HttpStatus.OK.getReasonPhrase())
                .httpStatus(HttpStatus.OK.value())
                .message(messageUtility.getMessage(MessageConstants.SUCCESS_MESSAGE))
                .data(response)
                .msId(Constants.MSID)
                .build()
        );
    }

    @GetMapping(value = "/{criteriaId}/category/{categoryCode}/participant/submissions")
    public ResponseEntity<APIResponse<List<ParticipantSubmissionsResponseDTO>>> fetchParticipantSubmissions(@PathVariable UUID criteriaId,
                                                                                                      @PathVariable UUID categoryCode,
                                                                                                      @RequestHeader(name="Accept-Language")
                                                                                    String acceptLanguage)
        throws IOException {

        List<ParticipantSubmissionsResponseDTO> response =
            paQuestionnaireResponseFacade.fetchParticipantSubmissions(criteriaId, categoryCode, acceptLanguage);
        return ResponseEntity.status(HttpStatus.OK).body(
            APIResponse.<List<ParticipantSubmissionsResponseDTO>>builder()
                .status(HttpStatus.OK.getReasonPhrase())
                .httpStatus(HttpStatus.OK.value())
                .message(messageUtility.getMessage(MessageConstants.SUCCESS_MESSAGE))
                .data(response)
                .msId(Constants.MSID)
                .build()
        );
    }

    @PutMapping(value = "/submissions/{submissionId}/evaluate")
    public ResponseEntity<APIResponse<UpdateSubmissionEvaluationResponseDTO>> updateSubmissionEvaluation(@PathVariable UUID submissionId,
                                                                                                         @RequestBody UpdateSubmissionEvaluationDTO updateSubmissionEvaluationRequest,
                                                                                                         @RequestHeader(name="Accept-Language")
                                                                                                     String acceptLanguage)
        throws IOException {

        UpdateSubmissionEvaluationResponseDTO response =
            paQuestionnaireResponseFacade.updateSubmissionEvaluation(submissionId, updateSubmissionEvaluationRequest, acceptLanguage);
        return ResponseEntity.status(HttpStatus.OK).body(
            APIResponse.<UpdateSubmissionEvaluationResponseDTO>builder()
                .status(HttpStatus.OK.getReasonPhrase())
                .httpStatus(HttpStatus.OK.value())
                .message(messageUtility.getMessage(MessageConstants.SUCCESS_MESSAGE))
                .data(response)
                .msId(Constants.MSID)
                .build()
        );
    }
    @PutMapping(value = "/submissions/{submissionId}/participant/{participantId}")
    public ResponseEntity<APIResponse<SubmissionStatusReqDTO>> updateSubmissionEvaluation(@PathVariable UUID submissionId,
                                                                                          @PathVariable UUID participantId,
                                                                                          @RequestBody SubmissionStatusReqDTO submissionStatusReqDTO,
                                                                                          @RequestHeader(name="Accept-Language")
                                                                                                         String acceptLanguage) {

        SubmissionStatusReqDTO response =
                paQuestionnaireResponseFacade.updateSubmissionStatus(submissionId, participantId, submissionStatusReqDTO, acceptLanguage);
        return ResponseEntity.status(HttpStatus.OK).body(
                APIResponse.<SubmissionStatusReqDTO>builder()
                        .status(HttpStatus.OK.getReasonPhrase())
                        .httpStatus(HttpStatus.OK.value())
                        .message(messageUtility.getMessage(MessageConstants.SUCCESS_WITHDRAWN))
                        .data(response)
                        .msId(Constants.MSID)
                        .build()
        );
    }

}
