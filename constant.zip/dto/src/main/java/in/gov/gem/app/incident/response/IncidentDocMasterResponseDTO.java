package in.gov.gem.app.incident.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.UUID;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class IncidentDocMasterResponseDTO {
    private UUID docId;
    private List<IncidentAttachmentResponseDTO> attachments;
}