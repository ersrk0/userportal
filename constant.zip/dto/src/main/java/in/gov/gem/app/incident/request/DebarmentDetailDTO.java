package in.gov.gem.app.incident.request;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DebarmentDetailDTO {
    private String debarmentClauseLookup;
    private String debarmentStartDate;
    private String debarmentEndDate;
    private String competentAuthorityName;
    private String competentAuthorityDesignation;
}