package in.gov.gem.app.incident.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class IncidentAttachmentResponseDTO {
    private UUID attachmentId;
    private String fileName;
    private String fileTypeLookup;
    private String filePath;
    private Long fileSize;
    private String uploadedByTypeLookup;
    private String uploadedById;
    private String statusLookup;
}