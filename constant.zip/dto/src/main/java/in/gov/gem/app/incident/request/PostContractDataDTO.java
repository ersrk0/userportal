package in.gov.gem.app.incident.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PostContractDataDTO {
    private String auctionId;
    private String bidId;
    private String orderId;
    private String productId;
    private String contractNo;
    private String invoiceId;
    private String panNo;
    private Boolean isDebarred;
    private DebarmentDetailDTO debarmentDetail;
}