package in.gov.gem.app.incident.request;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class IncidentAttachmentDTO {
    private String fileName;
    private String fileTypeLookup;
    private String filePath;
    private long fileSize;
    private String uploadedByTypeLookup;
    private String uploadedById;
    private String statusLookup;
}