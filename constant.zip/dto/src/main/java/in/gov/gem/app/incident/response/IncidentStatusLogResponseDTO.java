package in.gov.gem.app.incident.response;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.UUID;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class IncidentStatusLogResponseDTO {
    private UUID statusLogId;
    private String actionTypeLookup;
    private String previousStatusLookup;
    private String currentStatusLookup;
    private String actionByTypeLookup;
    private String actionById;
    private UUID incidentDocMasterFk;
    private String remarks;
    private LocalDateTime actionTimestamp;
}