package in.gov.gem.app.incident.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class IncidentStatusLogDTO {
    private String actionTypeLookup;
    private String previousStatusLookup;
    private String currentStatusLookup;
    private String actionByTypeLookup;
    private String actionById;
    private String incidentDocMasterFk;
    private String remarks;
}