package in.gov.gem.app.incident.response;

import in.gov.gem.app.incident.request.PostContractDataDTO;
import in.gov.gem.app.incident.request.PreContractDataDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class IncidentDetailResponseDTO {
    private UUID incidentId;
    private String incidentTitle;
    private String incidentDescription;
    private String moduleCode;
    private String incidentTypeLookup;
    private String raisedByTypeLookup;
    private String raisedById;
    private String raisedByRoleLookup;
    private String raisedAgainstTypeLookup;
    private String raisedAgainstRoleLookup;
    private String incidentReasonLookup;
    private String issueTypeLookup;
    private String statusLookup;
    private String severityLookup;
    private PreContractDataDTO preContractData;
    private PostContractDataDTO postContractData;
    private IncidentDocMasterResponseDTO incidentDocMasterData;
    private IncidentStatusLogResponseDTO incidentStatusLogData;
}