package in.gov.gem.app.incident.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PreContractDataDTO {
    private String traderId;
    private String categoryCode;
    private String productId;
    private String catalogId;
    private String compId;
    private String skuId;
    private String brandId;
    private String serviceId;
}