package in.gov.gem.app.incident.request;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class IncidentRequestDTO {
    @Schema(description = "PRECONTRACT or POSTCONTRACT")
    private String incidentTypeLookup;
    private String moduleCode;
    private String raisedByTypeLookup;
    private String raisedById;
    private String raisedByRoleLookup;
    private String raisedAgainstTypeLookup;
    private String raisedAgainstRoleLookup;
    private String incidentReasonLookup;
    private String issueTypeLookup;
    private String incidentTitle;
    private String incidentDescription;
    private String statusLookup;
    private String severityLookup;
    private PreContractDataDTO preContractData;
    private PostContractDataDTO postContractData;
    private IncidentDocMasterDTO incidentDocMasterData;
    private IncidentStatusLogDTO incidentStatusLogData;
}