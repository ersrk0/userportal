package in.gov.gem.app.incident.service;

import in.gov.gem.app.incident.request.IncidentRequestDTO;

import java.io.IOException;
import java.util.UUID;

public interface IncidentService {
     void saveIncident (String incidentPk, String acceptLanguage, IncidentRequestDTO incidentRequestDTO) throws IOException;
}