package in.gov.gem.app.incident.service;

import in.gov.gem.app.incident.request.IncidentRequestDTO;
import in.gov.gem.app.incident.response.IncidentResponseDTO;

import org.springframework.web.multipart.MultipartFile;
import java.io.IOException;
import java.util.List;
public interface IncidentService {
    List<IncidentResponseDTO> saveIncident(IncidentRequestDTO incidentRequestDTO, MultipartFile[] files) throws IOException;
}