package in.gov.gem.app.incident.service;

import in.gov.gem.app.incident.domain.entity.Incident;
import in.gov.gem.app.incident.request.IncidentRequestDTO;

import java.util.UUID;

public interface IncidentService {
    /**
     * Persists the incident entity based on incoming request and document reference.
     *
     * @param request DTO containing incident request data.
     * @param docMaster Reference to saved document master.
     * @param incidentId Generated unique ID for incident.
     * @return Persisted Incident entity.
     */
    Incident saveIncident(IncidentRequestDTO request, Object docMaster, UUID incidentId);
    /**
     * Fetches the Incident by its ID from DB.
     *
     * @param incidentId UUID of the incident.
     * @return Fetched Incident entity.
     */
    Incident fetchIncidentById(UUID incidentId);
}
