/*
package in.gov.gem.app.incident.service;

import org.springframework.core.io.ByteArrayResource;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

*/
/**
 * The interface Document service.
 *//*

public interface IDocumentService {

    */
/**
     * Upload bulk document string.
     *
     * @param file the file
     * @return the string
     * @throws IOException the io exception
     *//*

    String uploadBulkDocument(MultipartFile file) throws IOException;

    */
/**
     * Upload errone document string.
     *
     * @param file the file
     * @return the string
     *//*

    String uploadErroneDocument(ByteArrayResource file);
}
*/
