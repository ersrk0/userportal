package in.gov.gem.app.incident.service;

import java.util.Map;
import java.util.stream.Stream;

/**
 * The interface Sequence generate service.
 */
public interface ISequenceGenerateService {
    /**
     * Generate arn string.
     *
     * @return the string
     */
    String generateArn();

    /**
     * Gets email sequence map.
     *
     * @param stringStream the string stream
     * @return the email sequence map
     */
    Map<String, String> getEmailSequenceMap(Stream<String> stringStream);
}
