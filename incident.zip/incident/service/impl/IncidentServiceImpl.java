package in.gov.gem.app.incident.service.impl;

import in.gov.gem.app.incident.domain.repository.*;
import in.gov.gem.app.irm.incident.transformer.IncidentTransformer;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class IncidentServiceImpl implements IncidentService {
    private final IncidentMasterRepository incidentMasterRepository;
    private final PreContractIncidentRepository preContractIncidentRepository;
    private final PostContractIncidentRepository postContractIncidentRepository;
    private final IncidentDocMasterRepository incidentDocMasterRepository;
    private final IncidentStatusLogRepository incidentStatusLogRepository;
    private final DebarmentDetailRepository debarmentDetailRepository;
    private final SequenceGeneratorService sequenceGeneratorService;
    private final IncidentTransformer incidentTransformer;
    @Override
    public List<IncidentResponseDTO> saveIncident(IncidentRequestWrapperDTO requestWrapper, MultipartFile[] files) throws IOException {
        List<IncidentResponseDTO> responses = new ArrayList<>();
        for (IncidentRequestDTO request : requestWrapper.getIncidentRequestList()) {
            UUID incidentPk = UUID.randomUUID();
            String incidentId = sequenceGeneratorService.generateIncidentId();
            // Save Incident Master
            IncidentMasterEntity masterEntity = incidentTransformer.toIncidentMasterEntity(request, incidentPk, incidentId);
            incidentMasterRepository.save(masterEntity);
            // Save Pre or Post Contract Data
            if (request.getPreContractData() != null && !request.getPreContractData().isEmpty()) {
                for (PreContractDataDTO pre : request.getPreContractData()) {
                    PreContractIncidentEntity entity = incidentTransformer.toPreContractEntity(pre, incidentPk);
                    preContractIncidentRepository.save(entity);
                }
            } else if (request.getPostContractData() != null && !request.getPostContractData().isEmpty()) {
                for (PostContractDataDTO post : request.getPostContractData()) {
                    PostContractIncidentEntity postEntity = incidentTransformer.toPostContractEntity(post, incidentPk);
                    postContractIncidentRepository.save(postEntity);
                    if (post.getDebarmentDetail() != null && !post.getDebarmentDetail().isEmpty()) {
                        for (DebarmentDetailDTO debar : post.getDebarmentDetail()) {
                            DebarmentDetailEntity debarEntity = incidentTransformer.toDebarmentEntity(debar, postEntity.getPostContractPk());
                            debarmentDetailRepository.save(debarEntity);
                        }
                    }
                }
            }
            // Save Documents
            if (request.getIncidentDocMasterData() != null) {
                for (IncidentDocMasterDTO doc : request.getIncidentDocMasterData()) {
                    IncidentDocMasterEntity docEntity = incidentTransformer.toDocMasterEntity(doc, incidentPk);
                    incidentDocMasterRepository.save(docEntity);
                }
            }
            // Save Status Logs
            if (request.getIncidentStatusLogData() != null) {
                for (IncidentStatusLogDTO log : request.getIncidentStatusLogData()) {
                    IncidentStatusLogEntity logEntity = incidentTransformer.toStatusLogEntity(log, incidentPk);
                    incidentStatusLogRepository.save(logEntity);
                }
            }
            // Prepare response
            responses.add(incidentTransformer.toResponseDTO(incidentId, masterEntity.getIncidentTitle(), masterEntity.getIncidentDescription()));
        }
        return responses;
    }
}