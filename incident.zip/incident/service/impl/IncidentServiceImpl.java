package in.gov.gem.app.incident.service.impl;

import com.amazonaws.services.secretsmanager.model.ResourceNotFoundException;
import in.gov.gem.app.incident.domain.entity.Incident;
import in.gov.gem.app.incident.domain.repository.IncidentRepository;
import in.gov.gem.app.incident.service.IncidentService;
import in.gov.gem.app.service.core.utility.MessageUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.atomic.AtomicInteger;

@Service
@RequiredArgsConstructor
public class IncidentServiceImpl implements IncidentService {
    private final IncidentRepository incidentRepository;
    private final MessageUtility messageUtility;
    // In-memory counter (replace with DB sequence logic if needed)
    private static final AtomicInteger incidentCounter = new AtomicInteger(1);
    @Override
    public String generateIncidentId() {
        String datePart = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyyMMdd"));
        int count = incidentCounter.getAndIncrement();
        return "INC" + datePart + String.format("%03d", count);
    }
    @Override
    public void saveIncident(Incident incident) {
        incidentRepository.save(incident);
    }
    @Override
    public Incident getIncidentById(String incidentId) {
        return incidentRepository.findByIncidentId(incidentId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        MessageConstants.INCIDENT_NOT_FOUND,
                        messageUtility.getMessage(MessageConstants.INCIDENT_NOT_FOUND)));
    }
}