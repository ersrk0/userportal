package in.gov.gem.app.incident.controller;


import in.gov.gem.app.incident.constant.Constants;
import in.gov.gem.app.incident.constant.MessageConstants;
import in.gov.gem.app.incident.facade.IncidentFacade;
import in.gov.gem.app.incident.request.IncidentRequestDTO;
import in.gov.gem.app.incident.response.IncidentResponseDTO;
import in.gov.gem.app.service.dto.APIResponse;
import in.gov.gem.app.service.core.utility.MessageUtility;

import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import java.io.IOException;
import java.util.List;
import java.util.UUID;

@Tag(name = "Incident Management")
@RestController
@RequestMapping("/v1/public/incident")
@AllArgsConstructor
@Validated
public class IncidentController {
    private final IncidentFacade incidentFacade;
    private final MessageUtility messageUtility;

    @PostMapping("/save")
    public ResponseEntity<APIResponse<List<IncidentResponseDTO>>> submitIncident(
            @RequestHeader(value = "Accept-Language", required = false) String acceptLanguage,
            @Valid @RequestPart IncidentRequestDTO incidentRequestDTO,
            @PathVariable UUID incidentPk ,
            @RequestPart(name = "file", required = false) MultipartFile[] file)
           throws IOException {
        List<IncidentResponseDTO> responseList = incidentFacade.submitIncident(incidentPk, acceptLanguage,incidentRequestDTO);
        return ResponseEntity.status(HttpStatus.CREATED).body(
                APIResponse.<List<IncidentResponseDTO>>builder()
                        .msId(Constants.MSID)
                        .status(HttpStatus.CREATED.getReasonPhrase())
                        .httpStatus(HttpStatus.CREATED.value())
                        .message(messageUtility.getMessage(MessageConstants.INCIDENT_CREATED))
                        .data(responseList)
                        .build()
        );
    }


    //bulk upload all data
     @PostMapping("/save")
        public List<IncidentResponseDTO> submitBulk(@RequestParam("file") MultipartFile file)
            @RequestHeader(value = "Accept-Language", required = false) String acceptLanguage,
            @Valid @RequestPart IncidentRequestDTO incidentRequestDTO,
            @PathVariable UUID incidentPk,
            @RequestPart(name = "file", required = false) MultipartFile[] file))
            throws IOException{
        List<IncidentResponseDTO> responseList= incidentFacade.readExcelData();
        return ResponseEntity.status(HttpStatus.CREATED).body(
            APIResponse.<List<IncidentResponseDTO>>builder()
                    .msId(Constants.MSID)
                    .status(HttpStatus.CREATED.getReasonPhrase())
                    .httpStatus(HttpStatus.CREATED.value())
                    .message(messageUtility.getMessage(MessageConstants.INCIDENT_CREATED))
                    .data(responseList)
                    .build()
            );
        }

    }
