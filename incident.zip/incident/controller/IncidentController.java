package in.gov.gem.app.incident.controller;

import in.gov.gem.app.incident.facade.IIncidentFacade;
import in.gov.gem.app.incident.request.IncidentRequestDTO;
import in.gov.gem.app.incident.response.IncidentResponseDTO;
import in.gov.gem.app.service.core.utility.MessageUtility;
import in.gov.gem.app.service.dto.APIResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@Tag(name = "Incident Module APIs")
@RestController
@RequestMapping("/v1/incident")
@Validated
@AllArgsConstructor
public class IncidentController {
    private final IIncidentFacade incidentFacade;
    private final MessageUtility messageUtility;
    @PostMapping("/create")
    public ResponseEntity<APIResponse<IncidentResponseDTO>> createIncident(
            @RequestHeader(value = "Accept-Language", required = false) String acceptLanguage,
            @Valid @RequestBody IncidentRequestDTO requestDTO) {
        // Basic incidentTypeLookup check (PRECONTRACT or POSTCONTRACT)
        if (!("PRECONTRACT".equalsIgnoreCase(requestDTO.getIncidentTypeLookup())
                || "POSTCONTRACT".equalsIgnoreCase(requestDTO.getIncidentTypeLookup()))) {
            return ResponseEntity.badRequest().body(APIResponse.<IncidentResponseDTO>builder()
                    .msId(Constants.MSID)
                    .status("ERROR")
                    .httpStatus(HttpStatus.BAD_REQUEST.value())
                    .message("Invalid incidentTypeLookup value. Allowed: PRECONTRACT or POSTCONTRACT.")
                    .build());
        }
        IncidentResponseDTO response = incidentFacade.createIncident(acceptLanguage, requestDTO);
        return ResponseEntity.status(HttpStatus.CREATED).body(
                APIResponse.<IncidentResponseDTO>builder()
                        .status("SUCCESS")
                        .httpStatus(HttpStatus.CREATED.value())
                        .message(messageUtility.getMessage(MessageConstants.INCIDENT_CREATED_SUCCESSFULLY))
                        .msId(Constants.MSID)
                        .data(response)
                        .build()
        );
    }
    @GetMapping("/{incidentId}")
    public ResponseEntity<APIResponse<IncidentResponseDTO>> getIncidentById(
            @PathVariable String incidentId,
            @RequestHeader(value = "Accept-Language", required = false) String acceptLanguage) {
        IncidentResponseDTO response = incidentFacade.getIncidentById(incidentId, acceptLanguage);
        return ResponseEntity.ok().body(
                APIResponse.<IncidentResponseDTO>builder()
                        .status("SUCCESS")
                        .httpStatus(HttpStatus.OK.value())
                        .message(messageUtility.getMessage(MessageConstants.SUCCESS_MESSAGE))
                        .msId(Constants.MSID)
                        .data(response)
                        .build()
        );
    }
}