package in.gov.gem.app.incident;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages = {"in.gov.gem.app"})
public class GemIncidentServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(GemIncidentServiceApplication.class, args);
    }

}