package in.gov.gem.app.incident.facade;

import in.gov.gem.app.incident.request.IncidentRequestDTO;
import in.gov.gem.app.incident.response.IncidentResponseDTO;

import java.util.UUID;

public interface IIncidentFacade {
    /**
     * Creates a new incident (pre-contract or post-contract based on type)
     *
     * @param acceptLanguage Language header
     * @param request Incident request DTO
     * @return IncidentResponseDTO with incident ID, name, and description
     */
    IncidentResponseDTO createIncident(String acceptLanguage, IncidentRequestDTO request);
    /**
     * Fetches an incident by ID
     *
     * @param acceptLanguage Language header
     * @param incidentId UUID of the incident
     * @return IncidentResponseDTO
     */
    IncidentResponseDTO getIncidentById(String acceptLanguage, UUID incidentId);
}