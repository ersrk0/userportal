package in.gov.gem.app.incident.facade;

import in.gov.gem.app.incident.domain.entity.IncidentMasterEntity;
import in.gov.gem.app.incident.request.IncidentRequestDTO;
import in.gov.gem.app.incident.response.IncidentResponseDTO;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.UUID;

public interface IncidentFacade {

    IncidentMasterEntity saveIncident(String acceptLanguage, IncidentRequestDTO incidentRequestDTO)throws IOException;
}