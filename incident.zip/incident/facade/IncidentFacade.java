package in.gov.gem.app.incident.facade;

import in.gov.gem.app.incident.request.IncidentRequestDTO;
import in.gov.gem.app.incident.response.IncidentResponseDTO;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.UUID;

public interface IncidentFacade {

    List<IncidentResponseDTO> submitIncident(UUID incidentPk, String acceptLanguage, IncidentRequestDTO incidentRequestDTO) throws IOException;
    List<IncidentResponseDTO> readExcelData() throws IOException;;
    // ...other method declarations...
}