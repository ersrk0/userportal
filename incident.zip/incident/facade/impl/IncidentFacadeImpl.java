package in.gov.gem.app.incident.facade.impl;

import in.gov.gem.app.incident.domain.entity.IncidentMasterEntity;
import in.gov.gem.app.incident.facade.IncidentFacade;
import in.gov.gem.app.incident.facade.IncidentFacade;
import in.gov.gem.app.incident.request.AttachmentDTO;
import in.gov.gem.app.incident.request.IncidentDocMasterDTO;
import in.gov.gem.app.incident.request.IncidentRequestDTO;
import in.gov.gem.app.incident.response.IncidentResponseDTO;
import in.gov.gem.app.incident.service.IncidentService;
//import in.gov.gem.app.incident.service.impl.DocumentService;
import in.gov.gem.app.incident.service.impl.SequenceGenerateService;
import in.gov.gem.app.incident.transformer.IncidentTransformer;
import in.gov.gem.app.service.core.utility.MessageUtility;
import in.gov.gem.app.service.dto.CoreLookupDto;
import in.gov.gem.app.service.pack.service.interfaces.CoreLookupService;

import in.gov.gem.app.utility.CustomLoggerFactory;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;


@Component
@AllArgsConstructor
public class IncidentFacadeImpl implements IncidentFacade {

    private static final Logger logger = LoggerFactory.getLogger(IncidentFacadeImpl.class);
   // private final DocumentService documentService;
    private final IncidentService incidentService;
    private final IncidentTransformer incidentTransformer;
    private final MessageUtility messageUtility;
    private final CustomLoggerFactory log = CustomLoggerFactory.getLogger(this.getClass());
    private final SequenceGenerateService sequenceGenerateService;
    @Transactional
    public IncidentMasterEntity saveIncident(String acceptLanguage, IncidentRequestDTO incidentRequestDTO) throws IOException {
        List<String> uploadedFilePaths = new ArrayList<>(); // To store all uploaded file paths
        String incidentPk = sequenceGenerateService.generateArn();
        // Process each incident document master data
        for (IncidentDocMasterDTO incidentDocMasterDTO : incidentRequestDTO.getIncidentDocMasterData()) {
            List<AttachmentDTO> updatedAttachments = new ArrayList<>(); // To store updated attachments

            @Valid @Size(min = 0) List<AttachmentDTO> attachments = incidentDocMasterDTO.getAttachments();
            if (attachments != null && !attachments.isEmpty()) {
                for (AttachmentDTO attachment : attachments) {
                    MultipartFile file = attachment.getFilePath(); // Assuming this is MultipartFile
                    if (file != null && !file.isEmpty()) {
                        // Validate and upload file
                       // String filePath = documentService.uploadBulkDocument(file);
                        //uploadedFilePaths.add(filePath); // Add file path to the list
                     //   log.info("File uploaded successfully: {}", filePath);

                        // Set the file path and other details in the attachment object
                        attachment.setFileName(file.getOriginalFilename());
                        attachment.setFilePath(null); // Clear MultipartFile reference
                        attachment.setFileTypeLookup(file.getContentType());
                        attachment.setFileSize(file.getSize());
                        attachment.setStatusLookup("UPLOADED"); // Example status
                        updatedAttachments.add(attachment); // Add updated attachment to the list
                    }
                }
            }

            // Set updated attachments in the IncidentDocMasterDTO
            incidentDocMasterDTO.setAttachments(updatedAttachments);
        }

        // Save the incident and return the response
        IncidentMasterEntity incidentMasterEntity = incidentTransformer.toIncidentMasterEntity(incidentPk, acceptLanguage, incidentRequestDTO);
        incidentService.saveIncident(incidentPk, acceptLanguage, incidentRequestDTO);
        log.info("Incident saved successfully with ID: {}", incidentMasterEntity.getIncidentId());

        // Log the uploaded file paths
        log.info("Uploaded file paths: {}", uploadedFilePaths);

        // Return the response DTO
        return incidentMasterEntity;
    }

}
