package in.gov.gem.app.incident.facade.impl;

import in.gov.gem.app.exception.generic.InvalidInputException;
import in.gov.gem.app.incident.domain.entity.*;
import in.gov.gem.app.incident.facade.IIncidentFacade;
import in.gov.gem.app.incident.request.IncidentRequestDTO;
import in.gov.gem.app.incident.response.IncidentResponseDTO;
import in.gov.gem.app.incident.service.IncidentService;
import in.gov.gem.app.incident.transformer.IncidentTransformer;
import in.gov.gem.app.service.core.utility.MessageUtility;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.UUID;

@Component
@RequiredArgsConstructor
public class IncidentFacadeImpl implements IIncidentFacade {
    private final IncidentService incidentService;
    private final PreContractIncidentDataService preContractService;
    private final PostContractIncidentDataService postContractService;
    private final IncidentDocMasterService docMasterService;
    private final IncidentStatusLogService statusLogService;
    private final IncidentTransformer incidentTransformer;
    private final MessageUtility messageUtility;
    @Override
    @Transactional
    public IncidentResponseDTO createIncident(String acceptLanguage, IncidentRequestDTO requestDTO) {
        // Generate unique Incident ID
        String incidentId = incidentService.generateIncidentId();
        // Transform to Entity
        Incident incident = incidentTransformer.toIncidentEntity(requestDTO);
        incident.setIncidentId(incidentId);
        incident.setCreatedBy("SYSTEM");
        incident.setStatusLookup(requestDTO.getStatusLookup());
        // Save Incident main entity
        incidentService.saveIncident(incident);
        // Handle PRE or POST contract-specific logic
        String type = requestDTO.getIncidentTypeLookup();
        if (LookupConstants.Type.PRECONTRACT.equalsIgnoreCase(type)) {
            PreContractIncidentData preContract = incidentTransformer.toPreContractEntity(requestDTO.getPreContractData());
            preContract.setIncident(incident);
            preContract.setId(UUID.randomUUID());
            preContractService.save(preContract);
        } else if (LookupConstants.Type.POSTCONTRACT.equalsIgnoreCase(type)) {
            PostContractIncidentData postContract = incidentTransformer.toPostContractEntity(requestDTO.getPostContractData());
            postContract.setIncident(incident);
            postContract.setId(UUID.randomUUID());
            // Optional debarment detail
            if (requestDTO.getPostContractData().getDebarmentDetail() != null) {
                DebarmentDetail debar = incidentTransformer.toDebarmentEntity(requestDTO.getPostContractData().getDebarmentDetail());
                debar.setPostContractIncidentData(postContract);
                postContract.setDebarmentDetail(debar);
            }
            postContractService.save(postContract);
        } else {
            throw new InvalidInputException("Invalid incidentTypeLookup value: " + type);
        }
        // Document Master
        if (requestDTO.getIncidentDocMasterData() != null) {
            IncidentDocMaster docMaster = incidentTransformer.toDocMasterEntity(requestDTO.getIncidentDocMasterData());
            docMaster.setIncident(incident);
            docMaster.setId(UUID.randomUUID());
            docMasterService.save(docMaster);
            // Attachments
            if (requestDTO.getIncidentDocMasterData().getAttachments() != null) {
                for (var attachmentDTO : requestDTO.getIncidentDocMasterData().getAttachments()) {
                    IncidentAttachment attachment = incidentTransformer.toAttachmentEntity(attachmentDTO);
                    attachment.setIncidentDocMaster(docMaster);
                    attachment.setAttachmentId(UUID.randomUUID());
                    docMasterService.saveAttachment(attachment);
                }
            }
        }
        // Status Log
        if (requestDTO.getIncidentStatusLogData() != null) {
            IncidentStatusLog statusLog = incidentTransformer.toStatusLogEntity(requestDTO.getIncidentStatusLogData());
            statusLog.setIncident(incident);
            statusLog.setId(UUID.randomUUID());
            statusLogService.save(statusLog);
        }
        return incidentTransformer.toIncidentResponseDTO(incident);
    }
    @Override
    @Transactional(readOnly = true)
    public IncidentResponseDTO getIncidentById(String incidentId, String acceptLanguage) {
        Incident incident = incidentService.getIncidentById(incidentId);
        return incidentTransformer.toIncidentResponseDTO(incident);
    }
}