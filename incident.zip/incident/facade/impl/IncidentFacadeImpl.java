package in.gov.gem.app.incident.facade.impl;

import in.gov.gem.app.incident.facade.IncidentFacade;

import in.gov.gem.app.incident.request.AttachmentDTO;
import in.gov.gem.app.incident.request.IncidentRequestDTO;
import in.gov.gem.app.incident.response.IncidentResponseDTO;
import in.gov.gem.app.incident.transformer.IncidentTransformer;

import in.gov.gem.app.service.dto.CoreLookupDto;
import in.gov.gem.app.service.pack.service.interfaces.CoreLookupService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import org.apache.tomcat.util.http.RequestUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;


@Component
@AllArgsConstructor
public class IncidentFacadeImpl implements IncidentFacade {

    private static final Logger logger = LoggerFactory.getLogger(IncidentFacadeImpl.class);

    private final IncidentTransformer incidentTransformer;
    private final RequestUtil requestUtil;
    private final DocumentServiceUtil documentServiceUtil;
    private final CoreLookupService coreLookupService;
    private final DocumentMasterService documentMasterService;
    private final DocAttachmentService docAttachmentService;
    private final S3AttachmentUtility s3AttachmentUtility;

    @Transactional
    public List<IncidentResponseDTO> submitIncident(UUID incidentPk, String acceptLanguage, IncidentRequestDTO incidentRequestDTO) throws IOException {
        logger.info("Entering submitIncident with responseId: {}", incidentPk);
        // List to store all document masters for each attachment
        List<IncidentResponseDTO> documentMasters = new ArrayList<>();
        // Process each incident document master data
        for (int i = 0; i < incidentRequestDTO.getIncidentDocMasterData().size(); i++) {
            // Get attachments for current document master
            @Valid @Size(min = 0) List<AttachmentDTO> attachments = incidentRequestDTO.getIncidentDocMasterData().get(i).getAttachments();
            if (attachments != null && !attachments.isEmpty()) {
                for (AttachmentDTO attachment : attachments) {
                    MultipartFile file = attachment.getFilePath(); // Assuming this is MultipartFile
                    if (file != null && !file.isEmpty()) {
                        // Validate file
                        if (requestUtil.isFileValid(file)) {
                            // Upload document and get the document ID
                            UUID documentId = this.documentUpload(file, new DocMaster());
                            
                            // Get the DocMaster object using the returned UUID
                            DocMaster documentMaster = documentMasterService.findById(documentId);
                            documentMasters.add(documentMaster);

                            // Associate the document ID with the attachment for reference
                            attachment.setAttachmentPk(documentId);
                            logger.debug("Uploaded document: {}, documentId: {}", file.getOriginalFilename(), documentId);
                        } else {
                            logger.warn("Invalid file: {}", file.getOriginalFilename());
                            throw new IllegalArgumentException("Invalid file: " + file.getOriginalFilename());
                        }
                    }
                }
            }
        }
        // Transform the request DTO with document masters to response DTO
        List<IncidentResponseDTO> response = incidentTransformer.toIncidentMasterEntity(incidentRequestDTO, incidentPk, 
                                       incidentRequestDTO.getIncidentId());
        logger.info("Exiting submitIncident with incidentPk: {}, processed {} attachments", incidentPk, documentMasters.size());
        return response;
    }




}

    //bulk submit

    @Transactional
    @Override
    public List<IncidentResponseDTO> readExcelData() throws IOException; {
        logger.debug("Request payload for submitBulk: {}", submitBulk);
        DocMaster documentMaster = null;
        if (requestUtil.isFileValid(file) ) {
            documentMaster = this.documentUpload(file);
            logger.debug("Uploaded document: {}", documentMaster);
        }
        List<IncidentResponseDTO> dataList = new ArrayList<>();
        try (InputStream is = file.getInputStream();
             Workbook workbook = new XSSFWorkbook(is)) {
            Sheet sheet = workbook.getSheetAt(0); // First sheet
            for (int i = 1; i <= sheet.getLastRowNum(); i++) { // Skipping header row
                Row row = sheet.getRow(i);
                if (row == null) continue;
                ExcelData data = new ExcelData();
                data.setName(row.getCell(0).getStringCellValue());
                data.setAge((int) row.getCell(1).getNumericCellValue());
                data.setEmail(row.getCell(2).getStringCellValue());
                dataList.add(data);
                }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return dataList;
        }


@Transactional
public UUID documentUpload(MultipartFile file, DocMaster documentMaster) throws IOException {
    String fileName = file.getOriginalFilename();
    String docName = file.getContentType();
    assert fileName != null;
    UUID attachmentId = requestUtil.createRequestId();
    documentServiceUtil.fileSizeCheck(file);

    List<CoreLookupDto> lookupDtos = coreLookupService.findAllByLookupValueIgnoreCase(docName);
    if (lookupDtos.isEmpty()) {
        throw new ServiceException(MessageConstants.INVALID_INPUT,
                messageUtility.getMessage(MessageConstants.INVALID_INPUT),
                ErrorConstant.CATEGORY.BV,
                ErrorConstant.SEVERITY.C);
    }

    String docType = lookupDtos.get(0).getLookupCode();
    String filePath = requestUtil.createPath(LookupConstants.QUESTION_CREATION,attachmentId, fileName);
    docAttachmentService.saveDocumentDetails(documentMaster, filePath, docType, fileName, file.getSize(), attachmentId);
    s3AttachmentUtility.uploadMultipart("gem-consent-service", filePath, file);
    return attachmentId;
}



