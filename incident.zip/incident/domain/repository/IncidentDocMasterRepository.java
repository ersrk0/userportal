package in.gov.gem.app.incident.domain.repository;


import in.gov.gem.app.incident.domain.entity.IncidentDocMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IncidentDocMasterRepository extends JpaRepository<IncidentDocMaster, String> {
}