package in.gov.gem.app.incident.domain.repository;
import in.gov.gem.app.incident.domain.entity.IncidentDocMasterEntity;
import in.gov.gem.app.service.core.repository.BaseRepository;
import org.springframework.stereotype.Repository;
import java.util.UUID;
@Repository
public interface IncidentDocMasterRepository extends BaseRepository<IncidentDocMasterEntity, UUID> {
}