package in.gov.gem.app.incident.domain.repository;

import in.gov.gem.app.incident.domain.entity.IncidentAttachmentEntity;
import in.gov.gem.app.service.core.repository.BaseRepository;
import org.springframework.stereotype.Repository;
import java.util.UUID;
@Repository
public interface IncidentAttachmentRepository extends BaseRepository<IncidentAttachmentEntity, UUID> {
}