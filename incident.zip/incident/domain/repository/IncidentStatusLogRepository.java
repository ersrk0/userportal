package in.gov.gem.app.incident.domain.repository;


import in.gov.gem.app.incident.domain.entity.IncidentStatusLog;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface IncidentStatusLogRepository extends JpaRepository<IncidentStatusLog, String> {
    List<IncidentStatusLog> findByIncidentIncidentIdOrderByCreatedTimestampAsc(String incidentId);
}