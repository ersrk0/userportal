package in.gov.gem.app.incident.domain.entity;

import in.gov.gem.app.service.core.entity.BaseEntity;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "incident_status_log")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class IncidentStatusLog extends BaseEntity {
    @Id
    @Column(name = "incident_status_log_id", nullable = false, updatable = false)
    private String id;
    @Column(name = "action_type_lookup")
    private String actionTypeLookup;
    @Column(name = "previous_status_lookup")
    private String previousStatusLookup;
    @Column(name = "current_status_lookup")
    private String currentStatusLookup;
    @Column(name = "action_by_type_lookup")
    private String actionByTypeLookup;
    @Column(name = "action_by_id")
    private String actionById;
    @Column(name = "remarks")
    private String remarks;
    @Column(name = "created_timestamp")
    private LocalDateTime createdTimestamp;
    @ManyToOne
    @JoinColumn(name = "incident_id", nullable = false)
    private Incident incident;
    @ManyToOne
    @JoinColumn(name = "incident_doc_master_fk")
    private IncidentDocMaster incidentDocMaster;
}