package in.gov.gem.app.incident.domain.entity;
import in.gov.gem.app.service.core.entity.BaseEntity;
import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.SuperBuilder;
import org.hibernate.annotations.GenericGenerator;
import java.util.List;
import java.util.UUID;
@Entity
@Table(name = "incident_doc_master")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class IncidentDocMasterEntity extends BaseEntity {
    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(name = "doc_master_pk", updatable = false, nullable = false)
    private UUID docMasterPk;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "incident_pk", nullable = false)
    private IncidentMasterEntity incidentPk;
    @Column(name = "doc_id")
    private String docId;
    @OneToMany(mappedBy = "incidentDocMasterFk", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<IncidentAttachmentEntity> attachments;
}