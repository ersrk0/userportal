package in.gov.gem.app.incident.domain.entity;

import in.gov.gem.app.service.core.entity.BaseEntity;
import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "incident_pre_contract_data")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PreContractIncidentData extends BaseEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "id", updatable = false, nullable = false)
    private String id;
    @Column(name = "trader_id")
    private String traderId;
    @Column(name = "category_code")
    private String categoryCode;
    @Column(name = "product_id")
    private String productId;
    @Column(name = "catalog_id")
    private String catalogId;
    @Column(name = "comp_id")
    private String compId;
    @Column(name = "sku_id")
    private String skuId;
    @Column(name = "brand_id")
    private String brandId;
    @Column(name = "service_id")
    private String serviceId;
    @OneToOne
    @JoinColumn(name = "incident_id")
    private Incident incident;
}