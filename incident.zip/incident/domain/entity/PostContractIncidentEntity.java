package in.gov.gem.app.incident.domain.entity;

import in.gov.gem.app.incident.domain.entity.DebarmentDetailEntity;
import in.gov.gem.app.service.core.entity.BaseEntity;
import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.SuperBuilder;
import org.hibernate.annotations.GenericGenerator;
import java.util.List;
import java.util.UUID;
@Entity
@Table(name = "post_contract_incident")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class PostContractIncidentEntity extends BaseEntity {
    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(name = "post_contract_pk", updatable = false, nullable = false)
    private UUID postContractPk;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "incident_pk", nullable = false)
    private IncidentMasterEntity incidentPk;
    @Column(name = "auction_id")
    private String auctionId;
    @Column(name = "bid_id")
    private String bidId;
    @Column(name = "order_id")
    private String orderId;
    @Column(name = "product_id")
    private String productId;
    @Column(name = "contract_no")
    private String contractNo;
    @Column(name = "invoice_id")
    private String invoiceId;
    @Column(name = "pan_no")
    private String panNo;
    @Column(name = "is_debarred")
    private Boolean isDebarred;
    @OneToMany(mappedBy = "postContractPk", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<DebarmentDetailEntity> debarmentDetail;
}