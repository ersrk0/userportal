package in.gov.gem.app.incident.domain.entity;

import in.gov.gem.app.service.core.entity.BaseEntity;
import jakarta.persistence.*;
import lombok.*;

import java.time.ZonedDateTime;

@Entity
@Table(name = "incident_debarment_detail")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DebarmentDetail extends BaseEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "id", updatable = false, nullable = false)
    private String id;
    @Column(name = "debarment_clause_lookup")
    private String debarmentClauseLookup;
    @Column(name = "debarment_start_date")
    private ZonedDateTime debarmentStartDate;
    @Column(name = "debarment_end_date")
    private ZonedDateTime debarmentEndDate;
    @Column(name = "competent_authority_name")
    private String competentAuthorityName;
    @Column(name = "competent_authority_designation")
    private String competentAuthorityDesignation;
    @OneToOne
    @JoinColumn(name = "post_contract_data_id")
    private PostContractIncidentData postContractData;
}