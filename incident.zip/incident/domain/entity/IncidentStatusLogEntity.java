package in.gov.gem.app.incident.domain.entity;
import in.gov.gem.app.service.core.entity.BaseEntity;
import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.SuperBuilder;
import org.hibernate.annotations.GenericGenerator;
import java.time.Instant;
import java.util.UUID;
@Entity
@Table(name = "incident_status_log")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class IncidentStatusLogEntity extends BaseEntity {
    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(name = "status_log_pk", updatable = false, nullable = false)
    private UUID statusLogPk;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "incident_pk", nullable = false)
    private IncidentMasterEntity incidentPk;
    @Column(name = "action_type_lookup")
    private String actionTypeLookup;
    @Column(name = "previous_status_lookup")
    private String previousStatusLookup;
    @Column(name = "current_status_lookup")
    private String currentStatusLookup;
    @Column(name = "action_by_type_lookup")
    private String actionByTypeLookup;
    @Column(name = "action_by_id")
    private String actionById;
    @Column(name = "remarks")
    private String remarks;
    @Column(name = "action_timestamp")
    private Instant actionTimestamp;
}