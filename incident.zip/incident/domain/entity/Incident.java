package in.gov.gem.app.incident.domain.entity;

import in.gov.gem.app.service.core.entity.BaseEntity;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "incident")
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Incident extends BaseEntity {
    @Id
    @Column(name = "incident_id", nullable = false, updatable = false)
    private String id;
    @Column(name = "incident_type_lookup")
    private String incidentTypeLookup;
    @Column(name = "module_code")
    private String moduleCode;
    @Column(name = "raised_by_type_lookup")
    private String raisedByTypeLookup;
    @Column(name = "raised_by_id")
    private String raisedById;
    @Column(name = "raised_by_role_lookup")
    private String raisedByRoleLookup;
    @Column(name = "raised_against_type_lookup")
    private String raisedAgainstTypeLookup;
    @Column(name = "raised_against_role_lookup")
    private String raisedAgainstRoleLookup;
    @Column(name = "incident_reason_lookup")
    private String incidentReasonLookup;
    @Column(name = "issue_type_lookup")
    private String issueTypeLookup;
    @Column(name = "incident_title")
    private String incidentTitle;
    @Column(name = "incident_description", columnDefinition = "TEXT")
    private String incidentDescription;
    @Column(name = "status_lookup")
    private String statusLookup;
    @Column(name = "severity_lookup")
    private String severityLookup;
    @Column(name = "created_by")
    private String createdBy;
    @Column(name = "created_timestamp")
    private LocalDateTime createdTimestamp;
    @OneToOne(mappedBy = "incident", cascade = CascadeType.ALL)
    private PreContractIncidentData preContractIncidentData;
    @OneToOne(mappedBy = "incident", cascade = CascadeType.ALL)
    private PostContractIncidentData postContractIncidentData;
    @OneToOne(mappedBy = "incident", cascade = CascadeType.ALL)
    private IncidentDocMaster incidentDocMaster;
    @OneToOne(mappedBy = "incident", cascade = CascadeType.ALL)
    private IncidentStatusLog incidentStatusLog;
}