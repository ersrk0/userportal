package in.gov.gem.app.incident.domain.entity;

import jakarta.persistence.*;
import lombok.*;

import java.util.List;

@Entity
@Table(name = "incident_doc_master")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class IncidentDocMaster {
    @Id
    @Column(name = "doc_id", nullable = false, updatable = false)
    private String docId;
    @OneToMany(mappedBy = "incidentDocMaster", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<IncidentAttachment> attachments;
    @OneToOne
    @JoinColumn(name = "incident_id", nullable = false)
    private Incident incident;
}