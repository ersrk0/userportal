package in.gov.gem.app.incident.domain.entity;

import in.gov.gem.app.service.core.entity.BaseEntity;
import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "incident_post_contract_data")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PostContractIncidentData extends BaseEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "id", updatable = false, nullable = false)
    private String id;
    @Column(name = "auction_id")
    private String auctionId;
    @Column(name = "bid_id")
    private String bidId;
    @Column(name = "order_id")
    private String orderId;
    @Column(name = "product_id")
    private String productId;
    @Column(name = "contract_no")
    private String contractNo;
    @Column(name = "invoice_id")
    private String invoiceId;
    @Column(name = "pan_no")
    private String panNo;
    @Column(name = "is_debarred")
    private Boolean isDebarred;
    @OneToOne(mappedBy = "postContractData", cascade = CascadeType.ALL)
    private DebarmentDetail debarmentDetail;
    @OneToOne
    @JoinColumn(name = "incident_id")
    private Incident incident;
}