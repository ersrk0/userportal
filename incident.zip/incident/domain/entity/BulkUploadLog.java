/*
package in.gov.gem.app.incident.domain.entity;

import in.gov.gem.app.service.core.entity.BaseEntity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

*/
/**
 * The type Bulk upload log.
 *//*

@Entity
@SuperBuilder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(name ="bulk_upload_log" , schema = "secondary_seller_mgmt")
public class BulkUploadLog extends BaseEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "uploaded_by" , length =255)
    private String uploadedBy;

    @Column(name = "status_lookup", length = 10)
    private String statusLookup;

    @Column(name = "upload_type_lookup", length = 10)
    private String uploadTypeLookup;

    @Column(name = "record_count")
    private Long recordCount;

    @Column(name = "success_count")
    private Long successCount;

    @Column(name = "failed_count")
    private Long failedCount;

    @Column(name="failed_reason")
    private String failedReason;

    @Column(name = "doc_url" , length = 255)
    private String docUrl;

    @Column(name = "error_doc_url" , length = 255)
    private String errorDocUrl;

    @Column(name = "hashcode", unique = true)
    private String hashCode;
}
*/
