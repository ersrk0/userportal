package in.gov.gem.app.incident.domain.entity;

import in.gov.gem.app.service.core.entity.BaseEntity;
import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "incident_attachment")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class IncidentAttachment extends BaseEntity  {
    @Id
    @Column(name = "attachment_id", nullable = false, updatable = false)
    private String attachmentId;
    @Column(name = "file_name")
    private String fileName;
    @Column(name = "file_type_lookup")
    private String fileTypeLookup;
    @Column(name = "file_path")
    private String filePath;
    @Column(name = "file_size")
    private Long fileSize;
    @Column(name = "uploaded_by_type_lookup")
    private String uploadedByTypeLookup;
    @Column(name = "uploaded_by_id")
    private String uploadedById;
    @Column(name = "status_lookup")
    private String statusLookup;
    @ManyToOne
    @JoinColumn(name = "incident_doc_master_id")
    private IncidentDocMaster incidentDocMaster;
}