package in.gov.gem.app.incident.transformer;

import in.gov.gem.app.incident.domain.entity.PostContractIncidentEntity;
import in.gov.gem.app.incident.domain.entity.PreContractIncidentEntity;
import in.gov.gem.app.incident.request.IncidentRequestDTO;
import in.gov.gem.app.incident.request.PostContractDataDTO;
import in.gov.gem.app.incident.request.PreContractDataDTO;
import in.gov.gem.app.incident.response.IncidentResponseDTO;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.UUID;
@Component
public class IncidentTransformer {
    public List<IncidentResponseDTO> toIncidentMasterEntity(IncidentRequestDTO dto, UUID incidentPk, String incidentId) {
        return IncidentMasterEntity.builder()
                .incidentPk(incidentPk)
                .incidentId(incidentId)
                .incidentTypeLookup(dto.getIncidentTypeLookup())
                .moduleCode(dto.getModuleCode())
                .raisedByTypeLookup(dto.getRaisedByTypeLookup())
                .raisedById(dto.getRaisedById())
                .raisedByRoleLookup(dto.getRaisedByRoleLookup())
                .raisedAgainstTypeLookup(dto.getRaisedAgainstTypeLookup())
                .raisedAgainstRoleLookup(dto.getRaisedAgainstRoleLookup())
                .incidentReasonLookup(dto.getIncidentReasonLookup())
                .issueTypeLookup(dto.getIssueTypeLookup())
                .incidentTitle(dto.getIncidentTitle())
                .incidentDescription(dto.getIncidentDescription())
                .statusLookup(dto.getStatusLookup())
                .severityLookup(dto.getSeverityLookup())
                .build();
    }
    public PreContractIncidentEntity toPreContractEntity(PreContractDataDTO dto, UUID incidentPk) {
        return PreContractIncidentEntity.builder()
                .preContractPk(UUID.randomUUID())
                .incidentPk(incidentPk)
                .traderId(dto.getTraderId())
                .categoryCode(dto.getCategoryCode())
                .productId(dto.getProductId())
                .catalogId(dto.getCatalogId())
                .compId(dto.getCompId())
                .skuId(dto.getSkuId())
                .brandId(dto.getBrandId())
                .serviceId(dto.getServiceId())
                .build();
    }
    public PostContractIncidentEntity toPostContractEntity(PostContractDataDTO dto, UUID incidentPk) {
        return PostContractIncidentEntity.builder()
                .postContractPk(UUID.randomUUID())
                .incidentPk(incidentPk)
                .auctionId(dto.getAuctionId())
                .bidId(dto.getBidId())
                .orderId(dto.getOrderId())
                .productId(dto.getProductId())
                .contractNo(dto.getContractNo())
                .invoiceId(dto.getInvoiceId())
                .panNo(dto.getPanNo())
                .isDebarred(dto.getIsDebarred())
                .build();
    }
    public DebarmentDetailEntity toDebarmentEntity(DebarmentDetailDTO dto, UUID postContractPk) {
        return DebarmentDetailEntity.builder()
                .debarmentPk(UUID.randomUUID())
                .postContractPk(postContractPk)
                .debarmentClauseLookup(dto.getDebarmentClauseLookup())
                .debarmentStartDate(dto.getDebarmentStartDate())
                .debarmentEndDate(dto.getDebarmentEndDate())
                .competentAuthorityName(dto.getCompetentAuthorityName())
                .competentAuthorityDesignation(dto.getCompetentAuthorityDesignation())
                .build();
    }
    public IncidentDocMasterEntity toDocMasterEntity(IncidentDocMasterDTO dto, UUID incidentPk) {
        return IncidentDocMasterEntity.builder()
                .incidentDocMasterPk(UUID.randomUUID())
                .incidentPk(incidentPk)
                .docId(dto.getDocId())
                .fileName(dto.getFileName())
                .filePath(dto.getFilePath())
                .fileSize(dto.getFileSize())
                .fileTypeLookup(dto.getFileTypeLookup())
                .uploadedByTypeLookup(dto.getUploadedByTypeLookup())
                .uploadedById(dto.getUploadedById())
                .statusLookup(dto.getStatusLookup())
                .build();
    }
    public IncidentStatusLogEntity toStatusLogEntity(IncidentStatusLogDTO dto, UUID incidentPk) {
        return IncidentStatusLogEntity.builder()
                .incidentStatusLogPk(UUID.randomUUID())
                .incidentPk(incidentPk)
                .actionTypeLookup(dto.getActionTypeLookup())
                .previousStatusLookup(dto.getPreviousStatusLookup())
                .currentStatusLookup(dto.getCurrentStatusLookup())
                .actionByTypeLookup(dto.getActionByTypeLookup())
                .actionById(dto.getActionById())
                .remarks(dto.getRemarks())
                .build();
    }
    public IncidentResponseDTO toResponseDTO(String incidentId, String title, String description) {
        return IncidentResponseDTO.builder()
                .id(incidentId)
                .name(title)
                .description("Incident for " + title + " has been created successfully.")
                .build();
    }
}