package in.gov.gem.app.incident.transformer;

import in.gov.gem.app.incident.domain.entity.*;
import in.gov.gem.app.incident.request.*;
import in.gov.gem.app.incident.response.IncidentResponseDTO;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Component
public class IncidentTransformer {
    // Transform IncidentRequestDTO -> IncidentMasterEntity
    public static IncidentMasterEntity toIncidentMasterEntity(String incidentPk, String incidentId, IncidentRequestDTO dto) {
        if (dto == null || incidentPk == null || incidentId == null) {
            throw new IllegalArgumentException("Invalid input: dto, incidentPk, or incidentId is null");
        }
        return IncidentMasterEntity.builder()
                .incidentPk(incidentPk)
                .incidentId(incidentId)
                .incidentTypeLookup(dto.getIncidentTypeLookup())
                .moduleCode(dto.getModuleCode())
                .raisedByTypeLookup(dto.getRaisedByTypeLookup())
                .raisedById(dto.getRaisedById())
                .raisedByRoleLookup(dto.getRaisedByRoleLookup())
                .raisedAgainstTypeLookup(dto.getRaisedAgainstTypeLookup())
                .raisedAgainstRoleLookup(dto.getRaisedAgainstRoleLookup())
                .incidentReasonLookup(dto.getIncidentReasonLookup())
                .issueTypeLookup(dto.getIssueTypeLookup())
                .incidentTitle(dto.getIncidentTitle())
                .incidentDescription(dto.getIncidentDescription())
                .statusLookup(dto.getStatusLookup())
                .severityLookup(dto.getSeverityLookup())
                .build();
    }
    // Transform IncidentDocMasterDTO -> IncidentDocMasterEntity
    public static IncidentDocMasterEntity toDocMasterEntity(IncidentDocMasterDTO dto, UUID incidentPk) {
        if (dto == null || incidentPk == null) {
            throw new IllegalArgumentException("Invalid input: dto or incidentPk is null");
        }
        return IncidentDocMasterEntity.builder()
                .docMasterPk(UUID.randomUUID())
                //.incidentPk(incidentPk)
                .docId(dto.getDocId())
                .build();
    }
    // Transform AttachmentDTO -> IncidentAttachmentEntity list
    public static List<IncidentAttachmentEntity> toAttachmentEntities(List<AttachmentDTO> dtos, UUID incidentPk) {
        if (dtos == null || incidentPk == null) {
            throw new IllegalArgumentException("Invalid input: attachment list or incidentPk is null");
        }
        return dtos.stream()
                .map(dto -> IncidentAttachmentEntity.builder()
                        .attachmentPk(UUID.randomUUID())
                        //.incidentDocMasterFk(dtos.get())
                        .fileName(dto.getFileName())
                        .filePath(dto.getFilePath() != null ? dto.getFilePath().getOriginalFilename() : null)
                        .fileSize(dto.getFileSize())
                        .fileTypeLookup(dto.getFileTypeLookup())
                        .uploadedByTypeLookup(dto.getUploadedByTypeLookup())
                        .uploadedById(dto.getUploadedById())
                        .statusLookup(dto.getStatusLookup())
                        .build())
                .collect(Collectors.toList());
    }
    // Transform PostContractDataDTO -> PostContractIncidentEntity list
    public static List<PostContractIncidentEntity> toPostContractEntities(List<PostContractDataDTO> dtos, String incidentPk) {
        if (dtos == null || incidentPk == null) {
            throw new IllegalArgumentException("Invalid input: postContract list or incidentPk is null");
        }
        return dtos.stream()
                .map(dto -> PostContractIncidentEntity.builder()
                        .postContractPk(UUID.randomUUID())
                        //.incidentPk(incidentPk)
                        .auctionId(dto.getAuctionId())
                        .bidId(dto.getBidId())
                        .orderId(dto.getOrderId())
                        .productId(dto.getProductId())
                        .contractNo(dto.getContractNo())
                        .invoiceId(dto.getInvoiceId())
                        .panNo(dto.getPanNo())
                        .isDebarred(dto.getIsDebarred())
                        .build())
                .collect(Collectors.toList());
    }
    // Transform DebarmentDetailDTO -> DebarmentDetailEntity list
    public static List<DebarmentDetailEntity> toDebarmentEntities(List<DebarmentDetailDTO> dtos, String postContractPk) {
        if (dtos == null || postContractPk == null) {
            throw new IllegalArgumentException("Invalid input: debarment list or postContractPk is null");
        }
        return dtos.stream()
                .map(dto -> DebarmentDetailEntity.builder()
                        .debarmentPk(UUID.randomUUID())
                       // .postContractPk(postContractPk)
                        .debarmentClauseLookup(dto.getDebarmentClauseLookup())
                        .debarmentStartDate(dto.getDebarmentStartDate())
                        .debarmentEndDate(dto.getDebarmentEndDate())
                        .competentAuthorityName(dto.getCompetentAuthorityName())
                        .competentAuthorityDesignation(dto.getCompetentAuthorityDesignation())
                        .build())
                .collect(Collectors.toList());
    }
    // Transform PreContractDataDTO -> PreContractIncidentEntity list
    public static List<PreContractIncidentEntity> toPreContractEntities(List<PreContractDataDTO> dtos, String incidentPk) {
        if (dtos == null || incidentPk == null) {
            throw new IllegalArgumentException("Invalid input: preContract list or incidentPk is null");
        }
        return dtos.stream()
                .map(dto -> PreContractIncidentEntity.builder()
                        .preContractPk(UUID.randomUUID())
                        //incidentPk(incidentPk)
                        .traderId(dto.getTraderId())
                        .categoryCode(dto.getCategoryCode())
                        .productId(dto.getProductId())
                        .catalogId(dto.getCatalogId())
                        .compId(dto.getCompId())
                        .skuId(dto.getSkuId())
                        .brandId(dto.getBrandId())
                        .serviceId(dto.getServiceId())
                        .build())
                .collect(Collectors.toList());
    }
    // Transform IncidentStatusLogDTO -> IncidentStatusLogEntity list
    public static List<IncidentStatusLogEntity> toStatusLogEntities(List<IncidentStatusLogDTO> dtos, UUID incidentPk) {
        if (dtos == null || incidentPk == null) {
            throw new IllegalArgumentException("Invalid input: status log list or incidentPk is null");
        }
        return dtos.stream()
                .map(dto -> IncidentStatusLogEntity.builder()
                        .statusLogPk(UUID.randomUUID())
                       // .incidentPk(incidentPk)
                        .actionTypeLookup(dto.getActionTypeLookup())
                        .previousStatusLookup(dto.getPreviousStatusLookup())
                        .currentStatusLookup(dto.getCurrentStatusLookup())
                        .actionByTypeLookup(dto.getActionByTypeLookup())
                        .actionById(dto.getActionById())
                        .remarks(dto.getRemarks())
                        .build())
                .collect(Collectors.toList());
    }
    // Transform minimal response
    public static IncidentResponseDTO toResponseDTO(String incidentId, String title, String description) {
        if (incidentId == null || title == null || description == null) {
            throw new IllegalArgumentException("Invalid input: incidentId, title, or description is null");
        }
        return IncidentResponseDTO.builder()
                .incidentId(incidentId)
                .incidentTitle(title)
                .incidentDescription(description)
                .build();
    }
}