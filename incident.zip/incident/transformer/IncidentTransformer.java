package in.gov.gem.app.incident.transformer;

import in.gov.gem.app.incident.domain.entity.*;
import in.gov.gem.app.incident.request.*;
import in.gov.gem.app.incident.response.IncidentResponseDTO;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Component
public class IncidentTransformer {
    public Incident toEntity(IncidentRequestDTO dto, String incidentId) {
        return Incident.builder()
                .incidentId(incidentId)
                .incidentTypeLookup(dto.getIncidentTypeLookup())
                .moduleCode(dto.getModuleCode())
                .raisedByTypeLookup(dto.getRaisedByTypeLookup())
                .raisedById(dto.getRaisedById())
                .raisedByRoleLookup(dto.getRaisedByRoleLookup())
                .raisedAgainstTypeLookup(dto.getRaisedAgainstTypeLookup())
                .raisedAgainstRoleLookup(dto.getRaisedAgainstRoleLookup())
                .incidentReasonLookup(dto.getIncidentReasonLookup())
                .issueTypeLookup(dto.getIssueTypeLookup())
                .incidentTitle(dto.getIncidentTitle())
                .incidentDescription(dto.getIncidentDescription())
                .statusLookup(dto.getStatusLookup())
                .severityLookup(dto.getSeverityLookup())
                .preContractData(dto.getPreContractData() != null
                        ? toPreContractEntity(dto.getPreContractData()) : null)
                .postContractData(dto.getPostContractData() != null
                        ? toPostContractEntity(dto.getPostContractData()) : null)
                .incidentDocMasterData(toDocMasterEntity(dto.getIncidentDocMasterData()))
                .incidentStatusLogData(toStatusLogEntity(dto.getIncidentStatusLogData()))
                .build();
    }
    public PreContractIncidentData toPreContractEntity(PreContractDataDTO dto) {
        return PreContractIncidentData.builder()
                .traderId(dto.getTraderId())
                .categoryCode(dto.getCategoryCode())
                .productId(dto.getProductId())
                .catalogId(dto.getCatalogId())
                .compId(dto.getCompId())
                .skuId(dto.getSkuId())
                .brandId(dto.getBrandId())
                .serviceId(dto.getServiceId())
                .build();
    }
    public PostContractIncidentData toPostContractEntity(PostContractDataDTO dto) {
        return PostContractIncidentData.builder()
                .auctionId(dto.getAuctionId())
                .bidId(dto.getBidId())
                .orderId(dto.getOrderId())
                .productId(dto.getProductId())
                .contractNo(dto.getContractNo())
                .invoiceId(dto.getInvoiceId())
                .panNo(dto.getPanNo())
                .isDebarred(dto.getIsDebarred())
                .debarmentDetail(toDebarmentDetail(dto.getDebarmentDetail()))
                .build();
    }
    public DebarmentDetail toDebarmentDetail(DebarmentDetailDTO dto) {
        if (dto == null) return null;
        return DebarmentDetail.builder()
                .debarmentClauseLookup(dto.getDebarmentClauseLookup())
                .debarmentStartDate(dto.getDebarmentStartDate())
                .debarmentEndDate(dto.getDebarmentEndDate())
                .competentAuthorityName(dto.getCompetentAuthorityName())
                .competentAuthorityDesignation(dto.getCompetentAuthorityDesignation())
                .build();
    }
    public IncidentDocMaster toDocMasterEntity(IncidentDocMasterDTO dto) {
        if (dto == null) return null;
        return IncidentDocMaster.builder()
                .docId(dto.getDocId())
                .attachments(toAttachmentEntityList(dto.getAttachments()))
                .build();
    }
    public List<IncidentAttachment> toAttachmentEntityList(List<IncidentAttachmentDTO> dtos) {
        if (dtos == null) return null;
        return dtos.stream()
                .map(this::toAttachmentEntity)
                .collect(Collectors.toList());
    }
    public IncidentAttachment toAttachmentEntity(IncidentAttachmentDTO dto) {
        return IncidentAttachment.builder()
                .attachmentId(UUID.randomUUID())
                .fileName(dto.getFileName())
                .fileTypeLookup(dto.getFileTypeLookup())
                .filePath(dto.getFilePath())
                .fileSize(dto.getFileSize())
                .uploadedByTypeLookup(dto.getUploadedByTypeLookup())
                .uploadedById(dto.getUploadedById())
                .statusLookup(dto.getStatusLookup())
                .build();
    }
    public IncidentStatusLog toStatusLogEntity(IncidentStatusLogDTO dto) {
        if (dto == null) return null;
        return IncidentStatusLog.builder()
                .statusLogId(UUID.randomUUID())
                .actionTypeLookup(dto.getActionTypeLookup())
                .previousStatusLookup(dto.getPreviousStatusLookup())
                .currentStatusLookup(dto.getCurrentStatusLookup())
                .actionByTypeLookup(dto.getActionByTypeLookup())
                .actionById(dto.getActionById())
                .incidentDocMasterFk(dto.getIncidentDocMasterFk())
                .remarks(dto.getRemarks())
                .build();
    }
    public IncidentResponseDTO toResponseDTO(Incident incident) {
        return IncidentResponseDTO.builder()
                .id(incident.getIncidentId())
                .name(incident.getIncidentTitle())
                .description("Incident for " + incident.getIncidentTitle() + " has been created successfully.")
                .build();
    }