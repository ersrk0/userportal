package in.gov.gem.app.incident.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.List;
import java.util.UUID;

@Data
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class PostContractDataResponseDTO {
    private UUID postContractPk;    // PK
    private UUID incidentPk;        // FK
    private String auctionId;
    private String bidId;
    private String orderId;
    private String productId;
    private String contractNo;
    private String invoiceId;
    private String panNo;
    private Boolean isDebarred;
    private List<DebarmentDetailResponseDTO> debarmentDetail;
}