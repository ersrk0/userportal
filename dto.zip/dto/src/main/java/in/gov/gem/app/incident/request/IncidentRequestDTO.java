package in.gov.gem.app.incident.request;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.List;
import java.util.UUID;

@Data
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
public class IncidentRequestDTO {
        private UUID incidentPk;  // Primary Key (auto-generated)
        private String incidentId;  // Auto-generated ID used as FK elsewhere
        @NotBlank
        private String incidentTypeLookup;
        @NotBlank
        private String moduleCode;
        @NotBlank
        private String raisedByTypeLookup;
        @NotBlank
        private String raisedById;
        @NotBlank
        private String raisedByRoleLookup;
        @NotBlank
        private String raisedAgainstTypeLookup;
        @NotBlank
        private String raisedAgainstRoleLookup;
        @NotBlank
        private String incidentReasonLookup;
        @NotBlank
        private String issueTypeLookup;
        @NotBlank
        private String incidentTitle;
        @NotBlank
        private String incidentDescription;
        private String statusLookup;
        private String severityLookup;
        @Valid
        @Size(min = 0)
        private List<PreContractDataDTO> preContractData;
        @Valid
        @Size(min = 0)
        private List<PostContractDataDTO> postContractData;
        @Valid
        @Size(min = 0)
        private List<IncidentDocMasterDTO> incidentDocMasterData;
        @Valid
        @Size(min = 0)
        private List<IncidentStatusLogDTO> incidentStatusLogData;
}