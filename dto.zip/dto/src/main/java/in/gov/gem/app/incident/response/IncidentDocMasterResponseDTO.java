package in.gov.gem.app.incident.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.List;
import java.util.UUID;

@Data
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class IncidentDocMasterResponseDTO {
    private UUID incidentDocMasterPk;   // PK
    private UUID incidentPk;            // FK
    private String docId;
    private List<AttachmentResponseDTO> attachments;
}