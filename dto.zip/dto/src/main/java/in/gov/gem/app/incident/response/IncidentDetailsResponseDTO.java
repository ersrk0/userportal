package in.gov.gem.app.incident.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class IncidentDetailsResponseDTO {
    private String incidentId;
    private String incidentTypeLookup;
    private String moduleCode;
    private String raisedByTypeLookup;
    private String raisedById;
    private String raisedByRoleLookup;
    private String raisedAgainstTypeLookup;
    private String raisedAgainstRoleLookup;
    private String incidentReasonLookup;
    private String issueTypeLookup;
    private String incidentTitle;
    private String incidentDescription;
    private String statusLookup;
    private String severityLookup;
    private List<PreContractDataResponseDTO> preContractData;
    private List<PostContractDataResponseDTO> postContractData;
    private List<IncidentDocMasterResponseDTO> incidentDocMasterData;
    private List<IncidentStatusLogResponseDTO> incidentStatusLogData;
}